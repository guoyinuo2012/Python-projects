# Username checker

Version 1.14 · Python 3.10 or newer

A Python desktop app and command-line tool that checks whether a public account
already uses a username. Automatic lookups use public APIs and need no pip
packages or account login. Optional GitHub and GitLab tokens use your authenticated
API allowance. Platforms marked Manual provide
a page for you to verify a name in the platform's signup or username settings.

## Start on Windows, Linux, or macOS

The same Python application and character finder support all three systems.
The desktop needs Python **3.10 or newer**, **Tkinter/Tcl/Tk**, and a graphical
desktop. Command-line generation works without a display or Tkinter; checking
online services also needs an internet connection.

Extract the ZIP before starting. Keep all four application modules
(`username_checker.py`, `api_access.py`, `project_files.py`, and `ui_theme.py`) and the launchers together.

| System | Launcher | Command from the extracted folder |
| --- | --- | --- |
| Windows | Double-click `Start_on_Windows.cmd` | `py -3 username_checker.py --gui` |
| Linux | `Start_on_Linux.sh` | `sh Start_on_Linux.sh` |
| macOS | Double-click `Start_on_macOS.command` | `sh Start_on_macOS.command` |

The launchers locate the application relative to themselves, including folders
with spaces. Unix launchers try `python3`, then `python`, and require version
3.10 or newer. The Windows launcher tries `py -3`, then `python`.

### Windows setup

1. Extract the ZIP into a folder.
2. Install Python 3.10 or newer if necessary: https://www.python.org/downloads/
   Keep the installer’s Tcl/Tk option enabled.
3. Double-click **Start_on_Windows.cmd**.

The launcher keeps error messages visible if startup fails. You can also run:

```console
python username_checker.py
```

### Linux setup

Use your distribution's Python 3 and Tkinter packages. For Debian/Ubuntu:

```console
sudo apt install python3 python3-tk
sh Start_on_Linux.sh
```

You can also run the application directly:

```console
python3 username_checker.py
```

Other Linux distributions may use a different Tkinter package name. Run
`python3 -m tkinter` to check that the GUI toolkit can open a window.

### macOS setup

Install a current supported Python 3 from https://www.python.org/downloads/macos/,
including its bundled Tk support. After installation, run **Install Certificates.command**
in the installed Python folder under Applications so HTTPS lookups can verify
the services' certificates. Then open `Start_on_macOS.command` or run it with
`sh` from Terminal. If extraction removed its executable permission, you can use
`chmod +x Start_on_macOS.command`, or simply use the `sh` command above.

You can check Tkinter with `python3 -m tkinter` and run the app directly with
`python3 username_checker.py`. Official setup references:
https://docs.python.org/3/using/mac.html and
https://docs.python.org/3/library/tkinter.html.

The finder uses standard Python code, and the GUI uses Tkinter rather than
an operating-system-specific toolkit. Linux desktop execution and both Unix
launcher scripts are tested here. Native Windows/macOS execution and appearance
have not been tested on those operating systems in this environment.

## Desktop app

The desktop keeps username input and check settings together in a left sidebar,
with a taller results workspace on the right. Import and Character finder sit
below the input box; Check, Pause, and Stop are grouped underneath. Search and
status filters stay above the results, with Continue, Retry, copy, and export
actions below the table.
Choose **Light** or **Dark** from **Theme** in the upper right; the choice applies
to the main window, character finder, platform picker, comparisons, and batch
windows, including dialogs that are already open. The theme is remembered with
your settings. Older settings files start in Light mode and retain their other
preferences. The interface uses standard Tkinter and needs no additional pip packages.

The primary Check and Export actions use a teal accent. Results use subdued row
backgrounds with their written status, and an empty result view explains how to
start or adjust a filter. The layout keeps its controls available down to the
840 × 720 main-window minimum. Short windows automatically use tighter spacing
to leave more room for result rows. Tables support resizing and horizontal scrolling.

- **Batch limit** now defaults to **0 = Unlimited**. The old 10,000-name ceiling
  is removed. You can enter any positive whole-number limit instead; there is
  no fixed application maximum. It applies to typed names, imports, generation,
  and retries. In **Find until Stop**, it caps each processing chunk instead of
  the total search. The input heading shows whether your limit is unlimited.
- Enter usernames separated by commas, spaces, or new lines, up to your batch limit.
- A leading `@` is accepted; duplicate names are removed without regard to case.
- **Import names...** loads a UTF-8 TXT, CSV, or JSON file, replacing the input
  box after validating the complete file. The file limit is 16 MiB; the username
  count must fit your chosen batch limit.
- **Choose platforms...** opens a searchable list with category and check-type
  filters. Use **All automatic**, **All platforms**, or **None** as a starting
  point, then select individual platforms. Automatic platforms are selected by
  default; manual platforms are optional. Filtering this list preserves selections.
- Choose your platforms and click **Check usernames** or press **Ctrl+Enter**.
- Results arrive as each site replies; the window remains responsive.
- Roblox automatically groups up to **100 valid names per HTTP request**.
  A 250-name Roblox batch needs three requests instead of 250, when none are cached.
- **Reuse results (5 min)** avoids repeating confirmed Taken/Not found
  lookups during this app session. Reused rows say so in their details and retain
  the original check timestamp. Unknown results are always checked again.
  Uncheck this option for fresh lookups, or choose **Clear cache** to forget recent
  lookups while keeping the displayed rows. Fresh confirmed replies update the cache.
- The bottom counter shows elapsed seconds, HTTP requests attempted, and results
  reused. Invalid names and manual-check links do not send HTTP requests.
- Search results by name, site, or explanation. Use **Show** to filter by status;
  click a column heading to sort, and click it again to reverse the order.
- Select a row to see the full explanation and profile URL.
- Double-click a row or choose **Open page** to view its profile or manual-check
  page in your browser. No pages open automatically.
- **Copy shown** copies a text table. **Export shown...** saves the currently
  visible rows as CSV or JSON, including UTC timestamps. To export every result,
  clear the search and set **Show** to **All**. CSV exports are protected against
  spreadsheet formula injection.
- **Copy names** copies just the unique usernames from the shown rows, one per
  line. For a shortlist, set **Show** to **Not found**, then choose **Copy names**.
  This filter applies per site; it does not mean the name was missing on every site.
- **Retry unknown** checks only the failed username/site pairs and replaces their
  previous rows. Successful results remain available. Retries use the current
  timeout and the original result sites, even if you change platform selections.
  Complete an unfinished batch before using Retry unknown. Platform cooldowns
  still apply to manual retries.
- **Pause** stops scheduling new requests; requests already in flight may still
  return results. The same button becomes **Resume**. You can Stop while paused.
- **Stop**, or **Esc**, stops scheduling new requests and keeps completed results.
  In-flight requests finish in the background. New checks, retries, imports, and
  clearing become available when those requests actually finish; the app shows
  when it is waiting. You can still filter, copy, or export completed results.
- After stopped requests finish, **Continue remaining** checks only unfinished
  username/site pairs and keeps completed rows. It uses the last batch's original
  names, platforms, and timeout, even if you edit the input or platform selection.
  Your current batch limit must still fit the remaining names. Starting a new
  check replaces that unfinished batch. Use **File > Save session** before closing
  if you want to preserve the queue.
- **Clear** resets the input and results for a new batch.

The batch limit counts unique usernames, across however many platforms you
select. For example, 100 usernames checked on five platforms can produce 500
result rows. You can edit the limit between checks; its control is disabled
while requests are running or draining after Stop. Valid desktop settings are
remembered when you close the app. Use `--gui --batch-limit 1000` to override the
remembered limit; `--gui --batch-limit 0` selects unlimited mode. If a retry contains more failed names than the current
limit, the app asks you to raise it before starting that retry.

## Saved settings and sessions

Desktop preferences remember the batch limit, timeout, selected platforms, cache
toggle, finder options, window size, and appearance. **File > Save settings** saves immediately;
closing the app also saves valid settings. Preferences contain no username lists
or results. They live in the normal user configuration folder on Windows, Linux,
or macOS. CLI checks use their command-line options and do not change desktop preferences.

**File > Save session...** (`Ctrl+S`) stores the last checked batch, its completed
results and timestamps, and unfinished checks in one `.ucsession` file. Stop the
batch and wait for current requests first. In a large batch window, use its
**Save session...** button or **File > Save session...** menu. Large checking jobs and generate-only finder jobs
both support saved sessions. Saving and opening sessions run in the background.

**File > Open session...** (`Ctrl+O`) validates the file and opens a stopped batch
window. Opening makes no HTTP requests. **Continue** checks only unfinished pairs
and then continues any unconsumed names; completed rows retain their original
timestamps and are included in **Export all**. Generated sessions preserve the
character set, length, pattern, seed, range, and position across restarts.
An opened session uses a private snapshot, so replacing its original file does
not change a running job. You may save back to the same session file.

Sessions use the standard-library SQLite format and stream records rather than
loading the whole history into RAM. They have no fixed total-name cap. Saving
requires disk space for a complete replacement; opening uses temporary disk space
for the snapshot and working result journal. Failed saves keep the previous file.
Closing a batch without saving still discards its unsaved work. Saved results are
historical observations; restoring them does not refresh their availability.

## Compare the same name across platforms

Choose **Tools > Compare usernames...** for a snapshot of the main table's full
results, arranged as one row per username and one column per platform. Selected
platforms with no result remain **Unchecked**. Unknown and Manual check statuses
stay unresolved. Horizontal scrolling supports large platform selections.

Use the name search or **Every platform returned Not found** to make a strict
shortlist. This requires a Not found result for every platform in the batch;
missing, manual, invalid, and unknown checks never qualify. Registration still
needs confirmation on the service. **Copy shown names** copies the filtered list;
**Export comparison...** saves the filtered matrix as spreadsheet-safe CSV.

The large batch window has **File > Compare preview usernames...**. This compares
only the latest 500 preview rows, keeping its memory use bounded. Export all
remains the way to save the complete result history.

## Large and unlimited batches

**Batch limit 0** removes the name-count cap; **Batch size 0** in the finder
means **all remaining names** that match its pattern. These are separate settings.
The finder still defaults to generating 20 names per click. A positive Batch
size selects that many names, with no fixed maximum when the limit is unlimited.
A positive Batch limit is enforced for generated batches, including all-remaining
requests. Continuous finding uses it as a per-chunk cap and keeps searching.

Jobs producing more than 10,000 result rows automatically open a **Large username
batch** window. This threshold selects the processing mode; it is not a batch cap.

- Names are generated on demand and checked in chunks of 500 usernames.
- The live table retains only the most recent 500 rows. **Copy preview** copies
  those rows; **Open page** and double-click work for a selected checking result.
- **Export all...** saves every completed checking result as CSV/JSON, or every
  generated name as TXT/JSON. It streams the export in the background. During a
  running job, the export captures the completed prefix at the moment you click it.
- Full results are kept in a temporary disk journal until this window closes.
  Export results or save a session before closing. Large generation jobs leave the
  main input box unchanged rather than filling it with millions of names.
- **Pause**, **Resume**, **Stop**, and **Continue** work across chunks. Continue
  retries unfinished pairs and continues the source without duplicating saved rows.
  Existing requests must finish before Continue or Close becomes possible.
- Closing an unfinished finder job revisits its partial chunk on the next
  generation request, so names in that chunk are not silently skipped. Some names
  from the partial chunk may be revisited; export the completed results first.
- A service rate limit automatically pauses that platform and retries its
  unfinished request after the cooldown. Other platforms can keep checking.
  After three unsuccessful automatic retries, a normal batch stops with unfinished
  pairs preserved. Continue retries those pairs after any remaining cooldown.
  A continuous finder waits for another cooldown and resumes automatically.

Unlimited means there is no fixed batch-count ceiling. Your free disk space,
memory for pasted/imported input, processing time, and the services' own limits
still determine what can finish. The app adds no fixed delay between requests. The separate
16 MiB import-file limit remains; generated searches do not use that import limit.
The temporary journal is deleted when the window closes. A saved `.ucsession`
file preserves its completed results and remaining work for reopening later.

## Adjustable-length character finder

You can type a particular name such as `abc` or `a7x` directly into the main
input box. To discover names of a chosen length:

1. Select sites with **Choose platforms...** in the main window.
2. Open **Character finder**.
3. Set **Character count** to a whole number from **1 to 253**; the default is 3.
   For example, choose 5 to generate names such as `a7xb9`.
4. Choose **Letters**, **Digits**, **Letters + digits**, or **Custom** characters.
5. Leave **Pattern** blank for any name of that length, or enter one character
   per position. `?` means any selected character. Examples: `a????` for five
   characters starting with a, `??7??` for five with 7 in the middle, or `abc`
   with Character count 3 to generate exactly that one name.
6. Choose **Any selected platform** or **All selected platforms** beside **Find on**.
7. Click **Find until Stop**. It generates new candidates and checks them continuously.
   The live window shows only matching **Not found** results, completed platform
   checks, fully checked names, and names found. Use **Pause**, **Stop**, or **Esc** whenever you want; **Continue**
   resumes unfinished checks and keeps the existing finds.

Continuous finding checks the selected **automatic** platforms. Manual platforms
are omitted because they cannot verify a result automatically. **Any** keeps a name
when at least one selected platform reports Not found; its matching platform is
shown in the table. **All** requires Not found on every selected platform; Taken,
Unknown, Invalid, and incomplete checks do not qualify. Neither rule guarantees
that signup will allow registration.

**Find until Stop** ignores Batch size and keeps scanning the remaining matching
space. A positive Batch limit caps each processing chunk, up to 500 candidates,
rather than ending the search. Candidates do not repeat during a search. It ends
naturally if every combination has been checked. Length 3, 4, 5, and other valid
lengths use the same controls; changing the length starts a new sequence.

The live shortlist retains the most recent 500 matching rows. **Export found...**
saves every find, including rows beyond the preview: TXT contains unique names;
CSV/JSON include the matching platform and lookup details. **Copy preview** copies
unique names from the visible shortlist. Exports can run while searching. Stop
and **Save session...** preserves the complete search and shortlist for reopening
later; export or save before closing the window. Memory stays bounded as matches
and full checking history are streamed to temporary disk journals.

For a fixed batch, choose a batch size within your Batch limit and click
**Generate and check** instead of **Find until Stop**.
7. Set the main window's **Show** filter to **Not found** to review names for
   which no public profile was found.

**Generate next batch** fills the input box and preview without sending network
requests. You can then check those names with the main **Check usernames** button.
**Generate and check** generates a fresh batch and immediately checks it.

**Shuffled** explores a randomized, nonrepeating sequence. **Ordered** follows
the selected character sequence (letters a–z, then digits 0–9 for the combined
set). Names do not repeat as you advance the same sequence. **Reset sequence**
starts over; changing the length, characters, pattern, or order also starts a new sequence.
Changing only the batch size or batch limit continues from the current position.
Lowering the batch limit automatically reduces an oversized generator batch size
to fit. The generator's Batch size control follows the current limit.

Changing Character count resizes a default all-`?` pattern automatically. A custom
pattern is preserved, so update it to the new length or clear it before generating.
Invalid settings leave your current names and sequence position intact.

At length 3, the complete spaces contain 17,576 letter-only names, 1,000 digit-only
names, and 46,656 names made from letters and digits. Longer spaces grow rapidly:
five letters/digits have 60,466,176 combinations. The finder generates only the
requested batch; large shuffled searches use bounded memory rather than allocating
the full search space. Very large counters use scientific notation. You can page through the entire
matching space, up to your chosen batch limit at a time. The default generated
batch is 20 names, or your positive batch limit if it is lower. **Batch limit** sets
a maximum, with 0 meaning unlimited; **Batch size** chooses how many names to
generate on the next click, with 0 meaning all remaining matches.
The counter reports names **generated**,
including batches you have not checked yet. New small checks replace the main
table's previous results. Large jobs keep their results in their own window.

Custom characters may include ASCII letters, digits, `_`, `-`, and `.`.
Uppercase letters are normalized to lowercase and repeated characters are
removed. The 253-character maximum matches this app's input limit; each service
has its own, often much shorter, username limit. A generated name can receive
an **Invalid** result for a selected site. On Bluesky, a short name such as `abc`
is checked as `abc.bsky.social`, as in normal input mode.

The finder uses the same request scheduling, cancellation, rate-limit handling,
and result meanings as normal checks. **Not found** still does not guarantee
that a name can be registered.

The app sends names only to the selected services. Recent results are kept in
memory for five minutes, with a 50,000-entry capacity; the cache and unfinished
queue disappear when you close the app. Large jobs automatically write a temporary
result journal, removed when their window closes. Results are kept permanently
only when you export them. Requests to the same site run back to back without a
fixed pause, including across large-batch chunks. A reported rate limit or an
exhausted quota pauses only that platform until its cooldown ends. Platform-imposed
limits still apply. Services run in parallel, with only one request per service in flight.

For automatic platforms other than Roblox, 500 uncached valid names still need 500
requests; elapsed time depends on the responses. Roblox needs five requests for
500 uncached valid names. Cached, Invalid, and Manual check rows need no requests.
The normal table updates arriving rows without repeatedly rebuilding the default
view. Large jobs use a bounded rolling preview and disk-backed results.

## API access and automatic cooldowns

Open **API access...** beside **Check settings**, or choose **Tools → API access...**.
Enter an optional GitHub token or GitLab personal access token, then click **Apply**.
Fields are masked until you select **Show tokens**. Blank fields use public access.
Stop active checks before changing tokens; applying changes clears the recent-result
cache. Tokens are kept in memory for this app session and sent only to the matching
official HTTPS API. They are excluded from saved settings, `.ucsession` files,
result exports, URLs, and diagnostic messages.

For command-line use, set environment variables before launching the app. In PowerShell:

```powershell
$env:GITHUB_TOKEN = "your-github-token"
$env:GITLAB_TOKEN = "your-gitlab-token"
py -3 username_checker.py example --sites github,gitlab --json
```

On Linux/macOS:

```sh
export GITHUB_TOKEN="your-github-token"
export GITLAB_TOKEN="your-gitlab-token"
python3 username_checker.py example --sites github,gitlab --json
```

Set only the tokens you want to use. `USERNAME_CHECKER_GITHUB_TOKEN` and
`USERNAME_CHECKER_GITLAB_TOKEN` override the respective common variable; an empty
app-specific variable disables that environment token. The desktop also loads
these variables at startup. Credentials must be supplied again when reopening
the app or a saved session, through API access or the environment.

When an API returns HTTP 429 or a recognized HTTP 403 rate-limit response, the
app waits for `Retry-After` (seconds or HTTP date), or the platform's reset header.
Response dates account for differences between your computer's clock and the server.
If no usable time is provided, the first cooldown is 60 seconds and later cooldowns
double. A successful response reporting zero remaining quota can pause the next
request before it is rejected. There is no added delay when the platform reports
no cooldown.

The same request is retried up to three times automatically. Temporary throttling
does not produce a completed result row. If retries are exhausted, unfinished
checks remain pending; desktop Continue or a saved session can resume them.
A continuous finder instead waits for another cooldown and keeps searching until
you stop it or the search space is exhausted. Repeated zero-length reset replies
receive a longer fallback cooldown, keeping Stop responsive without a retry loop
that continuously sends requests.
Cooldowns survive Stop/Continue and chunk boundaries during the current app session.
Reopened sessions reevaluate the platform's current limits when checking resumes.
Desktop status shows a countdown; the CLI writes notices to stderr, keeping JSON
stdout valid. Stop, Pause, window closing, and Ctrl+C remain responsive while waiting.

Token authentication changes the allowance available to your account; it does not
disable platform limits or guarantee username registration. Token setup references:
https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api and
https://docs.gitlab.com/api/rest/authentication/.

## Platforms

There are **32 choices: 5 automatic and 27 manual**. The catalog focuses on widely
used social, gaming, messaging, publishing, developer, music, and payment services
with a username, handle, or custom-profile namespace. It is not an exhaustive list
of every app. Automatic lookups identify existing public profiles; signup
restrictions can still prevent registration.

| Automatic platform | CLI key | Lookup |
| --- | --- | --- |
| GitHub | `github` | Exact public user or organization account |
| GitLab | `gitlab` | Exact public username filter |
| Roblox | `roblox` | Bulk username lookup, including banned accounts and previous names |
| Bluesky | `bluesky` | Handle resolution; `name` becomes `name.bsky.social` |
| Chess.com | `chesscom` | Public player profile |

For Bluesky you can also enter a full handle, such as `bsky.app`. A full domain
handle is looked up as entered, rather than with `.bsky.social` appended. Other
services receive the same input username, so select only Bluesky when checking
a domain handle.

| Manual platform | CLI key | Open page |
| --- | --- | --- |
| Facebook | `facebook` | Candidate profile; verify the username in profile settings |
| Instagram | `instagram` | Candidate profile |
| Threads | `threads` | Candidate profile on threads.com; verify in account settings |
| TikTok | `tiktok` | Candidate profile |
| X | `x` | Candidate profile |
| YouTube | `youtube` | Candidate handle page; verify in handle settings |
| Pinterest | `pinterest` | Candidate profile |
| Snapchat | `snapchat` | Candidate add-user page |
| LinkedIn | `linkedin` | Candidate custom public profile URL, separate from a login name |
| Tumblr | `tumblr` | Candidate blog username/URL |
| Reddit | `reddit` | Candidate user profile |
| Discord | `discord` | Signup page; verify in signup or username settings |
| Telegram | `telegram` | Candidate public username link |
| LINE | `line` | Official guide to the in-app Settings > Profile > ID > Check action |
| Twitch | `twitch` | Candidate channel |
| Steam | `steam` | Candidate custom profile URL; this differs from an account login name |
| Xbox | `xbox` | Official gamertag checker; inspect any numeric suffix |
| PlayStation | `playstation` | Official guide to checking an online ID in Account Management |
| Epic Games | `epicgames` | Account display-name settings; used by Fortnite on supported platforms |
| Minecraft Java | `minecraft` | Minecraft.net account profile; Java profile names differ from Bedrock gamertags |
| SoundCloud | `soundcloud` | Candidate custom profile URL, separate from a display name |
| Medium | `medium` | Candidate profile username |
| Substack | `substack` | Candidate profile handle, separate from a publication subdomain |
| Patreon | `patreon` | Candidate custom creator-page URL, separate from a page name |
| Cash App | `cashapp` | Candidate Cashtag page; enter the name without the leading `$` |
| Venmo | `venmo` | Candidate user page; verify the 5-30 character username in profile settings |
| PayPal.Me | `paypal` | Candidate personal-link name, separate from a PayPal login |

Manual rows are labeled **Manual check**. The app does not infer availability
from these pages or send background requests to these services. Select a row and
use **Open page**, then verify the name on the platform. A missing profile page
alone is insufficient to prove that registration is allowed.

The six specialized entries removed from this release are Codeberg, DEV, Lichess,
Scratch, Hugging Face, and Mastodon.social. Their HTTP request builders, response
handlers, and obsolete fixtures have been removed. Existing commands using those
keys now return a platform-selection error before any requests. This is a catalog
choice, not a claim that those services have shut down.

Names such as Spotify's generated account ID are not presented as freely
claimable usernames. Display names, login identifiers, custom URLs, and game tags
are kept distinct in the platform instructions. Services that require account
access or do not provide a supported public lookup are manual; adding them to a
batch never pretends that their names have been checked automatically.

Common names work in both platform search and CLI selection: `twitter` selects X,
`psn` selects PlayStation, `epic` or `fortnite` selects Epic Games, `xboxlive`
selects Xbox, `minecraft-java` selects Minecraft Java, `paypalme` or `paypal.me`
selects PayPal.Me, and `cash-app` selects Cash App. Aliases resolve to one canonical
platform, so `--sites twitter,x` produces one X result per name.

## Understanding results

| Result | Meaning |
| --- | --- |
| **Taken** | The API returned an existing account that matches the requested name, or resolved the Bluesky handle. |
| **Not found** | The API returned a recognized missing-user response or an empty exact lookup. |
| **Unknown** | A timeout, connection failure, access block, rate limit, redirect, unrecognized reply, or service error prevented a reliable conclusion. |
| **Invalid** | The name fails this checker's preliminary input or site format checks. |
| **Manual check** | The platform requires you to verify the name on its own signup/settings page; the app has made no automated lookup. |

**Not found does not guarantee that a username is available to register.** A name
may be reserved, suspended, private, previously used, occupied by a group or
organization outside the user lookup, or rejected by a site's signup rules.
Some Bluesky resolution failures are deliberately marked Unknown because the API
does not distinguish a missing handle from every other resolution failure.
Registration on the service is the final confirmation. The app does not reserve
names or create accounts. APIs and signup rules can change.

## Command-line examples

```console
python username_checker.py yourname
python username_checker.py --gui --batch-limit 1000
python username_checker.py --input names.txt --batch-limit 1000 --sites github
python username_checker.py yourname --sites auto
python username_checker.py yourname --sites instagram,tiktok,facebook,threads,linkedin --json
python username_checker.py yourname --sites psn,xbox,fortnite,minecraft
python username_checker.py yourname --sites publishing
python username_checker.py yourname --sites gaming
python username_checker.py yourname --sites all
python username_checker.py name-one name-two --sites github,gitlab
python username_checker.py Roblox --sites roblox --timeout 20
python username_checker.py bsky.app --sites bluesky --json
python username_checker.py yourname --output results.csv
python username_checker.py --input names.csv --sites github,gitlab --output results.json
python username_checker.py --input names.txt --sites roblox --stats
python username_checker.py --input names.txt --sites roblox --checkpoint batch.ucsession --output results.csv
python username_checker.py --resume batch.ucsession --checkpoint batch.ucsession --output results.csv
python username_checker.py --input names.txt --sites roblox --status not-found --names-only > shortlist.txt
python username_checker.py --input names.txt --sites github --status unknown --json
python username_checker.py --generate --length 5 --count 100 --sites roblox
python username_checker.py --generate --length 8 --charset letters --pattern "a???????" --sites github
python username_checker.py --generate --length 6 --count 1000000 --generate-only > million_names.txt
python username_checker.py --generate --length 3 --count 0 --sites roblox --output all_three_char_results.csv
python username_checker.py --find --length 3 --sites roblox --output found.txt
python username_checker.py --find --length 4 --sites github,roblox --match all --checkpoint finder.ucsession --output found.csv
python username_checker.py --find --length 5 --pattern "a????" --sites github --batch-limit 100 --json
python username_checker.py --resume finder.ucsession --checkpoint finder.ucsession --output found.txt
python username_checker.py --three-char --charset letters --count 20 --sites github
python username_checker.py --three-char --count 500 --sites chesscom --output results.csv
python username_checker.py --three-char --pattern "a??" --count 10 --sites roblox
python username_checker.py --three-char --seed 42 --offset 0 --sites github --output results.json
python username_checker.py --three-char --seed 42 --offset 20 --sites github
python username_checker.py --list-sites
python username_checker.py --version
python username_checker.py --help
```

Names beginning with `-` must follow `--`, after any options, for example:
`python username_checker.py --sites gitlab -- -example`.

No arguments opens the GUI. Command-line output follows your input/site order.
`--json` prints only the JSON array to stdout; export notices go to stderr.
`--status` filters displayed and exported records: `all`, `taken`, `not-found`,
`unknown`, `invalid`, or `manual`. `--names-only` prints unique names from those
records, one per line, or a JSON array of strings with `--json`. No matching
names produces empty text output or `[]` in JSON mode. `--output` still exports
full records. `--stats` prints elapsed time and counts to stderr. Result filters,
name-only output, and stats require a check; they cannot be used with
`--generate-only`. The CLI uses Roblox batching automatically. Its single-run
checks do not persist a cache between commands.

`--find --length N` continuously checks new candidates until Ctrl+C or the search
space is exhausted. `--match any` (default) or `--match all` controls how selected
automatic platforms must report Not found; manual platforms are omitted. It
ignores the usual total batch cap and uses `--batch-limit` per processing chunk.
Use `--generate --count` for a fixed batch; `--count` and `--generate-only` are
incompatible with `--find`. Its result filter can be `all` or `not-found`.
Found results are written to stdout and `--output` when stopped or finished;
the desktop shows finds live. TXT exports contain unique found names; CSV/JSON
exports contain matching records. Combine `--checkpoint` with `--find` to save
the entire search on Ctrl+C, including its match rule and partial checks.

`--checkpoint FILE` saves checking progress on completion or after Ctrl+C, once
in-flight requests finish. `--resume FILE` preserves saved results and processes
only unfinished work. You can combine resume with `--output`, `--json`, `--status`,
`--names-only`, `--stats`, and `--checkpoint`; names, platforms, timeout, and source
options come from the saved session. Filters affect output, not the saved history.
The checkpoint path must differ from input and exported output files. A resumed
generated-name session exports TXT/JSON names; a checking session exports CSV/JSON
records. A continuous finder session exports found names as TXT or matching
records as CSV/JSON. CLI `--generate-only` itself remains a streaming stdout operation; save
generated-name sessions from the desktop finder when needed.
`--output` replaces an existing file; GUI exports ask before overwriting.
The CLI rejects using the same file for `--input` and `--output` before sending
any network requests. Positional names and imported names are combined and
deduplicated, subject to `--batch-limit` (0/unlimited by default). Positive limits
have no fixed ceiling. Inputs exceeding a positive limit are rejected before
network checks begin.

The CLI defaults to `--sites auto`, meaning all 5 automatic platforms. `all`
includes manual platforms; `manual` selects only those platforms. Category
presets are `developer`, `gaming`, `social`, `community`, `messaging`, `music`,
`publishing`, and `payments`; a category may include both automatic and manual
choices. A comma-separated list accepts the keys from `--list-sites` and the
aliases listed above. `--list-sites` shows each platform's type and category.

Use **`--generate --length N`** to choose an exact length from 1 to 253. The
default length is 3. Omit `--pattern` for any name, or supply a pattern of exactly
the chosen length. `--three-char` remains a shortcut for length 3, including its
existing seeded order; choose `--generate` when selecting a different length.

For generated names, `--count 0` selects all remaining matching names. A positive
count selects that many names; a positive `--batch-limit` is still enforced. If
count is omitted, it is 20 or the positive limit, whichever is smaller. Use
`--offset` to continue from a position in the sequence.
Without `--seed`, order is deterministic; with `--seed`, the
same seed, character set, and pattern produce the same shuffled order, allowing
nonrepeating pagination across commands. Progress and the next offset are
printed to stderr, so stdout remains suitable for JSON or text redirection.
Generator-only mode sends no network requests; it prints names rather than result
records. Redirect its stdout to save a name list. `--output` exports checked
results and cannot be combined with `--generate-only`. Generation-only stdout is
streamed, including JSON arrays. Large checked jobs use the same chunked, disk-backed
engine as the desktop; output and exports keep input/site order using bounded
per-chunk sorting. A stopped large CLI job can export its completed prefix and
reports a restart offset that revisits an unfinished chunk. On a normal completed
run, the reported offset continues without repeats.

`--generate`, `--three-char`, and `--find` cannot be combined with each other,
positional names, or `--input`. Generator options require one of these modes.

Exit codes: `0` = all results were Taken or Not found; `1` = at least one Unknown,
Invalid, or Manual check result, or unfinished work; `2` = input/startup/export error; `130` = interrupted
with Ctrl+C. Exit codes consider every checked result, including rows hidden
by `--status`. Generator-only mode returns `0` when generation succeeds.

## Import formats

TXT accepts commas, spaces, or new lines, just like the desktop input box:

```text
example_name
another-name
```

CSV accepts one username per row, or a `username` column in a wider table:

```csv
username,note
example_name,first choice
another-name,second choice
```

JSON accepts an array of strings or objects with a `username` field:

```json
["example_name", "another-name"]
```

The app's exported CSV and JSON files can be imported to check their usernames
again. Imports do not restore old statuses. A new check uses current API replies
or the desktop app's recent cache; uncheck Reuse recent results for fresh lookups.
Invalid names or file structures are rejected without starting a batch.

## Files and tests

- `username_checker.py` — checking engine, generation, GUI, and CLI.
- `api_access.py` — optional tokens and per-platform cooldown scheduling.
- `project_files.py` — atomic settings and streaming session persistence.
- `ui_theme.py` — shared desktop palettes, fonts, and native widget styling.
- `Start_on_Windows.cmd` — optional double-click launcher.
- `Start_on_Linux.sh` — optional Linux launcher.
- `Start_on_macOS.command` — optional macOS launcher.
- `README.md` — instructions and limitations.
- `test_username_checker.py` — standard-library tests; no internet needed.
- `test_project_features.py` — checkpoint, preference, and comparison regressions.
- `test_api_access.py` — token scope/privacy, retries, cooldowns, and recovery tests.
- `test_continuous_finder.py` — continuous matching, bounded previews, stop/restart, and finder CLI tests.

Run the tests from this folder:

```console
python -m unittest -v
```

Validation for this release: **277 tests passed on Python 3.12/Linux**, including
fifty-three actual Tk desktop tests, continuous 3/4/5-character searching,
Pause/Stop/Continue, shortlist export, token-dialog masking and persistence checks,
light/dark switching and compact-layout checks,
save/open/restart and comparison checks,
catalog/alias/manual-mode checks, unlimited
and chunk-boundary checks, checks for added request delays in single-name/bulk/chunked
processing, automatic retries, header parsing, cancellation during cooldowns,
unfinished-session recovery, length/pattern/large-space checks, both Unix launcher
scripts, and local HTTP integration checks, with no skipped tests. Python 3.10
syntax compatibility was also checked. Desktop tests skip when
no display is available; on Linux they can be run under Xvfb:

```console
xvfb-run -a python3 -m unittest -v
```

A headless session stress check stopped a seeded **200,000-name** generation job
after **73,421 names**, saved it, reopened it, and generated the rest. The final
sequence matched the original without missing or duplicated names, with zero
HTTP requests. Peak process memory was about **20 MiB** on this Linux run. This
measures local generation and checkpointing, not live API throughput or GUI memory.

Adapter response handling was tested with controlled fixtures and a local HTTP
server, using primary API documentation and official client/server source where
available. No live availability results are claimed for this release.
Windows/macOS execution and the Windows launcher were not run on those systems.
No claim is made that every service will respond from every network. Unix launcher
tests run with a POSIX shell and include paths with spaces, Python-version fallback,
missing Python, and application exit codes; these are not native macOS tests.

API references used for the adapters:

- GitHub: https://docs.github.com/en/rest/users/users
- GitLab: https://docs.gitlab.com/api/users/
- Roblox: https://users.roblox.com/docs/json/v1 (official multi-name endpoint schema;
  the app chooses a conservative 100-name chunk size)
- Bluesky: https://atproto.com/guides/reading-data
- Chess.com: https://support.chess.com/en/articles/9650547-what-is-the-pubapi-and-how-do-i-use-it

Official references for the added manual namespaces:

- Facebook usernames: https://www.facebook.com/help/162586890471598
- Threads web address: https://about.fb.com/news/2025/04/new-features-threads-web-experience/
- LinkedIn profile URLs: https://www.linkedin.com/help/linkedin/answer/a542685/manage-your-public-profile-url
- Tumblr usernames: https://help.tumblr.com/knowledge-base/changing-your-username-url/
- SoundCloud URLs: https://help.soundcloud.com/hc/en-us/articles/115003561828
- Medium profile URLs: https://help.medium.com/hc/en-us/articles/115004746707
- Substack handles: https://support.substack.com/hc/en-us/articles/15574565677204
- Patreon page URLs: https://support.patreon.com/hc/en-us/articles/40759154714253
- Xbox gamertags: https://support.xbox.com/en-US/help/account-profile/profile/change-xbox-live-gamertag
- PlayStation online IDs: https://www.playstation.com/en-us/support/account/change-online-id/
- Epic display names: https://www.epicgames.com/help/c-1/a18323090
- Minecraft names: https://help.minecraft.net/hc/en-us/articles/4408950195341
- LINE IDs: https://help.line.me/line/smartphone/sp?contentId=20000126&lang=en
- Cash App Cashtags: https://cash.app/legal/us/en-us/tos (section on Cashtags)
- Venmo usernames: https://help.venmo.com/cs/articles/check-or-edit-your-username-vhel208
- PayPal.Me names: https://www.paypal.com/us/cshelp/article/paypalme-frequently-asked-questions-help432
- Spotify identifiers (excluded): https://support.spotify.com/article/username-and-display-name/

Keep HTTPS certificate checks enabled. Connection failures are reported as
Unknown rather than worked around by disabling secure connections.
