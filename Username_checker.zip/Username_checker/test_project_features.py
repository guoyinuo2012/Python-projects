"""Preferences, checkpoint/restart, and comparison regressions; no public HTTP."""

import contextlib
import io
import json
import sqlite3
import tempfile
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import project_files as files
import username_checker as app


def settings():
    return {"version": 1, "batch_limit": 0, "timeout": 12, "sites": ["github", "minecraft"],
            "reuse_recent": True, "geometry": "1080x810", "theme": "Light", "generator": {
                "length": "3", "charset": "Letters + digits", "characters": "abc123", "pattern": "???",
                "count": "20", "order": "Ordered"}}


class PreferencesTests(unittest.TestCase):
    def test_preferences_round_trip_and_no_names_or_results(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "nested" / "settings.json"
            self.assertEqual(files.load_preferences(path), {})
            files.save_preferences(path, settings())
            self.assertEqual(app.validated_preferences(files.load_preferences(path)), settings())
            self.assertNotIn("results", json.loads(path.read_text()))

    def test_invalid_settings_are_rejected(self):
        changes = [("batch_limit", -1), ("timeout", float("nan")), ("sites", ["missing"]),
                   ("reuse_recent", "yes"), ("geometry", "execute something"), ("generator", {}), ("theme", "invalid")]
        for key, value in changes:
            with self.subTest(key=key), self.assertRaises((ValueError, KeyError, TypeError)):
                config = settings()
                config[key] = value
                app.validated_preferences(config)

    def test_finder_settings_validate_length_pattern_order_and_count(self):
        for key, value in (("length", "0"), ("pattern", "??"), ("order", "invalid"), ("count", "-1")):
            with self.subTest(key=key), self.assertRaises(ValueError):
                config = settings()
                config["generator"][key] = value
                app.validated_preferences(config)

    def test_older_preferences_without_an_appearance_keep_their_other_settings(self):
        config = settings()
        del config["theme"]
        config["batch_limit"] = 1000
        restored = app.validated_preferences(config)
        self.assertEqual(restored["theme"], "Light")
        self.assertEqual(restored["batch_limit"], 1000)
        self.assertEqual(restored["generator"], config["generator"])

    def test_failed_preference_write_preserves_previous_settings(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "settings.json"
            path.write_text("original", encoding="utf-8")
            with patch.object(files.os, "replace", side_effect=OSError("Read only")), self.assertRaises(OSError):
                files.save_preferences(path, settings())
            self.assertEqual(path.read_text(), "original")
            self.assertEqual(list(path.parent.iterdir()), [path])

    def test_platform_settings_paths(self):
        with patch.object(files, "os", SimpleNamespace(name="nt", environ={"APPDATA": "/tmp/appdata"})):
            self.assertEqual(files.preferences_path(), Path("/tmp/appdata/UsernameChecker/settings.json"))
        with patch.object(files, "os", SimpleNamespace(name="posix", environ={"XDG_CONFIG_HOME": "/tmp/config"})), patch.object(files.sys, "platform", "linux"):
            self.assertEqual(files.preferences_path(), Path("/tmp/config/UsernameChecker/settings.json"))
        with patch.object(files, "os", SimpleNamespace(name="posix", environ={})), patch.object(files.sys, "platform", "darwin"):
            self.assertEqual(files.preferences_path(), Path.home() / "Library/Application Support/UsernameChecker/settings.json")


class SessionTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.path = Path(self.directory.name) / "saved session.ucsession"

    def keep(self, job):
        self.addCleanup(job.close)
        return job

    def job(self, count=1201, *, generated=False, seed=None):
        sequence = app.CharacterSearch(seed=seed, length=8, offset=100)
        spec = {"kind": "generator", "config": sequence.config, "start": sequence.position}
        sites = [] if generated else app.select_sites("instagram,tiktok")
        return self.keep(app.LargeBatchJob(sequence.iter_take(count), count, sites, generate_only=generated, source_spec=spec))

    def finish(self, job, stop_after=None):
        original = job._record
        def record(result):
            original(result)
            if job.completed == stop_after:
                job.stop()
        with patch.object(job, "_record", side_effect=record), patch.object(app, "request_api") as request:
            self.assertTrue(job.start())
            self.assertTrue(job.done.wait(5))
            self.assertTrue(job.workers_done.wait(3))
        request.assert_not_called()
        self.assertEqual(job.error, "")

    def restore(self):
        with patch.object(app, "request_api") as request:
            job, config = app.load_checkpoint(self.path)
        request.assert_not_called()
        self.assertTrue(job.done.is_set())
        return self.keep(job), config

    def test_partial_multisite_checkpoint_resumes_only_missing_pairs(self):
        job = self.job(count=30)
        self.finish(job, stop_after=3)
        job.save_checkpoint(self.path, settings())
        before = list(job.journal.read())
        restored, config = self.restore()
        self.assertEqual(config, settings())
        self.assertEqual(restored.completed, 3)
        self.finish(restored)
        rows = list(restored.journal.read())
        self.assertEqual(len(rows), 60)
        self.assertEqual(len({(row.username, row.site) for row in rows}), 60)
        self.assertTrue(all(row in rows for row in before))
        self.assertEqual(restored.pending_pairs, set())

    def test_seeded_generation_survives_two_restarts_at_chunk_boundaries(self):
        job = self.job(generated=True, seed=19)
        expected = app.CharacterSearch(**job.source_spec["config"], offset=100).take(1201)
        self.finish(job, stop_after=413)
        job.save_checkpoint(self.path)
        restored, _ = self.restore()
        self.finish(restored, stop_after=857)
        restored.save_checkpoint(self.path)
        again, _ = self.restore()
        self.finish(again)
        self.assertEqual([row.username for row in again.journal.read()], expected)
        self.assertEqual(again.completed, 1201)

    def test_explicit_name_source_restores_unpulled_names_and_uses_a_private_snapshot(self):
        names = [f"name{index}" for index in range(1201)]
        job = self.keep(app.LargeBatchJob(iter(names), len(names), app.select_sites("instagram"),
                                         source_spec={"kind": "names", "names": names}))
        self.finish(job, stop_after=3)
        job.save_checkpoint(self.path)
        restored, _ = self.restore()
        self.path.write_bytes(b"replaced by another application")
        self.finish(restored)
        self.assertEqual([row.username for row in restored.journal.read()], names)
        restored.save_checkpoint(self.path)
        again, _ = self.restore()
        self.assertEqual(again.completed, len(names))

    def test_reader_and_journal_are_removed_when_a_restored_job_closes(self):
        job = self.job(count=5)
        self.finish(job)
        job.save_checkpoint(self.path)
        restored, _ = self.restore()
        snapshot = Path(restored.session_reader.directory.name)
        journal = restored.journal.path.parent
        restored.close()
        self.assertFalse(snapshot.exists())
        self.assertFalse(journal.exists())
        self.assertIsNone(restored.source_spec)

    def test_closed_jobs_and_jobs_without_a_source_cannot_be_saved(self):
        job = self.keep(app.LargeBatchJob(iter(["abc"]), 1, app.select_sites("instagram")))
        with self.assertRaises(ValueError):
            job.save_checkpoint(self.path)
        job.close()
        with self.assertRaises(ValueError):
            job.save_checkpoint(self.path)

    def test_saving_waits_for_inflight_requests_to_drain(self):
        entered, release = threading.Event(), threading.Event()
        names = ["abc", "def"]
        job = self.keep(app.LargeBatchJob(names, 2, app.select_sites("github"), source_spec={"kind": "names", "names": names}))
        def slow(site, name, timeout, **options):
            entered.set()
            release.wait(3)
            return app.Result(name, site.name, "Taken", site.url_for(name), "Found", "now")
        try:
            with patch.object(app, "check_one", side_effect=slow):
                self.assertTrue(job.start())
                self.assertTrue(entered.wait(2))
                job.stop()
                self.assertTrue(job.done.wait(2))
                self.assertFalse(job.workers_done.is_set())
                with self.assertRaisesRegex(ValueError, "wait"):
                    job.save_checkpoint(self.path)
                release.set()
                self.assertTrue(job.workers_done.wait(2))
                job.save_checkpoint(self.path)
        finally:
            release.set()
        restored, _ = self.restore()
        self.assertEqual(restored.completed, 0)
        self.assertEqual(len(restored.pending_pairs), 2)

    def test_checkpoint_io_blocks_restart_and_defers_cleanup_until_finished(self):
        job = self.job(count=5)
        self.finish(job, stop_after=3)
        entered, release = threading.Event(), threading.Event()
        errors = []
        original = app.write_session
        def delayed(*args, **kwargs):
            entered.set()
            release.wait(3)
            return original(*args, **kwargs)
        def save():
            try:
                job.save_checkpoint(self.path)
            except Exception as exc:
                errors.append(exc)
        with patch.object(app, "write_session", side_effect=delayed):
            worker = threading.Thread(target=save)
            worker.start()
            try:
                self.assertTrue(entered.wait(2))
                self.assertFalse(job.start())
                job.close()
                self.assertFalse(job.closed)
            finally:
                release.set()
                worker.join(3)
        self.assertFalse(worker.is_alive())
        self.assertEqual(errors, [])
        self.assertTrue(job.closed)
        self.assertEqual(self.restore()[0].completed, 3)

    def test_automatic_resume_does_not_repeat_successful_api_pairs(self):
        names = [f"name{index}" for index in range(10)]
        job = self.keep(app.LargeBatchJob(names, 10, app.select_sites("github,gitlab"), source_spec={"kind": "names", "names": names}))
        original = job._record
        def record(result):
            original(result)
            if job.completed == 3:
                job.stop()
        def api(request, timeout):
            if request.host == "api.github.com":
                name = request.full_url.rsplit("/", 1)[-1]
                return app.APIResponse(200, {"login": name, "id": 1}, {})
            name = app.urllib.parse.parse_qs(app.urllib.parse.urlsplit(request.full_url).query)["username"][0]
            return app.APIResponse(200, [{"username": name, "id": 2}], {})
        with patch.object(app, "request_api", side_effect=api), patch.object(job, "_record", side_effect=record):
            job.start()
            self.assertTrue(job.done.wait(3))
            self.assertTrue(job.workers_done.wait(3))
        saved = list(job.journal.read())
        job.save_checkpoint(self.path)
        restored, _ = self.restore()
        with patch.object(app, "request_api", side_effect=api) as request:
            restored.start()
            self.assertTrue(restored.done.wait(3))
        self.assertEqual(request.call_count, 17)
        self.assertEqual(len(list(restored.journal.read())), 20)
        self.assertTrue(all(row in list(restored.journal.read()) for row in saved))

    def test_failed_session_write_keeps_previous_file_and_cleans_staging_files(self):
        self.path.write_text("original", encoding="utf-8")
        def broken():
            yield {"valid": "first"}
            raise ValueError("Failed source")
        with self.assertRaisesRegex(ValueError, "Failed source"):
            files.write_session(self.path, {}, broken())
        self.assertEqual(self.path.read_text(), "original")
        self.assertEqual(list(self.path.parent.iterdir()), [self.path])

    def test_sqlite_write_error_is_readable_and_keeps_the_existing_file(self):
        self.path.write_text("original")
        with patch.object(files.sqlite3, "connect", side_effect=sqlite3.OperationalError("disk full")):
            with self.assertRaisesRegex(ValueError, "disk full"):
                files.write_session(self.path, {}, [])
        self.assertEqual(self.path.read_text(), "original")

    def test_corrupt_metadata_records_and_profile_links_are_rejected(self):
        job = self.job(count=3)
        self.finish(job)
        job.save_checkpoint(self.path)
        original = self.path.read_bytes()
        for mutation in ("version", "progress", "platform", "result", "link", "missing"):
            self.path.write_bytes(original)
            with sqlite3.connect(self.path) as connection:
                state = json.loads(connection.execute("SELECT state FROM metadata").fetchone()[0])
                if mutation == "version":state["version"] = 999
                elif mutation == "progress":state["completed"] += 1
                elif mutation == "platform":state["sites"] = ["unsupported"]
                elif mutation == "missing":connection.execute("DELETE FROM records WHERE position = 1")
                else:
                    record = json.loads(connection.execute("SELECT payload FROM records WHERE position = 0").fetchone()[0])
                    record["username" if mutation == "result" else "profile_url"] = "wrongname" if mutation == "result" else "file:///etc/passwd"
                    connection.execute("UPDATE records SET payload = ? WHERE position = 0", (json.dumps(record),))
                connection.execute("UPDATE metadata SET state = ?", (json.dumps(state),))
            with self.subTest(mutation=mutation), patch.object(app, "request_api") as request, self.assertRaises(ValueError):
                app.load_checkpoint(self.path)
            request.assert_not_called()

    def test_cli_checkpoint_and_resume_preserve_all_results_without_rechecking(self):
        with patch.object(app, "request_api") as request, contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(app.main(["abc", "def", "--sites", "instagram,tiktok", "--checkpoint", str(self.path), "--json"]), 1)
            with contextlib.redirect_stdout(io.StringIO()) as output:
                self.assertEqual(app.main(["--resume", str(self.path), "--checkpoint", str(self.path), "--json"]), 1)
        self.assertEqual(len(json.loads(output.getvalue())), 4)
        request.assert_not_called()

    def test_cli_resume_generated_session_exports_old_and_new_names(self):
        job = self.job(count=20, generated=True, seed=42)
        self.finish(job, stop_after=3)
        job.save_checkpoint(self.path)
        target = self.path.with_suffix(".txt")
        with contextlib.redirect_stdout(io.StringIO()) as output, contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(app.main(["--resume", str(self.path), "--output", str(target), "--json"]), 0)
        self.assertEqual(json.loads(output.getvalue()), target.read_text().splitlines())
        self.assertEqual(len(target.read_text().splitlines()), 20)

    def test_cli_rejects_checkpoint_over_input_and_resume_output_over_session(self):
        source = self.path.with_suffix(".txt")
        source.write_text("abc\ndef")
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as error:
            app.main(["--input", str(source), "--sites", "instagram", "--checkpoint", str(source)])
        self.assertEqual(error.exception.code, 2)
        self.assertEqual(source.read_text(), "abc\ndef")
        job = self.job(count=3)
        self.finish(job)
        job.save_checkpoint(self.path)
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as error:
            app.main(["--resume", str(self.path), "--output", str(self.path)])
        self.assertEqual(error.exception.code, 2)
        self.assertEqual(self.restore()[0].completed, 6)


class ComparisonTests(unittest.TestCase):
    def result(self, name, site, status):
        return app.Result(name, site, status, "", "", "")

    def test_comparison_preserves_unresolved_and_unchecked_pairs(self):
        sites, rows = app.compare_results([self.result("abc", "GitHub", "Not found"), self.result("abc", "GitLab", "Unknown"),
                                           self.result("def", "GitHub", "Not found"), self.result("ghi", "GitLab", "Manual check")])
        self.assertEqual(sites, ["GitHub", "GitLab"])
        self.assertEqual(dict(rows)["abc"], ["Not found", "Unknown"])
        self.assertEqual(dict(rows)["def"], ["Not found", "Unchecked"])
        self.assertEqual(dict(rows)["ghi"], ["Unchecked", "Manual check"])

    def test_platforms_with_no_results_stay_unchecked_in_the_shortlist(self):
        sites, rows = app.compare_results([self.result("abc", "GitHub", "Not found")], ["GitHub", "GitLab", "Roblox"])
        self.assertEqual(sites, ["GitHub", "GitLab", "Roblox"])
        self.assertEqual(rows, [("abc", ["Not found", "Unchecked", "Unchecked"])])

    def test_comparison_prefers_more_not_found_results_and_replaces_retried_status(self):
        _, rows = app.compare_results([self.result("taken", "GitHub", "Taken"), self.result("abc", "GitHub", "Unknown"),
                                       self.result("abc", "GitHub", "Not found"), self.result("generated", "", "Generated")])
        self.assertEqual(rows, [("abc", ["Not found"]), ("taken", ["Taken"])])


if __name__ == "__main__":
    unittest.main()
