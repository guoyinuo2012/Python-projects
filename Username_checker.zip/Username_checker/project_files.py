"""Local preferences and atomic, streaming session files. Standard library only."""

from __future__ import annotations

import json
import os
import shutil
import sqlite3
import sys
import tempfile
from pathlib import Path

MAX_STATE_BYTES = 8 * 1024 * 1024
MAX_RECORD_BYTES = 16 * 1024


def preferences_path() -> Path:
    if os.name == "nt":
        base = Path(os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming")
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config")
    return base / "UsernameChecker" / "settings.json"


def load_preferences(path: Path) -> dict:
    if not path.exists():
        return {}
    if path.stat().st_size > MAX_STATE_BYTES:
        raise ValueError("The settings file is too large.")
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("The settings file must contain an object.")
    return value


def save_preferences(path: Path, settings: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    content = json.dumps(settings, ensure_ascii=False, indent=2).encode("utf-8")
    if len(content) > MAX_STATE_BYTES:
        raise ValueError("The settings file is too large.")
    _replace_bytes(path, content)


def _replace_bytes(path: Path, content: bytes) -> None:
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, prefix=".username-checker-", delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def write_session(path: Path, state: dict, records, names=()) -> None:
    """Commit a complete snapshot before replacing a previous session file."""
    encoded = json.dumps(state, ensure_ascii=False)
    if len(encoded.encode("utf-8")) > MAX_STATE_BYTES:
        raise ValueError("Session settings exceed the supported size.")
    temporary = None
    connection = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, prefix=".username-session-", delete=False) as stream:
            temporary = Path(stream.name)
        connection = sqlite3.connect(temporary)
        with connection:
            connection.execute("CREATE TABLE metadata (id INTEGER PRIMARY KEY, state TEXT NOT NULL)")
            connection.execute("CREATE TABLE names (position INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE)")
            connection.execute("CREATE TABLE records (position INTEGER PRIMARY KEY, payload TEXT NOT NULL)")
            connection.execute("INSERT INTO metadata VALUES (1, ?)", (encoded,))
            connection.executemany("INSERT INTO names VALUES (?, ?)", enumerate(names))
            connection.executemany("INSERT INTO records VALUES (?, ?)",
                                   ((index, json.dumps(record, ensure_ascii=False)) for index, record in enumerate(records)))
        # The context manager commits but does not close a sqlite connection.
        connection.close()
        connection = None
        with temporary.open("rb") as stream:
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except sqlite3.Error as exc:
        raise ValueError(f"Could not write the session: {exc}") from exc
    finally:
        if connection is not None:
            connection.close()
        if temporary is not None:
            temporary.unlink(missing_ok=True)
            Path(str(temporary) + "-journal").unlink(missing_ok=True)


class SessionReader:
    """Read an independent local snapshot; later edits to the original cannot alter a running job."""

    def __init__(self, path: Path):
        self.directory = tempfile.TemporaryDirectory(prefix="username-session-")
        self.connection = None
        try:
            snapshot = Path(self.directory.name) / "session.sqlite"
            shutil.copyfile(path, snapshot)
            self.connection = sqlite3.connect(snapshot.as_uri() + "?mode=ro&immutable=1", uri=True, check_same_thread=False)
            self.connection.execute("PRAGMA trusted_schema = OFF")
            rows = self.connection.execute("SELECT length(CAST(state AS BLOB)) FROM metadata WHERE id = 1").fetchall()
            if len(rows) != 1 or rows[0][0] > MAX_STATE_BYTES:
                raise ValueError("Invalid session metadata.")
            self.state = json.loads(self.connection.execute("SELECT state FROM metadata WHERE id = 1").fetchone()[0])
            if not isinstance(self.state, dict):
                raise ValueError("Invalid session metadata.")
            for table, field, limit in (("records", "payload", MAX_RECORD_BYTES), ("names", "username", 253)):
                count, first, last = self.connection.execute(f"SELECT count(*), min(position), max(position) FROM {table}").fetchone()
                if count and (first != 0 or last != count - 1):
                    raise ValueError("The session has missing or duplicate positions.")
                if self.connection.execute(
                    f"SELECT 1 FROM {table} WHERE typeof({field}) != 'text' OR length(CAST({field} AS BLOB)) > ? LIMIT 1", (limit,)
                ).fetchone():
                    raise ValueError("The session contains an invalid or oversized entry.")
            self.name_count = self.connection.execute("SELECT count(*) FROM names").fetchone()[0]
        except Exception:
            self.close()
            raise

    def names(self, offset=0):
        for row in self.connection.execute("SELECT username FROM names WHERE position >= ? ORDER BY position", (offset,)):
            yield row[0]

    def records(self):
        for row in self.connection.execute("SELECT payload FROM records ORDER BY position"):
            yield json.loads(row[0])

    def close(self):
        if self.connection is not None:
            self.connection.close()
            self.connection = None
        self.directory.cleanup()
