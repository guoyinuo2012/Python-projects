"""Shared desktop colors and styles; imported without requiring Tkinter for CLI use."""

PALETTES = {
    "Light": {"canvas": "#f3f6f8", "surface": "#ffffff", "field": "#ffffff", "border": "#d9e2e8",
              "text": "#1c303d", "muted": "#607585", "accent": "#0f766e", "accent_hover": "#115e59",
              "accent_text": "#ffffff", "hover": "#edf3f5", "selection": "#d9efeb", "disabled": "#9aaab5",
              "success": "#edf8f3", "warning": "#fff7e8", "danger": "#b54740", "danger_bg": "#fff1ef",
              "quiet": "#eff3f6"},
    "Dark": {"canvas": "#101820", "surface": "#18242e", "field": "#1d2c38", "border": "#344553",
             "text": "#e5eef5", "muted": "#a2b5c4", "accent": "#4dd4bf", "accent_hover": "#72e4d2",
             "accent_text": "#072c28", "hover": "#263846", "selection": "#24524e", "disabled": "#748797",
             "success": "#1b3631", "warning": "#3b3222", "danger": "#ffb1a9", "danger_bg": "#3d292b",
             "quiet": "#21313e"},
}


def choose_font(root):
    from tkinter import font

    families = {name.casefold(): name for name in font.families(root)}
    fallback = font.nametofont("TkDefaultFont", root=root).actual("family")
    return next((families[name] for name in ("segoe ui", "sf pro text", "helvetica", "dejavu sans", "nimbus sans", "arial")
                 if name in families), fallback)


def configure_styles(root, ttk, family, mode):
    colors = PALETTES[mode]
    style = ttk.Style(root)
    if style.theme_use() != "clam" and "clam" in style.theme_names():
        style.theme_use("clam")
    style.configure(".", background=colors["canvas"], foreground=colors["text"], font=(family, 10),
                    bordercolor=colors["border"], lightcolor=colors["border"], darkcolor=colors["border"])
    style.configure("TFrame", background=colors["canvas"])
    style.configure("Card.TFrame", background=colors["surface"], relief="solid", borderwidth=1)
    style.configure("CardBody.TFrame", background=colors["surface"])
    for name, background, foreground in (
        ("TLabel", "canvas", "text"), ("Muted.TLabel", "canvas", "muted"),
        ("CardMuted.TLabel", "surface", "muted"),
    ):
        style.configure(name, background=colors[background], foreground=colors[foreground], font=(family, 10))
    style.configure("Heading.TLabel", font=(family, 23, "bold"))
    style.configure("DialogTitle.TLabel", font=(family, 18, "bold"))
    style.configure("Section.TLabel", background=colors["surface"], font=(family, 12, "bold"))
    style.configure("Small.TLabel", font=(family, 9), foreground=colors["muted"])
    style.configure("CardSmall.TLabel", background=colors["surface"], font=(family, 9), foreground=colors["muted"])
    style.configure("Badge.TLabel", background=colors["selection"], foreground=colors["accent"],
                    font=(family, 9, "bold"), padding=(8, 4))
    style.configure("ManualBadge.TLabel", background=colors["quiet"], foreground=colors["muted"],
                    font=(family, 9), padding=(8, 4))
    style.configure("TButton", background=colors["quiet"], foreground=colors["text"], relief="flat",
                    borderwidth=1, padding=(12, 7), font=(family, 10), focuscolor=colors["accent"],
                    lightcolor=colors["quiet"], darkcolor=colors["quiet"])
    style.map("TButton", background=[("disabled", colors["quiet"]), ("pressed", colors["selection"]), ("active", colors["hover"])],
              foreground=[("disabled", colors["disabled"])], bordercolor=[("focus", colors["accent"])])
    style.configure("Primary.TButton", background=colors["accent"], foreground=colors["accent_text"],
                    bordercolor=colors["accent"], lightcolor=colors["accent"], darkcolor=colors["accent"],
                    font=(family, 10, "bold"), focuscolor=colors["accent_text"])
    style.map("Primary.TButton", background=[("disabled", colors["quiet"]), ("pressed", colors["accent_hover"]), ("active", colors["accent_hover"])],
              foreground=[("disabled", colors["disabled"]), ("!disabled", colors["accent_text"])],
              bordercolor=[("disabled", colors["border"]), ("!disabled", colors["accent"])])
    style.configure("Subtle.TButton", borderwidth=0, padding=(8, 5), background=colors["surface"], foreground=colors["muted"])
    style.configure("Compact.TButton", padding=(9, 6))
    style.configure("Danger.TButton", background=colors["danger_bg"], foreground=colors["danger"])
    style.map("Danger.TButton", foreground=[("disabled", colors["disabled"]), ("!disabled", colors["danger"])])
    for name, background in (("TCheckbutton", "canvas"), ("Card.TCheckbutton", "surface")):
        style.configure(name, background=colors[background], foreground=colors["text"],
                        font=(family, 10), indicatorsize=16, indicatormargin=(0, 0, 6, 0),
                        indicatorbackground=colors["field"], indicatorforeground=colors["accent_text"])
        style.map(name, background=[("active", colors[background])], foreground=[("disabled", colors["disabled"])],
                  indicatorbackground=[("selected", colors["accent"]), ("!selected", colors["field"])])
    for name in ("TEntry", "TCombobox", "TSpinbox"):
        style.configure(name, fieldbackground=colors["field"], background=colors["field"], foreground=colors["text"],
                        padding=(9, 7), borderwidth=1, relief="flat", arrowsize=14,
                        insertcolor=colors["text"], arrowcolor=colors["muted"],
                        selectbackground=colors["selection"], selectforeground=colors["text"])
        style.map(name, fieldbackground=[("disabled", colors["quiet"]), ("readonly", colors["field"])],
                  foreground=[("disabled", colors["disabled"]), ("readonly", colors["text"])],
                  bordercolor=[("focus", colors["accent"]), ("!focus", colors["border"])],
                  lightcolor=[("focus", colors["accent"])], darkcolor=[("focus", colors["accent"])])
    style.configure("Treeview", background=colors["surface"], fieldbackground=colors["surface"],
                    foreground=colors["text"], font=(family, 10), rowheight=34, borderwidth=0)
    style.configure("Treeview.Heading", background=colors["quiet"], foreground=colors["muted"],
                    relief="flat", borderwidth=0, padding=(10, 9), font=(family, 9, "bold"))
    style.map("Treeview", background=[("selected", colors["selection"])], foreground=[("selected", colors["text"])])
    style.map("Treeview.Heading", background=[("active", colors["hover"])])
    style.configure("Horizontal.TProgressbar", background=colors["accent"], troughcolor=colors["quiet"],
                    borderwidth=0, lightcolor=colors["accent"], darkcolor=colors["accent"])
    for direction in ("Vertical", "Horizontal"):
        style.configure(direction + ".TScrollbar", background=colors["border"], troughcolor=colors["surface"],
                        borderwidth=0, arrowsize=11, relief="flat", arrowcolor=colors["muted"])
        style.map(direction + ".TScrollbar", background=[("active", colors["muted"])])
    root.option_add("*TCombobox*Listbox.font", (family, 10))
    root.option_add("*Menu.font", (family, 10))
    paint_widgets(root, colors)
    return colors


def progressbar(parent, ttk, **options):
    track = ttk.Frame(parent, height=4)
    track.pack_propagate(False)
    widget = ttk.Progressbar(track, **options)
    widget.pack(fill="both", expand=True)
    return track, widget


def paint_widgets(root, colors):
    """Refresh classic Tk widgets and result tags, including already-open dialogs."""
    from tkinter import TclError

    def visit(widget):
        kind = widget.winfo_class()
        if kind in ("Tk", "Toplevel"):
            widget.configure(background=colors["canvas"])
        elif kind == "Text":
            widget.configure(background=colors["field"], foreground=colors["text"], insertbackground=colors["text"],
                             selectbackground=colors["selection"], selectforeground=colors["text"],
                             highlightbackground=colors["border"], highlightcolor=colors["accent"])
        elif kind == "Canvas":
            widget.configure(background=colors["surface"])
        elif kind == "Menu":
            widget.configure(background=colors["surface"], foreground=colors["text"],
                             activebackground=colors["selection"], activeforeground=colors["text"],
                             disabledforeground=colors["disabled"], borderwidth=0, activeborderwidth=0)
        elif kind == "Treeview":
            for status, background in (("Taken", "surface"), ("Not found", "success"), ("Unknown", "warning"),
                                       ("Invalid", "quiet"), ("Manual check", "surface")):
                widget.tag_configure(status, foreground=colors["text"], background=colors[background])
        elif kind == "TCombobox":
            try:
                popdown = widget.tk.call("ttk::combobox::PopdownWindow", str(widget))
                widget.tk.call(str(popdown) + ".f.l", "configure", "-background", colors["field"],
                               "-foreground", colors["text"], "-selectbackground", colors["selection"],
                               "-selectforeground", colors["text"])
            except TclError:
                pass
        for child in widget.winfo_children():
            visit(child)
    visit(root)
