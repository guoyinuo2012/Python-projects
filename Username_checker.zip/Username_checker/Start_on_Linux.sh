#!/bin/sh
# Start from this folder even when launched elsewhere or from a path with spaces.
script_dir=$(CDPATH= cd -P "$(dirname "$0")" && pwd) || exit 2
cd "$script_dir" || exit 2

for python_cmd in python3 python; do
    if command -v "$python_cmd" >/dev/null 2>&1 &&
       "$python_cmd" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)' >/dev/null 2>&1; then
        "$python_cmd" "$script_dir/username_checker.py" --gui
        status=$?
        if [ "$status" -ne 0 ] && [ -t 0 ]; then
            printf '\nThe app could not start. See the error above. Press Enter to close.\n'
            IFS= read -r launcher_reply || :
        fi
        exit "$status"
    fi
done

printf '%s\n' 'Python 3.10 or newer was not found.' \
    'Install Python from https://www.python.org/downloads/ with Tcl/Tk support.' \
    'On Linux, your distribution may provide Tkinter in its python3-tk package.' >&2
if [ -t 0 ]; then
    printf 'Press Enter to close.\n'
    IFS= read -r launcher_reply || :
fi
exit 2
