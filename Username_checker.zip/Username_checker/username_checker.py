#!/usr/bin/env python3
"""Check public username profiles using official APIs; run without args for a GUI."""

from __future__ import annotations

import argparse
import csv
import http.client
import io
import itertools
import json
import math
import os
import queue
import random
import re
import socket
import ssl
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from collections import Counter, OrderedDict, deque
from contextlib import contextmanager
from dataclasses import asdict, dataclass, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Iterable

from api_access import ApiAccess, MAX_RATE_RETRIES, environment_tokens, is_rate_limited
from project_files import SessionReader, load_preferences, preferences_path, save_preferences, write_session
from ui_theme import PALETTES, choose_font, configure_styles, paint_widgets, progressbar

APP_NAME = "Username checker"
APP_VERSION = "1.14"
DEFAULT_BATCH_LIMIT = 0
LARGE_BATCH_THRESHOLD = 10_000
CHECK_CHUNK_SIZE = 500
RESULT_PREVIEW_SIZE = 500
DEFAULT_BATCH_SIZE = 20
DEFAULT_USERNAME_LENGTH = 3
MAX_USERNAME_LENGTH = 253
SHUFFLE_MEMORY_LIMIT = 100_000
MAX_INPUT_BYTES = 16 * 1024 * 1024
ROBLOX_BULK_SIZE = 100
CACHE_TTL = 5 * 60
CACHE_MAX_ENTRIES = 50_000
MAX_RESPONSE_BYTES = 512 * 1024
NOT_FOUND_DETAIL = "No public profile found. Registration may still be restricted."
STATUS_FILTERS = {"all": "All", "taken": "Taken", "not-found": "Not found", "unknown": "Unknown",
                  "invalid": "Invalid", "manual": "Manual check"}
FINDER_MATCHES = {"Any selected platform": "any", "All selected platforms": "all"}
CHARACTER_SETS = {
    "letters": "abcdefghijklmnopqrstuvwxyz",
    "digits": "0123456789",
    "alnum": "abcdefghijklmnopqrstuvwxyz0123456789",
}


def validate_batch_limit(value: int) -> int:
    """Validate the configurable cap used by every input/checking path."""
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError("Batch limit must be a whole number: 0 for unlimited, or any positive limit.")
    return value


def validate_character_length(value: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= MAX_USERNAME_LENGTH:
        raise ValueError(f"Character count must be a whole number from 1 to {MAX_USERNAME_LENGTH}.")
    return value


def format_candidate_count(value: int) -> str:
    """Keep very large search-space counters readable inside the finder window."""
    digits = str(value)
    if len(digits) <= 15:
        return f"{value:,}"
    return f"{digits[0]}.{digits[1:4]}e{len(digits) - 1}"


class CharacterSearch:
    """Paginated exact-length candidates, with bounded shuffle memory."""

    def __init__(self, charset: str = "alnum", pattern: str | None = None,
                 characters: str = "", seed: int | None = None, offset: int = 0,
                 *, length: int = DEFAULT_USERNAME_LENGTH):
        self.length = validate_character_length(length)
        if charset == "custom":
            if not characters or not re.fullmatch(r"[A-Za-z0-9_.-]+", characters):
                raise ValueError("Custom characters must contain letters, digits, _, - or .")
            alphabet = "".join(dict.fromkeys(characters.lower()))
        elif charset in CHARACTER_SETS:
            if characters:
                raise ValueError("Choose the custom character set when specifying characters.")
            alphabet = CHARACTER_SETS[charset]
        else:
            raise ValueError("Choose letters, digits, alnum, or custom characters.")
        pattern = "?" * self.length if pattern in (None, "") else pattern.lower()
        if len(pattern) != self.length or any(char != "?" and char not in alphabet for char in pattern):
            raise ValueError(f"Use a {self.length}-character pattern. ? means any selected character; "
                             "fixed characters must belong to the selected character set.")
        self.options = [alphabet if char == "?" else char for char in pattern]
        self.total = math.prod(len(option) for option in self.options)
        if isinstance(offset, bool) or not isinstance(offset, int) or not 0 <= offset < self.total:
            raise ValueError(f"Offset must be between 0 and {self.total - 1:,}.")
        self.position = offset
        self.config = {"charset": charset, "pattern": pattern, "characters": characters,
                       "seed": seed, "length": self.length}
        self.order = None
        self.stride, self.shift = 1, 0
        if seed is not None:
            rng = random.Random(seed)
            if self.total <= SHUFFLE_MEMORY_LIMIT:
                # Preserve the established seeded order for small/3-character spaces.
                self.order = list(range(self.total))
                rng.shuffle(self.order)
            elif self.total > 1:
                # A coprime stride visits every index exactly once. Unlike building
                # and shuffling the entire space, this also works for long names.
                self.stride = rng.randrange(1, self.total)
                while math.gcd(self.stride, self.total) != 1:
                    self.stride = rng.randrange(1, self.total)
                self.shift = rng.randrange(self.total)

    def batch_count(self, count: int, batch_limit: int = DEFAULT_BATCH_LIMIT) -> int:
        batch_limit = validate_batch_limit(batch_limit)
        if isinstance(count, bool) or not isinstance(count, int) or count < 0:
            raise ValueError("Batch size must be a whole number: 0 for all remaining names, or a positive count.")
        requested = self.total - self.position if count == 0 else count
        if batch_limit and requested > batch_limit:
            raise ValueError(f"Generate up to {batch_limit:,} usernames, or set Batch limit to 0 for unlimited.")
        return min(requested, self.total - self.position)

    def iter_take(self, count: int = DEFAULT_BATCH_SIZE, *, batch_limit: int = DEFAULT_BATCH_LIMIT) -> Iterable[str]:
        end = self.position + self.batch_count(count, batch_limit)
        return self._iterate_to(end)

    def _iterate_to(self, end: int) -> Iterable[str]:
        while self.position < end:
            position = self.position
            index = self.order[position] if self.order is not None else (
                (position * self.stride + self.shift) % self.total)
            chars = []
            for option in reversed(self.options):
                index, digit = divmod(index, len(option))
                chars.append(option[digit])
            self.position += 1
            yield "".join(reversed(chars))

    def take(self, count: int = DEFAULT_BATCH_SIZE, *, batch_limit: int = DEFAULT_BATCH_LIMIT) -> list[str]:
        """Materialize a small batch; use iter_take for streaming large jobs."""
        return list(self.iter_take(count, batch_limit=batch_limit))


# Existing scripts using the original three-character API keep its default length.
ThreeCharacterSearch = CharacterSearch


@dataclass(frozen=True)
class Site:
    key: str
    name: str
    profile_template: str
    category: str = "Developer"
    manual: bool = False
    manual_detail: str = "Use the platform's signup or username settings to confirm availability."
    aliases: tuple[str, ...] = ()

    def url_for(self, username: str) -> str:
        """Build a candidate profile or official verification page consistently."""
        return self.profile_template.format(username=urllib.parse.quote(lookup_name(self, username), safe=""))


SITES = (
    Site("github", "GitHub", "https://github.com/{username}"),
    Site("gitlab", "GitLab", "https://gitlab.com/{username}"),
    Site("roblox", "Roblox", "https://www.roblox.com/search/users?keyword={username}", "Gaming"),
    Site("bluesky", "Bluesky", "https://bsky.app/profile/{username}", "Social"),
    Site("chesscom", "Chess.com", "https://www.chess.com/member/{username}", "Gaming"),
    Site("facebook", "Facebook", "https://www.facebook.com/{username}", "Social", True,
         "Check this username in Facebook's profile username settings; display names are different."),
    Site("instagram", "Instagram", "https://www.instagram.com/{username}/", "Social", True),
    Site("threads", "Threads", "https://www.threads.com/@{username}", "Social", True,
         "Verify the Threads username in profile/account settings, including any linked Instagram account."),
    Site("tiktok", "TikTok", "https://www.tiktok.com/@{username}", "Social", True),
    Site("x", "X", "https://x.com/{username}", "Social", True, aliases=("twitter",)),
    Site("youtube", "YouTube", "https://www.youtube.com/@{username}", "Social", True,
         "Check this handle in YouTube Studio or on the platform's handle settings page."),
    Site("pinterest", "Pinterest", "https://www.pinterest.com/{username}/", "Social", True),
    Site("snapchat", "Snapchat", "https://www.snapchat.com/add/{username}", "Social", True),
    Site("linkedin", "LinkedIn", "https://www.linkedin.com/in/{username}/", "Social", True,
         "Check this custom public profile URL in LinkedIn's public profile settings; it is not a login name."),
    Site("tumblr", "Tumblr", "https://www.tumblr.com/{username}", "Social", True,
         "Check this blog username/URL in Tumblr's blog settings; inactive names may remain unavailable."),
    Site("reddit", "Reddit", "https://www.reddit.com/user/{username}/", "Community", True),
    Site("discord", "Discord", "https://discord.com/register", "Community", True,
         "Check this name in Discord's signup form or username settings."),
    Site("telegram", "Telegram", "https://t.me/{username}", "Messaging", True,
         "Check this public username in Telegram's username settings; collectible usernames have separate rules."),
    Site("line", "LINE", "https://help.line.me/line/smartphone/sp?contentId=20000126&lang=en", "Messaging", True,
         "In LINE, open Settings > Profile > ID, enter this candidate and tap Check. A saved LINE ID cannot be changed."),
    Site("twitch", "Twitch", "https://www.twitch.tv/{username}", "Gaming", True),
    Site("steam", "Steam", "https://steamcommunity.com/id/{username}", "Gaming", True,
         "Check this custom profile URL in Steam's profile settings; it differs from an account login name."),
    Site("xbox", "Xbox", "https://social.xbox.com/changegamertag", "Gaming", True,
         "Enter this candidate in Xbox's gamertag checker. Check the full tag and any numeric suffix.",
         aliases=("xboxlive",)),
    Site("playstation", "PlayStation", "https://www.playstation.com/en-us/support/account/change-online-id/", "Gaming", True,
         "Use PlayStation Account Management > Profile > Online ID to check this candidate.", aliases=("psn",)),
    Site("epicgames", "Epic Games", "https://www.epicgames.com/account/personal", "Gaming", True,
         "Check this display name in Epic Games account settings; console games may use your Xbox/PSN name instead.",
         aliases=("epic", "fortnite")),
    Site("minecraft", "Minecraft Java", "https://www.minecraft.net/en-us/msaprofile", "Gaming", True,
         "Sign in to Minecraft.net and check the Java Edition profile name; Bedrock uses an Xbox gamertag.",
         aliases=("minecraft-java",)),
    Site("soundcloud", "SoundCloud", "https://soundcloud.com/{username}", "Music", True,
         "Check this custom profile URL in SoundCloud's Edit profile form; display names are separate."),
    Site("medium", "Medium", "https://medium.com/@{username}", "Publishing", True,
         "Check this username in Medium's account settings; it determines your profile URL."),
    Site("substack", "Substack", "https://substack.com/@{username}", "Publishing", True,
         "Check this handle at substack.com/profile/edit; a publication subdomain is a separate setting."),
    Site("patreon", "Patreon", "https://www.patreon.com/{username}", "Publishing", True,
         "Check this custom creator-page URL in Patreon's Page Details; the page name is a separate setting."),
    Site("cashapp", "Cash App", "https://cash.app/${username}", "Payments", True,
         "Check this Cashtag in Cash App's profile settings. Enter the candidate without the leading $.",
         aliases=("cash-app",)),
    Site("venmo", "Venmo", "https://venmo.com/{username}", "Payments", True,
         "Check this username in Venmo > Settings > Account > Profile; names must be 5-30 characters."),
    Site("paypal", "PayPal.Me", "https://www.paypal.com/paypalme/{username}", "Payments", True,
         "Check this PayPal.Me link name during PayPal.Me setup; it is separate from your PayPal login.",
         aliases=("paypalme", "paypal.me")),
)
SITE_BY_KEY = {site.key: site for site in SITES}
SITE_ALIASES = {alias: site.key for site in SITES for alias in site.aliases}
AUTOMATIC_SITES = tuple(site for site in SITES if not site.manual)


def select_sites(selection: str) -> list[Site]:
    """Resolve site keys or one of the automatic/manual/category presets."""
    selection = selection.strip().lower()
    if selection == "all":
        return list(SITES)
    if selection == "auto":
        return list(AUTOMATIC_SITES)
    if selection == "manual":
        return [site for site in SITES if site.manual]
    category = [site for site in SITES if site.category.lower() == selection]
    if category:
        return category
    keys = [part.strip() for part in selection.split(",") if part.strip()]
    keys = list(dict.fromkeys(SITE_ALIASES.get(key, key) for key in keys))
    if not keys or any(key not in SITE_BY_KEY for key in keys):
        raise ValueError("Unknown or empty platform selection. Use --list-sites to see valid keys.")
    return [SITE_BY_KEY[key] for key in keys]


@dataclass(frozen=True)
class Result:
    username: str
    site: str
    status: str
    profile_url: str
    detail: str
    checked_at: str


class ResultCache:
    """Bounded, thread-safe session cache; only confirmed API results are reusable."""

    def __init__(self, ttl: float = CACHE_TTL, max_entries: int = CACHE_MAX_ENTRIES,
                 clock: Callable[[], float] = time.monotonic):
        if not math.isfinite(ttl) or ttl <= 0 or max_entries < 1:
            raise ValueError("Cache lifetime and capacity must be positive.")
        self.ttl, self.max_entries, self.clock = ttl, max_entries, clock
        self.entries: OrderedDict[tuple[str, str], tuple[float, Result]] = OrderedDict()
        self.lock = threading.Lock()

    def get(self, site: Site, username: str) -> Result | None:
        key = (site.key, lookup_name(site, username).casefold())
        with self.lock:
            entry = self.entries.get(key)
            if entry is None:
                return None
            expires, result = entry
            if self.clock() >= expires:
                del self.entries[key]
                return None
            self.entries.move_to_end(key)
            # Keep the original timestamp; a reused result is not a new API check.
            return replace(result, username=username, detail="Reused recent result. " + result.detail)

    def put(self, site: Site, result: Result) -> None:
        if site.manual or result.status not in ("Taken", "Not found"):
            return
        key = (site.key, lookup_name(site, result.username).casefold())
        with self.lock:
            self.entries[key] = (self.clock() + self.ttl, result)
            self.entries.move_to_end(key)
            while len(self.entries) > self.max_entries:
                self.entries.popitem(last=False)

    def clear(self) -> None:
        with self.lock:
            self.entries.clear()


class CheckStats:
    """Small counters shared by platform workers and the UI."""

    def __init__(self):
        self.lock = threading.Lock()
        self.counts = {"requests": 0, "cache_hits": 0, "local_results": 0}

    def add(self, key: str, count: int = 1) -> None:
        with self.lock:
            self.counts[key] += count

    def snapshot(self) -> dict[str, int]:
        with self.lock:
            return dict(self.counts)


@dataclass(frozen=True)
class APIResponse:
    status: int
    data: object
    headers: dict[str, str]
    valid_json: bool = True


class CheckError(Exception):
    """A request failed before its result could be interpreted."""


class NoRedirect(urllib.request.HTTPRedirectHandler):
    """A moved profile is ambiguous; don't silently check a different name."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def parse_usernames(text: str, batch_limit: int = DEFAULT_BATCH_LIMIT) -> list[str]:
    """Split comma/whitespace-separated names, remove @, and deduplicate."""
    batch_limit = validate_batch_limit(batch_limit)
    if batch_limit and len(text) > batch_limit * 300:
        raise ValueError(f"Input is too large. Check up to {batch_limit:,} usernames at a time.")
    names: list[str] = []
    seen: set[str] = set()
    for token in re.split(r"[\s,]+", text.strip()):
        if not token:
            continue
        name = token.removeprefix("@")
        if not re.fullmatch(r"[A-Za-z0-9_.-]{1,253}", name):
            raise ValueError(
                f"Invalid username {token[:60]!r}. Use letters, numbers, _, - or . "
                "Enter usernames rather than URLs."
            )
        if name.casefold() not in seen:
            seen.add(name.casefold())
            names.append(name)
        if batch_limit and len(names) > batch_limit:
            raise ValueError(f"Check up to {batch_limit:,} different usernames at a time.")
    if not names:
        raise ValueError("Enter at least one username.")
    return names


def load_usernames(path: Path, batch_limit: int = DEFAULT_BATCH_LIMIT) -> list[str]:
    """Read a bounded UTF-8 TXT, CSV, or JSON username list (including exports)."""
    batch_limit = validate_batch_limit(batch_limit)
    if path.suffix.lower() not in (".txt", ".csv", ".json"):
        raise ValueError("Import a .txt, .csv, or .json file.")
    with path.open("rb") as stream:
        raw = stream.read(MAX_INPUT_BYTES + 1)
    if len(raw) > MAX_INPUT_BYTES:
        raise ValueError("The input file is too large. The limit is 16 MiB.")
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeError as exc:
        raise ValueError("Save the input file using UTF-8 text encoding.") from exc
    extension = path.suffix.lower()
    if extension == ".txt":
        return parse_usernames(text, batch_limit)
    if extension == ".json":
        try:
            values = json.loads(text)
        except ValueError as exc:
            raise ValueError("The input file does not contain valid JSON.") from exc
        if not isinstance(values, list):
            raise ValueError("JSON must be an array of usernames or objects with a username field.")
        entries = [value.get("username") if isinstance(value, dict) else value for value in values]
    else:
        try:
            rows = list(csv.reader(io.StringIO(text, newline=""), strict=True))
        except csv.Error as exc:
            raise ValueError("The input file does not contain valid CSV.") from exc
        rows = [row for row in rows if any(cell.strip() for cell in row)]
        if not rows:
            raise ValueError("The input file is empty.")
        headings = [cell.strip().casefold() for cell in rows[0]]
        if "username" in headings:
            column = headings.index("username")
            if any(len(row) <= column for row in rows[1:]):
                raise ValueError("A CSV row is missing its username column.")
            entries = [row[column] for row in rows[1:]]
        elif all(len(row) == 1 for row in rows):
            entries = [row[0] for row in rows]
        else:
            raise ValueError("CSV needs a username header, or one username per row.")
        # Undo only our CSV export's protective prefix, never general quoting.
        entries = [value[1:] if value.startswith("'-") else value for value in entries]
    if any(not isinstance(value, str) or not value.strip() for value in entries):
        raise ValueError("Every imported entry must contain a nonempty username string.")
    if any(re.search(r"[\s,]", value.strip()) for value in entries):
        raise ValueError("Use one username per CSV row or JSON entry.")
    unique = dict.fromkeys(value.strip() for value in entries)
    return parse_usernames("\n".join(unique), batch_limit)


def filter_results(
    results: Iterable[Result], query: str = "", status: str = "All",
    sort_by: str | None = None, descending: bool = False,
) -> list[Result]:
    """Select visible rows without changing the complete result set."""
    query = query.strip().casefold()
    visible = [result for result in results if (status == "All" or result.status == status)
               and (not query or any(query in value.casefold() for value in (
                   result.username, result.site, result.status, result.detail,
               )))]
    if sort_by in ("username", "site", "status", "detail"):
        visible.sort(key=lambda result: getattr(result, sort_by).casefold(), reverse=descending)
    return visible


def lookup_name(site: Site, username: str) -> str:
    if site.key == "bluesky":
        return username.lower() if "." in username else username.lower() + ".bsky.social"
    return username


def format_error(site: Site, username: str) -> str | None:
    """Apply preliminary format checks, not a site's complete signup policy."""
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,253}", username):
        return "Use a username containing letters, numbers, _, - or ."
    if site.key == "github" and (
        len(username) > 39
        or not re.fullmatch(r"[A-Za-z0-9]+(?:-[A-Za-z0-9]+)*", username)
    ):
        return "GitHub: 1–39 letters/numbers; single hyphens between characters."
    if site.key == "roblox" and (
        not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_]{1,18}[A-Za-z0-9]", username)
        or username.count("_") > 1
    ):
        return "Roblox: 3–20 letters/numbers; at most one underscore, inside the name."
    if site.key == "bluesky":
        handle = lookup_name(site, username)
        labels = handle.split(".")
        if len(handle) > 253 or any(
            not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label)
            for label in labels
        ) or not re.match(r"[a-z]", labels[-1]):
            return "Bluesky: letters/numbers/hyphens, or a valid full domain handle."
    return None


def build_request(site: Site, username: str) -> urllib.request.Request:
    name = lookup_name(site, username)
    encoded = urllib.parse.quote(name, safe="")
    headers = {"User-Agent": f"UsernameChecker/{APP_VERSION}", "Accept": "application/json"}
    payload = None
    if site.key == "github":
        url = f"https://api.github.com/users/{encoded}"
        headers["Accept"] = "application/vnd.github+json"
        headers["X-GitHub-Api-Version"] = "2026-03-10"
    elif site.key == "gitlab":
        url = "https://gitlab.com/api/v4/users?" + urllib.parse.urlencode({"username": name})
    elif site.key == "roblox":
        url = "https://users.roblox.com/v1/usernames/users"
        headers["Content-Type"] = "application/json"
        payload = json.dumps({"usernames": [name], "excludeBannedUsers": False}).encode()
    elif site.key == "bluesky":
        url = "https://bsky.social/xrpc/com.atproto.identity.resolveHandle?" + (
            urllib.parse.urlencode({"handle": name})
        )
    elif site.key == "chesscom":
        url = f"https://api.chess.com/pub/player/{encoded}"
    else:
        raise ValueError(f"Unsupported site: {site.key}")
    return urllib.request.Request(url, data=payload, headers=headers)


def request_api(request: urllib.request.Request, timeout: float) -> APIResponse:
    """Read a bounded JSON response with TLS verification and no redirects."""
    opener = urllib.request.build_opener(NoRedirect())
    try:
        try:
            response = opener.open(request, timeout=timeout)
        except urllib.error.HTTPError as exc:
            response = exc
        with response:
            headers = {key.lower(): value for key, value in response.headers.items()}
            raw = response.read(MAX_RESPONSE_BYTES + 1)
            if len(raw) > MAX_RESPONSE_BYTES:
                raise CheckError("API response was unexpectedly large.")
            valid_json = "json" in headers.get("content-type", "").lower()
            try:
                data = json.loads(raw.decode("utf-8")) if valid_json else None
            except (ValueError, UnicodeError):
                valid_json, data = False, None
            return APIResponse(response.code, data, headers, valid_json)
    except (TimeoutError, socket.timeout) as exc:
        raise CheckError("Request timed out. Try again with a longer timeout.") from exc
    except urllib.error.URLError as exc:
        if isinstance(exc.reason, (TimeoutError, socket.timeout)):
            message = "Request timed out. Try again with a longer timeout."
        elif isinstance(exc.reason, ssl.SSLError):
            message = "Could not verify the site's secure connection."
        else:
            message = "Could not reach the site. Check your connection or proxy."
        raise CheckError(message) from exc
    except (OSError, ValueError, http.client.HTTPException) as exc:
        raise CheckError("Could not read the site's response. Try again later.") from exc


def matches_account(data: object, username: str, name_field: str, id_field: str = "id") -> bool:
    """Only an exact name with a positive numeric account ID confirms a match."""
    if not isinstance(data, dict):
        return False
    name, identity = data.get(name_field), data.get(id_field)
    return (isinstance(name, str) and name.casefold() == username.casefold()
            and type(identity) is int and identity > 0)


def interpret(site: Site, username: str, response: APIResponse) -> tuple[str, str, str]:
    """Require a matching identity or a recognized absence response."""
    profile = site.url_for(username)
    code, data = response.status, response.data
    unknown = ("Unknown", "The API returned an unexpected response.", profile)
    if site.manual:
        return "Manual check", site.manual_detail, profile
    if is_rate_limited(response):
        return "Unknown", "Rate limited. Wait before checking this site again.", profile
    if code in (401, 403):
        return "Unknown", "The site blocked this request or requires authentication.", profile
    if 300 <= code < 400:
        return "Unknown", "The API redirected the request; the name may have changed.", profile
    if code >= 500:
        return "Unknown", f"The site is unavailable (HTTP {code}). Try again later.", profile
    if not response.valid_json:
        return "Unknown", "Received a web page or invalid JSON instead of API data.", profile
    if site.key == "bluesky":
        if code == 200 and isinstance(data, dict) and isinstance(data.get("did"), str):
            if data["did"].startswith("did:") and len(data["did"]) > 4:
                return "Taken", "This handle resolves to an existing account.", profile
        if code in (400, 404) and isinstance(data, dict):
            if data.get("error") == "HandleNotFound":
                return "Not found", NOT_FOUND_DETAIL, profile
            if data.get("error") == "InvalidRequest" and data.get("message") == "Unable to resolve handle":
                return "Unknown", "Handle did not resolve; it may be missing or have a DNS/server error.", profile
        return unknown
    if code == 404 and isinstance(data, dict):
        if (site.key == "chesscom" and type(data.get("code")) is int and data["code"] == 0
                and data.get("message") == "Data not found"):
            return "Not found", NOT_FOUND_DETAIL, profile
        if site.key == "github" and data.get("message") == "Not Found":
            return "Not found", NOT_FOUND_DETAIL, profile
        return unknown
    if code != 200:
        return "Unknown", f"Could not check this name (HTTP {code}).", profile
    if site.key == "chesscom":
        if matches_account(data, username, "username", "player_id"):
            return "Taken", "An existing public account matched this username.", profile
        return unknown
    if site.key in ("gitlab", "roblox"):
        entries = data if site.key == "gitlab" else data.get("data") if isinstance(data, dict) else None
        if not isinstance(entries, list) or (isinstance(data, dict) and data.get("errors")):
            return unknown
        if not entries:
            return "Not found", NOT_FOUND_DETAIL, profile
        for entry in entries:
            field = "username" if site.key == "gitlab" else "requestedUsername"
            if not matches_account(entry, username, field):
                continue
            if site.key == "roblox":
                profile = f"https://www.roblox.com/users/{entry['id']}/profile"
                return "Taken", "An existing account matched this name (including banned accounts).", profile
            return "Taken", "An existing public account matched this username.", profile
        return unknown
    if site.key == "github" and matches_account(data, username, "login"):
        return "Taken", "An existing public account matched this username.", profile
    return unknown


def check_one(site: Site, username: str, timeout: float = 12.0, *, access: ApiAccess | None = None) -> Result:
    checked_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    profile = site.url_for(username)
    error = format_error(site, username)
    if error:
        return Result(username, site.name, "Invalid", "", error, checked_at)
    if site.manual:
        return Result(username, site.name, "Manual check", profile, site.manual_detail, checked_at)
    try:
        request = build_request(site, username)
        if access is not None:
            access.authorize(site.key, request)
        response = request_api(request, timeout)
        if access is not None:
            access.observe(site.key, response)
        status, detail, profile = interpret(site, username, response)
    except CheckError as exc:
        status, detail = "Unknown", str(exc)
    return Result(username, site.name, status, profile, detail, checked_at)


def build_bulk_request(site: Site, usernames: list[str]) -> urllib.request.Request:
    """Use Roblox's documented multi-name endpoint, with a conservative chunk cap."""
    if site.key != "roblox" or not 1 <= len(usernames) <= ROBLOX_BULK_SIZE:
        raise ValueError(f"Roblox bulk lookups need 1–{ROBLOX_BULK_SIZE} names.")
    if any(format_error(site, name) for name in usernames):
        raise ValueError("Validate names before sending a bulk request.")
    request = build_request(site, usernames[0])
    request.data = json.dumps({"usernames": usernames, "excludeBannedUsers": False}).encode("utf-8")
    return request


def check_bulk(site: Site, usernames: list[str], timeout: float = 12.0, *, access: ApiAccess | None = None) -> list[Result]:
    request = build_bulk_request(site, usernames)
    checked_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    try:
        if access is not None:
            access.authorize(site.key, request)
        response = request_api(request, timeout)
        if access is not None:
            access.observe(site.key, response)
    except CheckError as exc:
        return [Result(name, site.name, "Unknown", site.url_for(name),
                       str(exc), checked_at) for name in usernames]
    entries = response.data.get("data") if isinstance(response.data, dict) else None
    matches = {}
    valid_batch = (response.status == 200 and response.valid_json and isinstance(entries, list)
                   and not response.data.get("errors"))
    if valid_batch:
        requested = {name.casefold() for name in usernames}
        for entry in entries:
            if not isinstance(entry, dict):
                valid_batch = False
                break
            matched, identity = entry.get("requestedUsername"), entry.get("id")
            if (not isinstance(matched, str) or matched.casefold() not in requested
                    or matched.casefold() in matches or type(identity) is not int or identity <= 0):
                valid_batch = False
                break
            matches[matched.casefold()] = entry
    results = []
    for name in usernames:
        if valid_batch:
            entry = matches.get(name.casefold())
            individual = APIResponse(200, {"data": [entry] if entry else []}, response.headers)
            status, detail, profile = interpret(site, name, individual)
        elif response.status == 200:
            status, detail = "Unknown", "The API returned an unexpected bulk response."
            profile = site.url_for(name)
        else:
            status, detail, profile = interpret(site, name, response)
        results.append(Result(name, site.name, status, profile, detail, checked_at))
    return results


def run_checks(
    usernames: Iterable[str],
    sites: Iterable[Site],
    timeout: float = 12.0,
    cancel: threading.Event | None = None,
    on_result: Callable[[Result], None] | None = None,
    *,
    only: set[tuple[str, str]] | None = None,
    workers_done: threading.Event | None = None,
    batch_limit: int = DEFAULT_BATCH_LIMIT,
    cache: ResultCache | None = None,
    refresh: bool = False,
    pause: threading.Event | None = None,
    stats: CheckStats | None = None,
    access: ApiAccess | None = None,
) -> list[Result]:
    """Serialize each site's requests; bulk and cached results avoid redundant work.

    Set pause to stop scheduling, clear it to resume. Already-running requests
    may finish. Requests to each site run back to back without an added delay.
    Only a platform reporting a rate limit waits; unfinished requests are retried
    up to MAX_RATE_RETRIES times. Cancellation remains responsive while waiting.
    """
    batch_limit = validate_batch_limit(batch_limit)
    if not math.isfinite(timeout) or not 1 <= timeout <= 60:
        raise ValueError("Timeout must be between 1 and 60 seconds.")
    names = list(usernames)
    selected = list(sites)
    if not names or (batch_limit and len(names) > batch_limit) or not selected:
        raise ValueError("Choose at least one username and site, within your batch limit (0 means unlimited).")
    if len({site.key for site in selected}) != len(selected):
        raise ValueError("Choose each site only once.")
    if only is not None:
        name_set, site_keys = set(names), {site.key for site in selected}
        if not only or any(name not in name_set or key not in site_keys for name, key in only):
            raise ValueError("Retry targets must belong to the selected usernames and sites.")
    assignments = [(site, [name for name in names if only is None or (name, site.key) in only])
                   for site in selected]
    assignments = [(site, pending) for site, pending in assignments if pending]
    stop = cancel if cancel is not None else threading.Event()
    messages: queue.Queue[tuple[str, Result | None]] = queue.Queue()
    remaining_workers = len(assignments)
    worker_lock = threading.Lock()
    if workers_done is not None:
        workers_done.clear()

    counters = stats if stats is not None else CheckStats()
    access = access if access is not None else ApiAccess()

    def ready() -> bool:
        while pause is not None and pause.is_set():
            if stop.wait(0.05):
                return False
        return not stop.is_set()

    def publish(result: Result) -> None:
        if not stop.is_set():
            messages.put(("result", result))

    def worker(site: Site, pending: list[str]) -> None:
        nonlocal remaining_workers
        try:
            access.begin(site.key)
            network_names = []
            # Cache hits, invalid names and manual links do not need HTTP requests.
            for username in pending:
                if not ready():
                    break
                if site.manual or format_error(site, username):
                    try:
                        result = check_one(site, username, timeout)
                    except Exception:
                        result = Result(username, site.name, "Unknown", "",
                                        "Unexpected error while checking this site.",
                                        datetime.now(timezone.utc).isoformat(timespec="seconds"))
                    counters.add("local_results")
                    publish(result)
                else:
                    cached = cache.get(site, username) if cache is not None and not refresh else None
                    if cached is not None:
                        counters.add("cache_hits")
                        publish(cached)
                    else:
                        network_names.append(username)
            chunk_size = ROBLOX_BULK_SIZE if site.key == "roblox" else 1
            for offset in range(0, len(network_names), chunk_size):
                chunk = network_names[offset:offset + chunk_size]
                for attempt in range(MAX_RATE_RETRIES + 1):
                    if not ready() or not access.wait(site.key, stop, pause):
                        return
                    counters.add("requests")
                    try:
                        batch = (check_bulk(site, chunk, timeout, access=access) if len(chunk) > 1 else
                                 [check_one(site, chunk[0], timeout, access=access)])
                    except Exception:
                        # Keep an unexpected adapter failure from stopping other sites.
                        batch = [Result(
                            name, site.name, "Unknown", "", "Unexpected error while checking this site.",
                            datetime.now(timezone.utc).isoformat(timespec="seconds"),
                        ) for name in chunk]
                    limited = any(result.status == "Unknown" and result.detail.startswith("Rate limited.")
                                  for result in batch)
                    if not limited:
                        break
                    if attempt == MAX_RATE_RETRIES:
                        access.give_up(site.key)
                        return
                for result in batch:
                    if cache is not None:
                        cache.put(site, result)
                    publish(result)
        finally:
            with worker_lock:
                remaining_workers -= 1
                if remaining_workers == 0 and workers_done is not None:
                    workers_done.set()
            messages.put(("done", None))

    started = 0
    try:
        for site, pending in assignments:
            threading.Thread(target=worker, args=(site, pending), daemon=True).start()
            started += 1
    except Exception:
        stop.set()
        with worker_lock:
            remaining_workers -= len(assignments) - started
            if remaining_workers == 0 and workers_done is not None:
                workers_done.set()
        raise
    results: list[Result] = []
    finished = 0
    try:
        while finished < len(assignments) and not stop.is_set():
            try:
                event, result = messages.get(timeout=0.1)
            except queue.Empty:
                continue
            if event == "done":
                finished += 1
            elif result is not None:
                results.append(result)
                if on_result is not None:
                    on_result(result)
    finally:
        stop.set()
    return results


def result_text(results: Iterable[Result]) -> str:
    lines = ["Username\tSite\tStatus\tProfile\tDetails"]
    for result in results:
        lines.append("\t".join((
            result.username, result.site, result.status, result.profile_url, result.detail,
        )))
    return "\n".join(lines)


@contextmanager
def atomic_text_output(path: Path):
    """Keep the previous file intact if streaming an export fails."""
    temp_name = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", newline="", dir=path.parent,
            prefix=".username-checker-", suffix=".tmp", delete=False,
        ) as output:
            temp_name = output.name
            yield output
            output.flush()
            os.fsync(output.fileno())
        os.replace(temp_name, path)
    finally:
        if temp_name is not None:
            Path(temp_name).unlink(missing_ok=True)


def write_json_array(stream, values: Iterable[object]) -> None:
    stream.write("[")
    first = True
    for value in values:
        stream.write("\n  " if first else ",\n  ")
        stream.write(json.dumps(value, ensure_ascii=False))
        first = False
    stream.write("\n]\n" if not first else "]\n")


def csv_cell(value: str) -> str:
    return "'" + value if value.startswith(("=", "+", "-", "@", "\t", "\r")) else value


def export_results(path: Path, results: Iterable[Result]) -> None:
    """Stream JSON or spreadsheet-safe CSV without materializing all results."""
    extension = path.suffix.lower()
    if extension not in (".csv", ".json"):
        raise ValueError("Choose a filename ending in .csv or .json.")
    with atomic_text_output(path) as output:
        if extension == ".json":
            write_json_array(output, (asdict(result) for result in results))
        else:
            output.write("\ufeff")
            writer = csv.DictWriter(output, fieldnames=list(Result.__dataclass_fields__))
            writer.writeheader()
            for result in results:
                writer.writerow({key: csv_cell(value) for key, value in asdict(result).items()})


def unique_chunk_names(chunks, wanted=None):
    """Generated names do not repeat between chunks; retain only one chunk's set."""
    for chunk in chunks:
        seen = set()
        for result in chunk:
            if (wanted is None or result.status == wanted) and result.username not in seen:
                seen.add(result.username)
                yield result.username


def export_names(path: Path, names: Iterable[str]) -> None:
    if path.suffix.lower() not in (".txt", ".json"):
        raise ValueError("Choose a .txt or .json file for generated names.")
    with atomic_text_output(path) as output:
        if path.suffix.lower() == ".json":
            write_json_array(output, names)
        else:
            for name in names:
                output.write(name + "\n")


class ResultJournal:
    """A session-only disk journal; exports read a consistent completed prefix."""

    def __init__(self):
        self.directory = tempfile.TemporaryDirectory(prefix="username-checker-")
        self.path = Path(self.directory.name) / "results.jsonl"
        self.lock = threading.Lock()
        self.stream = self.path.open("w", encoding="utf-8", newline="\n")

    def append(self, result: Result) -> None:
        with self.lock:
            self.stream.write(json.dumps(asdict(result), ensure_ascii=False) + "\n")

    def begin_chunk(self, names, sites):
        with self.lock:
            self.stream.write(json.dumps({"chunk_names": names, "chunk_sites": sites}) + "\n")

    def flush(self):
        with self.lock:
            self.stream.flush()

    def read_chunks(self) -> Iterable[list[Result]]:
        with self.lock:
            self.stream.flush()
            end = self.path.stat().st_size
        def records():
            pending, name_order, site_order = [], {}, {}
            def ordered():
                return sorted(pending, key=lambda result: (name_order.get(result.username, 0), site_order.get(result.site, 0)))
            with self.path.open("rb") as source:
                remaining = end
                while remaining:
                    line = source.readline(remaining)
                    if not line:
                        break
                    remaining -= len(line)
                    record = json.loads(line)
                    if "chunk_names" in record:
                        if pending:
                            yield ordered()
                            pending = []
                        name_order = {name: index for index, name in enumerate(record["chunk_names"])}
                        site_order = {name: index for index, name in enumerate(record["chunk_sites"])}
                    else:
                        pending.append(Result(**record))
            if pending:
                yield ordered()
        return records()

    def read(self) -> Iterable[Result]:
        return itertools.chain.from_iterable(self.read_chunks())

    def close(self):
        with self.lock:
            try:
                self.stream.close()
            except OSError:
                # Closing a failed disk journal must still release its temp files.
                pass
            self.directory.cleanup()


class LargeBatchJob:
    """Consume a finite source in small chunks and retain full results on disk."""

    def __init__(self, names: Iterable[str], count: int, sites: Iterable[Site], timeout=12.0,
                 *, generate_only=False, cache=None, refresh=False, source_spec=None, access=None,
                 match_rule=None, chunk_size=None):
        selected = list(sites)
        if type(count) is not int or count < 1 or (not generate_only and not selected):
            raise ValueError("A large job needs names and at least one checking site.")
        if not math.isfinite(timeout) or not 1 <= timeout <= 60:
            raise ValueError("Timeout must be between 1 and 60 seconds.")
        if len({site.key for site in selected}) != len(selected):
            raise ValueError("Choose each site only once.")
        if match_rule is not None and (match_rule not in FINDER_MATCHES.values() or generate_only or any(site.manual for site in selected)):
            raise ValueError("Continuous finding needs automatic platforms and an any/all match rule.")
        if chunk_size is not None and (type(chunk_size) is not int or not 1 <= chunk_size <= CHECK_CHUNK_SIZE):
            raise ValueError(f"Processing chunks must contain 1–{CHECK_CHUNK_SIZE} names.")
        self.source, self.count, self.sites, self.timeout = iter(names), count, selected, timeout
        self.generate_only, self.cache, self.refresh = generate_only, cache, refresh
        self.access = access if access is not None else ApiAccess()
        self.source_spec, self.session_reader = source_spec, None
        self.match_rule, self.chunk_size = match_rule, chunk_size
        self.saving = False
        self.journal = ResultJournal()
        self.matches = ResultJournal() if match_rule is not None else None
        self.match_preview = deque(maxlen=RESULT_PREVIEW_SIZE)
        self.match_results, self.matched_names = {}, set()
        self.found_count = self.found_rows = self.checked_names = 0
        self.preview = deque(maxlen=RESULT_PREVIEW_SIZE)
        self.counts, self.stats = Counter(), CheckStats()
        self.lock = threading.Lock()
        self.cancel, self.pause, self.halt = threading.Event(), threading.Event(), threading.Event()
        self.done, self.workers_done = threading.Event(), threading.Event()
        self.done.set()
        self.workers_done.set()
        self.pending_names, self.pending_pairs = [], set()
        self.pulled = self.completed = 0
        self.total = count * (1 if generate_only else len(selected))
        self.exhausted = self.closed = self.close_requested = False
        self.error, self.reason = "", ""
        self.site_keys = {site.name: site.key for site in selected}

    def start(self) -> bool:
        if (self.closed or self.close_requested or self.saving or not self.done.is_set() or not self.workers_done.is_set()
                or (not self.pending_pairs and (self.exhausted or self.pulled >= self.count))):
            return False
        self.cancel = threading.Event()
        self.halt.clear()
        self.pause.clear()
        self.error = self.reason = ""
        self.done.clear()
        try:
            threading.Thread(target=self._run, daemon=True).start()
        except Exception:
            self.done.set()
            raise
        return True

    def stop(self):
        self.halt.set()
        self.cancel.set()

    def _ready(self):
        while self.pause.is_set():
            if self.cancel.wait(0.05):
                return False
        return not self.cancel.is_set() and not self.halt.is_set()

    def _record(self, result):
        self.journal.append(result)
        with self.lock:
            self.pending_pairs.discard((result.username, "" if self.generate_only else self.site_keys[result.site]))
            self.completed += 1
            self.counts[result.status] += 1
            self.preview.append(result)
        self._collect_match(result)

    def _begin_matches(self, names):
        if self.matches is not None:
            self.match_results.clear()
            self.matched_names.clear()
            self.matches.begin_chunk(names, [site.name for site in self.sites])

    def _collect_match(self, result):
        if self.matches is None:
            return
        statuses = self.match_results.setdefault(result.username, {})
        if result.site in statuses:
            return
        statuses[result.site] = result
        complete = len(statuses) == len(self.sites)
        records = []
        if self.match_rule == "any" and result.status == "Not found":
            records = [result]
        elif self.match_rule == "all" and complete and all(value.status == "Not found" for value in statuses.values()):
            records = [statuses[site.name] for site in self.sites]
        for record in records:
            self.matches.append(record)
        with self.lock:
            if complete:
                self.checked_names += 1
            if records and result.username not in self.matched_names:
                self.found_count += 1
                self.matched_names.add(result.username)
            self.found_rows += len(records)
            self.match_preview.extend(records)

    def match_snapshot(self):
        with self.lock:
            return self.found_count, self.checked_names, self.found_rows, list(self.match_preview)

    def output_journal(self):
        return self.matches if self.matches is not None else self.journal

    def _run(self):
        try:
            while self._ready():
                if not self.pending_pairs:
                    if self.pulled >= self.count:
                        self.exhausted = True
                        break
                    self.pending_names = list(itertools.islice(self.source, min(self.chunk_size or CHECK_CHUNK_SIZE, self.count - self.pulled)))
                    if not self.pending_names:
                        self.exhausted = True
                        break
                    self.pulled += len(self.pending_names)
                    keys = [""] if self.generate_only else [site.key for site in self.sites]
                    self.pending_pairs = {(name, key) for name in self.pending_names for key in keys}
                    self.journal.begin_chunk(self.pending_names, [""] if self.generate_only else [site.name for site in self.sites])
                    self._begin_matches(self.pending_names)
                if self.generate_only:
                    for name in self.pending_names:
                        if (name, "") not in self.pending_pairs:
                            continue
                        if not self._ready():
                            break
                        self._record(Result(name, "", "Generated", "", "", ""))
                else:
                    run_checks(self.pending_names, self.sites, self.timeout, self.cancel, self._record,
                               only=set(self.pending_pairs), workers_done=self.workers_done, batch_limit=0,
                               pause=self.pause, cache=self.cache, refresh=self.refresh, stats=self.stats, access=self.access)
                    limited = self.access.exhausted_sites() & {key for _, key in self.pending_pairs}
                    if limited:
                        if self.match_rule is not None and not self.halt.is_set():
                            for key in limited:
                                self.access.continue_after_cooldown(key)
                            self.cancel.clear()
                            continue
                        else:
                            self.reason = "Automatic rate-limit retries exhausted. Unfinished checks are kept; use Continue to retry."
                            self.halt.set()
                    # run_checks sets its cancel event on normal completion too.
                    if not self.pending_pairs and not self.halt.is_set():
                        self.cancel.clear()
                if self.pending_pairs:
                    break
                self.journal.flush()
                if self.matches is not None:
                    self.matches.flush()
                self.pending_names = []
        except Exception as exc:
            self.error = f"The large batch could not finish: {exc}"
            self.cancel.set()
        finally:
            try:
                self.journal.flush()
                if self.matches is not None:
                    self.matches.flush()
            except OSError as exc:
                self.error = f"The result journal could not be written: {exc}"
            self.done.set()
            if self.close_requested:
                self.close()

    def snapshot(self):
        with self.lock:
            return self.completed, self.total, list(self.preview), dict(self.counts)

    def save_checkpoint(self, path: Path, settings=None):
        if self.closed or self.saving or not self.done.is_set() or not self.workers_done.is_set():
            raise ValueError("Stop the batch and wait for current requests before saving a session.")
        if self.source_spec is None:
            raise ValueError("This batch has no resumable source description.")
        self.saving = True
        try:
            state = checkpoint_state(self.count, self.pulled, self.sites, self.timeout, self.generate_only,
                                     self.pending_names, self.pending_pairs, self.completed, self.source_spec, settings)
            if self.match_rule is not None:
                state["finder"] = {"match_rule": self.match_rule, "chunk_size": self.chunk_size or CHECK_CHUNK_SIZE}
            names = self.source_spec.get("names", ())
            write_session(path, state, (asdict(result) for result in self.journal.read()), names() if callable(names) else names)
        finally:
            self.saving = False
            if self.close_requested:
                self.close()

    def close(self):
        self.close_requested = True
        self.stop()
        if self.done.is_set() and not self.saving:
            with self.lock:
                if self.closed:
                    return
                self.closed = True
                self.pending_names = []
                self.pending_pairs.clear()
                self.preview.clear()
                self.match_preview.clear()
                self.match_results.clear()
                self.matched_names.clear()
            self.journal.close()
            if self.matches is not None:
                self.matches.close()
            close_source = getattr(self.source, "close", None)
            if close_source is not None:
                close_source()
            self.source = iter(())
            self.source_spec = None
            if self.session_reader is not None:
                self.session_reader.close()
                self.session_reader = None


def checkpoint_state(count, pulled, sites, timeout, generate_only, pending_names, pending_pairs,
                     completed, source_spec, settings=None):
    return {"format": "UsernameCheckerSession", "version": 1, "app_version": APP_VERSION,
            "count": count, "pulled": pulled, "sites": [site.key for site in sites], "timeout": timeout,
            "generate_only": generate_only, "pending_names": list(pending_names),
            "pending_pairs": sorted(pending_pairs), "completed": completed,
            "source": {key: value for key, value in source_spec.items() if key != "names"},
            "settings": settings or {}}


def load_checkpoint(path: Path) -> tuple[LargeBatchJob, dict]:
    """Validate a saved snapshot without requests, then reconstruct a stopped job."""
    reader, job = None, None
    try:
        reader = SessionReader(path)
        state = reader.state
        if state.get("format") != "UsernameCheckerSession" or state.get("version") != 1:
            raise ValueError("This is not a supported Username checker session.")
        count, pulled, completed = (state[key] for key in ("count", "pulled", "completed"))
        if any(type(value) is not int or value < 0 for value in (count, pulled, completed)) or not count or pulled > count:
            raise ValueError("Invalid session progress.")
        keys, generated = state["sites"], state["generate_only"]
        if (not isinstance(keys, list) or any(key not in SITE_BY_KEY for key in keys)
                or len(set(keys)) != len(keys) or type(generated) is not bool or (not generated and not keys)):
            raise ValueError("The session contains unsupported platform choices.")
        selected = [SITE_BY_KEY[key] for key in keys]
        pair_keys = [""] if generated else keys
        pending_names, raw_pairs = state["pending_names"], state["pending_pairs"]
        max_chunk = max(CHECK_CHUNK_SIZE, LARGE_BATCH_THRESHOLD // len(pair_keys))
        if (not isinstance(pending_names, list) or len(pending_names) > min(pulled, max_chunk)
                or len(set(pending_names)) != len(pending_names)
                or any(not isinstance(name, str) or not re.fullmatch(r"[A-Za-z0-9_.-]{1,253}", name) for name in pending_names)):
            raise ValueError("Invalid pending names in the session.")
        pending = {tuple(pair) for pair in raw_pairs}
        if (len(pending) != len(raw_pairs) or any(len(pair) != 2 or pair[0] not in pending_names
                                                or pair[1] not in pair_keys for pair in pending)):
            raise ValueError("Invalid pending checks in the session.")
        if completed != pulled * len(pair_keys) - len(pending):
            raise ValueError("The session's results and progress disagree.")
        source = state["source"]
        if source["kind"] == "generator":
            config, start = source["config"], source["start"]
            if type(start) is not int or start < 0 or (config.get("seed") is not None and type(config["seed"]) is not int):
                raise ValueError("Invalid generator state.")
            sequence = CharacterSearch(**config)
            if start + count > sequence.total or reader.name_count:
                raise ValueError("The saved generator range is invalid.")
            def candidates(offset=0):
                search = CharacterSearch(**config)
                search.position = start + offset
                return search.iter_take(count - offset) if offset < count else iter(())
            source_spec = source
        elif source["kind"] == "names":
            if reader.name_count != count:
                raise ValueError("The saved name list is incomplete.")
            for name in reader.names():
                if not re.fullmatch(r"[A-Za-z0-9_.-]{1,253}", name):
                    raise ValueError("The saved list contains an invalid username.")
            candidates = reader.names
            source_spec = {"kind": "names", "names": reader.names}
        else:
            raise ValueError("Unsupported session source.")
        if pending_names and list(itertools.islice(candidates(pulled - len(pending_names)), len(pending_names))) != pending_names:
            raise ValueError("Pending names do not match the saved source.")
        finder = state.get("finder", {})
        if "finder" in state and (not isinstance(finder, dict) or set(finder) != {"match_rule", "chunk_size"}
                                  or finder["match_rule"] not in FINDER_MATCHES.values()):
            raise ValueError("Invalid continuous finder settings.")
        job = LargeBatchJob(candidates(pulled), count, selected, state["timeout"],
                            generate_only=generated, source_spec=source_spec, **finder)
        job.pulled, job.pending_names, job.pending_pairs = pulled, pending_names, pending
        expected = ((name, key) for name in itertools.islice(candidates(), pulled)
                    for key in pair_keys if (name, key) not in pending)
        partial, block = [], []
        def append_block(values):
            if values:
                job.journal.begin_chunk(list(dict.fromkeys(result.username for result in values)),
                                        [""] if generated else [site.name for site in selected])
                job._begin_matches(list(dict.fromkeys(result.username for result in values)))
                for result in values:
                    job.journal.append(result)
                    job._collect_match(result)
        by_name = {site.name: site for site in selected}
        pending_set = set(pending_names)
        for record in reader.records():
            result = Result(**record)
            if any(not isinstance(value, str) for value in asdict(result).values()):
                raise ValueError("Invalid saved result fields.")
            site = by_name.get(result.site)
            key = "" if generated else site.key if site is not None else None
            if ((result.username, key) != next(expected, None)
                    or result.status not in (("Generated",) if generated else tuple(STATUS_FILTERS.values())[1:])):
                raise ValueError("Saved results do not match the batch's names and platforms.")
            if result.profile_url:
                url = urllib.parse.urlsplit(result.profile_url)
                if site is None or url.scheme != "https" or url.netloc != urllib.parse.urlsplit(site.url_for(result.username)).netloc:
                    raise ValueError("A saved result contains an unsupported profile link.")
            if result.username in pending_set:
                partial.append(result)
            else:
                if block and block[-1].username != result.username and len(block) >= CHECK_CHUNK_SIZE:
                    append_block(block)
                    block.clear()
                block.append(result)
            job.completed += 1
            job.counts[result.status] += 1
            job.preview.append(result)
        append_block(block)
        if pending_names:
            job.journal.begin_chunk(pending_names, [""] if generated else [site.name for site in selected])
            job._begin_matches(pending_names)
            for result in partial:
                job.journal.append(result)
                job._collect_match(result)
        if job.completed != completed or next(expected, None) is not None:
            raise ValueError("The session has missing or extra result rows.")
        job.journal.flush()
        if job.matches is not None:
            job.matches.flush()
        job.session_reader = reader
        return job, state.get("settings", {})
    except Exception as exc:
        if job is not None:
            job.close()
        if reader is not None:
            reader.close()
        raise ValueError(f"Could not open this session: {exc}") from exc


def compare_results(results: Iterable[Result], expected_sites: Iterable[str] = ()):
    """Return a matrix of actual statuses; missing pairs remain Unchecked."""
    accounts, sites = {}, list(dict.fromkeys(expected_sites))
    for result in results:
        if result.status == "Generated":
            continue
        if result.site not in sites:
            sites.append(result.site)
        accounts.setdefault(result.username, {})[result.site] = result.status
    rows = [(name, [statuses.get(site, "Unchecked") for site in sites]) for name, statuses in accounts.items()]
    rows.sort(key=lambda row: (-row[1].count("Not found"), row[1].count("Taken"), row[0].casefold()))
    return sites, rows


class ComparisonWindow:
    """A snapshot comparison, with an honest shortlist and spreadsheet export."""

    def __init__(self, owner, results, *, parent=None, preview=False, expected_sites=()):
        self.owner = owner
        tk, ttk = owner.tk, owner.ttk
        self.dialog = tk.Toplevel(parent or owner.root)
        self.dialog.title("Compare usernames" + (" - latest preview only" if preview else ""))
        self.dialog.geometry("960x540")
        self.dialog.minsize(700, 420)
        self.dialog.transient(parent or owner.root)
        self.sites, self.rows = compare_results(results, expected_sites)
        self.filtered = []
        self.search = tk.StringVar(self.dialog)
        self.shortlist = tk.BooleanVar(self.dialog, value=False)
        frame = ttk.Frame(self.dialog, padding=18)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(3, weight=1)
        ttk.Label(frame, text="Compare usernames", style="DialogTitle.TLabel").grid(row=0, column=0, sticky="w")
        description = ttk.Label(frame, text=("Latest preview rows only. " if preview else "Snapshot of this batch. ") +
                  "Not found still needs signup confirmation. Manual, Unknown, and Unchecked remain unresolved.",
                  wraplength=860, style="Muted.TLabel")
        description.grid(row=1, column=0, sticky="w", pady=(6, 16))
        frame.bind("<Configure>", lambda event: description.configure(wraplength=max(300, event.width - 40)))
        filters = ttk.Frame(frame)
        filters.grid(row=2, column=0, sticky="ew", pady=(0, 10))
        ttk.Label(filters, text="Name").pack(side="left")
        ttk.Entry(filters, textvariable=self.search, width=25).pack(side="left", padx=8)
        ttk.Checkbutton(filters, text="Every platform returned Not found", variable=self.shortlist).pack(side="left")
        table_frame = ttk.Frame(frame, style="Card.TFrame")
        table_frame.grid(row=3, column=0, sticky="nsew")
        table_frame.columnconfigure(0, weight=1)
        table_frame.rowconfigure(0, weight=1)
        columns = ("username", *(f"site_{index}" for index in range(len(self.sites))))
        self.table = ttk.Treeview(table_frame, columns=columns, show="headings")
        for column, title in zip(columns, ("Username", *self.sites)):
            self.table.heading(column, text=title)
            self.table.column(column, width=165 if column == "username" else 135, stretch=False)
        self.table.grid(row=0, column=0, sticky="nsew")
        vertical = ttk.Scrollbar(table_frame, command=self.table.yview)
        vertical.grid(row=0, column=1, sticky="ns")
        horizontal = ttk.Scrollbar(table_frame, orient="horizontal", command=self.table.xview)
        horizontal.grid(row=1, column=0, sticky="ew")
        self.table.configure(yscrollcommand=vertical.set, xscrollcommand=horizontal.set)
        bottom = ttk.Frame(frame)
        bottom.grid(row=4, column=0, sticky="ew", pady=(12, 0))
        self.summary = tk.StringVar(self.dialog)
        ttk.Label(bottom, textvariable=self.summary).pack(side="left")
        ttk.Button(bottom, text="Close", command=self.dialog.destroy).pack(side="right")
        ttk.Button(bottom, text="Export comparison...", style="Primary.TButton", command=self.export).pack(side="right", padx=8)
        ttk.Button(bottom, text="Copy shown names", command=self.copy_names).pack(side="right")
        self.search.trace_add("write", lambda *_: self.refresh())
        self.shortlist.trace_add("write", lambda *_: self.refresh())
        self.refresh()
        paint_widgets(self.dialog, owner.palette)

    def refresh(self):
        query = self.search.get().strip().casefold()
        self.filtered = [(name, statuses) for name, statuses in self.rows if (not query or query in name.casefold())
                         and (not self.shortlist.get() or (statuses and all(status == "Not found" for status in statuses)))]
        rows = self.table.get_children()
        if rows:
            self.table.delete(*rows)
        for name, statuses in self.filtered:
            self.table.insert("", "end", values=(name, *statuses))
        self.summary.set(f"{len(self.filtered):,} of {len(self.rows):,} names")

    def copy_names(self):
        if self.filtered:
            self.dialog.clipboard_clear()
            self.dialog.clipboard_append("\n".join(name for name, _ in self.filtered))

    def export(self):
        filename = self.owner.filedialog.asksaveasfilename(title="Export username comparison", defaultextension=".csv",
                                                         initialfile="username_comparison.csv", filetypes=(("CSV", "*.csv"),))
        if filename:
            try:
                with atomic_text_output(Path(filename)) as stream:
                    stream.write("\ufeff")
                    writer = csv.writer(stream)
                    writer.writerow(["username", *self.sites])
                    for name, statuses in self.filtered:
                        writer.writerow([csv_cell(name), *statuses])
            except (OSError, ValueError) as exc:
                self.owner.messagebox.showerror("Export failed", str(exc))


class LargeBatchWindow:
    """A bounded live preview with complete, streaming exports for large jobs."""

    def __init__(self, owner, job: LargeBatchJob, on_close=None, *, autostart=True):
        self.owner, self.job, self.on_close = owner, job, on_close
        tk, ttk = owner.tk, owner.ttk
        self.dialog = tk.Toplevel(owner.root)
        self.dialog.title("Continuous username finder" if job.match_rule else "Large username batch")
        self.dialog.geometry("1060x720")
        self.dialog.minsize(820, 540)
        self.dialog.transient(owner.root)
        self.dialog.grab_set()
        self.closing = self.exporting = False
        self.export_events = queue.Queue()
        self.last_render = -1
        self.visible = []
        self.row_results = {}
        frame = ttk.Frame(self.dialog, padding=18)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(5, weight=1)
        ttk.Label(frame, text="Found usernames" if job.match_rule else "Batch results", style="DialogTitle.TLabel").grid(row=0, column=0, sticky="w", pady=(0, 10))
        self.status = tk.StringVar(self.dialog, value="Starting large batch…")
        status_label = ttk.Label(frame, textvariable=self.status, wraplength=1000)
        status_label.grid(row=1, column=0, sticky="ew")
        self.activity = tk.StringVar(self.dialog)
        activity_label = ttk.Label(frame, textvariable=self.activity, style="Muted.TLabel", wraplength=1000)
        activity_label.grid(row=2, column=0, sticky="w", pady=8)
        progress_track, self.progress = progressbar(frame, ttk, maximum=1000)
        progress_track.grid(row=3, column=0, sticky="ew", pady=(0, 12))
        self.hint = tk.StringVar(self.dialog, value=f"Preview shows the latest {RESULT_PREVIEW_SIZE} rows. "
                                 "Export all keeps every completed row. Save a session to continue later.")
        if job.match_rule:
            self.hint.set(f"Showing names reported Not found on {job.match_rule} selected platform{'s' if job.match_rule == 'all' else ''}. "
                          "Confirm availability when signing up. Stop keeps your finds; Continue resumes the search.")
        hint_label = ttk.Label(frame, textvariable=self.hint, wraplength=1000, style="Muted.TLabel")
        hint_label.grid(row=4, column=0, sticky="ew", pady=(0, 12))
        def wrap_labels(event):
            for label in (status_label, activity_label, hint_label):
                label.configure(wraplength=max(400, event.width - 40))
        frame.bind("<Configure>", wrap_labels)
        table_frame = ttk.Frame(frame, style="Card.TFrame")
        table_frame.grid(row=5, column=0, sticky="nsew")
        table_frame.columnconfigure(0, weight=1)
        table_frame.rowconfigure(0, weight=1)
        self.table = ttk.Treeview(table_frame, columns=("username", "site", "status", "detail"), show="headings")
        for key, title, width in (("username", "Username", 160), ("site", "Site", 120), ("status", "Result", 110), ("detail", "Details", 520)):
            self.table.heading(key, text=title)
            self.table.column(key, width=width, minwidth=80, stretch=key == "detail")
        self.table.grid(row=0, column=0, sticky="nsew")
        scroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.table.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        self.table.configure(yscrollcommand=scroll.set)
        self.table.bind("<Double-1>", lambda event: self.open_page())
        controls = ttk.Frame(frame)
        controls.grid(row=6, column=0, sticky="ew", pady=(12, 0))
        run_controls = ttk.Frame(controls)
        run_controls.pack(fill="x")
        file_controls = ttk.Frame(controls)
        file_controls.pack(fill="x", pady=(8, 0))
        self.pause_button = ttk.Button(run_controls, text="Pause", command=self.toggle_pause)
        self.pause_button.pack(side="left")
        self.stop_button = ttk.Button(run_controls, text="Stop", style="Danger.TButton", command=job.stop)
        self.stop_button.pack(side="left", padx=8)
        self.continue_button = ttk.Button(run_controls, text="Continue", command=lambda: job.start() if not self.exporting else None)
        self.continue_button.pack(side="left")
        self.close_button = ttk.Button(run_controls, text="Close", command=self.request_close)
        self.close_button.pack(side="right")
        self.export_button = ttk.Button(file_controls, text="Export found..." if job.match_rule else "Export all...", style="Primary.TButton", command=self.export_all)
        self.export_button.pack(side="right")
        self.session_button = ttk.Button(file_controls, text="Save session...", command=self.save_session)
        self.session_button.pack(side="right", padx=(0, 8))
        self.open_button = ttk.Button(file_controls, text="Open page", command=self.open_page,
                                      state="disabled" if job.generate_only else "normal")
        self.open_button.pack(side="left")
        self.copy_button = ttk.Button(file_controls, text="Copy preview", command=self.copy_preview)
        self.copy_button.pack(side="left", padx=8)
        self.dialog.protocol("WM_DELETE_WINDOW", self.request_close)
        self.dialog.bind("<Escape>", lambda event: job.stop())
        menubar = tk.Menu(self.dialog)
        self.file_menu = tk.Menu(menubar, tearoff=False)
        self.file_menu.add_command(label="Save session...", command=self.save_session, accelerator="Ctrl+S")
        self.file_menu.add_command(label="Compare preview usernames...", command=self.compare_names,
                                   state="disabled" if job.generate_only else "normal")
        menubar.add_cascade(label="File", menu=self.file_menu)
        self.dialog.configure(menu=menubar)
        self.dialog.bind("<Control-s>", lambda event: self.save_session())
        if autostart:
            job.start()
        else:
            self.hint.set("Saved session restored without requests. Continue resumes unfinished checks; export includes saved results.")
        paint_widgets(self.dialog, owner.palette)
        self.poll_id = self.dialog.after(80, self.poll)

    def save_session(self):
        if self.exporting or not self.job.done.is_set() or not self.job.workers_done.is_set():
            self.hint.set("Stop the batch and wait for current requests before saving a session.")
            return
        filename = self.owner.filedialog.asksaveasfilename(title="Save username session", defaultextension=".ucsession",
                                                         initialfile="username_session.ucsession", filetypes=(("Username session", "*.ucsession"),))
        if not filename:
            return
        try:
            settings = self.owner.get_preferences()
        except (ValueError, KeyError, TypeError) as exc:
            self.owner.messagebox.showerror("Check your settings", str(exc))
            return
        self.exporting = True
        self.hint.set("Saving the complete session. Please wait before continuing or closing.")
        def save():
            try:
                self.job.save_checkpoint(Path(filename), settings)
                self.export_events.put((True, f"Saved {Path(filename).name}; open it later to continue this batch."))
            except Exception as exc:
                self.export_events.put((False, str(exc)))
        threading.Thread(target=save, daemon=True).start()

    def compare_names(self):
        if not self.job.generate_only and self.visible:
            return ComparisonWindow(self.owner, list(self.visible), parent=self.dialog, preview=True,
                                    expected_sites=[site.name for site in self.job.sites])

    def toggle_pause(self):
        if self.job.pause.is_set():
            self.job.pause.clear()
        else:
            self.job.pause.set()

    def copy_preview(self):
        if self.visible:
            self.dialog.clipboard_clear()
            self.dialog.clipboard_append("\n".join(dict.fromkeys(r.username for r in self.visible))
                                         if self.job.generate_only or self.job.match_rule else result_text(self.visible))

    def open_page(self):
        selected = self.table.selection()
        result = self.row_results.get(selected[0]) if selected else None
        if result is not None and result.profile_url:
            try:
                opened = webbrowser.open(result.profile_url)
            except webbrowser.Error:
                opened = False
            if not opened:
                self.owner.messagebox.showinfo("Profile link", result.profile_url)

    def export_all(self):
        if self.exporting:
            return
        names = self.job.generate_only
        finder = self.job.match_rule is not None
        filename = self.owner.filedialog.asksaveasfilename(
            title="Export found usernames" if finder else "Export all completed names" if names else "Export all completed results",
            defaultextension=".txt" if names or finder else ".csv",
            initialfile="found_usernames.txt" if finder else "generated_names.txt" if names else "username_results.csv",
            filetypes=(("Text names", "*.txt"), ("CSV", "*.csv"), ("JSON", "*.json")) if finder else
                      (("Text names", "*.txt"), ("JSON", "*.json")) if names else (("CSV", "*.csv"), ("JSON", "*.json")))
        if not filename:
            return
        try:
            chunks = self.job.output_journal().read_chunks()
        except (OSError, ValueError) as exc:
            self.owner.messagebox.showerror("Export failed", str(exc))
            return
        self.exporting = True
        self.hint.set("Exporting the completed rows. You can keep using the batch controls.")
        def save():
            try:
                if finder and Path(filename).suffix.lower() == ".txt":
                    export_names(Path(filename), unique_chunk_names(chunks))
                elif names:
                    export_names(Path(filename), (result.username for chunk in chunks for result in chunk))
                else:
                    export_results(Path(filename), itertools.chain.from_iterable(chunks))
                self.export_events.put((True, f"Saved {Path(filename).name}."))
            except Exception as exc:
                self.export_events.put((False, str(exc)))
        threading.Thread(target=save, daemon=True).start()

    def request_close(self):
        self.closing = True
        self.job.stop()
        self.hint.set("Closing after current requests and any export finish…")
        if self.job.done.is_set() and self.job.workers_done.is_set() and not self.exporting:
            self.finish_close()

    def finish_close(self):
        self.dialog.after_cancel(self.poll_id)
        if self.on_close is not None:
            self.on_close()
        self.job.close()
        self.dialog.grab_release()
        self.dialog.destroy()
        if self in self.owner.large_windows:
            self.owner.large_windows.remove(self)

    def poll(self):
        try:
            success, message = self.export_events.get_nowait()
            self.exporting = False
            self.hint.set(message)
            if not success:
                self.owner.messagebox.showerror("Export failed", message)
        except queue.Empty:
            pass
        completed, total, preview, counts = self.job.snapshot()
        render_version = completed
        found = checked = 0
        if self.job.match_rule:
            found, checked, render_version, preview = self.job.match_snapshot()
        running = not self.job.done.is_set()
        phase = "Failed" if self.job.error else "Paused" if running and self.job.pause.is_set() else (
            "Generating" if running and self.job.generate_only else "Searching" if running and self.job.match_rule else "Checking" if running else
            "Finished" if completed == total else "Stopped")
        self.status.set(f"{phase} · {format_candidate_count(completed)} / {format_candidate_count(total)} rows · "
                        + " · ".join(f"{value:,} {key.lower()}" for key, value in counts.items()))
        if self.job.match_rule:
            self.status.set(f"{phase} · {format_candidate_count(completed)} / {format_candidate_count(total)} platform checks · "
                            f"{format_candidate_count(found)} names found")
        if running and not self.job.pause.is_set() and not self.job.cancel.is_set():
            cooldown = cooldown_summary(self.job.access, self.job.sites)
            if cooldown:
                self.status.set(self.status.get() + " · " + cooldown)
        stats = self.job.stats.snapshot()
        self.activity.set(f"{stats['requests']:,} requests | {stats['cache_hits']:,} reused | "
                          f"{len(preview)} preview rows | full results kept until this window closes")
        if self.job.match_rule:
            self.activity.set(f"{stats['requests']:,} requests | {stats['cache_hits']:,} reused | "
                              f"{format_candidate_count(checked)} names fully checked | {len(preview)} matching preview rows")
        self.progress.configure(value=completed * 1000 // total)
        if render_version != self.last_render:
            selected = self.table.selection()
            previous = self.table.item(selected[0], "values")[:2] if selected else None
            rows = self.table.get_children()
            if rows:
                self.table.delete(*rows)
            self.row_results.clear()
            for result in preview:
                values = (result.username, result.site, result.status, result.detail)
                row = self.table.insert("", "end", values=values, tags=(result.status,))
                self.row_results[row] = result
                if previous == values[:2]:
                    self.table.selection_set(row)
            self.visible, self.last_render = preview, render_version
        ready = not running and self.job.workers_done.is_set()
        self.file_menu.entryconfigure(0, state="normal" if ready and not self.exporting and self.job.source_spec is not None else "disabled")
        self.session_button.configure(state="normal" if ready and not self.exporting and self.job.source_spec is not None else "disabled")
        pending = self.job.pending_pairs or (not self.job.exhausted and self.job.pulled < self.job.count)
        self.pause_button.configure(state="normal" if running and not self.job.halt.is_set() else "disabled",
                                    text="Resume" if self.job.pause.is_set() else "Pause")
        self.stop_button.configure(state="normal" if running else "disabled")
        self.continue_button.configure(state="normal" if ready and pending and not self.closing and not self.exporting else "disabled")
        self.export_button.configure(state="normal" if (found if self.job.match_rule else completed) and not self.exporting else "disabled")
        self.copy_button.configure(state="normal" if preview else "disabled")
        if self.job.error or self.job.reason:
            self.hint.set(self.job.error or self.job.reason)
        elif not running and not ready:
            self.hint.set("Waiting for stopped requests to finish before continuing or closing.")
        if self.closing and ready and not self.exporting:
            self.finish_close()
            return
        self.poll_id = self.dialog.after(150, self.poll)


def cooldown_summary(access, sites):
    remaining = access.remaining()
    exhausted = access.exhausted_sites()
    parts = []
    for site in sites:
        seconds = remaining.get(site.key) if site.key not in exhausted else None
        if seconds:
            minutes, seconds = divmod(seconds, 60)
            parts.append(f"{site.name} {minutes}m {seconds:02}s" if minutes else f"{site.name} {seconds}s")
    return "Cooldown · " + ", ".join(parts) + " · resumes automatically" if parts else ""


def validated_preferences(settings: dict) -> dict:
    if not isinstance(settings, dict) or settings.get("version") != 1:
        raise ValueError("Unsupported settings format.")
    limit = validate_batch_limit(settings["batch_limit"])
    timeout = settings["timeout"]
    if type(timeout) not in (int, float) or not math.isfinite(timeout) or not 1 <= timeout <= 60:
        raise ValueError("Timeout must be between 1 and 60 seconds.")
    sites = settings["sites"]
    if (not isinstance(sites, list) or any(key not in SITE_BY_KEY for key in sites)
            or len(set(sites)) != len(sites) or type(settings["reuse_recent"]) is not bool):
        raise ValueError("Invalid platform or cache settings.")
    generator = settings["generator"]
    if not isinstance(generator, dict) or set(generator) != {"length", "charset", "characters", "pattern", "count", "order"}:
        raise ValueError("Invalid finder settings.")
    if any(not isinstance(value, str) or len(value) > 1000 for value in generator.values()):
        raise ValueError("Invalid finder settings.")
    length = validate_character_length(int(generator["length"]))
    charset = {"Letters + digits": "alnum", "Letters": "letters", "Digits": "digits", "Custom": "custom"}[generator["charset"]]
    CharacterSearch(charset, generator["pattern"], generator["characters"] if charset == "custom" else "", length=length)
    if int(generator["count"]) < 0 or generator["order"] not in ("Shuffled", "Ordered"):
        raise ValueError("Invalid finder batch size or order.")
    geometry = settings.get("geometry", "1080x810")
    if not isinstance(geometry, str) or not re.fullmatch(r"[1-9][0-9]{2,4}x[1-9][0-9]{2,4}", geometry):
        raise ValueError("Invalid window size.")
    appearance = settings.get("theme", "Light")
    if appearance not in PALETTES:
        raise ValueError("Choose the Light or Dark appearance.")
    return {"version": 1, "batch_limit": limit, "timeout": timeout, "sites": sites,
            "reuse_recent": settings["reuse_recent"], "generator": generator, "geometry": geometry, "theme": appearance}


def launch_gui(batch_limit: int | None = None) -> int:
    """Import Tk lazily so command-line checks also work without a desktop."""
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox, ttk
    except ImportError:
        print("Tkinter is missing. Install Python with Tcl/Tk on Windows/macOS, or python3-tk on Linux. "
              "Command-line mode works without Tkinter.", file=sys.stderr)
        return 2
    try:
        root = tk.Tk()
    except tk.TclError:
        print("Cannot open a desktop window. Try: python username_checker.py yourname", file=sys.stderr)
        return 2
    CheckerWindow(root, tk, ttk, filedialog, messagebox, batch_limit=batch_limit, preferences_file=preferences_path())
    root.mainloop()
    return 0


class CheckerWindow:
    """All widget updates stay on Tk's main thread; networking runs in the background."""

    def __init__(self, root, tk, ttk, filedialog, messagebox, *, batch_limit=None, preferences_file=None):
        self.root, self.tk, self.ttk = root, tk, ttk
        self.appearance = tk.StringVar(root, value="Light")
        self.batch_limit = tk.StringVar(root, value=str(validate_batch_limit(DEFAULT_BATCH_LIMIT if batch_limit is None else batch_limit)))
        self.preferences_file = preferences_file
        self.file_busy = False
        self.original_batch = None
        self.generator_count_input = None
        self.filedialog, self.messagebox = filedialog, messagebox
        self.results: list[Result] = []
        self.row_results: dict[str, Result] = {}
        self.row_keys: dict[tuple[str, str], str] = {}
        self.events: queue.Queue[tuple[str, object]] = queue.Queue()
        self.cancel: threading.Event | None = None
        self.running = False
        self.pause = threading.Event()
        self.cache = ResultCache()
        token_error = ""
        try:
            self.access = ApiAccess(environment_tokens())
        except ValueError as exc:
            self.access = ApiAccess()
            token_error = str(exc)
        self.api_dialog = None
        self.api_token_vars = {}
        self.reuse_recent = tk.BooleanVar(root, value=True)
        self.stats = CheckStats()
        self.started_at = None
        self.finished_at = None
        self.pending_pairs: set[tuple[str, str]] = set()
        self.last_batch = None
        self.workers_done = threading.Event()
        self.workers_done.set()
        self.visible_results: list[Result] = []
        self.sort_by: str | None = None
        self.sort_descending = False
        self.completed = 0
        self.total = 0
        self.result_indices: dict[tuple[str, str], int] = {}
        self.platform_dialog = None
        self.generator_dialog = None
        self.large_windows = []
        self.generator: CharacterSearch | None = None
        self.previous_generator_length = DEFAULT_USERNAME_LENGTH
        self.generator_signature = None
        self.generator_actions = []
        self.finder_match = tk.StringVar(root, value="Any selected platform")
        self.generator_vars = {
            "length": tk.StringVar(root, value=str(DEFAULT_USERNAME_LENGTH)),
            "charset": tk.StringVar(root, value="Letters + digits"),
            "characters": tk.StringVar(root, value="abcdefghijklmnopqrstuvwxyz0123456789_-"),
            "pattern": tk.StringVar(root, value="???"),
            "count": tk.StringVar(root, value=str(DEFAULT_BATCH_SIZE)),
            "order": tk.StringVar(root, value="Shuffled"),
        }
        self.generator_vars["length"].trace_add("write", self.generator_length_changed)
        self.generator_progress = tk.StringVar(root, value="Choose a pattern, then generate a batch.")
        root.title(APP_NAME)
        root.geometry("1180x850")
        root.minsize(840, 720)
        self.ui_font = ui_font = choose_font(root)
        self.palette = configure_styles(root, ttk, ui_font, self.appearance.get())
        outer = ttk.Frame(root, padding=20)
        outer.pack(fill="both", expand=True)
        outer.columnconfigure(0, minsize=320)
        outer.columnconfigure(1, weight=1)
        outer.rowconfigure(1, weight=1)
        header = ttk.Frame(outer)
        header.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 18))
        header.columnconfigure(0, weight=1)
        ttk.Label(header, text=APP_NAME, style="Heading.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(header, text="Check public accounts. Confirm availability when you sign up.", style="Muted.TLabel").grid(
            row=1, column=0, sticky="w", pady=(3, 0))
        header_actions = ttk.Frame(header)
        header_actions.grid(row=0, column=1, rowspan=2, sticky="e", padx=(12, 0))
        self.open_session_button = ttk.Button(header_actions, text="Open session...", command=self.open_session)
        self.open_session_button.pack(side="left", padx=(0, 16))
        ttk.Label(header_actions, text="Theme", style="Small.TLabel").pack(side="left", padx=(0, 8))
        ttk.Combobox(header_actions, textvariable=self.appearance, values=("Light", "Dark"),
                     state="readonly", width=7).pack(side="left")
        sidebar = ttk.Frame(outer, width=320)
        sidebar.grid(row=1, column=0, sticky="nsew", padx=(0, 16))
        sidebar.grid_propagate(False)
        sidebar.columnconfigure(0, weight=1)
        sidebar.rowconfigure(0, weight=1)
        input_frame = ttk.Frame(sidebar, style="Card.TFrame", padding=14)
        input_frame.grid(row=0, column=0, sticky="nsew", pady=(0, 12))
        input_frame.columnconfigure(0, weight=1)
        input_frame.rowconfigure(2, weight=1)
        input_header = ttk.Frame(input_frame, style="CardBody.TFrame")
        input_header.grid(row=0, column=0, sticky="ew")
        ttk.Label(input_header, text="Usernames", style="Section.TLabel").pack(side="left")
        self.clear_button = ttk.Button(input_header, text="Clear", width=0, style="Subtle.TButton", command=self.clear)
        self.clear_button.pack(side="right")
        self.input_hint = tk.StringVar(root)
        hint = ttk.Label(input_frame, textvariable=self.input_hint, style="CardSmall.TLabel", wraplength=500)
        hint.grid(row=1, column=0, sticky="ew", pady=(4, 10))
        input_frame.bind("<Configure>", lambda event: hint.configure(wraplength=max(240, event.width - 40)))
        input_area = ttk.Frame(input_frame, style="CardBody.TFrame")
        input_area.grid(row=2, column=0, sticky="nsew")
        input_area.columnconfigure(0, weight=1)
        input_area.rowconfigure(0, weight=1)
        self.input = tk.Text(
            input_area, height=4, font=(ui_font, 11), wrap="word", relief="flat", width=24,
            highlightthickness=1, padx=12, pady=8,
        )
        self.input.grid(row=0, column=0, sticky="nsew")
        input_scroll = ttk.Scrollbar(input_area, orient="vertical", command=self.input.yview)
        input_scroll.grid(row=0, column=1, sticky="ns")
        self.input.configure(yscrollcommand=input_scroll.set)
        self.input.focus_set()
        controls = ttk.Frame(input_frame, style="CardBody.TFrame")
        controls.grid(row=4, column=0, sticky="ew", pady=(10, 0))
        controls.columnconfigure((0, 1), weight=1, uniform="check_controls")
        self.check_button = ttk.Button(controls, text="Check usernames", style="Primary.TButton", command=self.start)
        self.check_button.grid(row=0, column=0, columnspan=2, sticky="ew")
        self.pause_button = ttk.Button(controls, text="Pause", command=self.toggle_pause, state="disabled")
        self.pause_button.grid(row=1, column=0, sticky="ew", padx=(0, 4), pady=(6, 0))
        self.stop_button = ttk.Button(controls, text="Stop", style="Danger.TButton", command=self.stop, state="disabled")
        self.stop_button.grid(row=1, column=1, sticky="ew", padx=(4, 0), pady=(6, 0))
        input_actions = ttk.Frame(input_frame, style="CardBody.TFrame")
        input_actions.grid(row=3, column=0, sticky="ew", pady=(8, 0))
        input_actions.columnconfigure((0, 1), weight=1, uniform="input_actions")
        self.import_button = ttk.Button(input_actions, text="Import names...", width=0, style="Subtle.TButton", command=self.import_names)
        self.import_button.grid(row=0, column=0, sticky="ew", padx=(0, 4))
        self.generator_button = ttk.Button(input_actions, text="Character finder", width=0, style="Subtle.TButton", command=self.open_generator)
        self.generator_button.grid(row=0, column=1, sticky="ew", padx=(4, 0))
        options = ttk.Frame(sidebar, style="Card.TFrame", padding=14)
        options.grid(row=1, column=0, sticky="ew")
        options.columnconfigure(0, weight=1)
        settings_header = ttk.Frame(options, style="CardBody.TFrame")
        settings_header.grid(row=0, column=0, sticky="ew")
        ttk.Label(settings_header, text="Check settings", style="Section.TLabel").pack(side="left")
        self.api_button = ttk.Button(settings_header, text="API access...", width=0, style="Subtle.TButton", command=self.open_api_access)
        self.api_button.pack(side="right")
        self.site_vars = {}
        for site in SITES:
            variable = tk.BooleanVar(root, value=not site.manual)
            self.site_vars[site.key] = variable
        self.platform_summary = tk.StringVar(root)
        ttk.Label(options, textvariable=self.platform_summary, style="CardSmall.TLabel", wraplength=244).grid(
            row=1, column=0, sticky="w", pady=(5, 8))
        self.platform_button = ttk.Button(options, text="Choose platforms...", command=self.open_platforms)
        self.platform_button.grid(row=2, column=0, sticky="ew")
        for variable in self.site_vars.values():
            variable.trace_add("write", lambda *_: self.update_platform_summary())
        self.update_platform_summary()
        timeout_options = ttk.Frame(options, style="CardBody.TFrame")
        timeout_options.grid(row=3, column=0, sticky="ew", pady=(12, 0))
        timeout_options.columnconfigure((0, 1), weight=1)
        ttk.Label(timeout_options, text="Timeout (sec)", style="CardSmall.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(timeout_options, text="Batch limit", style="CardSmall.TLabel").grid(row=0, column=1, sticky="w", padx=(10, 0))
        self.timeout = tk.StringVar(root, value="12")
        ttk.Spinbox(timeout_options, from_=1, to=60, textvariable=self.timeout, width=6).grid(row=1, column=0, sticky="ew", pady=(4, 0))
        self.batch_limit_input = ttk.Spinbox(timeout_options, from_=0, to=sys.maxsize,
                                            textvariable=self.batch_limit, width=8)
        self.batch_limit_input.grid(row=1, column=1, sticky="ew", padx=(10, 0), pady=(4, 0))
        ttk.Label(timeout_options, text="0 = Unlimited", style="CardSmall.TLabel").grid(row=2, column=1, sticky="w", padx=(10, 0), pady=(3, 0))
        cache_options = ttk.Frame(options, style="CardBody.TFrame")
        cache_options.grid(row=4, column=0, sticky="ew", pady=(10, 0))
        self.cache_toggle = ttk.Checkbutton(cache_options, text="Reuse results (5 min)", style="Card.TCheckbutton", variable=self.reuse_recent)
        self.cache_toggle.pack(side="left")
        self.clear_cache_button = ttk.Button(cache_options, text="Clear cache", width=0, style="Subtle.TButton", command=self.clear_cache)
        self.clear_cache_button.pack(side="right", padx=(4, 0))
        results_card = ttk.Frame(outer, style="Card.TFrame", padding=16)
        results_card.grid(row=1, column=1, sticky="nsew")
        results_card.columnconfigure(0, weight=1)
        results_card.rowconfigure(2, weight=1)
        results_header = ttk.Frame(results_card, style="CardBody.TFrame")
        results_header.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        ttk.Label(results_header, text="Results", style="Section.TLabel").pack(side="left")
        self.shown = tk.StringVar(root, value="0 shown")
        ttk.Label(results_header, textvariable=self.shown, style="CardSmall.TLabel").pack(side="left", padx=(12, 0))
        self.compare_button = ttk.Button(results_header, text="Compare usernames", style="Subtle.TButton", command=self.compare_names, state="disabled")
        self.compare_button.pack(side="right")
        filters = ttk.Frame(results_card, style="CardBody.TFrame")
        filters.grid(row=1, column=0, sticky="ew", pady=(0, 10))
        filters.columnconfigure(1, weight=1)
        ttk.Label(filters, text="Search", style="CardSmall.TLabel").grid(row=0, column=0, padx=(0, 8))
        self.search = tk.StringVar(root, value="")
        ttk.Entry(filters, textvariable=self.search).grid(row=0, column=1, sticky="ew")
        ttk.Label(filters, text="Status", style="CardSmall.TLabel").grid(row=0, column=2, padx=(12, 8))
        self.status_filter = tk.StringVar(root, value="All")
        ttk.Combobox(filters, textvariable=self.status_filter, state="readonly", width=11,
                     values=tuple(STATUS_FILTERS.values())).grid(row=0, column=3)
        table_frame = ttk.Frame(results_card, style="CardBody.TFrame")
        table_frame.grid(row=2, column=0, sticky="nsew")
        table_frame.columnconfigure(0, weight=1)
        table_frame.rowconfigure(0, weight=1)
        self.table = ttk.Treeview(
            table_frame, columns=("username", "site", "status", "detail"),
            show="headings", selectmode="browse",
        )
        for key, label, width in (("username", "Username", 140), ("site", "Site", 110),
                                   ("status", "Result", 100), ("detail", "Details", 320)):
            self.table.heading(key, text=label, command=lambda column=key: self.sort_column(column))
            self.table.column(key, width=width, minwidth=70, stretch=key == "detail")
        self.table.grid(row=0, column=0, sticky="nsew")
        vertical = ttk.Scrollbar(table_frame, orient="vertical", command=self.table.yview)
        vertical.grid(row=0, column=1, sticky="ns")
        horizontal = ttk.Scrollbar(table_frame, orient="horizontal", command=self.table.xview)
        horizontal.grid(row=1, column=0, sticky="ew")
        self.table.configure(yscrollcommand=vertical.set, xscrollcommand=horizontal.set)
        self.empty_state = ttk.Frame(table_frame, style="CardBody.TFrame", padding=12)
        self.empty_title = ttk.Label(self.empty_state, text="Your results appear here", style="Section.TLabel")
        self.empty_title.pack()
        self.empty_hint = ttk.Label(self.empty_state, text="Paste names, choose platforms, then run a check.", style="CardMuted.TLabel")
        self.empty_hint.pack(pady=(6, 0))
        self.table.bind("<Configure>", lambda event: self.update_empty_state())
        self.table.bind("<<TreeviewSelect>>", self.select_row)
        self.table.bind("<Double-1>", lambda event: self.open_profile())
        self.details = tk.StringVar(root, value="Select a result to view its details and profile link.")
        if token_error:
            self.details.set(token_error + " Open API access to enter a token, or use public access.")
        detail_label = ttk.Label(results_card, textvariable=self.details, style="CardSmall.TLabel", wraplength=1000)
        detail_label.grid(row=3, column=0, sticky="ew", pady=(8, 0))
        results_card.bind("<Configure>", lambda event: detail_label.configure(wraplength=max(300, event.width - 36)))
        recovery = ttk.Frame(results_card, style="CardBody.TFrame")
        recovery.grid(row=4, column=0, sticky="ew", pady=(10, 0))
        self.continue_button = ttk.Button(recovery, text="Continue remaining", width=0, style="Compact.TButton", command=self.continue_checks, state="disabled")
        self.continue_button.pack(side="left")
        self.retry_button = ttk.Button(recovery, text="Retry unknown", width=0, style="Compact.TButton", command=self.retry_unknown, state="disabled")
        self.retry_button.pack(side="left", padx=(8, 0))
        bottom = ttk.Frame(results_card, style="CardBody.TFrame")
        bottom.grid(row=5, column=0, sticky="ew", pady=(8, 0))
        bottom.columnconfigure((0, 1, 2, 3), weight=1)
        self.open_button = ttk.Button(bottom, text="Open page", width=0, style="Compact.TButton", command=self.open_profile, state="disabled")
        self.open_button.grid(row=0, column=0, sticky="ew")
        self.copy_names_button = ttk.Button(bottom, text="Copy names", width=0, style="Compact.TButton", command=self.copy_names, state="disabled")
        self.copy_names_button.grid(row=0, column=1, sticky="ew", padx=(8, 0))
        self.copy_button = ttk.Button(bottom, text="Copy shown", width=0, style="Compact.TButton", command=self.copy_results, state="disabled")
        self.copy_button.grid(row=0, column=2, sticky="ew", padx=(8, 0))
        self.save_button = ttk.Button(bottom, text="Export shown...", width=0, style="Primary.TButton", command=self.save_results, state="disabled")
        self.save_button.grid(row=0, column=3, sticky="ew", padx=(8, 0))
        progress_track, self.progress = progressbar(outer, ttk, mode="determinate")
        progress_track.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(10, 8))
        footer = ttk.Frame(outer)
        footer.grid(row=3, column=0, columnspan=2, sticky="ew")
        footer.columnconfigure(0, weight=1)
        self.summary = tk.StringVar(root, value="Ready · Ctrl+Enter to check")
        summary_label = ttk.Label(footer, textvariable=self.summary, style="Small.TLabel", wraplength=700)
        summary_label.grid(row=0, column=0, sticky="w")
        footer.bind("<Configure>", lambda event: summary_label.configure(wraplength=max(300, event.width - 210)))
        self.activity = tk.StringVar(root, value="0 requests | 0 reused")
        ttk.Label(footer, textvariable=self.activity, style="Small.TLabel").grid(row=0, column=1, sticky="e", padx=(12, 0))
        self.compact_layout = None
        def fit_window(event):
            if event.widget is not root:
                return
            compact = root.winfo_height() < 800
            if compact == self.compact_layout:
                return
            self.compact_layout = compact
            outer.configure(padding=16 if compact else 20)
            header.grid_configure(pady=(0, 10 if compact else 18))
            sidebar.grid_configure(padx=(0, 12 if compact else 16))
            input_frame.configure(padding=12 if compact else 14)
            options.configure(padding=12 if compact else 14)
            input_frame.grid_configure(pady=(0, 10 if compact else 12))
            timeout_options.grid_configure(pady=(6 if compact else 12, 0))
            cache_options.grid_configure(pady=(4 if compact else 10, 0))
            results_card.configure(padding=12 if compact else 16)
            results_header.grid_configure(pady=(0, 6 if compact else 10))
            filters.grid_configure(pady=(0, 6 if compact else 10))
            detail_label.grid_configure(pady=(6 if compact else 8, 0))
            recovery.grid_configure(pady=(6 if compact else 10, 0))
            bottom.grid_configure(pady=(6 if compact else 8, 0))
            progress_track.grid_configure(pady=(8, 6) if compact else (10, 8))
        root.bind("<Configure>", fit_window, add="+")
        self.search.trace_add("write", lambda *_: self.refresh_table())
        self.status_filter.trace_add("write", lambda *_: self.refresh_table())
        self.batch_limit.trace_add("write", self.batch_limit_changed)
        self.batch_limit_changed()
        menubar = tk.Menu(root)
        self.file_menu = tk.Menu(menubar, tearoff=False)
        self.file_menu.add_command(label="Open session...", command=self.open_session, accelerator="Ctrl+O")
        self.file_menu.add_command(label="Save session...", command=self.save_session, accelerator="Ctrl+S")
        self.file_menu.add_separator()
        self.file_menu.add_command(label="Save settings", command=self.save_settings)
        self.file_menu.add_command(label="Exit", command=self.close)
        menubar.add_cascade(label="File", menu=self.file_menu)
        tools_menu = tk.Menu(menubar, tearoff=False)
        tools_menu.add_command(label="Compare usernames...", command=self.compare_names)
        tools_menu.add_command(label="API access...", command=self.open_api_access)
        menubar.add_cascade(label="Tools", menu=tools_menu)
        root.configure(menu=menubar)
        self.appearance.trace_add("write", self.apply_appearance)
        if preferences_file is not None:
            try:
                saved = load_preferences(preferences_file)
                if saved:
                    self.apply_preferences(validated_preferences(saved))
            except (OSError, ValueError, KeyError, TypeError):
                self.details.set("Saved settings could not be loaded. Default settings are in use.")
        if batch_limit is not None:
            self.batch_limit.set(str(batch_limit))
        self.apply_appearance()
        self.update_empty_state()
        root.bind("<Control-Return>", lambda event: self.start())
        root.bind("<Control-o>", lambda event: self.open_session())
        root.bind("<Control-s>", lambda event: self.save_session())
        root.bind("<Escape>", lambda event: self.stop())
        root.protocol("WM_DELETE_WINDOW", self.close)
        self.poll_id = root.after(80, self.poll)

    def get_preferences(self):
        settings = {"version": 1, "batch_limit": self.get_batch_limit(), "timeout": float(self.timeout.get()),
                    "sites": [site.key for site in SITES if self.site_vars[site.key].get()],
                    "reuse_recent": self.reuse_recent.get(),
                    "generator": {key: value.get() for key, value in self.generator_vars.items()},
                    "geometry": re.match(r"\d+x\d+", self.root.winfo_geometry()).group(), "theme": self.appearance.get()}
        return validated_preferences(settings)

    def apply_preferences(self, settings):
        self.appearance.set(settings["theme"])
        self.batch_limit.set(str(settings["batch_limit"]))
        self.timeout.set(str(settings["timeout"]))
        self.reuse_recent.set(settings["reuse_recent"])
        for site in SITES:
            self.site_vars[site.key].set(site.key in settings["sites"])
        for key in ("length", "charset", "characters", "pattern", "count", "order"):
            self.generator_vars[key].set(settings["generator"][key])
        width, height = (int(value) for value in settings["geometry"].split("x"))
        self.root.geometry(f"{min(width, self.root.winfo_screenwidth())}x{min(height, self.root.winfo_screenheight())}")

    def apply_appearance(self, *_):
        self.palette = configure_styles(self.root, self.ttk, self.ui_font, self.appearance.get())

    def open_api_access(self):
        if self.api_dialog is not None and self.api_dialog.winfo_exists():
            self.api_dialog.lift()
            return
        tk, ttk = self.tk, self.ttk
        dialog = tk.Toplevel(self.root)
        self.api_dialog = dialog
        dialog.title("API access")
        dialog.geometry("520x420")
        dialog.minsize(480, 410)
        dialog.transient(self.root)
        dialog.grab_set()
        frame = ttk.Frame(dialog, padding=20)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(0, weight=1)
        ttk.Label(frame, text="API access", style="DialogTitle.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(frame, text="Optional tokens use your platform's authenticated API allowance.",
                  style="Muted.TLabel", wraplength=440).grid(row=1, column=0, sticky="ew", pady=(6, 12))
        current = self.access.tokens()
        self.api_token_vars, self.api_entries = {}, {}
        for row, (key, label) in enumerate((("github", "GitHub token"), ("gitlab", "GitLab personal access token"))):
            ttk.Label(frame, text=label).grid(row=2 + row * 2, column=0, sticky="w")
            variable = tk.StringVar(dialog, value=current.get(key, ""))
            entry = ttk.Entry(frame, textvariable=variable, show="*")
            entry.grid(row=3 + row * 2, column=0, sticky="ew", pady=(4, 10))
            self.api_token_vars[key], self.api_entries[key] = variable, entry
        self.api_show_tokens = tk.BooleanVar(dialog, value=False)
        ttk.Checkbutton(frame, text="Show tokens", variable=self.api_show_tokens,
                        command=lambda: [entry.configure(show="" if self.api_show_tokens.get() else "*")
                                         for entry in self.api_entries.values()]).grid(row=6, column=0, sticky="w")
        ttk.Label(frame, text="Tokens stay in memory for this session. They are excluded from settings, saved sessions, and exports. Leave fields blank for public access.",
                  style="Muted.TLabel", wraplength=440).grid(row=7, column=0, sticky="ew", pady=(10, 12))
        frame.rowconfigure(8, weight=1)
        actions = ttk.Frame(frame)
        actions.grid(row=9, column=0, sticky="ew")
        ttk.Button(actions, text="Cancel", command=dialog.destroy).pack(side="right")
        self.api_apply_button = ttk.Button(actions, text="Apply", style="Primary.TButton", command=self.apply_api_access)
        self.api_apply_button.pack(side="right", padx=(0, 8))
        paint_widgets(dialog, self.palette)
        self.api_entries["github"].focus_set()

    def apply_api_access(self):
        if (self.running or self.file_busy or not self.workers_done.is_set()
                or any(not view.job.done.is_set() or not view.job.workers_done.is_set() for view in self.large_windows)):
            self.messagebox.showinfo("Checking in progress", "Stop checking and wait for current requests before changing tokens.")
            return
        try:
            self.access.set_tokens({key: variable.get() for key, variable in self.api_token_vars.items()})
        except ValueError as exc:
            self.messagebox.showerror("Check your API token", str(exc))
            return
        self.cache.clear()
        self.details.set("API access updated for this session. Recent lookup cache cleared.")
        for variable in self.api_token_vars.values():
            variable.set("")
        self.api_dialog.destroy()

    def update_empty_state(self):
        if self.visible_results or self.table.winfo_height() < 130:
            self.empty_state.place_forget()
            return
        if self.results:
            title, hint = "No matching results", "Try a different name search or status filter."
        elif self.running:
            title, hint = "Waiting for results", "Checks are running. Results appear as each platform replies."
        else:
            title, hint = "Your results appear here", "Paste names, choose platforms, then run a check."
        self.empty_title.configure(text=title)
        self.empty_hint.configure(text=hint)
        self.empty_state.place(relx=0.5, rely=0.55, anchor="center")

    def save_settings(self):
        if self.preferences_file is None:
            self.details.set("Settings persistence is disabled for this window.")
            return
        try:
            save_preferences(self.preferences_file, self.get_preferences())
            self.details.set("Settings saved. Usernames and results are only saved through Save session.")
        except (OSError, ValueError, KeyError, TypeError) as exc:
            self.messagebox.showerror("Settings could not be saved", str(exc))

    def open_session(self):
        if self.running or self.file_busy or not self.workers_done.is_set():
            return
        filename = self.filedialog.askopenfilename(title="Open username session", filetypes=(("Username sessions", "*.ucsession"),))
        if not filename:
            return
        self.file_busy = True
        self.details.set("Opening and validating the saved session...")
        self.update_actions()
        def read():
            job = None
            try:
                job, settings = load_checkpoint(Path(filename))
                if settings:
                    settings = validated_preferences(settings)
                self.events.put(("session_opened", (job, settings)))
            except Exception as exc:
                if job is not None:
                    job.close()
                self.events.put(("file_error", str(exc)))
        threading.Thread(target=read, daemon=True).start()

    def save_session(self):
        if self.running or self.file_busy or not self.workers_done.is_set() or self.original_batch is None:
            self.details.set("Stop a checked batch and wait for current requests before saving a session.")
            return
        filename = self.filedialog.asksaveasfilename(title="Save username session", defaultextension=".ucsession",
                                                   initialfile="username_session.ucsession", filetypes=(("Username session", "*.ucsession"),))
        if not filename:
            return
        try:
            settings = self.get_preferences()
        except (ValueError, KeyError, TypeError) as exc:
            self.messagebox.showerror("Check your settings", str(exc))
            return
        names, sites, timeout = self.original_batch
        name_order, site_order = {name: index for index, name in enumerate(names)}, {site.name: index for index, site in enumerate(sites)}
        by_name = {site.name: site.key for site in sites}
        results = sorted((result for result in self.results if (result.username, by_name[result.site]) not in self.pending_pairs),
                         key=lambda result: (name_order[result.username], site_order[result.site]))
        state = checkpoint_state(len(names), len(names), sites, timeout, False, names if self.pending_pairs else [],
                                 self.pending_pairs, len(results), {"kind": "names"}, settings)
        self.file_busy = True
        self.update_actions()
        def save():
            try:
                write_session(Path(filename), state, (asdict(result) for result in results), names)
                self.events.put(("file_saved", Path(filename).name))
            except Exception as exc:
                self.events.put(("file_error", str(exc)))
        threading.Thread(target=save, daemon=True).start()

    def compare_names(self):
        if self.results:
            return ComparisonWindow(self, list(self.results),
                                    expected_sites=[site.name for site in self.original_batch[1]] if self.original_batch else ())

    def get_batch_limit(self):
        try:
            return validate_batch_limit(int(self.batch_limit.get()))
        except ValueError as exc:
            raise ValueError("Batch limit must be a whole number: 0 for unlimited, or a positive limit.") from exc

    def batch_limit_changed(self, *_):
        try:
            limit = self.get_batch_limit()
        except ValueError:
            self.input_hint.set("Usernames · enter a positive batch limit, or 0 for unlimited.")
            return
        self.input_hint.set("Separate with commas or new lines. Unlimited batch limit." if not limit else
                            f"Separate with commas or new lines; up to {format_candidate_count(limit)} names.")
        if self.generator_count_input is not None and self.generator_count_input.winfo_exists():
            self.generator_count_input.configure(to=min(limit or sys.maxsize, sys.maxsize))
        try:
            if limit and int(self.generator_vars["count"].get()) > limit:
                self.generator_vars["count"].set(str(limit))
        except ValueError:
            pass

    def start(self):
        if self.running or self.file_busy:
            return
        if not self.workers_done.is_set():
            self.details.set("Waiting for stopped requests to finish before starting another batch.")
            return
        try:
            limit = self.get_batch_limit()
            names = parse_usernames(self.input.get("1.0", "end"), limit)
            selected = [site for site in SITES if self.site_vars[site.key].get()]
            timeout = float(self.timeout.get())
            if not selected:
                raise ValueError("Select at least one site.")
            if not math.isfinite(timeout) or not 1 <= timeout <= 60:
                raise ValueError("Timeout must be between 1 and 60 seconds.")
        except ValueError as exc:
            self.messagebox.showerror("Check your input", str(exc))
            return
        if len(names) * len(selected) > LARGE_BATCH_THRESHOLD:
            self.open_large_batch(iter(names), len(names), selected, timeout, source_names=names)
            return
        self.results.clear()
        self.original_batch = (list(names), list(selected), timeout)
        self.search.set("")
        self.status_filter.set("All")
        self.begin_check(names, selected, timeout, batch_limit=limit)

    def begin_check(self, names, selected, timeout, only=None, *, batch_limit=None):
        """Start a normal or targeted retry batch, preserving successful retry rows."""
        limit = self.get_batch_limit() if batch_limit is None else batch_limit
        self.events = queue.Queue()
        self.cancel = threading.Event()
        self.workers_done = threading.Event()
        self.workers_done.set()
        self.running = True
        self.pause = threading.Event()
        self.stats = CheckStats()
        self.started_at = time.monotonic()
        self.finished_at = None
        self.last_batch = (list(names), list(selected), timeout)
        self.pending_pairs = (set(only) if only is not None else
                              {(name, site.key) for name in names for site in selected})
        self.result_indices = {(result.username, result.site): index for index, result in enumerate(self.results)}
        self.completed = 0
        self.total = len(only) if only is not None else len(names) * len(selected)
        self.progress.configure(maximum=self.total, value=0)
        self.refresh_table()
        self.update_actions()
        self.stop_button.configure(state="normal")
        self.details.set("Checking public profiles…")
        self.summary.set("Checking…")
        self.update_activity()
        output_queue, stop, finished = self.events, self.cancel, self.workers_done
        pause, cache, stats, refresh = self.pause, self.cache, self.stats, not self.reuse_recent.get()

        def background():
            try:
                run_checks(names, selected, timeout, stop, lambda result: output_queue.put(("result", result)),
                           only=only, workers_done=finished, batch_limit=limit,
                           pause=pause, cache=cache, stats=stats, refresh=refresh, access=self.access)
            except Exception:
                if not finished.is_set():
                    stop.set()
                output_queue.put(("error", "The check could not finish. Please try again."))
            finally:
                output_queue.put(("done", None))

        threading.Thread(target=background, daemon=True).start()

    def stop(self):
        if self.running and self.cancel is not None:
            self.cancel.set()
            self.stop_button.configure(state="disabled")
            self.pause_button.configure(state="disabled")
            self.summary.set("Stopping…")

    def toggle_pause(self):
        if not self.running or self.cancel is None or self.cancel.is_set():
            return
        if self.pause.is_set():
            self.pause.clear()
            self.pause_button.configure(text="Pause")
            self.details.set("Checking resumed.")
        else:
            self.pause.set()
            self.pause_button.configure(text="Resume")
            self.details.set("Paused. Requests already in progress may still return results.")
        self.update_check_summary()

    def continue_checks(self):
        if self.running or not self.workers_done.is_set() or not self.pending_pairs or self.last_batch is None:
            return
        original_names, selected, timeout = self.last_batch
        pending = set(self.pending_pairs)
        names = [name for name in original_names if any((name, site.key) in pending for site in selected)]
        try:
            limit = self.get_batch_limit()
            if limit and len(names) > limit:
                raise ValueError(f"Continue includes {len(names):,} usernames. Raise Batch limit to at least {len(names):,}.")
        except ValueError as exc:
            self.messagebox.showerror("Check your batch limit", str(exc))
            return
        self.begin_check(names, selected, timeout, only=pending, batch_limit=limit)

    def clear_cache(self):
        if self.running or not self.workers_done.is_set():
            return
        self.cache.clear()
        self.details.set("Recent lookup cache cleared. Your result rows are kept.")

    def update_activity(self):
        counts = self.stats.snapshot()
        elapsed = 0 if self.started_at is None else (self.finished_at or time.monotonic()) - self.started_at
        self.activity.set(f"{elapsed:.0f}s | {counts['requests']:,} requests | {counts['cache_hits']:,} reused")

    def update_check_summary(self):
        prefix = "Stopping" if self.cancel is not None and self.cancel.is_set() else (
            "Paused" if self.pause.is_set() else "Checked")
        self.summary.set(f"{prefix} {self.completed:,} of {self.total:,}")
        if self.running and not self.pause.is_set() and self.cancel is not None and not self.cancel.is_set():
            sites = self.last_batch[1] if self.last_batch is not None else []
            cooldown = cooldown_summary(self.access, sites)
            if cooldown:
                self.summary.set(self.summary.get() + " · " + cooldown)

    def poll(self):
        changes = []
        site_keys = {site.name: site.key for site in SITES}
        try:
            # Bound each poll so a large batch leaves time for Tk to process Stop.
            deadline = time.monotonic() + 0.02
            for _ in range(250):
                event, payload = self.events.get_nowait()
                if event == "result":
                    result = payload
                    key = (result.username, result.site)
                    index = self.result_indices.get(key)
                    if index is not None:
                        self.results[index] = result
                    else:
                        self.result_indices[key] = len(self.results)
                        self.results.append(result)
                    self.pending_pairs.discard((result.username, site_keys[result.site]))
                    self.completed += 1
                    changes.append(result)
                elif event == "error":
                    self.messagebox.showerror("Check failed", str(payload))
                elif event == "file_error":
                    self.file_busy = False
                    self.messagebox.showerror("Session operation failed", str(payload))
                    self.details.set("Session operation failed; your current results are kept.")
                elif event == "file_saved":
                    self.file_busy = False
                    self.details.set(f"Saved {payload}. Open it later to restore results and continue unfinished checks.")
                elif event == "session_opened":
                    self.file_busy = False
                    job, settings = payload
                    job.access = self.access
                    if settings:
                        self.apply_preferences(settings)
                    finder = self.generator_dialog
                    if finder is not None and finder.winfo_exists():
                        finder.withdraw()
                    def restore_finder():
                        if finder is not None and finder.winfo_exists():
                            finder.deiconify()
                            finder.lift()
                    view = LargeBatchWindow(self, job, restore_finder, autostart=False)
                    self.large_windows.append(view)
                    self.details.set("Saved session opened without requests. Use Continue in its batch window to resume.")
                elif event == "done":
                    self.running = False
                    self.finished_at = time.monotonic()
                    self.stop_button.configure(state="disabled")
                    counts = Counter(result.status for result in self.results)
                    description = " · ".join(f"{count} {status.lower()}" for status, count in counts.items())
                    prefix = "Stopped" if self.completed < self.total else "Finished"
                    self.summary.set(f"{prefix} · {self.completed}/{self.total} checked"
                                     + (f" · {description}" if description else ""))
                    self.details.set(f"{len(self.pending_pairs):,} pairs remain. Use Continue remaining to resume."
                                     if self.pending_pairs else
                                     "Double-click a row to open its page. Copy and export use the shown rows.")
                    if self.access.exhausted_sites() & {key for _, key in self.pending_pairs}:
                        self.details.set("Automatic rate-limit retries exhausted. Unfinished checks are kept; use Continue remaining to retry.")
                if time.monotonic() >= deadline:
                    break
        except queue.Empty:
            pass
        if changes:
            self.progress.configure(value=self.completed)
            if self.running:
                self.update_check_summary()
            self.refresh_table(changes)
        if self.running:
            self.update_check_summary()
        self.update_activity()
        self.update_actions()
        if not self.running and not self.workers_done.is_set():
            self.details.set("Stopped. Waiting for requests already in progress to finish…")
        self.poll_id = self.root.after(80, self.poll)

    def update_actions(self):
        ready = not self.running and not self.file_busy and self.workers_done.is_set()
        self.file_menu.entryconfigure(0, state="normal" if ready else "disabled")
        self.file_menu.entryconfigure(1, state="normal" if ready and self.original_batch is not None else "disabled")
        for button in (self.check_button, self.import_button, self.clear_button, self.generator_button,
                       self.platform_button, self.batch_limit_input, self.cache_toggle, self.clear_cache_button, self.open_session_button,
                       self.api_button):
            button.configure(state="normal" if ready else "disabled")
        self.pause_button.configure(state="normal" if self.running and self.cancel is not None
                                    and not self.cancel.is_set() else "disabled",
                                    text="Resume" if self.running and self.pause.is_set() else "Pause")
        self.continue_button.configure(state="normal" if ready and self.pending_pairs else "disabled")
        for button in self.generator_actions:
            if button.winfo_exists():
                button.configure(state="normal" if ready else "disabled")
        self.retry_button.configure(state="normal" if ready and not self.pending_pairs and any(
            result.status == "Unknown" for result in self.results
        ) else "disabled")
        for button in (self.copy_button, self.copy_names_button, self.save_button):
            button.configure(state="normal" if self.visible_results else "disabled")
        self.compare_button.configure(state="normal" if self.results else "disabled")
        self.update_empty_state()

    def refresh_table(self, changes=None):
        if changes is not None and not self.search.get() and self.status_filter.get() == "All" and self.sort_by is None:
            # The default streaming view updates only arriving rows, not every
            # previously rendered row. This matters for large manual/cache batches.
            for result in changes:
                key = (result.username, result.site)
                row = self.row_keys.get(key)
                values = (result.username, result.site, result.status, result.detail)
                if row is None:
                    row = self.table.insert("", "end", values=values, tags=(result.status,))
                    self.row_keys[key] = row
                    self.visible_results.append(result)
                else:
                    self.table.item(row, values=values, tags=(result.status,))
                    self.visible_results[self.result_indices[key]] = result
                self.row_results[row] = result
            self.shown.set(f"{len(self.visible_results)} / {len(self.results)} shown")
            self.select_row()
            self.update_actions()
            return
        previous = self.selected_result()
        self.visible_results = filter_results(self.results, self.search.get(), self.status_filter.get(),
                                             self.sort_by, self.sort_descending)
        existing = {(result.username, result.site): row for row, result in self.row_results.items()}
        visible_keys = {(result.username, result.site) for result in self.visible_results}
        remove = [row for key, row in existing.items() if key not in visible_keys]
        if remove:
            self.table.delete(*remove)
        updated = {}
        desired = []
        for result in self.visible_results:
            row = existing.get((result.username, result.site))
            values = (result.username, result.site, result.status, result.detail)
            if row is None:
                row = self.table.insert("", "end", values=values, tags=(result.status,))
            elif self.row_results[row] != result:
                self.table.item(row, values=values, tags=(result.status,))
            updated[row] = result
            desired.append(row)
            if previous is not None and (previous.username, previous.site) == (result.username, result.site):
                self.table.selection_set(row)
        if list(self.table.get_children()) != desired:
            for index, row in enumerate(desired):
                self.table.move(row, "", index)
        self.row_results = updated
        self.row_keys = {(result.username, result.site): row for row, result in updated.items()}
        self.shown.set(f"{len(self.visible_results)} / {len(self.results)} shown")
        self.select_row()
        self.update_actions()

    def sort_column(self, column):
        self.sort_descending = not self.sort_descending if self.sort_by == column else False
        self.sort_by = column
        for key, label in (("username", "Username"), ("site", "Site"), ("status", "Result"), ("detail", "Details")):
            marker = (" ▼" if self.sort_descending else " ▲") if key == column else ""
            self.table.heading(key, text=label + marker)
        self.refresh_table()

    def update_platform_summary(self):
        selected = [site for site in SITES if self.site_vars[site.key].get()]
        manual = sum(site.manual for site in selected)
        self.platform_summary.set(f"{len(selected)} selected · {len(selected) - manual} automatic · {manual} manual")

    def choose_platform_preset(self, preset):
        for site in SITES:
            self.site_vars[site.key].set(preset == "all" or (preset == "auto" and not site.manual))

    def open_platforms(self):
        if self.platform_dialog is not None and self.platform_dialog.winfo_exists():
            self.platform_dialog.lift()
            return
        tk, ttk = self.tk, self.ttk
        dialog = tk.Toplevel(self.root)
        self.platform_dialog = dialog
        dialog.title("Choose platforms")
        dialog.transient(self.root)
        dialog.geometry("760x620")
        dialog.minsize(600, 520)
        outer = ttk.Frame(dialog, padding=18)
        outer.pack(fill="both", expand=True)
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(3, weight=1)
        ttk.Label(outer, text="Choose platforms", style="DialogTitle.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(outer, text="Automatic checks look up public accounts. Manual checks provide a page to verify yourself.",
                  wraplength=560, style="Muted.TLabel").grid(row=1, column=0, sticky="w", pady=(6, 12))
        filters = ttk.Frame(outer)
        filters.grid(row=2, column=0, sticky="ew", pady=(0, 8))
        filters.columnconfigure(1, weight=1)
        ttk.Label(filters, text="Search").grid(row=0, column=0, padx=(0, 8))
        self.platform_search = tk.StringVar(dialog)
        search = ttk.Entry(filters, textvariable=self.platform_search)
        search.grid(row=0, column=1, sticky="ew")
        self.platform_category = tk.StringVar(dialog, value="All categories")
        categories = ttk.Combobox(filters, textvariable=self.platform_category, state="readonly", width=15,
                                  values=("All categories", *sorted({site.category for site in SITES})))
        categories.grid(row=0, column=2, padx=(10, 0))
        self.platform_mode = tk.StringVar(dialog, value="All types")
        modes = ttk.Combobox(filters, textvariable=self.platform_mode, state="readonly", width=11,
                            values=("All types", "Automatic", "Manual"))
        modes.grid(row=0, column=3, padx=(8, 0))
        list_frame = ttk.Frame(outer, style="Card.TFrame")
        list_frame.grid(row=3, column=0, sticky="nsew")
        list_frame.columnconfigure(0, weight=1)
        list_frame.rowconfigure(0, weight=1)
        canvas = tk.Canvas(list_frame, highlightthickness=0, background=self.palette["surface"])
        canvas.grid(row=0, column=0, sticky="nsew")
        scroll = ttk.Scrollbar(list_frame, orient="vertical", command=canvas.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        canvas.configure(yscrollcommand=scroll.set)
        self.platform_rows = ttk.Frame(canvas, style="CardBody.TFrame")
        item = canvas.create_window((0, 0), window=self.platform_rows, anchor="nw")
        canvas.bind("<Configure>", lambda event: canvas.itemconfigure(item, width=event.width))
        self.platform_rows.bind("<Configure>", lambda event: canvas.configure(scrollregion=canvas.bbox("all")))
        def wheel(event):
            direction = -1 if event.num == 4 or event.delta > 0 else 1
            canvas.yview_scroll(direction, "units")
            return "break"
        dialog.bind("<MouseWheel>", wheel)
        dialog.bind("<Button-4>", wheel)
        dialog.bind("<Button-5>", wheel)
        search.bind("<KeyRelease>", self.refresh_platforms)
        categories.bind("<<ComboboxSelected>>", self.refresh_platforms)
        modes.bind("<<ComboboxSelected>>", self.refresh_platforms)
        bottom = ttk.Frame(outer)
        bottom.grid(row=4, column=0, sticky="ew", pady=(12, 0))
        for text, preset in (("All automatic", "auto"), ("All platforms", "all"), ("None", "none")):
            ttk.Button(bottom, text=text, command=lambda choice=preset: self.choose_platform_preset(choice)).pack(
                side="left", padx=(0, 8)
            )
        ttk.Button(bottom, text="Done", style="Primary.TButton", command=dialog.destroy).pack(side="right")
        self.refresh_platforms()
        paint_widgets(dialog, self.palette)

    def refresh_platforms(self, event=None):
        query = self.platform_search.get().strip().casefold()
        category, mode = self.platform_category.get(), self.platform_mode.get()
        for widget in self.platform_rows.winfo_children():
            widget.destroy()
        self.platform_visible = [site for site in SITES
                                 if (not query or query in " ".join((site.name, site.key, *site.aliases)).casefold())
                                 and (category == "All categories" or category == site.category)
                                 and (mode == "All types" or site.manual == (mode == "Manual"))]
        self.platform_rows.columnconfigure(0, weight=1)
        for index, site in enumerate(self.platform_visible):
            ttk = self.ttk
            ttk.Checkbutton(self.platform_rows, text=site.name, variable=self.site_vars[site.key], style="Card.TCheckbutton").grid(
                row=index, column=0, sticky="w", pady=7, padx=8
            )
            ttk.Label(self.platform_rows, text=site.category, style="CardMuted.TLabel").grid(
                row=index, column=1, sticky="w", padx=12
            )
            ttk.Label(self.platform_rows, text="Manual" if site.manual else "Automatic",
                      style="ManualBadge.TLabel" if site.manual else "Badge.TLabel").grid(
                row=index, column=2, sticky="e", padx=(12, 8)
            )
        if not self.platform_visible:
            self.ttk.Label(self.platform_rows, text="No platforms match these filters.", style="CardMuted.TLabel").grid(row=0, column=0, pady=15)

    def open_generator(self):
        """Show a reusable finder; generating alone sends no network requests."""
        try:
            limit = self.get_batch_limit()
        except ValueError as exc:
            self.messagebox.showerror("Check your input", str(exc))
            return
        if self.generator_dialog is not None and self.generator_dialog.winfo_exists():
            self.generator_dialog.lift()
            return
        tk, ttk = self.tk, self.ttk
        dialog = tk.Toplevel(self.root)
        self.generator_dialog = dialog
        dialog.title("Username character finder")
        dialog.transient(self.root)
        dialog.geometry("740x700")
        dialog.minsize(640, 580)
        dialog.configure(background=self.palette["canvas"])
        frame = ttk.Frame(dialog, padding=20)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(1, weight=1)
        frame.rowconfigure(8, weight=1)
        ttk.Label(frame, text="Character finder", style="DialogTitle.TLabel").grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 10)
        )
        ttk.Label(frame, text="Choose a length, then find names continuously on your selected automatic platforms.",
                  style="Muted.TLabel", wraplength=550).grid(row=1, column=0, columnspan=2, sticky="w", pady=(0, 12))
        ttk.Label(frame, text="Character count").grid(row=2, column=0, sticky="w", padx=(0, 12), pady=(0, 8))
        length_options = ttk.Frame(frame)
        length_options.grid(row=2, column=1, sticky="ew", pady=(0, 8))
        self.generator_length_input = ttk.Spinbox(length_options, from_=1, to=MAX_USERNAME_LENGTH, width=6,
                                                  textvariable=self.generator_vars["length"])
        self.generator_length_input.pack(side="left")
        ttk.Label(length_options, text=f"characters (1 to {MAX_USERNAME_LENGTH})", style="Muted.TLabel").pack(
            side="left", padx=(10, 0))
        ttk.Label(frame, text="Character set").grid(row=3, column=0, sticky="w", padx=(0, 12))
        charset_menu = ttk.Combobox(frame, textvariable=self.generator_vars["charset"], state="readonly",
                                   values=("Letters + digits", "Letters", "Digits", "Custom"))
        charset_menu.grid(row=3, column=1, sticky="ew")
        ttk.Label(frame, text="Custom characters").grid(row=4, column=0, sticky="w", padx=(0, 12), pady=8)
        custom_entry = ttk.Entry(frame, textvariable=self.generator_vars["characters"])
        custom_entry.grid(row=4, column=1, sticky="ew", pady=8)
        def update_custom_entry(event=None):
            custom_entry.configure(state="normal" if self.generator_vars["charset"].get() == "Custom" else "disabled")
        charset_menu.bind("<<ComboboxSelected>>", update_custom_entry)
        update_custom_entry()
        ttk.Label(frame, text="Pattern (optional)").grid(row=5, column=0, sticky="w", padx=(0, 12))
        ttk.Entry(frame, textvariable=self.generator_vars["pattern"]).grid(row=5, column=1, sticky="ew")
        options = ttk.Frame(frame)
        options.grid(row=6, column=0, columnspan=2, sticky="ew", pady=(12, 0))
        ttk.Label(options, text="Batch size").pack(side="left")
        self.generator_count_input = ttk.Spinbox(options, from_=0, to=min(limit or sys.maxsize, sys.maxsize), width=8,
                                                 textvariable=self.generator_vars["count"])
        self.generator_count_input.pack(side="left", padx=(8, 14))
        ttk.Combobox(options, textvariable=self.generator_vars["order"], state="readonly", width=13,
                     values=("Shuffled", "Ordered")).pack(side="right")
        ttk.Label(frame, text="Pattern: ? matches any character; a???? starts with a and has five characters.\n"
                  "Batch size 0 = all remaining. Find until Stop ignores Batch size.\n"
                  "Continuous searches use Batch limit per chunk and end if all combinations are checked.",
                  style="Muted.TLabel", wraplength=590).grid(row=7, column=0, columnspan=2, sticky="w", pady=12)
        self.generator_preview = tk.Text(frame, height=4, wrap="word", state="disabled", relief="flat",
                                         font=(self.ui_font, 11), highlightthickness=1, padx=12, pady=10)
        self.generator_preview.grid(row=8, column=0, columnspan=2, sticky="nsew")
        ttk.Label(frame, textvariable=self.generator_progress, wraplength=590).grid(
            row=9, column=0, columnspan=2, sticky="w", pady=(8, 12)
        )
        actions = ttk.Frame(frame)
        actions.grid(row=10, column=0, columnspan=2, sticky="ew")
        self.generator_actions = [
            ttk.Button(actions, text="Generate next batch", command=self.generate_candidates),
            ttk.Button(actions, text="Generate and check", command=lambda: self.generate_candidates(check=True)),
            ttk.Button(actions, text="Reset sequence", command=self.reset_generator),
        ]
        for button in self.generator_actions:
            button.pack(side="left", padx=(0, 8))
        continuous = ttk.Frame(frame)
        continuous.grid(row=11, column=0, columnspan=2, sticky="ew", pady=(10, 0))
        continuous.columnconfigure(1, weight=1)
        ttk.Label(continuous, text="Find on").grid(row=0, column=0, sticky="w", padx=(0, 10))
        self.finder_match_input = ttk.Combobox(continuous, textvariable=self.finder_match, state="readonly",
                                              values=tuple(FINDER_MATCHES), width=22)
        self.finder_match_input.grid(row=0, column=1, sticky="ew", padx=(0, 10))
        self.finder_start_button = ttk.Button(continuous, text="Find until Stop", style="Primary.TButton", command=self.find_continuously)
        self.finder_start_button.grid(row=0, column=2, sticky="e")
        self.generator_actions.append(self.finder_start_button)
        self.update_actions()
        paint_widgets(dialog, self.palette)

    def get_generator_length(self):
        try:
            return validate_character_length(int(self.generator_vars["length"].get()))
        except ValueError as exc:
            raise ValueError(f"Character count must be a whole number from 1 to {MAX_USERNAME_LENGTH}.") from exc

    def generator_length_changed(self, *_):
        try:
            length = self.get_generator_length()
        except ValueError:
            return
        pattern = self.generator_vars["pattern"].get()
        if not pattern.strip() or pattern == "?" * self.previous_generator_length:
            self.generator_vars["pattern"].set("?" * length)
        self.previous_generator_length = length

    def reset_generator(self):
        if self.running or not self.workers_done.is_set():
            return
        self.generator = None
        self.generator_signature = None
        self.generator_progress.set("Sequence reset. Generate a fresh batch.")
        if self.generator_dialog is not None and self.generator_dialog.winfo_exists():
            self.generator_preview.configure(state="normal")
            self.generator_preview.delete("1.0", "end")
            self.generator_preview.configure(state="disabled")

    def configured_generator(self):
        charset = {"Letters + digits": "alnum", "Letters": "letters", "Digits": "digits", "Custom": "custom"}[
            self.generator_vars["charset"].get()]
        characters = self.generator_vars["characters"].get() if charset == "custom" else ""
        length = self.get_generator_length()
        pattern = self.generator_vars["pattern"].get().strip() or None
        order = self.generator_vars["order"].get()
        if order not in ("Ordered", "Shuffled"):
            raise ValueError("Choose Ordered or Shuffled generation.")
        signature = (length, charset, characters, pattern, order)
        generator = self.generator
        if generator is None or self.generator_signature != signature:
            seed = random.SystemRandom().getrandbits(64) if order == "Shuffled" else None
            generator = CharacterSearch(charset, pattern, characters, seed, length=length)
        return generator, signature

    def find_continuously(self):
        if self.running or self.file_busy or not self.workers_done.is_set():
            return
        try:
            limit = self.get_batch_limit()
            timeout = float(self.timeout.get())
            selected = [site for site in SITES if self.site_vars[site.key].get() and not site.manual]
            if not selected:
                raise ValueError("Choose at least one automatic platform in the main window.")
            if not math.isfinite(timeout) or not 1 <= timeout <= 60:
                raise ValueError("Timeout must be between 1 and 60 seconds.")
            rule = FINDER_MATCHES[self.finder_match.get()]
            generator, signature = self.configured_generator()
            count = generator.batch_count(0)
            if not count:
                self.generator_progress.set("All matching names have been checked or generated. Reset or change the pattern.")
                return
            self.generator, self.generator_signature = generator, signature
            self.open_large_batch(generator.iter_take(0), count, selected, timeout, generator=generator,
                                  match_rule=rule, chunk_size=min(CHECK_CHUNK_SIZE, limit or CHECK_CHUNK_SIZE))
        except (KeyError, ValueError) as exc:
            self.messagebox.showerror("Check the finder settings", str(exc))

    def generate_candidates(self, check=False):
        if self.running or not self.workers_done.is_set():
            return
        try:
            limit = self.get_batch_limit()
            if check:
                timeout = float(self.timeout.get())
                if not any(variable.get() for variable in self.site_vars.values()):
                    raise ValueError("Select at least one site in the main window.")
                if not math.isfinite(timeout) or not 1 <= timeout <= 60:
                    raise ValueError("Timeout must be between 1 and 60 seconds.")
            count = int(self.generator_vars["count"].get())
            if count < 0 or (limit and count > limit):
                raise ValueError("Use a nonnegative batch size within your chosen limit; set the limit to 0 for unlimited.")
            generator, signature = self.configured_generator()
            length = generator.length
            actual = generator.batch_count(count, limit)
            self.generator, self.generator_signature = generator, signature
            selected = [site for site in SITES if self.site_vars[site.key].get()] if check else []
            if actual * (len(selected) if check else 1) > LARGE_BATCH_THRESHOLD:
                self.open_large_batch(generator.iter_take(count, batch_limit=limit), actual, selected,
                                      timeout if check else 12, generate_only=not check, generator=generator)
                return
            names = self.generator.take(count, batch_limit=limit)
        except (KeyError, ValueError) as exc:
            self.messagebox.showerror("Check the generator settings", str(exc))
            return
        if not names:
            self.generator_progress.set("All matching names have been generated. Reset or change the pattern.")
            return
        self.input.delete("1.0", "end")
        self.input.insert("1.0", "\n".join(names))
        self.generator_progress.set(f"{format_candidate_count(self.generator.position)} / "
                                    f"{format_candidate_count(self.generator.total)} names generated · "
                                    f"{len(names)} in this batch")
        if self.generator_dialog is not None and self.generator_dialog.winfo_exists():
            self.generator_preview.configure(state="normal")
            self.generator_preview.delete("1.0", "end")
            self.generator_preview.insert("1.0", ", ".join(names))
            self.generator_preview.configure(state="disabled")
        self.details.set(f"Generated {len(names)} usernames with {length} characters. Select sites, then check.")
        if check:
            self.start()

    def open_large_batch(self, names, count, selected, timeout, *, generate_only=False, generator=None, source_names=None,
                         match_rule=None, chunk_size=None):
        start_position = generator.position if generator is not None else None
        source_spec = ({"kind": "generator", "config": generator.config, "start": start_position} if generator is not None else
                       {"kind": "names", "names": source_names} if source_names is not None else None)
        job = LargeBatchJob(names, count, selected, timeout, generate_only=generate_only,
                            cache=self.cache, refresh=not self.reuse_recent.get(), source_spec=source_spec, access=self.access,
                            match_rule=match_rule, chunk_size=chunk_size)
        finder = self.generator_dialog
        if finder is not None and finder.winfo_exists():
            finder.withdraw()
        def finished():
            if generator is not None:
                # Revisit a partially processed chunk on the next finder job;
                # closing an unfinished job must not silently skip those names.
                if job.pending_pairs:
                    generator.position = max(start_position, generator.position - len(job.pending_names))
                self.generator_progress.set(f"{format_candidate_count(generator.position)} / "
                                            f"{format_candidate_count(generator.total)} names generated")
            if finder is not None and finder.winfo_exists():
                finder.deiconify()
                finder.lift()
        view = LargeBatchWindow(self, job, finished)
        self.large_windows.append(view)
        self.details.set("Continuous finder opened. Stop keeps your finds; Export found saves the complete shortlist."
                         if match_rule else "Large batch opened. Use its Export all button to save every completed result.")
        return view

    def import_names(self):
        if self.running or not self.workers_done.is_set():
            return
        filename = self.filedialog.askopenfilename(
            title="Import usernames", filetypes=(("Username lists", "*.txt *.csv *.json"), ("All files", "*")),
        )
        if filename:
            try:
                names = load_usernames(Path(filename), self.get_batch_limit())
            except (OSError, ValueError) as exc:
                self.messagebox.showerror("Import failed", str(exc))
                return
            self.input.delete("1.0", "end")
            self.input.insert("1.0", "\n".join(names))
            self.details.set(f"Imported {len(names)} usernames. Select sites, then check.")

    def clear(self):
        if self.running or not self.workers_done.is_set():
            return
        self.input.delete("1.0", "end")
        self.results.clear()
        self.result_indices.clear()
        self.pending_pairs.clear()
        self.last_batch = self.original_batch = None
        self.started_at = self.finished_at = None
        self.stats = CheckStats()
        self.update_activity()
        self.search.set("")
        self.status_filter.set("All")
        self.refresh_table()
        self.progress.configure(value=0)
        self.summary.set("Ready · Ctrl+Enter to check")
        self.details.set("Select a result to view its details and profile link.")
        self.input.focus_set()

    def retry_unknown(self):
        if self.running or not self.workers_done.is_set():
            return
        if self.pending_pairs:
            self.details.set("Continue the unfinished batch before retrying unknown results, or start a new check.")
            return
        unknown = [result for result in self.results if result.status == "Unknown"]
        if not unknown:
            return
        try:
            limit = self.get_batch_limit()
            timeout = float(self.timeout.get())
            if not math.isfinite(timeout) or not 1 <= timeout <= 60:
                raise ValueError("Timeout must be between 1 and 60 seconds.")
        except ValueError as exc:
            self.messagebox.showerror("Check your input", str(exc))
            return
        site_keys = {site.name: site.key for site in SITES}
        only = {(result.username, site_keys[result.site]) for result in unknown}
        names = list(dict.fromkeys(result.username for result in unknown))
        if limit and len(names) > limit:
            self.messagebox.showerror("Increase the batch limit",
                                      f"Retry includes {len(names):,} usernames. Set Batch limit to at least {len(names):,}.")
            return
        selected = [site for site in SITES if any(key == site.key for _, key in only)]
        self.begin_check(names, selected, timeout, only, batch_limit=limit)

    def selected_result(self):
        selected = self.table.selection()
        return self.row_results.get(selected[0]) if selected else None

    def select_row(self, event=None):
        result = self.selected_result()
        if result is not None:
            self.details.set(result.detail + ("  " + result.profile_url if result.profile_url else ""))
            self.open_button.configure(state="normal" if result.profile_url else "disabled")
        else:
            self.open_button.configure(state="disabled")

    def open_profile(self):
        result = self.selected_result()
        if result is not None and result.profile_url:
            try:
                opened = webbrowser.open(result.profile_url)
            except webbrowser.Error:
                opened = False
            if not opened:
                self.messagebox.showinfo("Profile link", result.profile_url)

    def copy_results(self):
        if not self.visible_results:
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(result_text(self.visible_results))
        self.details.set("Results copied to the clipboard.")

    def copy_names(self):
        names = list(dict.fromkeys(result.username for result in self.visible_results))
        if names:
            self.root.clipboard_clear()
            self.root.clipboard_append("\n".join(names))
            self.details.set(f"Copied {len(names):,} unique usernames from the shown rows.")

    def save_results(self):
        if not self.visible_results:
            return
        filename = self.filedialog.asksaveasfilename(
            title="Export results", defaultextension=".csv", initialfile="username_results.csv",
            filetypes=(("CSV spreadsheet", "*.csv"), ("JSON", "*.json")),
        )
        if filename:
            try:
                export_results(Path(filename), self.visible_results)
            except (OSError, ValueError) as exc:
                self.messagebox.showerror("Export failed", str(exc))
            else:
                self.details.set(f"Saved {len(self.visible_results)} results to {Path(filename).name}.")

    def close(self):
        if self.file_busy:
            self.root.after(100, self.close)
            return
        live = [view for view in self.large_windows if view.dialog.winfo_exists()]
        if live:
            for view in live:
                view.request_close()
            self.root.after(100, self.close)
            return
        if self.cancel is not None:
            self.cancel.set()
        if self.preferences_file is not None:
            try:
                save_preferences(self.preferences_file, self.get_preferences())
            except (OSError, ValueError, KeyError, TypeError):
                pass
        self.root.after_cancel(self.poll_id)
        self.root.destroy()


def print_result_table(results: Iterable[Result]) -> None:
    """Share the CLI table renderer across in-memory and streamed results."""
    print(f"{'USERNAME':<28} {'SITE':<16} {'RESULT':<12} DETAILS")
    for result in results:
        print(f"{result.username:<28} {result.site:<16} {result.status:<12} {result.detail}")
    print("\nNot found does not guarantee registration availability.")


def cli_api_access():
    def notice(key, seconds):
        print(f"{SITE_BY_KEY[key].name}: cooldown {math.ceil(seconds)}s. Press Ctrl+C to stop.",
              file=sys.stderr, flush=True)
    return ApiAccess(environment_tokens(), on_cooldown=notice)


def run_large_cli(args, names, count, selected, sequence=None, *, restored_job=None, source_spec=None, access=None,
                  match_rule=None, chunk_size=None):
    """Run a large finite job without keeping its results or JSON output in RAM."""
    job = restored_job or LargeBatchJob(names, count, selected, args.timeout, source_spec=source_spec, access=access,
                                        match_rule=match_rule, chunk_size=chunk_size)
    if restored_job is not None and access is not None:
        job.access = access
    started = time.monotonic()
    interrupted = False
    wanted = None if args.status == "all" else STATUS_FILTERS[args.status]
    def shown():
        return (result for result in job.output_journal().read() if wanted is None or result.status == wanted)
    def unique_names():
        return unique_chunk_names(job.output_journal().read_chunks(), wanted)
    try:
        job.start()
        try:
            while not job.done.wait(0.1):
                pass
        except KeyboardInterrupt:
            interrupted = True
            job.stop()
            if not job.done.wait(1):
                print("Check stopped. Current work is finishing in the background.", file=sys.stderr)
                return 130
        if args.checkpoint:
            if not job.workers_done.wait(min(args.timeout + 1, 60)):
                print("Current requests have not finished; no checkpoint was written.", file=sys.stderr)
                return 130 if interrupted else 2
            job.save_checkpoint(args.checkpoint)
            print(f"Session saved: {args.checkpoint}", file=sys.stderr)
        if args.output:
            if job.generate_only or job.match_rule and args.output.suffix.lower() == ".txt":
                export_names(args.output, unique_names())
            else:
                export_results(args.output, shown())
            print(f"Saved: {args.output}", file=sys.stderr)
        if args.json:
            write_json_array(sys.stdout, unique_names() if args.names_only or job.generate_only else (asdict(result) for result in shown()))
        elif args.names_only or job.generate_only:
            for name in unique_names():
                print(name)
        else:
            print_result_table(shown())
        if sequence is not None:
            offset = sequence.position - (len(job.pending_names) if job.pending_pairs else 0)
            print(f"Next offset: {offset}." if offset < sequence.total else "Sequence complete.", file=sys.stderr)
        if args.stats:
            stats = job.stats.snapshot()
            print(f"{time.monotonic() - started:.2f}s | {stats['requests']:,} requests | "
                  f"{stats['cache_hits']:,} reused | {stats['local_results']:,} local results", file=sys.stderr)
        if job.error or job.reason:
            print(job.error or job.reason, file=sys.stderr)
        if interrupted:
            return 130
        if job.error:
            return 2
        return 1 if job.completed < job.total or any(job.counts[status] for status in ("Unknown", "Invalid", "Manual check")) else 0
    except (OSError, ValueError) as exc:
        print(f"Large batch failed: {exc}", file=sys.stderr)
        return 2
    finally:
        job.close()


def validate_checkpoint_destination(path, protected):
    if path is not None and (not path.parent.is_dir() or any(path.resolve() == other.resolve() for other in protected if other is not None)):
        raise ValueError("Choose a session file in an existing folder, separate from your input and exported results.")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Check public username profiles. No arguments opens the desktop app.")
    parser.add_argument("usernames", nargs="*", help="Usernames separated by spaces or commas; optional @ prefix")
    parser.add_argument("--sites", default="auto", help="Site keys, auto (default), all, manual, or a category")
    parser.add_argument("--list-sites", action="store_true", help="List supported site keys")
    parser.add_argument("--timeout", type=float, default=12, help="Request timeout in seconds (1–60)")
    parser.add_argument("--batch-limit", type=int,
                        help="Maximum names per batch; 0 means unlimited (default). Positive limits have no fixed maximum.")
    parser.add_argument("--output", type=Path, help="Export .csv or .json (overwrites an existing file)")
    parser.add_argument("--json", action="store_true", help="Print JSON instead of a table")
    parser.add_argument("--status", choices=tuple(STATUS_FILTERS),
                        default="all", help="Show/export only this result status")
    parser.add_argument("--names-only", action="store_true", help="Print only unique names from the shown results")
    parser.add_argument("--stats", action="store_true", help="Print elapsed time and request counts to stderr")
    parser.add_argument("--input", type=Path, help="Read usernames from a UTF-8 TXT, CSV, or JSON file")
    parser.add_argument("--checkpoint", type=Path, help="Save checking progress as a .ucsession file, including after Ctrl+C")
    parser.add_argument("--resume", type=Path, help="Resume a saved session, preserving completed results")
    generator_mode = parser.add_mutually_exclusive_group()
    generator_mode.add_argument("--generate", action="store_true", help="Generate names with --length, then check them")
    generator_mode.add_argument("--three-char", action="store_true", help="Shortcut for --generate --length 3")
    generator_mode.add_argument("--find", action="store_true", help="Keep finding names at --length until Ctrl+C or all combinations are checked")
    parser.add_argument("--match", choices=("any", "all"), help="With --find: require Not found on any/all selected automatic platforms (default: any)")
    parser.add_argument("--length", type=int, help=f"Exact character count for --generate/--find, 1–{MAX_USERNAME_LENGTH} (default: 3)")
    parser.add_argument("--charset", choices=("letters", "digits", "alnum", "custom"), default="alnum",
                        help="Character set for generated names (default: alnum)")
    parser.add_argument("--characters", default="", help="Characters to use with --charset custom")
    parser.add_argument("--pattern", help="Pattern matching --length; ? is a wildcard, e.g. a????; omit for any name")
    parser.add_argument("--count", type=int,
                        help=f"Number of names to generate; 0 means all remaining (default: {DEFAULT_BATCH_SIZE} or your lower limit)")
    parser.add_argument("--offset", type=int, default=0, help="Start at this position in the generated sequence")
    parser.add_argument("--seed", type=int, help="Shuffle deterministically with this seed; omit for ordered names")
    parser.add_argument("--generate-only", action="store_true", help="Print generated names without network checks")
    parser.add_argument("--version", action="version", version=f"{APP_NAME} {APP_VERSION}")
    parser.add_argument("--gui", action="store_true", help="Open the desktop app")
    args = parser.parse_args(argv)
    explicit_batch_limit = args.batch_limit is not None
    if args.batch_limit is None:
        args.batch_limit = DEFAULT_BATCH_LIMIT
    try:
        validate_batch_limit(args.batch_limit)
    except ValueError as exc:
        parser.error(str(exc))
    if args.list_sites:
        for site in SITES:
            print(f"{site.key:<14} {site.name:<17} {'Manual' if site.manual else 'Automatic':<10} {site.category}")
        return 0
    generate = args.generate or args.three_char or args.find
    if args.match is not None and not args.find:
        parser.error("Use --match with --find. Reopened finder sessions use their saved match rule.")
    if args.find and (args.count is not None or args.generate_only or args.status not in ("all", "not-found")):
        parser.error("--find checks all remaining candidates. Use --generate for fixed batches, and all/not-found for its result filter.")
    generator_options = (args.charset != "alnum" or args.characters or args.pattern is not None or args.length is not None
                         or args.count is not None or args.offset != 0 or args.seed is not None
                         or args.generate_only)
    if generator_options and not generate:
        parser.error("Use --generate or --find with generator options, or --three-char for length 3.")
    if args.three_char and args.length not in (None, 3):
        parser.error("--three-char uses length 3. Use --generate --length for a different length.")
    if args.gui:
        if (args.usernames or args.input or generate or args.output or args.json or args.checkpoint or args.resume or args.sites != "auto"
                or args.timeout != 12 or args.status != "all" or args.names_only or args.stats):
            parser.error("Use --gui with only --batch-limit, or enter usernames for command-line mode.")
        return launch_gui(batch_limit=args.batch_limit) if explicit_batch_limit else launch_gui()
    if args.resume:
        if (args.usernames or args.input or generate or generator_options or args.sites != "auto"
                or args.timeout != 12 or explicit_batch_limit):
            parser.error("--resume uses its saved names and settings; combine it with output/filter/stats/checkpoint options only.")
        job = None
        try:
            access = cli_api_access()
            job, _ = load_checkpoint(args.resume)
            if args.output and (args.output.resolve() == args.resume.resolve() or not args.output.parent.is_dir()
                                or args.output.suffix.lower() not in ((".txt", ".json") if job.generate_only else
                                                                   (".txt", ".csv", ".json") if job.match_rule else (".csv", ".json"))):
                raise ValueError("Choose a separate output file with the correct CSV/JSON or generated TXT/JSON extension.")
            if job.generate_only and args.status != "all":
                raise ValueError("Generated-name sessions have no checking statuses to filter.")
            if job.match_rule and args.status not in ("all", "not-found"):
                raise ValueError("Finder sessions contain Not found matches only.")
            validate_checkpoint_destination(args.checkpoint, [args.output])
        except (OSError, ValueError) as exc:
            if job is not None:
                job.close()
            parser.error(str(exc))
        args.timeout = job.timeout
        return run_large_cli(args, (), job.count, job.sites, restored_job=job, access=access)
    if not args.usernames and not args.input and not generate:
        if (args.output or args.json or args.checkpoint or args.sites != "auto" or args.timeout != 12
                or args.batch_limit != DEFAULT_BATCH_LIMIT or args.status != "all" or args.names_only or args.stats):
            parser.error("Enter at least one username for command-line options.")
        return launch_gui()
    try:
        sequence = None
        if generate:
            if args.usernames or args.input:
                raise ValueError("Use the generator without positional names or --input.")
            if args.generate_only and args.output:
                raise ValueError("--generate-only prints names to stdout; redirect it to a TXT or JSON file.")
            if args.generate_only and args.checkpoint:
                raise ValueError("Use --checkpoint with checking batches. Generated-name sessions can be saved in the desktop finder.")
            if args.generate_only and (args.status != "all" or args.names_only or args.stats):
                raise ValueError("Result filters, --names-only and --stats require checking the generated names.")
            length = args.length if args.length is not None else DEFAULT_USERNAME_LENGTH
            sequence = CharacterSearch(args.charset, args.pattern, args.characters, args.seed, args.offset, length=length)
            count = 0 if args.find else args.count if args.count is not None else min(DEFAULT_BATCH_SIZE, args.batch_limit or DEFAULT_BATCH_SIZE)
            limit = 0 if args.find else args.batch_limit
            name_count = sequence.batch_count(count, limit)
            usernames = (sequence.iter_take(count, batch_limit=limit)
                         if args.find or args.generate_only or args.checkpoint or name_count > LARGE_BATCH_THRESHOLD else
                         sequence.take(count, batch_limit=limit))
        else:
            imported = load_usernames(args.input, args.batch_limit) if args.input else []
            usernames = parse_usernames(" ".join([*args.usernames, *imported]), args.batch_limit)
            name_count = len(usernames)
        if not math.isfinite(args.timeout) or not 1 <= args.timeout <= 60:
            raise ValueError("Timeout must be between 1 and 60 seconds.")
        selected = select_sites(args.sites)
        if args.find:
            selected = [site for site in selected if not site.manual]
            if not selected:
                raise ValueError("Continuous finding needs at least one automatic platform.")
        if args.output and (args.output.suffix.lower() not in ((".txt", ".csv", ".json") if args.find else (".csv", ".json"))
                            or not args.output.parent.is_dir()):
            raise ValueError("Choose an output file inside an existing directory: .csv/.json, or .txt for continuous finds.")
        if args.output and args.input and args.output.resolve() == args.input.resolve():
            raise ValueError("Choose a different output file so your input list is preserved.")
        validate_checkpoint_destination(args.checkpoint, [args.input, args.output])
    except (OSError, ValueError) as exc:
        parser.error(str(exc))
    if args.generate_only:
        try:
            if args.json:
                write_json_array(sys.stdout, usernames)
            else:
                for name in usernames:
                    print(name)
        except KeyboardInterrupt:
            print(f"\nGeneration stopped. Next offset: {sequence.position}.", file=sys.stderr)
            return 130
    if sequence is not None and not args.find and (args.generate_only or name_count * len(selected) <= LARGE_BATCH_THRESHOLD):
        progress = f"{format_candidate_count(sequence.position)}/{format_candidate_count(sequence.total)} names generated"
        continuation = f"next offset {sequence.position}" if sequence.position < sequence.total else "sequence complete"
        print(f"{sequence.length}-character batch: {progress}; {continuation}.", file=sys.stderr)
    if args.generate_only:
        return 0
    try:
        access = cli_api_access()
    except ValueError as exc:
        parser.error(str(exc))
    if args.find or args.checkpoint or name_count * len(selected) > LARGE_BATCH_THRESHOLD:
        source_spec = ({"kind": "generator", "config": sequence.config, "start": args.offset} if sequence is not None else
                       {"kind": "names", "names": usernames})
        return run_large_cli(args, usernames, name_count, selected, sequence, source_spec=source_spec, access=access,
                             match_rule=(args.match or "any") if args.find else None,
                             chunk_size=min(CHECK_CHUNK_SIZE, args.batch_limit or CHECK_CHUNK_SIZE) if args.find else None)
    cancel = threading.Event()
    started_at = time.monotonic()
    stats = CheckStats()
    check_options = {"batch_limit": args.batch_limit, "access": access}
    if args.stats:
        check_options["stats"] = stats
    try:
        results = run_checks(usernames, selected, args.timeout, cancel, **check_options)
    except KeyboardInterrupt:
        cancel.set()
        print("\nCheck stopped.", file=sys.stderr)
        return 130
    order = {(name, site.name): (i, j) for i, name in enumerate(usernames) for j, site in enumerate(selected)}
    results.sort(key=lambda result: order[(result.username, result.site)])
    if access.exhausted_sites():
        print("Automatic rate-limit retries exhausted. Unfinished checks were not marked as completed. "
              "Use --checkpoint to save resumable progress.", file=sys.stderr)
    shown = filter_results(results, status=STATUS_FILTERS[args.status])
    if args.names_only:
        names = list(dict.fromkeys(result.username for result in shown))
        if args.json:
            print(json.dumps(names, indent=2))
        elif names:
            print("\n".join(names))
    elif args.json:
        print(json.dumps([asdict(result) for result in shown], indent=2, ensure_ascii=False))
    else:
        print_result_table(shown)
    if args.output:
        try:
            export_results(args.output, shown)
        except (OSError, ValueError) as exc:
            print(f"Export failed: {exc}", file=sys.stderr)
            return 2
        print(f"Saved: {args.output}", file=sys.stderr)
    if args.stats:
        counts = stats.snapshot()
        print(f"{time.monotonic() - started_at:.2f}s | {counts['requests']:,} requests | "
              f"{counts['cache_hits']:,} reused | {counts['local_results']:,} local results", file=sys.stderr)
    return 1 if len(results) < name_count * len(selected) or any(
        result.status in ("Unknown", "Invalid", "Manual check") for result in results) else 0


if __name__ == "__main__":
    raise SystemExit(main())
