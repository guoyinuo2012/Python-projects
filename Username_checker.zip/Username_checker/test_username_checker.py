"""Deterministic tests for the checker; no accounts or internet required."""

import contextlib
import csv
import http.client
import io
import itertools
import json
import os
import shutil
import ssl
import subprocess
import sys
import tempfile
import threading
import time
import tracemalloc
import unittest
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import Mock, patch

import username_checker as app


def response(code, data, *, valid_json=True, headers=None):
    return app.APIResponse(code, data, headers or {}, valid_json)


def sample_result(name="example", site="GitHub", status="Taken", detail="Account found."):
    return app.Result(name, site, status, "https://github.com/example", detail, "2026-10-14T07:00:00+00:00")


class InputTests(unittest.TestCase):
    def test_split_prefix_and_case_insensitive_duplicates(self):
        self.assertEqual(app.parse_usernames(" @Example,example\nother_name\tthird-name "),
                         ["Example", "other_name", "third-name"])

    def test_empty_url_control_characters_and_non_ascii_are_rejected(self):
        for value in ("", "@", "@@name", "https://example.com/name", "a/b", "a\x00b", "你好", "a" * 254):
            with self.subTest(value=value), self.assertRaises(ValueError):
                app.parse_usernames(value)

    def test_input_limit(self):
        self.assertEqual(len(app.parse_usernames(" ".join(f"name{i}" for i in range(500)), batch_limit=500)), 500)
        with self.assertRaises(ValueError):
            app.parse_usernames(" ".join(f"name{i}" for i in range(501)), batch_limit=500)
        with self.assertRaises(ValueError):
            app.parse_usernames("x" * 301, batch_limit=1)

    def test_github_format(self):
        site = app.SITE_BY_KEY["github"]
        for name in ("a", "name-123", "a" * 39):
            self.assertIsNone(app.format_error(site, name))
        for name in ("-name", "name-", "name--name", "name_name", "a" * 40):
            self.assertIsNotNone(app.format_error(site, name))

    def test_roblox_format(self):
        site = app.SITE_BY_KEY["roblox"]
        self.assertIsNone(app.format_error(site, "name_123"))
        for name in ("ab", "_name", "name_", "na_me_2", "a" * 21):
            self.assertIsNotNone(app.format_error(site, name))

    def test_bluesky_short_and_full_handles(self):
        site = app.SITE_BY_KEY["bluesky"]
        self.assertEqual(app.lookup_name(site, "Example"), "example.bsky.social")
        self.assertEqual(app.lookup_name(site, "BSKY.APP"), "bsky.app")
        for name in ("name", "name-with-dashes", "bsky.app", "a" * 63):
            self.assertIsNone(app.format_error(site, name))
        for name in ("name_name", "-name", "name-", "a..app", "name.123", "a" * 64):
            self.assertIsNotNone(app.format_error(site, name))

    def test_invalid_name_makes_no_network_request(self):
        with patch.object(app, "request_api") as request:
            result = app.check_one(app.SITE_BY_KEY["github"], "name_name")
        self.assertEqual(result.status, "Invalid")
        self.assertEqual(result.profile_url, "")
        request.assert_not_called()


class CustomBatchLimitTests(unittest.TestCase):
    def test_custom_limits_accept_larger_inputs_and_enforce_the_chosen_cap(self):
        for limit in (1, 1000, 10001):
            text = " ".join(f"name{i}" for i in range(limit))
            self.assertEqual(len(app.parse_usernames(text, batch_limit=limit)), limit)
            with self.assertRaises(ValueError):
                app.parse_usernames(text + " extra_name", batch_limit=limit)
        with self.assertRaises(ValueError):
            app.parse_usernames(" ".join(f"name{i}" for i in range(1000)), batch_limit=500)

    def test_all_import_formats_respect_a_custom_limit(self):
        names = [f"name{i}" for i in range(25)]
        fixtures = {"txt": "\n".join(names), "csv": "username\n" + "\n".join(names), "json": json.dumps(names)}
        with tempfile.TemporaryDirectory() as folder:
            for extension, content in fixtures.items():
                path = Path(folder) / ("names." + extension)
                path.write_text(content, encoding="utf-8")
                self.assertEqual(app.load_usernames(path, batch_limit=25), names)
                with self.assertRaises(ValueError):
                    app.load_usernames(path, batch_limit=24)

    def test_generation_uses_the_chosen_limit_without_consuming_rejected_batches(self):
        search = app.ThreeCharacterSearch(seed=123)
        with self.assertRaises(ValueError):
            search.take(1000, batch_limit=500)
        self.assertEqual(search.position, 0)
        self.assertEqual(len(search.take(1000, batch_limit=1000)), 1000)
        with self.assertRaises(ValueError):
            search.take(11, batch_limit=10)
        self.assertEqual(search.position, 1000)
        self.assertEqual(len(search.take(10, batch_limit=10)), 10)

    def test_invalid_limits_are_rejected_before_requests_or_import_reads(self):
        invalid = (-1, -100, True, 1.5, "100")
        with patch.object(app, "request_api") as request:
            for limit in invalid:
                operations = (
                    lambda: app.parse_usernames("example", batch_limit=limit),
                    lambda: app.load_usernames(Path("missing.txt"), batch_limit=limit),
                    lambda: app.ThreeCharacterSearch().take(1, batch_limit=limit),
                    lambda: app.run_checks(["example"], [app.SITE_BY_KEY["instagram"]], batch_limit=limit),
                )
                for operation in operations:
                    with self.subTest(limit=limit), self.assertRaises(ValueError):
                        operation()
        request.assert_not_called()

    def test_backend_checks_a_batch_larger_than_the_default(self):
        names = [f"name{i}" for i in range(1000)]
        with patch.object(app, "request_api") as request:
            results = app.run_checks(names, [app.SITE_BY_KEY["instagram"]], batch_limit=1000)
        self.assertEqual([result.username for result in results], names)
        self.assertTrue(all(result.status == "Manual check" for result in results))
        request.assert_not_called()


class ThreeCharacterTests(unittest.TestCase):
    def test_large_candidate_batches_have_no_repeats(self):
        sequence = app.ThreeCharacterSearch(seed=123)
        first, second = sequence.take(500), sequence.take(500)
        self.assertEqual(len(first), 500)
        self.assertEqual(len(second), 500)
        self.assertEqual(len(set(first + second)), 1000)
        self.assertTrue(all(len(name) == 3 for name in first + second))

    def test_default_sequence_contains_exactly_three_characters(self):
        sequence = app.ThreeCharacterSearch()
        names = sequence.take(20)
        self.assertEqual(sequence.total, 36 ** 3)
        self.assertEqual(len(names), 20)
        self.assertTrue(all(len(name) == 3 and name.isalnum() and name == name.lower() for name in names))
        self.assertEqual(len(set(names)), 20)

    def test_all_custom_combinations_are_reachable_without_duplicates(self):
        sequence = app.ThreeCharacterSearch("custom", characters="a1_")
        names = []
        while sequence.position < sequence.total:
            names.extend(sequence.take(7))
        expected = {"".join(chars) for chars in itertools.product("a1_", repeat=3)}
        self.assertEqual(set(names), expected)
        self.assertEqual(len(names), len(expected))
        self.assertEqual(sequence.take(), [])

    def test_letter_and_digit_counts_and_first_and_last_names(self):
        for charset, total, first, last in (("letters", 26 ** 3, "aaa", "zzz"), ("digits", 1000, "000", "999")):
            with self.subTest(charset=charset):
                sequence = app.ThreeCharacterSearch(charset)
                self.assertEqual(sequence.total, total)
                self.assertEqual(sequence.take(1), [first])
                ending = app.ThreeCharacterSearch(charset, offset=total - 1)
                self.assertEqual(ending.take(20), [last])

    def test_patterns_support_each_wildcard_position_and_exact_names(self):
        sequence = app.ThreeCharacterSearch("letters", "a??")
        self.assertEqual(sequence.total, 676)
        self.assertTrue(all(name.startswith("a") for name in sequence.take()))
        sequence = app.ThreeCharacterSearch("alnum", "?7?")
        self.assertEqual(sequence.total, 36 ** 2)
        self.assertTrue(all(name[1] == "7" for name in sequence.take()))
        self.assertEqual(app.ThreeCharacterSearch("alnum", "ABC").take(), ["abc"])

    def test_custom_characters_are_case_normalized_and_deduplicated(self):
        sequence = app.ThreeCharacterSearch("custom", characters="AaBbBb")
        self.assertEqual(sequence.total, 8)
        self.assertEqual(sequence.take(), ["aaa", "aab", "aba", "abb", "baa", "bab", "bba", "bbb"])

    def test_shuffled_pagination_is_repeatable_and_never_repeats(self):
        first = app.ThreeCharacterSearch("custom", characters="abc", seed=42)
        names = first.take(20) + first.take(20)
        self.assertEqual(len(names), 27)
        self.assertEqual(len(set(names)), 27)
        repeated = app.ThreeCharacterSearch("custom", characters="abc", seed=42)
        self.assertEqual(repeated.take(20) + repeated.take(20), names)
        continued = app.ThreeCharacterSearch("custom", characters="abc", seed=42, offset=20)
        self.assertEqual(continued.take(), names[20:])
        self.assertNotEqual(names, app.ThreeCharacterSearch("custom", characters="abc").take(20))

    def test_invalid_patterns_characters_and_offsets_are_rejected(self):
        cases = ({"pattern": "??"}, {"pattern": "????"}, {"pattern": "a ?"},
                 {"charset": "letters", "pattern": "?1?"}, {"charset": "unknown"},
                 {"charset": "custom"}, {"charset": "custom", "characters": "a!"},
                 {"charset": "custom", "characters": "你好"}, {"characters": "abc"},
                 {"offset": -1}, {"offset": 36 ** 3}, {"offset": True}, {"offset": 0.5})
        for settings in cases:
            with self.subTest(settings=settings), self.assertRaises(ValueError):
                app.ThreeCharacterSearch(**settings)

    def test_batch_limits_are_checked_without_consuming_names(self):
        sequence = app.ThreeCharacterSearch()
        for count in (501, -1, True, 2.5):
            with self.subTest(count=count), self.assertRaises(ValueError):
                sequence.take(count, batch_limit=500)
            self.assertEqual(sequence.position, 0)


class CharacterLengthTests(unittest.TestCase):
    def test_selected_lengths_generate_exactly_that_many_characters(self):
        for length in (1, 2, 3, 4, 5, 12, 32, 64, 253):
            with self.subTest(length=length):
                sequence = app.CharacterSearch("letters", length=length)
                names = sequence.take(20)
                self.assertEqual(len(names), 20)
                self.assertTrue(all(len(name) == length and name.isascii() and name.islower() for name in names))
                self.assertEqual(sequence.total, 26 ** length)

    def test_patterns_and_custom_characters_match_the_selected_length(self):
        sequence = app.CharacterSearch("custom", "a?b??", characters="ABC12_", length=5)
        names = sequence.take(100)
        self.assertTrue(all(len(name) == 5 and name[0] == "a" and name[2] == "b" for name in names))
        self.assertTrue(all(set(name) <= set("abc12_") for name in names))
        self.assertEqual(sequence.total, 6 ** 3)
        self.assertEqual(app.CharacterSearch("letters", "Exact", length=5).take(), ["exact"])

    def test_small_spaces_exhaust_without_repeating_or_padding(self):
        sequence = app.CharacterSearch("custom", characters="ab", length=1, seed=7)
        self.assertEqual(set(sequence.take(20)), {"a", "b"})
        self.assertEqual(sequence.take(), [])
        self.assertEqual(sequence.position, 2)

    def test_invalid_lengths_and_mismatching_patterns_are_rejected(self):
        for length in (0, -1, 254, 1000000, True, 3.5, "5"):
            with self.subTest(length=length), self.assertRaisesRegex(ValueError, "Character count"):
                app.CharacterSearch(length=length)
        for pattern in ("???", "??????", "ab!??", "12???"):
            with self.subTest(pattern=pattern), self.assertRaises(ValueError):
                app.CharacterSearch("letters", pattern, length=5)

    def test_empty_or_omitted_pattern_uses_the_selected_length(self):
        for pattern in (None, ""):
            self.assertEqual(app.CharacterSearch("digits", pattern, length=4).take(3), ["0000", "0001", "0002"])

    def test_long_shuffled_generation_has_bounded_memory(self):
        tracemalloc.start()
        try:
            sequence = app.CharacterSearch(length=253, seed=42)
            names = sequence.take(100)
            _, peak = tracemalloc.get_traced_memory()
        finally:
            tracemalloc.stop()
        self.assertTrue(all(len(name) == 253 for name in names))
        self.assertEqual(len(set(names)), 100)
        self.assertLess(peak, 8 * 1024 * 1024)

    def test_large_shuffled_pages_resume_from_the_same_seed_and_offset(self):
        sequence = app.CharacterSearch(length=32, seed=42)
        first, second = sequence.take(500), sequence.take(500)
        self.assertEqual(len(set(first + second)), 1000)
        repeated = app.CharacterSearch(length=32, seed=42, offset=500)
        self.assertEqual(repeated.take(500), second)
        self.assertNotEqual(app.CharacterSearch(length=32, seed=43).take(), first[:20])

    def test_large_space_permutation_reaches_every_combination_once(self):
        with patch.object(app, "SHUFFLE_MEMORY_LIMIT", 0):
            for characters in ("a", "ab", "a1_", "abcd"):
                for seed in (0, 1, 42):
                    with self.subTest(characters=characters, seed=seed):
                        sequence = app.CharacterSearch("custom", characters=characters, length=4, seed=seed)
                        names = sequence.take(500)
                        expected = {"".join(parts) for parts in itertools.product(characters, repeat=4)}
                        self.assertEqual(set(names), expected)
                        self.assertEqual(len(names), len(expected))
                        self.assertEqual(sequence.take(), [])

    def test_huge_ordered_offsets_do_not_require_enumerating_previous_names(self):
        total = 36 ** 64
        sequence = app.CharacterSearch(length=64, offset=total - 2)
        self.assertEqual(sequence.take(), ["9" * 63 + "8", "9" * 64])
        self.assertEqual(sequence.position, total)
        self.assertEqual(sequence.take(), [])

    def test_fully_fixed_long_pattern_and_custom_limits(self):
        self.assertEqual(app.CharacterSearch("letters", "a" * 253, length=253, seed=4).take(), ["a" * 253])
        sequence = app.CharacterSearch(length=5)
        with self.assertRaises(ValueError):
            sequence.take(21, batch_limit=20)
        self.assertEqual(sequence.position, 0)
        self.assertEqual(len(sequence.take(1000, batch_limit=1000)), 1000)

    def test_large_search_counters_stay_short_and_small_counters_stay_exact(self):
        self.assertEqual(app.format_candidate_count(46656), "46,656")
        self.assertEqual(app.format_candidate_count(10 ** 100), "1.000e100")
        self.assertLess(len(app.format_candidate_count(36 ** 253)), 15)


@unittest.skipUnless(os.name == "posix" and shutil.which("sh"), "Unix launchers require a POSIX shell.")
class UnixLauncherTests(unittest.TestCase):
    def run_launcher(self, launcher, python3_status=0, python_status=0, app_status=0, missing=False):
        folder = tempfile.TemporaryDirectory()
        self.addCleanup(folder.cleanup)
        base = Path(folder.name)
        project, binaries = base / "App folder with spaces", base / "bin"
        project.mkdir()
        binaries.mkdir()
        source = Path(__file__).resolve().parent / launcher
        shutil.copy2(source, project / launcher)
        shutil.copy2(shutil.which("dirname"), binaries / "dirname")
        log = base / "calls.json"
        executable = sys.executable.replace("'", "'\"'\"'")
        for name, probe_status in (() if missing else (("python3", python3_status), ("python", python_status))):
            script = ("#!/bin/sh\nif [ \"$1\" = '-c' ]; then exit " + str(probe_status) + "; fi\n"
                      "exec '" + executable + "' -c 'import json, os, sys; "
                      "open(os.environ[\"LAUNCH_TEST_LOG\"], \"w\").write(json.dumps({\"cwd\": os.getcwd(), \"args\": sys.argv[1:]})); "
                      "raise SystemExit(int(os.environ[\"LAUNCH_TEST_STATUS\"]))' \"$@\"\n")
            path = binaries / name
            path.write_text(script, encoding="utf-8")
            path.chmod(0o755)
        env = dict(os.environ, PATH=str(binaries), LAUNCH_TEST_LOG=str(log), LAUNCH_TEST_STATUS=str(app_status))
        result = subprocess.run([shutil.which("sh"), str(project / launcher)], cwd=base, env=env,
                                capture_output=True, text=True, timeout=5)
        record = json.loads(log.read_text()) if log.exists() else None
        return result, record, project

    def test_both_launchers_handle_other_working_directories_and_spaces(self):
        for launcher in ("Start_on_Linux.sh", "Start_on_macOS.command"):
            with self.subTest(launcher=launcher):
                result, record, project = self.run_launcher(launcher)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(record, {"cwd": str(project), "args": [str(project / "username_checker.py"), "--gui"]})

    def test_both_launchers_fall_back_from_an_unsupported_python3(self):
        for launcher in ("Start_on_Linux.sh", "Start_on_macOS.command"):
            with self.subTest(launcher=launcher):
                result, record, _ = self.run_launcher(launcher, python3_status=1)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertIsNotNone(record)

    def test_missing_or_old_python_gives_a_readable_error(self):
        for launcher in ("Start_on_Linux.sh", "Start_on_macOS.command"):
            for missing in (True, False):
                with self.subTest(launcher=launcher, missing=missing):
                    result, record, _ = self.run_launcher(launcher, python3_status=1, python_status=1, missing=missing)
                    self.assertEqual(result.returncode, 2)
                    self.assertIn("Python 3.10", result.stderr)
                    self.assertIsNone(record)

    def test_application_exit_code_is_preserved_without_hanging_noninteractive_runs(self):
        for launcher in ("Start_on_Linux.sh", "Start_on_macOS.command"):
            with self.subTest(launcher=launcher):
                result, _, _ = self.run_launcher(launcher, app_status=7)
                self.assertEqual(result.returncode, 7)


class ImportTests(unittest.TestCase):
    def load(self, extension, contents):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / ("names" + extension)
            path.write_text(contents, encoding="utf-8")
            return app.load_usernames(path)

    def test_text_import_handles_bom_prefixes_and_duplicates(self):
        self.assertEqual(self.load(".txt", "\ufeff@Example, example\nsecond"), ["Example", "second"])

    def test_csv_header_can_be_in_any_column(self):
        self.assertEqual(self.load(".csv", 'site, Username ,note\nGitHub,example,"note, with comma"\nGitLab,second,ok\n'),
                         ["example", "second"])

    def test_single_column_csv_without_header(self):
        self.assertEqual(self.load(".csv", "example\nsecond\n"), ["example", "second"])

    def test_json_accepts_strings_and_exported_records(self):
        self.assertEqual(self.load(".json", '["example", {"username":"second"}, "EXAMPLE"]'),
                         ["example", "second"])

    def test_exported_files_can_be_imported(self):
        with tempfile.TemporaryDirectory() as folder:
            for extension in (".csv", ".json"):
                path = Path(folder) / ("results" + extension)
                app.export_results(path, [sample_result(name="-example"), sample_result(name="other")])
                self.assertEqual(app.load_usernames(path), ["-example", "other"])

    def test_bad_structure_and_empty_names_are_rejected(self):
        cases = ((".txt", ""), (".txt", "https://github.com/example"), (".json", "{}"),
                 (".json", "[1]"), (".json", '[{"name":"example"}]'), (".json", '[""]'),
                 (".json", '["two names"]'), (".json", "{"), (".csv", "site,name\nx,y"),
                 (".csv", "username\n\"broken"), (".csv", "site,username\nx"))
        for extension, text in cases:
            with self.subTest(extension=extension, text=text), self.assertRaises(ValueError):
                self.load(extension, text)

    def test_size_encoding_extension_and_name_count_limits(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "names.txt"
            for raw in (b"a" * (app.MAX_INPUT_BYTES + 1), b"\xff\xfe"):
                path.write_bytes(raw)
                with self.assertRaises(ValueError):
                    app.load_usernames(path)
        with self.assertRaises(ValueError):
            self.load(".bin", "example")
        self.assertEqual(self.load(".json", json.dumps([f"name{i}" for i in range(1001)])), [f"name{i}" for i in range(1001)])

    def test_long_username_exports_deduplicate_before_input_limit(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "results.json"
            results = [sample_result(name=("a" * 250) + str(index), site=site.name)
                       for index in range(20) for site in app.SITES]
            app.export_results(path, results)
            self.assertEqual(len(app.load_usernames(path)), 20)


class ResultViewTests(unittest.TestCase):
    def test_search_status_and_sort_are_combined_without_mutating_source(self):
        original = [sample_result("zeta", status="Unknown"), sample_result("alpha", status="Taken"),
                    sample_result("beta", site="GitLab", status="Taken")]
        self.assertEqual([r.username for r in app.filter_results(original, "github", "Taken")], ["alpha"])
        self.assertEqual([r.username for r in app.filter_results(original, sort_by="username")],
                         ["alpha", "beta", "zeta"])
        self.assertEqual([r.username for r in app.filter_results(original, sort_by="username", descending=True)],
                         ["zeta", "beta", "alpha"])
        self.assertEqual([r.username for r in original], ["zeta", "alpha", "beta"])

    def test_search_is_case_insensitive_and_matches_details(self):
        self.assertEqual(len(app.filter_results([sample_result()], "  ACCOUNT FOUND  ")), 1)
        self.assertEqual(app.filter_results([sample_result()], status="Invalid"), [])


class AdapterTests(unittest.TestCase):
    def interpret(self, key, value, name="example"):
        return app.interpret(app.SITE_BY_KEY[key], name, value)

    def test_matching_accounts_are_taken_and_case_insensitive(self):
        self.assertEqual(self.interpret("github", response(200, {"login": "EXAMPLE", "id": 42}))[0], "Taken")
        self.assertEqual(self.interpret("gitlab", response(200, [{"username": "Example", "id": 42}]))[0], "Taken")

    def test_account_identity_and_exact_match_are_required(self):
        for data in ({"login": "example"}, {"login": "other", "id": 1},
                     {"login": "example", "id": True}, {"login": "example", "id": "1"}, [], None):
            self.assertEqual(self.interpret("github", response(200, data))[0], "Unknown")
        self.assertEqual(self.interpret("gitlab", response(200, [{"username": "other", "id": 1}]))[0], "Unknown")

    def test_known_missing_account_responses(self):
        self.assertEqual(self.interpret("github", response(404, {"message": "Not Found"}))[0], "Not found")
        self.assertEqual(self.interpret("gitlab", response(200, []))[0], "Not found")
        self.assertEqual(self.interpret("roblox", response(200, {"data": []}))[0], "Not found")

    def test_unrecognized_404_and_html_do_not_imply_availability(self):
        for key in (site.key for site in app.AUTOMATIC_SITES):
            for value in (response(404, {"message": "maintenance"}),
                          response(404, None, valid_json=False), response(200, None, valid_json=False)):
                self.assertEqual(self.interpret(key, value)[0], "Unknown")

    def test_blocked_rate_limited_redirected_and_server_errors(self):
        for key in (site.key for site in app.AUTOMATIC_SITES):
            for code in (301, 302, 401, 403, 429, 500, 503):
                with self.subTest(site=key, code=code):
                    self.assertEqual(self.interpret(key, response(code, {}))[0], "Unknown")
        limited = response(403, {}, headers={"x-ratelimit-remaining": "0"})
        self.assertIn("Rate limited", self.interpret("github", limited)[1])

    def test_roblox_request_includes_banned_accounts(self):
        request = app.build_request(app.SITE_BY_KEY["roblox"], "Example")
        self.assertEqual(request.get_method(), "POST")
        self.assertEqual(json.loads(request.data), {"usernames": ["Example"], "excludeBannedUsers": False})

    def test_roblox_requested_name_and_numeric_profile_url(self):
        value = response(200, {"data": [{"requestedUsername": "EXAMPLE", "name": "NewName", "id": 42}]})
        result = self.interpret("roblox", value)
        self.assertEqual(result[0], "Taken")
        self.assertEqual(result[2], "https://www.roblox.com/users/42/profile")
        bad = response(200, {"data": [{"requestedUsername": "other", "id": 42}]})
        self.assertEqual(self.interpret("roblox", bad)[0], "Unknown")

    def test_bluesky_resolution_and_unambiguous_missing_handle(self):
        self.assertEqual(self.interpret("bluesky", response(200, {"did": "did:plc:example"}))[0], "Taken")
        self.assertEqual(self.interpret("bluesky", response(400, {"error": "HandleNotFound"}))[0], "Not found")
        for data in ({"error": "InvalidRequest", "message": "Unable to resolve handle"},
                     {"did": "not-a-did"}, {"did": 123}, {"did": "did:"}):
            self.assertEqual(self.interpret("bluesky", response(400, data))[0], "Unknown")

    def test_all_requests_use_fixed_https_hosts(self):
        expected = {"github": "api.github.com", "gitlab": "gitlab.com", "roblox": "users.roblox.com",
                    "bluesky": "bsky.social", "chesscom": "api.chess.com"}
        self.assertEqual({site.key for site in app.AUTOMATIC_SITES}, set(expected))
        for site in app.AUTOMATIC_SITES:
            request = app.build_request(site, "example")
            self.assertEqual(request.type, "https")
            self.assertEqual(request.host, expected[site.key])

    def test_network_error_returns_unknown_and_timestamp(self):
        with patch.object(app, "request_api", side_effect=app.CheckError("Request timed out.")):
            result = app.check_one(app.SITE_BY_KEY["github"], "example")
        self.assertEqual(result.status, "Unknown")
        self.assertIn("timed out", result.detail)
        self.assertTrue(result.checked_at.endswith("+00:00"))

    def test_chesscom_requires_a_matching_name_and_numeric_player_identity(self):
        self.assertEqual(self.interpret("chesscom", response(200, {"username": "EXAMPLE", "player_id": 42}))[0], "Taken")
        for data in ({"username": "different", "player_id": 42}, {"username": "example", "player_id": True},
                     {"username": "example", "player_id": 0}, {"username": "example", "player_id": "42"}, {}, None):
            with self.subTest(data=data):
                self.assertEqual(self.interpret("chesscom", response(200, data))[0], "Unknown")

    def test_chesscom_recognizes_only_its_specific_missing_response(self):
        missing = {"code": 0, "message": "Data not found"}
        self.assertEqual(self.interpret("chesscom", response(404, missing))[0], "Not found")
        for code in (200, 403, 503):
            self.assertEqual(self.interpret("chesscom", response(code, missing))[0], "Unknown")
        self.assertEqual(self.interpret("chesscom", response(404, {"code": False, "message": "Data not found"}))[0], "Unknown")
        self.assertEqual(self.interpret("chesscom", response(404, {"code": 0, "message": "maintenance"}))[0], "Unknown")

    def test_roblox_error_payload_does_not_look_like_an_empty_success(self):
        self.assertEqual(self.interpret("roblox", response(200, {"data": [], "errors": [{"code": 1}]}))[0], "Unknown")

    def test_manual_platforms_never_make_automated_requests(self):
        with patch.object(app, "request_api") as request:
            for site in app.SITES:
                if site.manual:
                    with self.subTest(site=site.key):
                        result = app.check_one(site, "example")
                        self.assertEqual(result.status, "Manual check")
                        self.assertTrue(result.profile_url.startswith("https://"))
                        self.assertNotIn(result.status, ("Taken", "Not found"))
        request.assert_not_called()

    def test_manual_platforms_have_no_http_adapter(self):
        for site in app.select_sites("manual"):
            with self.subTest(site=site.key), self.assertRaises(ValueError):
                app.build_request(site, "example")

    def test_all_platforms_use_only_the_five_supported_api_adapters(self):
        fixtures = {
            "api.github.com": {"login": "example", "id": 1},
            "gitlab.com": [{"username": "example", "id": 2}],
            "users.roblox.com": {"data": [{"requestedUsername": "example", "id": 3}]},
            "bsky.social": {"did": "did:plc:example"},
            "api.chess.com": {"username": "example", "player_id": 4},
        }
        stats = app.CheckStats()
        with patch.object(app, "request_api", side_effect=lambda request, timeout: response(200, fixtures[request.host])) as request:
            results = app.run_checks(["example"], app.SITES, stats=stats)
        self.assertEqual(len(results), 32)
        self.assertEqual(request.call_count, 5)
        self.assertEqual(sum(result.status == "Taken" for result in results), 5)
        self.assertEqual(sum(result.status == "Manual check" for result in results), 27)
        self.assertEqual(stats.snapshot(), {"requests": 5, "cache_hits": 0, "local_results": 27})

    def test_unknown_adapter_cannot_accept_a_github_shaped_response(self):
        site = app.Site("unsupported", "Unsupported", "https://example.com/{username}")
        self.assertEqual(app.interpret(site, "example", response(200, {"login": "example", "id": 1}))[0], "Unknown")
        with self.assertRaises(ValueError):
            app.build_request(site, "example")


class PlatformSelectionTests(unittest.TestCase):
    def test_automatic_manual_and_category_presets(self):
        self.assertEqual(len(app.select_sites("auto")), 5)
        self.assertTrue(all(not site.manual for site in app.select_sites("auto")))
        self.assertEqual(len(app.select_sites("all")), 32)
        self.assertEqual(len(app.select_sites("manual")), 27)
        self.assertTrue(all(site.manual for site in app.select_sites("manual")))
        self.assertEqual({site.key for site in app.select_sites("gaming")},
                         {"roblox", "chesscom", "twitch", "steam", "xbox", "playstation", "epicgames", "minecraft"})

    def test_exact_key_lists_are_normalized_and_unknown_names_are_rejected(self):
        self.assertEqual([site.key for site in app.select_sites(" GITHUB, chesscom,github ")], ["github", "chesscom"])
        for selection in ("", ",", "madeup", "github,madeup"):
            with self.subTest(selection=selection), self.assertRaises(ValueError):
                app.select_sites(selection)

    def test_common_names_resolve_to_one_canonical_platform(self):
        self.assertEqual([site.key for site in app.select_sites("Twitter,x,PSN,playstation,Fortnite,epic,epicgames")],
                         ["x", "playstation", "epicgames"])
        for alias, canonical in (("minecraft-java", "minecraft"), ("xboxlive", "xbox"),
                                 ("paypal.me", "paypal"), ("cash-app", "cashapp")):
            self.assertEqual(app.select_sites(alias), [app.SITE_BY_KEY[canonical]])

    def test_removed_platforms_are_rejected_before_any_lookup(self):
        with patch.object(app, "request_api") as request:
            for key in ("codeberg", "dev", "lichess", "scratch", "huggingface", "mastodon"):
                with self.subTest(key=key), self.assertRaises(ValueError):
                    app.select_sites(key)
        request.assert_not_called()

    def test_catalog_names_keys_aliases_and_categories_are_consistent(self):
        self.assertEqual(len({site.name for site in app.SITES}), len(app.SITES))
        self.assertEqual(len(app.SITE_BY_KEY), len(app.SITES))
        self.assertFalse(set(app.SITE_ALIASES) & set(app.SITE_BY_KEY))
        self.assertEqual(len(app.SITE_ALIASES), sum(len(site.aliases) for site in app.SITES))
        categories = {site.category for site in app.SITES}
        self.assertEqual({site.key for category in categories for site in app.select_sites(category)}, set(app.SITE_BY_KEY))

    def test_new_candidate_pages_point_to_the_correct_namespace(self):
        expected = {
            "facebook": "https://www.facebook.com/example",
            "threads": "https://www.threads.com/@example",
            "linkedin": "https://www.linkedin.com/in/example/",
            "tumblr": "https://www.tumblr.com/example",
            "soundcloud": "https://soundcloud.com/example",
            "medium": "https://medium.com/@example",
            "substack": "https://substack.com/@example",
            "patreon": "https://www.patreon.com/example",
            "cashapp": "https://cash.app/$example",
            "venmo": "https://venmo.com/example",
            "paypal": "https://www.paypal.com/paypalme/example",
        }
        with patch.object(app, "request_api") as request:
            for key, url in expected.items():
                with self.subTest(key=key):
                    result = app.check_one(app.SITE_BY_KEY[key], "example")
                    self.assertEqual((result.profile_url, result.status), (url, "Manual check"))
        request.assert_not_called()

    def test_services_without_candidate_pages_open_official_verification(self):
        expected = {"xbox": "social.xbox.com", "playstation": "www.playstation.com", "epicgames": "www.epicgames.com",
                    "minecraft": "www.minecraft.net", "line": "help.line.me"}
        for key, host in expected.items():
            with self.subTest(key=key):
                site = app.SITE_BY_KEY[key]
                result = app.check_one(site, "example")
                self.assertEqual(urllib.parse.urlsplit(result.profile_url).netloc, host)
                self.assertEqual(result.status, "Manual check")
                self.assertNotEqual(result.detail, app.Site.manual_detail)

    def test_candidate_url_encoding_keeps_names_out_of_the_host(self):
        for site in app.SITES:
            with self.subTest(key=site.key):
                url = urllib.parse.urlsplit(site.url_for("someone/else?key=value#anchor"))
                base = urllib.parse.urlsplit(site.url_for("example"))
                self.assertEqual((url.scheme, url.netloc), ("https", base.netloc))
                self.assertEqual(url.fragment, "")


class LocalHandler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        if self.path == "/redirect":
            self.send_response(302)
            self.send_header("Location", "/profile")
            self.end_headers()
            return
        status, kind, raw = 200, "application/json", b'{"login":"example","id":42}'
        if self.path == "/missing":
            status, raw = 404, b'{"message":"Not Found"}'
        elif self.path == "/html":
            status, kind, raw = 404, "text/html", b"<html>Not Found</html>"
        elif self.path == "/broken":
            raw = b"{broken"
        elif self.path == "/large":
            raw = b" " * (app.MAX_RESPONSE_BYTES + 1)
        self.send_response(status)
        self.send_header("Content-Type", kind)
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        try:
            self.wfile.write(raw)
        except (BrokenPipeError, ConnectionResetError):
            pass


class TransportTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), LocalHandler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.server.server_port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)

    def get(self, path):
        return app.request_api(urllib.request.Request(self.base + path), 2)

    def test_real_transport_reads_success_and_http_error_bodies(self):
        self.assertEqual(self.get("/profile").data["id"], 42)
        missing = self.get("/missing")
        self.assertEqual(missing.status, 404)
        self.assertTrue(missing.valid_json)
        self.assertEqual(missing.data["message"], "Not Found")

    def test_html_and_malformed_json_are_flagged(self):
        self.assertFalse(self.get("/html").valid_json)
        self.assertFalse(self.get("/broken").valid_json)

    def test_redirects_are_not_followed(self):
        self.assertEqual(self.get("/redirect").status, 302)

    def test_large_response_is_bounded(self):
        with self.assertRaisesRegex(app.CheckError, "large"):
            self.get("/large")

    def test_timeout_tls_and_connection_errors_are_readable(self):
        for reason, expected in ((TimeoutError(), "timed out"),
                                 (ssl.SSLError(), "secure connection"),
                                 (ConnectionError(), "reach the site")):
            with patch.object(app.urllib.request, "build_opener") as opener:
                opener.return_value.open.side_effect = urllib.error.URLError(reason)
                with self.assertRaisesRegex(app.CheckError, expected):
                    self.get("/profile")

    def test_incomplete_http_response_is_reported_as_a_read_error(self):
        with patch.object(app.urllib.request, "build_opener") as opener:
            opener.return_value.open.side_effect = http.client.IncompleteRead(b"partial", 100)
            with self.assertRaisesRegex(app.CheckError, "read"):
                self.get("/profile")


class BatchTests(unittest.TestCase):
    def test_full_500_name_manual_batch_needs_no_network(self):
        names = [f"name{i}" for i in range(500)]
        with patch.object(app, "request_api") as request:
            results = app.run_checks(names, [app.SITE_BY_KEY["instagram"]])
        self.assertEqual([result.username for result in results], names)
        self.assertTrue(all(result.status == "Manual check" for result in results))
        request.assert_not_called()

    def test_full_500_name_automatic_batch_emits_every_result(self):
        names = [f"name{i}" for i in range(500)]
        def checked(site, name, timeout, **options):
            return sample_result(name, site.name)
        emitted = []
        with patch.object(app, "check_one", side_effect=checked) as check:
            results = app.run_checks(names, [app.SITES[0]], on_result=emitted.append)
        self.assertEqual(check.call_count, 500)
        self.assertEqual(results, emitted)
        self.assertEqual([result.username for result in results], names)

    def test_worker_start_failure_signals_cleanup(self):
        finished = threading.Event()
        with patch.object(app.threading.Thread, "start", side_effect=RuntimeError("no threads")):
            with self.assertRaises(RuntimeError):
                app.run_checks(["example"], [app.SITES[0]], workers_done=finished)
        self.assertTrue(finished.is_set())

    def test_retry_only_checks_requested_pairs(self):
        sites = [app.SITE_BY_KEY["github"], app.SITE_BY_KEY["gitlab"]]
        calls = []
        def check(site, name, timeout, **options):
            calls.append((name, site.key))
            return sample_result(name, site.name)
        with patch.object(app, "check_one", side_effect=check):
            results = app.run_checks(["first", "second"], sites, only={("first", "github"), ("second", "gitlab")})
        self.assertEqual(set(calls), {("first", "github"), ("second", "gitlab")})
        self.assertEqual(len(results), 2)

    def test_workers_done_waits_for_cancelled_inflight_work(self):
        cancel, started, release, finished = (threading.Event() for _ in range(4))
        def check(site, name, timeout, **options):
            started.set()
            release.wait(3)
            return sample_result(name, site.name)
        def cancel_after_start():
            started.wait(1)
            cancel.set()
        watcher = threading.Thread(target=cancel_after_start, daemon=True)
        watcher.start()
        try:
            with patch.object(app, "check_one", side_effect=check):
                results = app.run_checks(["first", "second"], [app.SITES[0]], cancel=cancel, workers_done=finished)
                self.assertEqual(results, [])
                self.assertFalse(finished.is_set())
                release.set()
                self.assertTrue(finished.wait(2))
        finally:
            release.set()
            watcher.join(timeout=2)

    def test_invalid_retry_targets_send_no_requests(self):
        for only in (set(), {("other", "github")}, {("example", "invalid-site")}):
            with self.subTest(only=only), patch.object(app, "check_one") as check:
                with self.assertRaises(ValueError):
                    app.run_checks(["example"], [app.SITES[0]], only=only)
                check.assert_not_called()

    def test_completed_batch_signals_workers_done(self):
        finished = threading.Event()
        with patch.object(app, "check_one", return_value=sample_result()):
            app.run_checks(["example"], [app.SITES[0]], workers_done=finished)
        self.assertTrue(finished.is_set())

    def test_concurrent_sites_emit_results_on_the_coordinating_thread(self):
        thread_ids = []
        names = ["example"]
        sites = [app.SITE_BY_KEY["github"], app.SITE_BY_KEY["gitlab"]]
        def check(site, name, timeout, **options):
            return sample_result(name, site.name)
        with patch.object(app, "check_one", side_effect=check):
            results = app.run_checks(names, sites, on_result=lambda result: thread_ids.append(threading.get_ident()))
        self.assertEqual({result.site for result in results}, {"GitHub", "GitLab"})
        self.assertEqual(thread_ids, [threading.get_ident()] * 2)

    def test_cancelled_batch_makes_no_requests(self):
        cancel = threading.Event()
        cancel.set()
        with patch.object(app, "check_one") as check:
            self.assertEqual(app.run_checks(["example"], app.SITES, cancel=cancel), [])
        check.assert_not_called()

    def test_cancel_returns_promptly_during_inflight_request(self):
        cancel, started, release = threading.Event(), threading.Event(), threading.Event()
        def slow_check(site, name, timeout, **options):
            started.set()
            release.wait(2)
            return sample_result()
        def cancel_when_started():
            started.wait(1)
            cancel.set()
        watcher = threading.Thread(target=cancel_when_started, daemon=True)
        watcher.start()
        start = time.monotonic()
        try:
            with patch.object(app, "check_one", side_effect=slow_check):
                results = app.run_checks(["example"], [app.SITES[0]], cancel=cancel)
            self.assertLess(time.monotonic() - start, 0.8)
            self.assertEqual(results, [])
        finally:
            release.set()
            watcher.join(timeout=2)

    def test_exhausted_rate_limit_retries_leave_remaining_names_unfinished(self):
        value = sample_result(status="Unknown", detail="Rate limited. Wait before checking this site again.")
        access = app.ApiAccess()
        with patch.object(app, "check_one", return_value=value) as check:
            results = app.run_checks(["example", "second", "third"], [app.SITES[0]], access=access)
        self.assertEqual(check.call_count, app.MAX_RATE_RETRIES + 1)
        self.assertEqual(results, [])
        self.assertEqual(access.exhausted_sites(), {app.SITES[0].key})

    def test_unexpected_adapter_error_does_not_drop_results(self):
        with patch.object(app, "check_one", side_effect=RuntimeError("failure")):
            results = app.run_checks(["example"], [app.SITES[0]])
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].status, "Unknown")

    def test_invalid_configuration_is_rejected(self):
        for timeout in (0, 61, float("nan"), float("inf")):
            with self.assertRaises(ValueError):
                app.run_checks(["example"], [app.SITES[0]], timeout=timeout)
        for names, sites in (([], app.SITES), (["name"], []),
                              (["a"], [app.SITES[0], app.SITES[0]])):
            with self.assertRaises(ValueError):
                app.run_checks(names, sites)
        with self.assertRaises(ValueError):
            app.run_checks(["first", "second"], [app.SITES[0]], batch_limit=1)


class CacheTests(unittest.TestCase):
    def test_reuse_preserves_check_time_and_handles_case_and_platforms(self):
        cache = app.ResultCache()
        site = app.SITE_BY_KEY["github"]
        original = sample_result("Example")
        cache.put(site, original)
        cached = cache.get(site, "example")
        self.assertEqual(cached.username, "example")
        self.assertEqual(cached.checked_at, original.checked_at)
        self.assertIn("Reused recent result", cached.detail)
        self.assertIsNone(cache.get(app.SITE_BY_KEY["gitlab"], "example"))
        self.assertNotIn("Reused", original.detail)

    def test_expiry_does_not_extend_when_a_result_is_read(self):
        clock = Mock(return_value=0)
        cache = app.ResultCache(ttl=10, clock=clock)
        site = app.SITES[0]
        cache.put(site, sample_result())
        clock.return_value = 9
        self.assertIsNotNone(cache.get(site, "example"))
        clock.return_value = 10
        self.assertIsNone(cache.get(site, "example"))
        self.assertEqual(len(cache.entries), 0)

    def test_capacity_evicts_least_recently_used_and_clear_works(self):
        cache, site = app.ResultCache(max_entries=2), app.SITES[0]
        for name in ("first", "second"):
            cache.put(site, sample_result(name))
        cache.get(site, "first")
        cache.put(site, sample_result("third"))
        self.assertIsNone(cache.get(site, "second"))
        self.assertIsNotNone(cache.get(site, "first"))
        cache.clear()
        self.assertEqual(len(cache.entries), 0)

    def test_only_confirmed_results_are_cached(self):
        cache = app.ResultCache()
        for status in ("Unknown", "Invalid", "Manual check"):
            cache.put(app.SITES[0], sample_result(status=status))
            self.assertIsNone(cache.get(app.SITES[0], "example"))
        cache.put(app.SITE_BY_KEY["instagram"], sample_result())
        self.assertIsNone(cache.get(app.SITE_BY_KEY["instagram"], "example"))
        cache.put(app.SITES[0], sample_result(status="Not found"))
        self.assertEqual(cache.get(app.SITES[0], "example").status, "Not found")

    def test_bluesky_short_and_full_handle_share_a_key(self):
        site, cache = app.SITE_BY_KEY["bluesky"], app.ResultCache()
        cache.put(site, sample_result("abc", site.name))
        self.assertEqual(cache.get(site, "ABC.bsky.social").username, "ABC.bsky.social")

    def test_invalid_cache_settings_are_rejected(self):
        for kwargs in ({"ttl": 0}, {"ttl": float("nan")}, {"max_entries": 0}):
            with self.assertRaises(ValueError):
                app.ResultCache(**kwargs)


class BulkTests(unittest.TestCase):
    def setUp(self):
        self.site = app.SITE_BY_KEY["roblox"]

    def test_250_names_need_three_requests_and_reuse_needs_none(self):
        names = [f"user{i:03}" for i in range(250)]
        payloads = []
        def request(req, timeout):
            payload = json.loads(req.data)
            payloads.append(payload)
            return response(200, {"data": [
                {"requestedUsername": name.upper(), "id": i + 1}
                for i, name in enumerate(payload["usernames"]) if int(name[4:]) % 2 == 0
            ]})
        cache, first, second = app.ResultCache(), app.CheckStats(), app.CheckStats()
        with patch.object(app, "request_api", side_effect=request) as lookup:
            results = app.run_checks(names, [self.site], cache=cache, stats=first)
            reused = app.run_checks(names, [self.site], cache=cache, stats=second)
        self.assertEqual(lookup.call_count, 3)
        self.assertEqual([len(payload["usernames"]) for payload in payloads], [100, 100, 50])
        self.assertTrue(all(payload["excludeBannedUsers"] is False for payload in payloads))
        self.assertEqual([result.username for result in results], names)
        self.assertEqual([result.status for result in results], ["Taken" if i % 2 == 0 else "Not found" for i in range(250)])
        self.assertEqual([result.status for result in reused], [result.status for result in results])
        self.assertEqual(first.snapshot()["requests"], 3)
        self.assertEqual(second.snapshot(), {"requests": 0, "cache_hits": 250, "local_results": 0})

    def test_bulk_matching_uses_requested_name_not_current_name_or_order(self):
        data = {"data": [{"requestedUsername": "OLD", "name": "new", "id": 42},
                         {"requestedUsername": "abc", "id": 7}]}
        with patch.object(app, "request_api", return_value=response(200, data)):
            results = app.check_bulk(self.site, ["abc", "old", "missing"])
        self.assertEqual([r.status for r in results], ["Taken", "Taken", "Not found"])
        self.assertEqual(results[1].profile_url, "https://www.roblox.com/users/42/profile")

    def test_malformed_or_unrelated_entries_never_imply_missing_names(self):
        cases = [None, {}, {"data": None}, {"data": [None]}, {"data": [{"id": 42}]},
                 {"data": [{"requestedUsername": "other", "id": 42}]},
                 {"data": [{"requestedUsername": "abc", "id": True}]},
                 {"data": [{"requestedUsername": "abc", "id": 42}] * 2},
                 {"data": [], "errors": [{"message": "failed"}]}]
        for data in cases:
            with self.subTest(data=data), patch.object(app, "request_api", return_value=response(200, data)):
                self.assertTrue(all(r.status == "Unknown" for r in app.check_bulk(self.site, ["abc", "def"])))

    def test_html_blocks_network_failures_and_server_errors_are_unknown(self):
        for reply in (response(200, {"data": []}, valid_json=False), response(403, {}), response(500, {})):
            with patch.object(app, "request_api", return_value=reply):
                self.assertTrue(all(r.status == "Unknown" for r in app.check_bulk(self.site, ["abc", "def"])))
        with patch.object(app, "request_api", side_effect=app.CheckError("Request timed out.")):
            self.assertTrue(all(r.status == "Unknown" for r in app.check_bulk(self.site, ["abc", "def"])))

    def test_exhausted_bulk_retries_leave_names_unfinished_without_caching_them(self):
        cache, stats, access = app.ResultCache(), app.CheckStats(), app.ApiAccess()
        with patch.object(app, "request_api", return_value=response(429, {}, headers={"retry-after": "0"})) as lookup:
            results = app.run_checks([f"name{i}" for i in range(201)], [self.site], cache=cache, stats=stats, access=access)
        self.assertEqual(lookup.call_count, app.MAX_RATE_RETRIES + 1)
        self.assertEqual(results, [])
        self.assertEqual(access.exhausted_sites(), {"roblox"})
        self.assertEqual(len(cache.entries), 0)

    def test_invalid_bulk_requests_are_rejected_before_network(self):
        with patch.object(app, "request_api") as lookup:
            for site, names in ((self.site, []), (self.site, ["valid"] * 101),
                                (self.site, ["a", "valid"]), (app.SITES[0], ["abc", "def"])):
                with self.assertRaises(ValueError):
                    app.check_bulk(site, names)
        lookup.assert_not_called()

    def test_retry_pairs_are_grouped_without_rechecking_other_names(self):
        with patch.object(app, "request_api", return_value=response(200, {"data": []})) as lookup:
            results = app.run_checks(["abc", "def", "ghi"], [self.site],
                                     only={("abc", "roblox"), ("ghi", "roblox")})
        self.assertEqual(json.loads(lookup.call_args.args[0].data)["usernames"], ["abc", "ghi"])
        self.assertEqual([r.username for r in results], ["abc", "ghi"])

    def test_real_http_transport_posts_bounded_batches(self):
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_POST(self):
                payload = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                self.server.payloads.append(payload)
                raw = json.dumps({"data": [{"requestedUsername": payload["usernames"][0], "id": 42}]}).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        server.payloads = []
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        original = app.build_bulk_request
        def local_request(site, names):
            request = original(site, names)
            request.full_url = f"http://127.0.0.1:{server.server_port}/bulk"
            return request
        try:
            with patch.object(app, "build_bulk_request", side_effect=local_request):
                results = app.run_checks([f"name{i}" for i in range(250)], [self.site])
            self.assertEqual([len(p["usernames"]) for p in server.payloads], [100, 100, 50])
            self.assertEqual(sum(r.status == "Taken" for r in results), 3)
            self.assertEqual(sum(r.status == "Not found" for r in results), 247)
        finally:
            server.shutdown()
            server.server_close()
            thread.join(2)


class EfficientBatchTests(unittest.TestCase):
    def test_network_checks_have_no_artificial_delay_for_single_or_bulk_requests(self):
        for key, count in (("github", 3), ("roblox", 250)):
            with self.subTest(site=key):
                names = [f"name{i}" for i in range(count)]
                cancel, stats = threading.Event(), app.CheckStats()
                reply = response(200, {"data": []}) if key == "roblox" else response(404, {"message": "Not Found"})
                with patch.object(cancel, "wait", return_value=False) as wait, patch.object(app, "request_api", return_value=reply) as request:
                    results = app.run_checks(names, [app.SITE_BY_KEY[key]], cancel=cancel, stats=stats)
                self.assertEqual([r.username for r in results], names)
                self.assertTrue(all(r.status == "Not found" for r in results))
                self.assertEqual(request.call_count, 3)
                self.assertEqual(stats.snapshot()["requests"], 3)
                wait.assert_not_called()

    def test_cached_and_local_results_do_not_wait_or_send_requests(self):
        cache, stats, cancel = app.ResultCache(), app.CheckStats(), threading.Event()
        for name in ("first", "second"):
            cache.put(app.SITES[0], sample_result(name))
        with patch.object(cancel, "wait", side_effect=AssertionError("Unneeded wait")), patch.object(app, "request_api") as request:
            results = app.run_checks(["first", "_invalid", "second", "bad.name"], [app.SITES[0]],
                                     cache=cache, stats=stats, cancel=cancel)
        self.assertEqual([r.status for r in results], ["Taken", "Invalid", "Taken", "Invalid"])
        self.assertEqual(stats.snapshot(), {"requests": 0, "cache_hits": 2, "local_results": 2})
        request.assert_not_called()

    def test_fresh_lookup_bypasses_and_updates_a_confirmed_cached_result(self):
        cache, stats = app.ResultCache(), app.CheckStats()
        cache.put(app.SITES[0], sample_result())
        with patch.object(app, "check_one", return_value=sample_result(status="Not found")) as lookup:
            results = app.run_checks(["example"], [app.SITES[0]], cache=cache, refresh=True, stats=stats)
        lookup.assert_called_once()
        self.assertEqual(results[0].status, "Not found")
        self.assertEqual(cache.get(app.SITES[0], "example").status, "Not found")
        self.assertEqual(stats.snapshot()["requests"], 1)

    def test_unknown_results_are_rechecked_on_the_next_run(self):
        cache = app.ResultCache()
        with patch.object(app, "check_one", return_value=sample_result(status="Unknown")) as lookup:
            for _ in range(2):
                app.run_checks(["example"], [app.SITES[0]], cache=cache)
        self.assertEqual(lookup.call_count, 2)

    def test_initially_paused_batch_resumes_without_losing_work(self):
        pause, cancel, finished = threading.Event(), threading.Event(), threading.Event()
        pause.set()
        results = []
        with patch.object(app, "check_one", return_value=sample_result()) as lookup:
            worker = threading.Thread(target=lambda: results.extend(app.run_checks(
                ["example"], [app.SITES[0]], pause=pause, cancel=cancel, workers_done=finished)))
            worker.start()
            try:
                time.sleep(0.08)
                lookup.assert_not_called()
                pause.clear()
                worker.join(2)
                self.assertFalse(worker.is_alive())
                self.assertTrue(finished.is_set())
                self.assertEqual(len(results), 1)
            finally:
                cancel.set()
                pause.clear()
                worker.join(2)

    def test_cancel_while_paused_returns_promptly(self):
        pause, cancel, finished = threading.Event(), threading.Event(), threading.Event()
        pause.set()
        with patch.object(app, "check_one") as lookup:
            worker = threading.Thread(target=app.run_checks, args=(["example"], [app.SITES[0]]),
                                      kwargs={"pause": pause, "cancel": cancel, "workers_done": finished})
            worker.start()
            time.sleep(0.05)
            cancel.set()
            worker.join(1)
            self.assertFalse(worker.is_alive())
            self.assertTrue(finished.wait(1))
        lookup.assert_not_called()

    def test_bulk_adapter_exception_still_emits_every_target(self):
        with patch.object(app, "check_bulk", side_effect=RuntimeError("adapter failed")):
            results = app.run_checks(["abc", "def"], [app.SITE_BY_KEY["roblox"]])
        self.assertEqual([r.username for r in results], ["abc", "def"])
        self.assertTrue(all(r.status == "Unknown" for r in results))

    def test_local_adapter_exception_still_emits_every_target(self):
        with patch.object(app, "check_one", side_effect=RuntimeError("adapter failed")):
            results = app.run_checks(["abc", "def"], [app.SITE_BY_KEY["instagram"]])
        self.assertEqual([r.username for r in results], ["abc", "def"])
        self.assertTrue(all(r.status == "Unknown" for r in results))


class UnlimitedBatchTests(unittest.TestCase):
    def test_default_is_unlimited_and_positive_limits_have_no_fixed_ceiling(self):
        self.assertEqual(app.DEFAULT_BATCH_LIMIT, 0)
        for value in (0, 10001, 1000000, 10 ** 100):
            self.assertEqual(app.validate_batch_limit(value), value)
            self.assertEqual(app.parse_usernames("example", value), ["example"])
        names = " ".join(f"name{i}" for i in range(20001))
        self.assertEqual(len(app.parse_usernames(names)), 20001)

    def test_zero_count_streams_all_remaining_and_honors_a_positive_limit(self):
        search = app.CharacterSearch("custom", characters="ab", length=4)
        self.assertEqual(search.take(2), ["aaaa", "aaab"])
        self.assertEqual(search.batch_count(0), 14)
        with self.assertRaises(ValueError):
            search.iter_take(0, batch_limit=10)
        remaining = list(search.iter_take(0))
        self.assertEqual(len(remaining), 14)
        self.assertEqual(search.position, 16)
        self.assertEqual(list(search.iter_take(0)), [])

    def test_enormous_search_can_stop_after_a_small_prefix_with_bounded_memory(self):
        search = app.CharacterSearch(length=253, seed=42)
        job = app.LargeBatchJob(search.iter_take(0), search.total, [], generate_only=True)
        self.addCleanup(job.close)
        original = job._record
        def record(result):
            original(result)
            if job.completed == 37:
                job.stop()
        tracemalloc.start()
        try:
            with patch.object(job, "_record", side_effect=record):
                job.start()
                self.assertTrue(job.done.wait(5))
            _, peak = tracemalloc.get_traced_memory()
        finally:
            tracemalloc.stop()
        self.assertEqual(job.completed, 37)
        self.assertLessEqual(search.position, app.CHECK_CHUNK_SIZE)
        self.assertEqual(len(list(job.journal.read())), 37)
        self.assertLess(peak, 12 * 1024 * 1024)

    def test_large_job_preview_is_bounded_and_full_results_keep_input_order(self):
        names = [f"name{i:05}" for i in range(12001)]
        sites = [app.SITE_BY_KEY["instagram"], app.SITE_BY_KEY["tiktok"]]
        job = app.LargeBatchJob(iter(names), len(names), sites)
        self.addCleanup(job.close)
        with patch.object(app, "request_api") as request:
            job.start()
            self.assertTrue(job.done.wait(10))
        self.assertFalse(job.error)
        self.assertEqual(job.completed, 24002)
        self.assertEqual(len(job.preview), app.RESULT_PREVIEW_SIZE)
        records = list(job.journal.read())
        self.assertEqual([(r.username, r.site) for r in records], [(n, s.name) for n in names for s in sites])
        request.assert_not_called()

    def test_stop_at_a_chunk_boundary_does_not_automatically_start_the_next_chunk(self):
        names = [f"name{i}" for i in range(25)]
        job = app.LargeBatchJob(iter(names), 25, [app.SITE_BY_KEY["instagram"]])
        self.addCleanup(job.close)
        original = job._record
        def record(result):
            original(result)
            if job.completed == 5:
                job.stop()
        with patch.object(app, "CHECK_CHUNK_SIZE", 5), patch.object(job, "_record", side_effect=record):
            job.start()
            self.assertTrue(job.done.wait(3))
            self.assertEqual(job.completed, 5)
            self.assertEqual(job.pulled, 5)
            self.assertTrue(job.start())
            self.assertTrue(job.done.wait(3))
        self.assertEqual(job.completed, 25)
        self.assertEqual([r.username for r in job.journal.read()], names)

    def test_stop_mid_chunk_then_continue_never_duplicates_saved_pairs(self):
        names = [f"name{i}" for i in range(25)]
        job = app.LargeBatchJob(iter(names), 25, [], generate_only=True)
        self.addCleanup(job.close)
        original = job._record
        def record(result):
            original(result)
            if job.completed == 7:
                job.stop()
        with patch.object(app, "CHECK_CHUNK_SIZE", 5), patch.object(job, "_record", side_effect=record):
            job.start()
            self.assertTrue(job.done.wait(3))
            self.assertEqual(job.completed, 7)
            self.assertTrue(job.start())
            self.assertTrue(job.done.wait(3))
        self.assertEqual(job.completed, 25)
        self.assertEqual([r.username for r in job.journal.read()], names)

    def test_cancelled_inflight_work_must_finish_before_continue(self):
        started, release = threading.Event(), threading.Event()
        names = ["first", "second", "third"]
        job = app.LargeBatchJob(iter(names), 3, [app.SITES[0]], cache=app.ResultCache())
        self.addCleanup(job.close)
        def check(site, name, timeout, **options):
            if name == "first":
                started.set()
                release.wait(3)
            return sample_result(name, site.name)
        try:
            with patch.object(app, "check_one", side_effect=check) as lookup:
                job.start()
                self.assertTrue(started.wait(2))
                job.stop()
                self.assertTrue(job.done.wait(2))
                self.assertFalse(job.workers_done.is_set())
                self.assertFalse(job.start())
                release.set()
                self.assertTrue(job.workers_done.wait(2))
                self.assertTrue(job.start())
                self.assertTrue(job.done.wait(3))
            self.assertEqual(lookup.call_count, 3)
            self.assertEqual([r.username for r in job.journal.read()], names)
        finally:
            release.set()
            job.stop()
            job.done.wait(2)

    def test_exhausted_rate_limit_retries_keep_large_job_progress_before_later_chunks(self):
        job = app.LargeBatchJob((f"name{i}" for i in range(1000)), 1000, [app.SITE_BY_KEY["roblox"]])
        self.addCleanup(job.close)
        with patch.object(app, "CHECK_CHUNK_SIZE", 3), patch.object(app, "request_api", return_value=response(429, {}, headers={"retry-after": "0"})) as lookup:
            job.start()
            self.assertTrue(job.done.wait(3))
        self.assertEqual(lookup.call_count, app.MAX_RATE_RETRIES + 1)
        self.assertEqual(job.completed, 0)
        self.assertLessEqual(job.pulled, 3)
        self.assertEqual(len(job.pending_pairs), 3)
        self.assertIn("retries exhausted", job.reason)

    def test_large_job_adds_no_request_delay_within_or_between_chunks(self):
        waits, requests = [], []
        def request(req, timeout):
            requests.append(req.full_url)
            return response(404, {"message": "Not Found"})
        job = app.LargeBatchJob((f"name{i}" for i in range(6)), 6, [app.SITES[0]])
        self.addCleanup(job.close)
        original_run = job._run
        def run():
            with patch.object(job.cancel, "wait", side_effect=lambda seconds: waits.append(seconds) or False):
                original_run()
        with patch.object(app, "CHECK_CHUNK_SIZE", 2), patch.object(job, "_run", side_effect=run), patch.object(app, "request_api", side_effect=request):
            job.start()
            self.assertTrue(job.done.wait(3))
        self.assertEqual(len(requests), 6)
        self.assertEqual(job.completed, 6)
        self.assertEqual([r.username for r in job.journal.read()], [f"name{i}" for i in range(6)])
        self.assertEqual(waits, [])

    def test_journal_snapshot_is_consistent_with_later_appends_and_unicode(self):
        journal = app.ResultJournal()
        self.addCleanup(journal.close)
        journal.begin_chunk(["first", "second", "third"], ["GitHub"])
        journal.append(sample_result("second", detail="Résumé 日本語"))
        journal.append(sample_result("first"))
        snapshot = journal.read()
        journal.append(sample_result("third"))
        self.assertEqual([r.username for r in snapshot], ["first", "second"])
        self.assertEqual([r.username for r in journal.read()], ["first", "second", "third"])

    def test_job_errors_are_reported_and_temporary_results_are_cleaned(self):
        job = app.LargeBatchJob(iter(["name"]), 1, [], generate_only=True)
        folder = job.journal.path.parent
        with patch.object(job.journal, "append", side_effect=OSError("Disk full")):
            job.start()
            self.assertTrue(job.done.wait(3))
        self.assertIn("Disk full", job.error)
        self.assertEqual(job.completed, 0)
        job.close()
        self.assertFalse(folder.exists())

    def test_delayed_disk_write_failures_are_reported_before_a_job_is_marked_done(self):
        job = app.LargeBatchJob(iter(["name"]), 1, [], generate_only=True)
        self.addCleanup(job.close)
        with patch.object(job.journal, "flush", side_effect=OSError("Disk full")):
            job.start()
            self.assertTrue(job.done.wait(3))
        self.assertIn("Disk full", job.error)

    def test_streaming_export_failure_preserves_the_existing_file(self):
        def records():
            yield sample_result()
            raise ValueError("Broken source")
        with tempfile.TemporaryDirectory() as folder:
            for extension in (".csv", ".json"):
                path = Path(folder) / ("results" + extension)
                path.write_text("original")
                with self.assertRaisesRegex(ValueError, "Broken source"):
                    app.export_results(path, records())
                self.assertEqual(path.read_text(), "original")
            self.assertFalse(list(Path(folder).glob("*.tmp")))


class ExportTests(unittest.TestCase):
    def test_csv_and_json_round_trip(self):
        result = sample_result(detail='Name found, with "quotes" and ünicode.')
        with tempfile.TemporaryDirectory() as folder:
            csv_path, json_path = Path(folder) / "results.csv", Path(folder) / "results.json"
            app.export_results(csv_path, [result])
            app.export_results(json_path, [result])
            with csv_path.open(encoding="utf-8-sig", newline="") as stream:
                self.assertEqual(list(csv.DictReader(stream))[0]["detail"], result.detail)
            records = json.loads(json_path.read_text(encoding="utf-8"))
            self.assertEqual(records[0]["detail"], result.detail)
            self.assertEqual(records[0]["checked_at"], result.checked_at)

    def test_csv_formula_protection(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "results.csv"
            app.export_results(path, [sample_result(name="-danger", detail="=1+1")])
            with path.open(encoding="utf-8-sig", newline="") as stream:
                record = list(csv.DictReader(stream))[0]
            self.assertEqual(record["username"], "'-danger")
            self.assertEqual(record["detail"], "'=1+1")

    def test_failed_write_preserves_existing_file_and_cleans_temporary(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "results.csv"
            path.write_text("original", encoding="utf-8")
            with patch.object(app.os, "replace", side_effect=OSError("read-only")):
                with self.assertRaises(OSError):
                    app.export_results(path, [sample_result()])
            self.assertEqual(path.read_text(encoding="utf-8"), "original")
            self.assertEqual(list(Path(folder).iterdir()), [path])

    def test_unsupported_extension_leaves_no_file(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "results.txt"
            with self.assertRaises(ValueError):
                app.export_results(path, [])
            self.assertFalse(path.exists())


class CommandLineTests(unittest.TestCase):
    def test_cli_accepts_counts_beyond_the_old_ten_thousand_limit(self):
        stdout = io.StringIO()
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(io.StringIO()), patch.object(app, "request_api") as lookup:
            code = app.main(["--generate", "--length", "5", "--count", "20001", "--generate-only", "--json"])
        names = json.loads(stdout.getvalue())
        self.assertEqual(code, 0)
        self.assertEqual(len(names), 20001)
        self.assertEqual(len(set(names)), 20001)
        lookup.assert_not_called()

    def test_cli_zero_count_generates_the_complete_remaining_space(self):
        stdout = io.StringIO()
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(io.StringIO()):
            code = app.main(["--generate", "--length", "2", "--charset", "custom", "--characters", "ab",
                             "--count", "0", "--offset", "1", "--generate-only", "--json"])
        self.assertEqual(code, 0)
        self.assertEqual(json.loads(stdout.getvalue()), ["ab", "ba", "bb"])

    def test_large_cli_names_only_deduplicates_sites_and_exports_complete_ordered_records(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "all.json"
            stdout, stderr = io.StringIO(), io.StringIO()
            with patch.object(app, "LARGE_BATCH_THRESHOLD", 5), contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                code = app.main(["--generate", "--length", "4", "--count", "20", "--sites", "instagram,tiktok",
                                 "--status", "manual", "--names-only", "--json", "--stats", "--output", str(path)])
            records = json.loads(path.read_text())
        names = json.loads(stdout.getvalue())
        self.assertEqual(code, 1)
        self.assertEqual(len(names), 20)
        self.assertEqual(len(set(names)), 20)
        self.assertEqual([(r["username"], r["site"]) for r in records], [(n, s) for n in names for s in ("Instagram", "TikTok")])
        self.assertIn("0 requests", stderr.getvalue())
        self.assertIn("40 local results", stderr.getvalue())

    def test_large_cli_rate_limit_keeps_valid_partial_json_and_reports_a_repeatable_offset(self):
        stdout, stderr = io.StringIO(), io.StringIO()
        with patch.object(app, "LARGE_BATCH_THRESHOLD", 5), patch.object(app, "request_api", return_value=response(429, {}, headers={"retry-after": "0"})) as lookup:
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                code = app.main(["--generate", "--count", "20", "--sites", "roblox", "--json"])
        self.assertEqual(code, 1)
        self.assertEqual(lookup.call_count, app.MAX_RATE_RETRIES + 1)
        self.assertEqual(json.loads(stdout.getvalue()), [])
        self.assertIn("Next offset: 0", stderr.getvalue())

    def test_gui_cli_accepts_unlimited_and_arbitrarily_large_positive_caps(self):
        for limit in (0, 10 ** 100):
            with patch.object(app, "launch_gui", return_value=0) as launch:
                self.assertEqual(app.main(["--gui", "--batch-limit", str(limit)]), 0)
            launch.assert_called_once_with(batch_limit=limit)

    def test_all_remaining_still_respects_an_explicit_smaller_limit(self):
        with contextlib.redirect_stderr(io.StringIO()), patch.object(app, "run_checks") as lookup:
            with self.assertRaises(SystemExit) as error:
                app.main(["--generate", "--length", "5", "--count", "0", "--batch-limit", "100"])
        self.assertEqual(error.exception.code, 2)
        lookup.assert_not_called()

    def test_adjustable_length_generation_and_default_wildcard_pattern(self):
        stdout = io.StringIO()
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(io.StringIO()), patch.object(app, "request_api") as lookup:
            self.assertEqual(app.main(["--generate", "--length", "5", "--charset", "letters", "--count", "3",
                                       "--generate-only", "--json"]), 0)
        self.assertEqual(json.loads(stdout.getvalue()), ["aaaaa", "aaaab", "aaaac"])
        lookup.assert_not_called()

    def test_adjustable_length_checking_uses_selected_sites_and_preserves_exit_codes(self):
        stdout = io.StringIO()
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(io.StringIO()), patch.object(app, "request_api") as lookup:
            code = app.main(["--generate", "--length", "7", "--charset", "digits", "--count", "5",
                             "--sites", "instagram", "--json"])
        results = json.loads(stdout.getvalue())
        self.assertEqual(code, 1)
        self.assertEqual(len(results), 5)
        self.assertTrue(all(len(r["username"]) == 7 and r["status"] == "Manual check" for r in results))
        lookup.assert_not_called()

    def test_custom_length_patterns_and_small_space_exhaustion(self):
        for options, expected in ((["--length", "5", "--pattern", "a????", "--count", "2"], ["aaaaa", "aaaab"]),
                                  (["--length", "1", "--charset", "custom", "--characters", "a1_", "--count", "20"], ["a", "1", "_"])):
            stdout = io.StringIO()
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(io.StringIO()):
                self.assertEqual(app.main(["--generate", "--generate-only", "--json", *options]), 0)
            self.assertEqual(json.loads(stdout.getvalue()), expected)

    def test_large_seeded_generator_cli_pages_continue_without_overlap(self):
        batches = []
        for offset in (0, 20, 0):
            stdout = io.StringIO()
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(io.StringIO()):
                self.assertEqual(app.main(["--generate", "--length", "64", "--seed", "123", "--offset", str(offset),
                                           "--generate-only", "--json"]), 0)
            batches.append(json.loads(stdout.getvalue()))
        self.assertEqual(batches[0], batches[2])
        self.assertTrue(set(batches[0]).isdisjoint(batches[1]))
        self.assertTrue(all(len(name) == 64 for batch in batches for name in batch))

    def test_invalid_length_options_fail_before_network_or_gui_start(self):
        cases = (["--generate", "--length", "0"], ["--generate", "--length", "254"],
                 ["--generate", "--length", "1.5"], ["--generate", "--length", "5", "--pattern", "???"],
                 ["--length", "5"], ["example", "--length", "5"], ["--gui", "--generate"],
                 ["--generate", "--three-char"], ["--three-char", "--length", "5"],
                 ["--generate", "--input", "names.txt"])
        for args in cases:
            with self.subTest(args=args), contextlib.redirect_stderr(io.StringIO()), patch.object(app, "run_checks") as run:
                with self.assertRaises(SystemExit) as error:
                    app.main(args)
                self.assertEqual(error.exception.code, 2)
                run.assert_not_called()

    def test_three_character_alias_and_generate_default_keep_existing_behavior(self):
        batches = []
        for mode in ("--generate", "--three-char"):
            stdout = io.StringIO()
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(io.StringIO()):
                self.assertEqual(app.main([mode, "--seed", "42", "--generate-only", "--json"]), 0)
            batches.append(json.loads(stdout.getvalue()))
        self.assertEqual(batches[0], batches[1])
        self.assertTrue(all(len(name) == 3 for name in batches[0]))

    def test_status_filter_names_only_and_export_use_the_shown_rows(self):
        results = [sample_result("example"), sample_result("missing", status="Not found"),
                   sample_result("missing", "GitLab", "Not found"), sample_result("failed", status="Unknown")]
        stdout = io.StringIO()
        with tempfile.TemporaryDirectory() as folder:
            output = Path(folder) / "missing.json"
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(io.StringIO()), patch.object(app, "run_checks", return_value=results):
                code = app.main(["example", "missing", "failed", "--sites", "github,gitlab",
                                 "--status", "not-found", "--names-only", "--json", "--output", str(output)])
            records = json.loads(output.read_text())
        self.assertEqual(json.loads(stdout.getvalue()), ["missing"])
        self.assertEqual(len(records), 2)
        self.assertTrue(all(record["status"] == "Not found" for record in records))
        self.assertEqual(code, 1)  # Hidden unknowns still make a check incomplete.

    def test_names_only_no_matches_produces_empty_stdout(self):
        stdout = io.StringIO()
        with contextlib.redirect_stdout(stdout), patch.object(app, "run_checks", return_value=[sample_result()]):
            self.assertEqual(app.main(["example", "--sites", "github", "--status", "not-found", "--names-only"]), 0)
        self.assertEqual(stdout.getvalue(), "")

    def test_stats_stay_on_stderr_and_count_manual_results_without_requests(self):
        stdout, stderr = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr), patch.object(app, "request_api") as lookup:
            code = app.main(["first", "second", "--sites", "instagram", "--json", "--stats"])
        self.assertEqual(len(json.loads(stdout.getvalue())), 2)
        self.assertIn("0 requests", stderr.getvalue())
        self.assertIn("2 local results", stderr.getvalue())
        self.assertEqual(code, 1)
        lookup.assert_not_called()

    def test_result_flags_require_a_check_and_cannot_silently_open_gui(self):
        options = [["--status", "taken"], ["--names-only"], ["--stats"],
                   ["--gui", "--stats"], ["--three-char", "--generate-only", "--status", "taken"]]
        for args in options:
            with self.subTest(args=args), contextlib.redirect_stderr(io.StringIO()), patch.object(app, "run_checks") as check:
                with self.assertRaises(SystemExit) as error:
                    app.main(args)
                self.assertEqual(error.exception.code, 2)
                check.assert_not_called()

    def test_cli_custom_limit_allows_one_thousand_generated_names(self):
        stdout = io.StringIO()
        with patch.object(app, "run_checks") as run, contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(io.StringIO()):
            code = app.main(["--three-char", "--batch-limit", "1000", "--count", "1000", "--generate-only", "--json"])
        self.assertEqual(code, 0)
        names = json.loads(stdout.getvalue())
        self.assertEqual(len(names), 1000)
        self.assertEqual(len(set(names)), 1000)
        run.assert_not_called()

    def test_cli_lower_limit_adjusts_only_the_implicit_generation_count(self):
        stdout = io.StringIO()
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(app.main(["--three-char", "--batch-limit", "5", "--generate-only", "--json"]), 0)
        self.assertEqual(len(json.loads(stdout.getvalue())), 5)
        with patch.object(app, "run_checks") as run, contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit) as error:
                app.main(["--three-char", "--batch-limit", "5", "--count", "6"])
        self.assertEqual(error.exception.code, 2)
        run.assert_not_called()

    def test_cli_invalid_batch_limits_never_send_requests(self):
        cases = (["example", "--batch-limit", "-1"], ["example", "--batch-limit", "1.5"],
                 ["--gui", "--batch-limit", "-1"])
        for args in cases:
            with self.subTest(args=args), patch.object(app, "run_checks") as run, contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit) as error:
                    app.main(args)
                self.assertEqual(error.exception.code, 2)
                run.assert_not_called()

    def test_gui_can_start_with_a_custom_initial_limit(self):
        with patch.object(app, "launch_gui", return_value=0) as launch:
            self.assertEqual(app.main(["--gui", "--batch-limit", "1000"]), 0)
        launch.assert_called_once_with(batch_limit=1000)

    def test_default_selection_uses_only_automatic_platforms(self):
        results = [sample_result("example", site.name) for site in app.AUTOMATIC_SITES]
        with patch.object(app, "run_checks", return_value=results) as run, contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(app.main(["example"]), 0)
        self.assertEqual(run.call_args.args[1], list(app.AUTOMATIC_SITES))

    def test_manual_cli_output_is_explicit_and_sets_incomplete_exit_code(self):
        stdout = io.StringIO()
        with patch.object(app, "request_api") as request, contextlib.redirect_stdout(stdout):
            code = app.main(["example", "--sites", "discord", "--json"])
        self.assertEqual(code, 1)
        records = json.loads(stdout.getvalue())
        self.assertEqual(records[0]["status"], "Manual check")
        self.assertEqual(records[0]["profile_url"], "https://discord.com/register")
        request.assert_not_called()

    def test_cli_common_platform_names_do_not_duplicate_results(self):
        stdout = io.StringIO()
        with patch.object(app, "request_api") as request, contextlib.redirect_stdout(stdout):
            code = app.main(["example", "--sites", "twitter,x,psn,fortnite,paypal.me", "--json"])
        self.assertEqual(code, 1)
        records = json.loads(stdout.getvalue())
        self.assertEqual([record["site"] for record in records], ["X", "PlayStation", "Epic Games", "PayPal.Me"])
        self.assertTrue(all(record["status"] == "Manual check" for record in records))
        request.assert_not_called()

    def test_large_generator_cli_count_is_accepted_without_network(self):
        stdout = io.StringIO()
        with patch.object(app, "run_checks") as run, contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(app.main(["--three-char", "--count", "500", "--generate-only", "--json"]), 0)
        self.assertEqual(len(json.loads(stdout.getvalue())), 500)
        run.assert_not_called()
    def test_three_character_generate_only_never_uses_the_network(self):
        stdout, stderr = io.StringIO(), io.StringIO()
        with patch.object(app, "run_checks") as run, contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            code = app.main(["--three-char", "--charset", "letters", "--pattern", "a??",
                             "--count", "3", "--generate-only", "--json"])
        self.assertEqual(code, 0)
        self.assertEqual(json.loads(stdout.getvalue()), ["aaa", "aab", "aac"])
        self.assertIn("next offset 3", stderr.getvalue())
        run.assert_not_called()

    def test_generated_batch_uses_selected_sites_and_can_export_results(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "results.json"
            def checked(names, sites, timeout, cancel, *, batch_limit=app.DEFAULT_BATCH_LIMIT, **options):
                return [sample_result(name, site.name) for name in names for site in sites]
            with patch.object(app, "run_checks", side_effect=checked) as run, contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                code = app.main(["--three-char", "--charset", "digits", "--count", "2", "--offset", "998",
                                 "--sites", "github", "--output", str(path)])
            self.assertEqual(code, 0)
            self.assertEqual(run.call_args.args[0], ["998", "999"])
            self.assertEqual(run.call_args.args[1], [app.SITE_BY_KEY["github"]])
            self.assertEqual([r["username"] for r in json.loads(path.read_text())], ["998", "999"])

    def test_seeded_cli_batches_continue_without_overlap(self):
        batches = []
        for offset in (0, 20):
            stdout = io.StringIO()
            with patch.object(app, "run_checks") as run, contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(io.StringIO()):
                code = app.main(["--three-char", "--seed", "123", "--offset", str(offset), "--generate-only", "--json"])
            self.assertEqual(code, 0)
            batches.append(json.loads(stdout.getvalue()))
            run.assert_not_called()
        self.assertEqual(len(set(batches[0] + batches[1])), 40)

    def test_invalid_generator_options_send_no_requests(self):
        cases = (["--three-char", "--batch-limit", "500", "--count", "501"], ["--three-char", "--count", "-1"],
                 ["--three-char", "--pattern", "??"], ["--three-char", "--charset", "custom"],
                 ["--three-char", "--offset", "-1"], ["--three-char", "example"],
                 ["--gui", "--three-char"], ["example", "--generate-only"], ["--seed", "42"],
                 ["--three-char", "--generate-only", "--output", "names.json"],
                 ["--three-char", "--input", "names.txt"])
        for args in cases:
            with self.subTest(args=args), patch.object(app, "run_checks") as run, contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit) as error:
                    app.main(args)
                self.assertEqual(error.exception.code, 2)
                run.assert_not_called()

    def test_input_file_and_positional_names_are_merged_and_deduplicated(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "names.txt"
            path.write_text("example\nsecond", encoding="utf-8")
            results = [sample_result("EXAMPLE"), sample_result("second")]
            with patch.object(app, "run_checks", return_value=results) as run, contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(app.main(["EXAMPLE", "--input", str(path), "--sites", "github"]), 0)
            self.assertEqual(run.call_args.args[0], ["EXAMPLE", "second"])

    def test_input_file_errors_and_same_output_are_rejected_before_lookup(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "names.json"
            path.write_text('["example"]', encoding="utf-8")
            for args in (["--input", str(path), "--output", str(path)],
                         ["--input", str(path.parent / "missing.txt")],
                         ["--gui", "--input", str(path)]):
                with self.subTest(args=args), patch.object(app, "run_checks") as run, contextlib.redirect_stderr(io.StringIO()):
                    with self.assertRaises(SystemExit) as error:
                        app.main(args)
                    self.assertEqual(error.exception.code, 2)
                    run.assert_not_called()
            self.assertEqual(path.read_text(encoding="utf-8"), '["example"]')

    def test_version_and_site_listing_make_no_requests(self):
        with patch.object(app, "run_checks") as run, contextlib.redirect_stdout(io.StringIO()) as stdout:
            self.assertEqual(app.main(["--list-sites"]), 0)
            with self.assertRaises(SystemExit) as exit_code:
                app.main(["--version"])
        self.assertEqual(exit_code.exception.code, 0)
        self.assertIn(app.APP_VERSION, stdout.getvalue())
        for site in app.SITES:
            self.assertIn(site.key, stdout.getvalue())
        run.assert_not_called()

    def test_json_stdout_and_export_are_clean(self):
        value = sample_result()
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "results.json"
            stdout, stderr = io.StringIO(), io.StringIO()
            with patch.object(app, "run_checks", return_value=[value]), contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                code = app.main(["example", "--sites", "github", "--json", "--output", str(path)])
            self.assertEqual(code, 0)
            self.assertEqual(json.loads(stdout.getvalue()), json.loads(path.read_text(encoding="utf-8")))
            self.assertIn("Saved:", stderr.getvalue())

    def test_unknown_result_sets_exit_code(self):
        with patch.object(app, "run_checks", return_value=[sample_result(status="Unknown")]), contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(app.main(["example", "--sites", "github"]), 1)

    def test_invalid_args_never_send_network_requests(self):
        cases = (["example", "--sites", "nonsense"], ["example", "--sites", ","],
                 ["example", "--timeout", "nan"], ["example", "--timeout", "0"],
                 ["example", "--output", "file.txt"], ["--json"], ["--gui", "example"],
                 ["--gui", "--timeout", "20"], ["--gui", "--sites", "github"])
        for args in cases:
            with self.subTest(args=args), patch.object(app, "run_checks") as run, contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit) as error:
                    app.main(args)
                self.assertEqual(error.exception.code, 2)
                run.assert_not_called()

    def test_no_args_launches_gui(self):
        with patch.object(app, "launch_gui", return_value=0) as launch:
            self.assertEqual(app.main([]), 0)
        launch.assert_called_once()

    def test_ctrl_c_is_handled(self):
        with patch.object(app, "run_checks", side_effect=KeyboardInterrupt), contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(app.main(["example"]), 130)


@unittest.skipUnless(os.name == "nt" or sys.platform == "darwin" or os.environ.get("DISPLAY"),
                     "Desktop tests require Tkinter and a display (or Xvfb on Linux).")
class DesktopTests(unittest.TestCase):
    def setUp(self):
        try:
            import tkinter as tk
            from tkinter import ttk
            self.root = tk.Tk()
        except (ImportError, RuntimeError) as exc:
            self.skipTest(str(exc))
        self.errors = []
        self.root.report_callback_exception = lambda kind, value, trace: self.errors.append(str(value))
        self.dialogs, self.messages = Mock(), Mock()
        self.window = app.CheckerWindow(self.root, tk, ttk, self.dialogs, self.messages)
        self.root.update()

    def tearDown(self):
        self.window.close()
        self.assertEqual(self.errors, [])

    def pump_until(self, predicate, timeout=4):
        deadline = time.monotonic() + timeout
        while not predicate():
            if time.monotonic() > deadline:
                self.fail("Desktop operation did not finish in time.")
            self.root.update()
            time.sleep(0.01)
        self.root.update()

    def test_saved_preferences_restore_platforms_finder_and_explicit_limit_override(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "settings.json"
            self.window.preferences_file = path
            self.window.batch_limit.set("999")
            self.window.appearance.set("Dark")
            self.window.timeout.set("20")
            self.window.reuse_recent.set(False)
            self.window.choose_platform_preset("none")
            self.window.site_vars["instagram"].set(True)
            self.window.generator_vars["length"].set("5")
            self.window.generator_vars["pattern"].set("a????")
            self.window.generator_vars["count"].set("17")
            self.window.save_settings()
            other_root = self.window.tk.Toplevel(self.root)
            other = app.CheckerWindow(other_root, self.window.tk, self.window.ttk, self.dialogs, self.messages,
                                      preferences_file=path, batch_limit=0)
            try:
                self.assertEqual(other.get_batch_limit(), 0)
                self.assertEqual(other.appearance.get(), "Dark")
                self.assertEqual(float(other.timeout.get()), 20)
                self.assertFalse(other.reuse_recent.get())
                self.assertEqual([key for key, value in other.site_vars.items() if value.get()], ["instagram"])
                self.assertEqual(other.generator_vars["pattern"].get(), "a????")
                self.assertEqual(other.generator_vars["count"].get(), "17")
            finally:
                other.close()
                self.window.preferences_file = None
        self.messages.showerror.assert_not_called()

    def test_bad_preference_file_uses_defaults_without_preventing_startup(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "settings.json"
            path.write_text("not JSON")
            other = app.CheckerWindow(self.window.tk.Toplevel(self.root), self.window.tk, self.window.ttk,
                                      self.dialogs, self.messages, preferences_file=path)
            try:
                self.assertEqual(other.get_batch_limit(), 0)
                self.assertIn("Default settings", other.details.get())
            finally:
                other.close()

    def test_appearance_switch_keeps_inputs_rows_selection_and_pending_checks(self):
        self.window.input.insert("1.0", "draft_names")
        original = [sample_result("first"), sample_result("second", status="Not found")]
        self.window.results = list(original)
        self.window.pending_pairs = {("third", "github")}
        self.window.refresh_table()
        row = self.window.table.get_children()[1]
        self.window.table.selection_set(row)
        for mode in ("Dark", "Light"):
            self.window.appearance.set(mode)
            self.root.update()
            self.assertEqual(self.window.input.get("1.0", "end").strip(), "draft_names")
            self.assertEqual(self.window.results, original)
            self.assertEqual(self.window.table.selection(), (row,))
            self.assertEqual(self.window.pending_pairs, {("third", "github")})

    def test_open_dialogs_follow_the_theme_without_resetting_finder_or_platform_choices(self):
        self.window.open_generator()
        self.window.open_platforms()
        self.window.site_vars["instagram"].set(True)
        self.window.generator_vars["pattern"].set("a??")
        original = self.window.input.cget("background")
        self.window.appearance.set("Dark")
        self.root.update()
        self.assertNotEqual(self.window.input.cget("background"), original)
        self.assertEqual(self.window.generator_preview.cget("background"), self.window.input.cget("background"))
        self.window.appearance.set("Light")
        self.root.update()
        self.assertEqual(self.window.input.cget("background"), original)
        self.assertEqual(self.window.generator_vars["pattern"].get(), "a??")
        self.assertTrue(self.window.site_vars["instagram"].get())

    def test_empty_results_guidance_tracks_checks_and_search_filters(self):
        self.root.update()
        self.assertEqual(self.window.empty_state.winfo_manager(), "place")
        self.window.results = [sample_result()]
        self.window.refresh_table()
        self.assertEqual(self.window.empty_state.winfo_manager(), "")
        self.window.search.set("no matching name")
        self.root.update()
        self.assertEqual(self.window.empty_state.winfo_manager(), "place")
        self.assertEqual(self.window.empty_title.cget("text"), "No matching results")
        self.window.search.set("")
        self.assertEqual(self.window.empty_state.winfo_manager(), "")

    def test_normal_batch_session_round_trip_opens_without_requests_and_exports_saved_rows(self):
        self.window.choose_platform_preset("none")
        self.window.site_vars["instagram"].set(True)
        self.window.site_vars["tiktok"].set(True)
        self.window.input.insert("1.0", "abc\ndef")
        with tempfile.TemporaryDirectory() as folder, patch.object(app, "request_api") as request:
            path = Path(folder) / "session.ucsession"
            self.window.start()
            self.pump_until(lambda: not self.window.running)
            self.dialogs.asksaveasfilename.return_value = str(path)
            self.window.save_session()
            self.pump_until(lambda: not self.window.file_busy)
            self.assertTrue(path.exists())
            self.window.clear()
            self.dialogs.askopenfilename.return_value = str(path)
            self.window.open_session()
            self.pump_until(lambda: len(self.window.large_windows) == 1)
            view = self.window.large_windows[0]
            self.assertTrue(view.job.done.is_set())
            self.assertEqual(view.job.completed, 4)
            target = Path(folder) / "results.csv"
            self.dialogs.asksaveasfilename.return_value = str(target)
            view.export_all()
            self.pump_until(lambda: not view.exporting)
            with target.open(encoding="utf-8-sig", newline="") as source:
                self.assertEqual(len(list(csv.DictReader(source))), 4)
            view.request_close()
            self.pump_until(lambda: not self.window.large_windows)
        request.assert_not_called()
        self.messages.showerror.assert_not_called()

    def test_stopped_normal_batch_session_continues_missing_checks(self):
        self.window.choose_platform_preset("none")
        self.window.site_vars["github"].set(True)
        self.window.input.insert("1.0", "abc\ndef\nghi")
        entered, release = threading.Event(), threading.Event()
        def delayed(site, name, timeout, **options):
            entered.set()
            release.wait(3)
            return sample_result(name, site.name)
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "session.ucsession"
            try:
                with patch.object(app, "check_one", side_effect=delayed):
                    self.window.start()
                    self.assertTrue(entered.wait(2))
                    self.window.stop()
                    self.pump_until(lambda: not self.window.running)
                    release.set()
                    self.pump_until(self.window.workers_done.is_set)
            finally:
                release.set()
            self.assertEqual(len(self.window.pending_pairs), 3)
            self.dialogs.asksaveasfilename.return_value = str(path)
            self.window.save_session()
            self.pump_until(lambda: not self.window.file_busy)
            self.dialogs.askopenfilename.return_value = str(path)
            self.window.open_session()
            self.pump_until(lambda: bool(self.window.large_windows))
            view = self.window.large_windows[0]
            with patch.object(app, "check_one", side_effect=lambda site, name, timeout, **options: sample_result(name, site.name)) as check:
                view.continue_button.invoke()
                self.pump_until(lambda: view.job.done.is_set() and view.job.completed == 3)
            self.assertEqual(check.call_count, 3)
            view.request_close()
            self.pump_until(lambda: not self.window.large_windows)
        self.messages.showerror.assert_not_called()

    def test_large_generated_session_restores_all_rows_and_keeps_finder_visible_after_close(self):
        self.window.open_generator()
        self.window.generator_vars["length"].set("6")
        self.window.generator_vars["count"].set("12001")
        self.window.generator_vars["order"].set("Ordered")
        with tempfile.TemporaryDirectory() as folder, patch.object(app, "request_api") as request:
            path = Path(folder) / "generated.ucsession"
            self.window.generate_candidates()
            view = self.window.large_windows[0]
            self.pump_until(view.job.done.is_set, timeout=10)
            self.dialogs.asksaveasfilename.return_value = str(path)
            view.save_session()
            self.pump_until(lambda: not view.exporting, timeout=10)
            view.request_close()
            self.pump_until(lambda: not self.window.large_windows)
            self.dialogs.askopenfilename.return_value = str(path)
            self.window.open_session()
            self.pump_until(lambda: bool(self.window.large_windows), timeout=10)
            restored = self.window.large_windows[0]
            self.assertEqual(restored.job.completed, 12001)
            self.assertTrue(restored.job.generate_only)
            self.assertFalse(self.window.generator_dialog.winfo_viewable())
            restored.request_close()
            self.pump_until(lambda: not self.window.large_windows)
            self.assertTrue(self.window.generator_dialog.winfo_viewable())
        request.assert_not_called()
        self.messages.showerror.assert_not_called()

    def test_corrupt_session_keeps_current_results_and_reports_the_problem(self):
        original = sample_result()
        self.window.results = [original]
        self.window.refresh_table()
        with tempfile.TemporaryDirectory() as folder, patch.object(app, "request_api") as request:
            path = Path(folder) / "bad.ucsession"
            path.write_text("broken file")
            self.dialogs.askopenfilename.return_value = str(path)
            self.window.open_session()
            self.pump_until(lambda: not self.window.file_busy)
        self.assertEqual(self.window.results, [original])
        self.assertEqual(self.window.large_windows, [])
        self.messages.showerror.assert_called_once()
        request.assert_not_called()

    def test_comparison_shortlist_copy_search_and_csv_export_preserve_statuses(self):
        self.window.results = [sample_result("-danger", "GitHub", "Not found"), sample_result("-danger", "GitLab", "Not found"),
                               sample_result("uncertain", "GitHub", "Not found"), sample_result("uncertain", "GitLab", "Unknown"),
                               sample_result("manual", "GitHub", "Manual check")]
        comparison = self.window.compare_names()
        self.assertEqual(len(comparison.filtered), 3)
        comparison.shortlist.set(True)
        self.assertEqual([row[0] for row in comparison.filtered], ["-danger"])
        comparison.copy_names()
        self.assertEqual(comparison.dialog.clipboard_get(), "-danger")
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "comparison.csv"
            self.dialogs.asksaveasfilename.return_value = str(target)
            comparison.export()
            with target.open(encoding="utf-8-sig", newline="") as source:
                records = list(csv.reader(source))
        self.assertEqual(records, [["username", "GitHub", "GitLab"], ["'-danger", "Not found", "Not found"]])
        comparison.shortlist.set(False)
        comparison.search.set("manual")
        self.assertEqual(comparison.filtered, [("manual", ["Manual check", "Unchecked"])])
        comparison.dialog.destroy()

    def test_unlimited_default_and_huge_caps_are_accepted_by_the_desktop_controls(self):
        self.assertEqual(self.window.get_batch_limit(), 0)
        self.assertIn("Unlimited", self.window.input_hint.get())
        self.window.batch_limit.set(str(10 ** 400))
        self.window.open_generator()
        self.assertEqual(self.window.get_batch_limit(), 10 ** 400)
        self.assertIsNotNone(self.window.generator_dialog)
        self.window.batch_limit.set("0")
        self.assertEqual(self.window.generator_vars["count"].get(), "20")

    def test_large_generated_batch_uses_a_bounded_preview_and_exports_every_name(self):
        self.window.open_generator()
        self.window.generator_vars["length"].set("5")
        self.window.generator_vars["count"].set("12001")
        self.window.input.insert("1.0", "keep-this-input")
        with patch.object(app, "request_api") as lookup:
            self.window.generate_candidates()
            view = self.window.large_windows[-1]
            self.pump_until(view.job.done.is_set, timeout=10)
            self.pump_until(lambda: view.last_render == 12001)
        self.assertEqual(view.job.completed, 12001)
        self.assertFalse(self.window.generator_dialog.winfo_viewable())
        self.assertEqual(len(view.table.get_children()), app.RESULT_PREVIEW_SIZE)
        self.assertEqual(self.window.input.get("1.0", "end").strip(), "keep-this-input")
        self.assertIn("Finished", view.status.get())
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "names.txt"
            self.dialogs.asksaveasfilename.return_value = str(target)
            view.export_all()
            self.pump_until(lambda: not view.exporting, timeout=10)
            names = target.read_text().splitlines()
        self.assertEqual(len(names), 12001)
        self.assertEqual(len(set(names)), 12001)
        view.copy_preview()
        self.assertEqual(len(self.root.clipboard_get().splitlines()), app.RESULT_PREVIEW_SIZE)
        view.request_close()
        self.assertFalse(view.dialog.winfo_exists())
        self.assertFalse(self.window.large_windows)
        self.root.update()
        self.assertTrue(self.window.generator_dialog.winfo_viewable())
        self.assertEqual(self.window.generator.position, 12001)
        lookup.assert_not_called()

    def test_large_typed_batch_checks_and_exports_all_rows(self):
        self.window.choose_platform_preset("none")
        self.window.site_vars["instagram"].set(True)
        self.window.input.insert("1.0", " ".join(f"name{i}" for i in range(10001)))
        with patch.object(app, "request_api") as lookup:
            self.window.start()
            view = self.window.large_windows[-1]
            self.pump_until(view.job.done.is_set, timeout=10)
            self.pump_until(lambda: view.last_render == 10001)
        self.assertEqual(view.job.completed, 10001)
        self.assertEqual(len(view.table.get_children()), app.RESULT_PREVIEW_SIZE)
        row = view.table.get_children()[0]
        view.table.selection_set(row)
        with patch.object(app.webbrowser, "open", return_value=True) as browser:
            view.open_page()
        browser.assert_called_once_with(view.row_results[row].profile_url)
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "all.csv"
            self.dialogs.asksaveasfilename.return_value = str(target)
            view.export_all()
            self.pump_until(lambda: not view.exporting, timeout=10)
            with target.open(encoding="utf-8-sig", newline="") as source:
                self.assertEqual(sum(1 for _ in csv.DictReader(source)), 10001)
        view.request_close()
        lookup.assert_not_called()

    def test_all_remaining_huge_space_stops_without_overflow_and_revisits_unfinished_names(self):
        self.window.open_generator()
        self.window.generator_vars["length"].set("253")
        self.window.generator_vars["count"].set("0")
        self.window.generate_candidates()
        view = self.window.large_windows[-1]
        view.job.stop()
        self.pump_until(view.job.done.is_set)
        self.pump_until(lambda: view.last_render == view.job.completed)
        self.assertGreater(view.job.total, 10 ** 308)
        self.assertLess(len(view.status.get()), 250)
        expected = view.job.pulled - (len(view.job.pending_names) if view.job.pending_pairs else 0)
        view.request_close()
        self.assertEqual(self.window.generator.position, expected)

    def test_large_batch_window_can_pause_resume_and_continue_after_stop(self):
        started, release = threading.Event(), threading.Event()
        def check(site, name, timeout, **options):
            started.set()
            release.wait(3)
            return sample_result(name, site.name)
        self.window.choose_platform_preset("none")
        self.window.site_vars["github"].set(True)
        self.window.input.insert("1.0", "first second third")
        try:
            with patch.object(app, "LARGE_BATCH_THRESHOLD", 2), patch.object(app, "check_one", side_effect=check):
                self.window.start()
                view = self.window.large_windows[-1]
                self.pump_until(started.is_set)
                view.toggle_pause()
                release.set()
                self.pump_until(lambda: view.job.completed == 1)
                self.assertTrue(view.job.pause.is_set())
                view.job.stop()
                self.pump_until(view.job.done.is_set)
                self.pump_until(view.job.workers_done.is_set)
                self.assertTrue(view.job.start())
                self.pump_until(view.job.done.is_set)
            self.assertEqual(view.job.completed, 3)
            self.assertEqual(len(list(view.job.journal.read())), 3)
            view.request_close()
        finally:
            release.set()

    def test_finder_length_control_updates_default_pattern_and_resets_the_sequence(self):
        self.window.open_generator()
        self.assertEqual(int(self.window.generator_length_input["from"]), 1)
        self.assertEqual(int(self.window.generator_length_input["to"]), 253)
        self.window.generator_vars["charset"].set("Letters")
        self.window.generator_vars["order"].set("Ordered")
        self.window.generator_vars["count"].set("3")
        with patch.object(app, "request_api") as request:
            self.window.generator_vars["length"].set("5")
            self.assertEqual(self.window.generator_vars["pattern"].get(), "?????")
            self.window.generator_actions[0].invoke()
            self.assertEqual(self.window.input.get("1.0", "end").split(), ["aaaaa", "aaaab", "aaaac"])
            self.window.generate_candidates()
            self.assertEqual(self.window.generator.position, 6)
            self.window.generator_vars["length"].set("2")
            self.assertEqual(self.window.generator_vars["pattern"].get(), "??")
            self.window.generate_candidates()
            self.assertEqual(self.window.input.get("1.0", "end").split(), ["aa", "ab", "ac"])
            self.assertEqual(self.window.generator.position, 3)
        request.assert_not_called()

    def test_custom_pattern_is_preserved_and_invalid_length_change_does_not_consume_work(self):
        self.window.open_generator()
        self.window.generator_vars["order"].set("Ordered")
        self.window.generator_vars["pattern"].set("a??")
        self.window.generator_vars["count"].set("3")
        self.window.generate_candidates()
        original = self.window.generator
        original_input = self.window.input.get("1.0", "end")
        self.window.generator_vars["length"].set("5")
        self.assertEqual(self.window.generator_vars["pattern"].get(), "a??")
        self.window.generate_candidates()
        self.assertIs(self.window.generator, original)
        self.assertEqual(original.position, 3)
        self.assertEqual(self.window.input.get("1.0", "end"), original_input)
        self.messages.showerror.assert_called_once()
        self.window.generator_vars["pattern"].set("a????")
        self.window.generate_candidates()
        self.assertTrue(all(len(name) == 5 and name.startswith("a") for name in self.window.input.get("1.0", "end").split()))

    def test_blank_pattern_and_length_survive_reopening_the_finder(self):
        self.window.open_generator()
        self.window.generator_vars["length"].set("6")
        self.window.generator_vars["pattern"].set("")
        self.window.generator_vars["order"].set("Ordered")
        self.window.generator_vars["count"].set("2")
        self.window.generate_candidates()
        self.assertEqual(self.window.input.get("1.0", "end").split(), ["aaaaaa", "aaaaab"])
        self.window.generator_dialog.destroy()
        self.window.open_generator()
        self.assertEqual(self.window.generator_vars["length"].get(), "6")
        self.window.generate_candidates()
        self.assertEqual(self.window.input.get("1.0", "end").split(), ["aaaaac", "aaaaad"])
        self.assertEqual(self.window.generator.position, 4)

    def test_invalid_character_counts_keep_existing_input_and_generator_position(self):
        self.window.open_generator()
        self.window.generate_candidates()
        original, original_input = self.window.generator, self.window.input.get("1.0", "end")
        with patch.object(app, "request_api") as request:
            for length in ("", "0", "-1", "254", "1.5", "abc"):
                self.window.generator_vars["length"].set(length)
                self.window.generate_candidates()
                self.assertIs(self.window.generator, original)
                self.assertEqual(original.position, 20)
                self.assertEqual(self.window.input.get("1.0", "end"), original_input)
                self.assertIn("Character count", self.messages.showerror.call_args.args[1])
        request.assert_not_called()

    def test_selected_length_generate_and_check_uses_bulk_lookup_and_existing_controls(self):
        self.window.choose_platform_preset("none")
        self.window.site_vars["roblox"].set(True)
        self.window.open_generator()
        self.window.generator_vars["length"].set("5")
        self.window.generator_vars["count"].set("3")
        self.window.generator_vars["order"].set("Ordered")
        with patch.object(app, "request_api", return_value=response(200, {"data": []})) as lookup:
            self.window.generator_actions[1].invoke()
            self.assertTrue(self.window.running)
            self.assertTrue(all("disabled" in button.state() for button in self.window.generator_actions))
            self.pump_until(lambda: not self.window.running)
        self.assertEqual(json.loads(lookup.call_args.args[0].data)["usernames"], ["aaaaa", "aaaab", "aaaac"])
        self.assertEqual(len(self.window.results), 3)
        self.assertTrue(all(len(r.username) == 5 and r.status == "Not found" for r in self.window.results))
        self.assertEqual(self.window.stats.snapshot()["requests"], 1)

    def test_continuous_finder_checks_three_four_and_five_character_names_beyond_batch_size(self):
        self.window.choose_platform_preset("none")
        self.window.site_vars["roblox"].set(True)
        self.window.site_vars["instagram"].set(True)
        self.window.batch_limit.set("2")
        self.window.open_generator()
        self.window.generator_vars["charset"].set("Custom")
        self.window.generator_vars["characters"].set("ab")
        self.window.generator_vars["order"].set("Ordered")
        self.window.generator_vars["count"].set("1")
        for length in (3, 4, 5):
            self.window.generator_vars["length"].set(str(length))
            with patch.object(app, "request_api", return_value=response(200, {"data": []})):
                self.window.finder_start_button.invoke()
                view = self.window.large_windows[-1]
                self.pump_until(view.job.done.is_set)
                self.pump_until(lambda: view.last_render == 2 ** length)
            self.assertEqual(view.job.count, 2 ** length)
            self.assertEqual(view.job.chunk_size, 2)
            self.assertEqual([site.key for site in view.job.sites], ["roblox"])
            self.assertEqual(view.job.found_count, 2 ** length)
            self.assertTrue(all(len(r.username) == length and r.status == "Not found" for r in view.visible))
            self.assertEqual(len({r.username for r in view.visible}), 2 ** length)
            view.request_close()
            self.root.update()

    def test_continuous_all_platform_finds_can_be_copied_and_exported_without_duplicate_names(self):
        self.window.choose_platform_preset("none")
        for key in ("github", "gitlab"):
            self.window.site_vars[key].set(True)
        self.window.open_generator()
        self.window.generator_vars["charset"].set("Custom")
        self.window.generator_vars["characters"].set("ab")
        self.window.generator_vars["order"].set("Ordered")
        self.window.finder_match.set("All selected platforms")
        def lookup(request, timeout):
            return response(404, {"message": "Not Found"}) if request.host == "api.github.com" else response(200, [])
        with patch.object(app, "request_api", side_effect=lookup):
            self.window.find_continuously()
            view = self.window.large_windows[-1]
            self.pump_until(view.job.done.is_set)
            self.pump_until(lambda: view.last_render == 16)
        self.assertEqual(view.job.found_count, 8)
        self.assertTrue(all(r.status == "Not found" for r in view.visible))
        view.copy_preview()
        copied = self.root.clipboard_get().splitlines()
        self.assertEqual(len(copied), 8)
        self.assertEqual(len(set(copied)), 8)
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "found.txt"
            self.dialogs.asksaveasfilename.return_value = str(path)
            view.export_all()
            self.pump_until(lambda: not view.exporting)
            self.assertEqual(set(path.read_text().splitlines()), set(copied))
        view.request_close()
        self.root.update()

    def test_continuous_finder_pause_stop_and_continue_keep_found_names(self):
        self.window.choose_platform_preset("none")
        self.window.site_vars["github"].set(True)
        self.window.open_generator()
        self.window.generator_vars["length"].set("10")
        self.window.generator_vars["charset"].set("Custom")
        self.window.generator_vars["characters"].set("ab")
        self.window.generator_vars["order"].set("Ordered")
        started, release = threading.Event(), threading.Event()
        def check(site, name, timeout, **options):
            if not started.is_set():
                started.set()
                release.wait(3)
            return sample_result(name, site.name, "Not found", app.NOT_FOUND_DETAIL)
        try:
            with patch.object(app, "check_one", side_effect=check):
                self.window.find_continuously()
                view = self.window.large_windows[-1]
                self.assertTrue(started.wait(2))
                view.pause_button.invoke()
                release.set()
                self.pump_until(lambda: view.job.completed == 1)
                self.assertTrue(view.job.pause.is_set())
                view.stop_button.invoke()
                self.pump_until(lambda: view.job.done.is_set() and view.job.workers_done.is_set())
                self.assertEqual(view.job.found_count, 1)
                self.pump_until(lambda: "disabled" not in view.continue_button.state())
                view.continue_button.invoke()
                self.pump_until(view.job.done.is_set)
                self.pump_until(lambda: view.last_render == 1024)
            self.assertEqual(view.job.found_count, 1024)
            self.assertEqual(len(list(view.job.matches.read())), 1024)
            self.assertEqual(len(view.visible), app.RESULT_PREVIEW_SIZE)
            view.request_close()
            self.root.update()
        finally:
            release.set()

    def test_maximum_length_generation_keeps_the_minimum_finder_layout_usable(self):
        self.window.open_generator()
        self.window.generator_vars["length"].set("253")
        self.window.generator_vars["count"].set("2")
        with patch.object(app, "request_api") as lookup:
            self.window.generate_candidates()
        self.assertTrue(all(len(name) == 253 for name in self.window.input.get("1.0", "end").split()))
        self.assertLess(len(self.window.generator_progress.get()), 100)
        self.window.generator_dialog.geometry("640x580")
        self.root.update()
        dialog = self.window.generator_dialog
        for widget in [self.window.generator_length_input, self.window.generator_count_input, self.window.finder_match_input,
                       *self.window.generator_actions]:
            x, y = widget.winfo_rootx() - dialog.winfo_rootx(), widget.winfo_rooty() - dialog.winfo_rooty()
            self.assertGreaterEqual(x, 0)
            self.assertGreaterEqual(y, 0)
            self.assertLessEqual(x + widget.winfo_width(), dialog.winfo_width())
            self.assertLessEqual(y + widget.winfo_height(), dialog.winfo_height())
        lookup.assert_not_called()

    def test_repeat_batches_reuse_cache_and_fresh_or_clear_performs_new_lookups(self):
        self.window.choose_platform_preset("none")
        self.window.site_vars["github"].set(True)
        self.window.input.insert("1.0", "first second")
        def check(site, name, timeout, **options):
            return sample_result(name, site.name)
        with patch.object(app, "check_one", side_effect=check) as lookup:
            self.window.start()
            self.pump_until(lambda: not self.window.running)
            self.assertEqual(lookup.call_count, 2)
            self.window.start()
            self.pump_until(lambda: not self.window.running)
            self.assertEqual(lookup.call_count, 2)
            self.assertIn("2 reused", self.window.activity.get())
            self.assertTrue(all("Reused recent result" in r.detail for r in self.window.results))
            self.window.reuse_recent.set(False)
            self.window.start()
            self.pump_until(lambda: not self.window.running)
            self.assertEqual(lookup.call_count, 4)
            self.window.reuse_recent.set(True)
            kept = list(self.window.results)
            self.window.clear_cache()
            self.assertEqual(self.window.results, kept)
            self.window.start()
            self.pump_until(lambda: not self.window.running)
            self.assertEqual(lookup.call_count, 6)

    def test_pause_allows_inflight_result_and_resume_finishes_the_batch(self):
        started, release = threading.Event(), threading.Event()
        self.window.choose_platform_preset("none")
        self.window.site_vars["github"].set(True)
        self.window.input.insert("1.0", "first second")
        def check(site, name, timeout, **options):
            if name == "first":
                started.set()
                release.wait(3)
            return sample_result(name, site.name)
        try:
            with patch.object(app, "check_one", side_effect=check) as lookup:
                self.window.start()
                self.pump_until(started.is_set)
                self.window.toggle_pause()
                self.assertEqual(self.window.pause_button["text"], "Resume")
                release.set()
                self.pump_until(lambda: len(self.window.results) == 1)
                self.assertTrue(self.window.running)
                self.assertEqual(lookup.call_count, 1)
                self.assertIn("Paused", self.window.summary.get())
                self.window.toggle_pause()
                self.pump_until(lambda: not self.window.running)
                self.assertEqual(lookup.call_count, 2)
                self.assertEqual(len(self.window.results), 2)
                self.assertFalse(self.window.pending_pairs)
        finally:
            release.set()
            self.window.cancel.set()
            self.window.workers_done.wait(2)

    def test_stop_then_continue_uses_original_pending_pairs_and_preserves_completed_rows(self):
        started, release = threading.Event(), threading.Event()
        self.window.choose_platform_preset("none")
        self.window.site_vars["github"].set(True)
        self.window.input.insert("1.0", "first second third")
        calls = []
        def check(site, name, timeout, **options):
            calls.append((name, site.key))
            if name == "second":
                started.set()
                release.wait(3)
            return sample_result(name, site.name)
        try:
            with patch.object(app, "check_one", side_effect=check):
                self.window.start()
                self.pump_until(lambda: started.is_set() and self.window.completed == 1)
                first = self.window.results[0]
                self.window.stop()
                self.pump_until(lambda: not self.window.running)
                self.assertIn("disabled", self.window.continue_button.state())
                release.set()
                self.pump_until(lambda: "disabled" not in self.window.continue_button.state())
                self.window.input.delete("1.0", "end")
                self.window.input.insert("1.0", "different-input")
                self.window.choose_platform_preset("none")
                self.window.site_vars["gitlab"].set(True)
                self.window.continue_checks()
                self.pump_until(lambda: not self.window.running)
            self.assertEqual(calls, [("first", "github"), ("second", "github"), ("third", "github")])
            self.assertIs(self.window.results[0], first)
            self.assertEqual({r.username for r in self.window.results}, {"first", "second", "third"})
            self.assertTrue(all(r.site == "GitHub" for r in self.window.results))
            self.assertFalse(self.window.pending_pairs)
            self.assertEqual(self.window.stats.snapshot()["cache_hits"], 1)
        finally:
            release.set()
            self.window.cancel.set()
            self.window.workers_done.wait(2)

    def test_continue_obeys_new_limit_and_clear_removes_pending_work(self):
        self.window.last_batch = (["first", "second"], [app.SITES[0]], 12)
        self.window.pending_pairs = {("first", "github"), ("second", "github")}
        self.window.batch_limit.set("1")
        with patch.object(app, "request_api") as request:
            self.window.continue_checks()
        request.assert_not_called()
        self.messages.showerror.assert_called_once()
        self.assertEqual(len(self.window.pending_pairs), 2)
        self.window.clear()
        self.assertFalse(self.window.pending_pairs)
        self.assertIsNone(self.window.last_batch)
        self.assertIn("disabled", self.window.continue_button.state())

    def test_copy_names_uses_filters_and_removes_duplicate_rows(self):
        self.window.results = [sample_result("first", status="Not found"),
                               sample_result("first", "GitLab", "Not found"),
                               sample_result("second"), sample_result("third", status="Not found")]
        self.window.status_filter.set("Not found")
        self.window.copy_names()
        self.assertEqual(self.root.clipboard_get(), "first\nthird")
        self.window.search.set("absent")
        self.assertIn("disabled", self.window.copy_names_button.state())

    def test_large_streaming_view_does_not_refilter_every_arriving_chunk(self):
        self.window.choose_platform_preset("none")
        self.window.site_vars["instagram"].set(True)
        self.window.batch_limit.set("1000")
        self.window.input.insert("1.0", " ".join(f"name{i}" for i in range(1000)))
        with patch.object(app, "filter_results", wraps=app.filter_results) as filtered, patch.object(app, "request_api") as request:
            self.window.start()
            self.pump_until(lambda: not self.window.running)
        self.assertLessEqual(filtered.call_count, 3)
        self.assertEqual(len(self.window.results), 1000)
        self.assertEqual(self.window.visible_results, self.window.results)
        self.assertEqual(len(self.window.table.get_children()), 1000)
        request.assert_not_called()

    def test_editable_limit_controls_manual_input_and_is_locked_during_checks(self):
        self.window.choose_platform_preset("none")
        self.window.site_vars["instagram"].set(True)
        self.window.batch_limit.set("5")
        self.window.input.insert("1.0", " ".join(f"name{i}" for i in range(6)))
        with patch.object(app, "request_api") as request:
            self.window.start()
            self.assertFalse(self.window.running)
            self.messages.showerror.assert_called_once()
            self.window.batch_limit.set("10")
            self.window.start()
            self.assertTrue(self.window.running)
            self.assertIn("disabled", self.window.batch_limit_input.state())
            self.pump_until(lambda: not self.window.running)
        self.assertEqual(len(self.window.results), 6)
        self.assertIn("up to 10", self.window.input_hint.get())
        self.assertNotIn("disabled", self.window.batch_limit_input.state())
        request.assert_not_called()

    def test_finder_tracks_limit_changes_and_continues_the_sequence(self):
        self.window.batch_limit.set("1000")
        self.window.open_generator()
        self.window.generator_vars["order"].set("Ordered")
        self.window.generator_vars["count"].set("600")
        with patch.object(app, "request_api") as request:
            self.window.generate_candidates()
            first = self.window.input.get("1.0", "end").split()
            self.assertEqual(len(first), 600)
            self.window.batch_limit.set("10")
            self.assertEqual(self.window.generator_vars["count"].get(), "10")
            self.assertEqual(int(self.window.generator_count_input["to"]), 10)
            self.window.generate_candidates()
            second = self.window.input.get("1.0", "end").split()
        self.assertEqual(len(second), 10)
        self.assertEqual(self.window.generator.position, 610)
        self.assertTrue(set(first).isdisjoint(second))
        request.assert_not_called()

    def test_invalid_limit_preserves_input_and_does_not_open_the_finder(self):
        self.window.input.insert("1.0", "example")
        for value in ("", "-1", "-10001", "text", "1.5"):
            self.window.batch_limit.set(value)
            self.window.start()
            self.assertFalse(self.window.running)
            self.assertEqual(self.window.input.get("1.0", "end").strip(), "example")
        self.window.open_generator()
        self.assertIsNone(self.window.generator_dialog)
        self.assertEqual(self.messages.showerror.call_count, 6)

    def test_retry_requires_a_limit_that_fits_the_failed_names(self):
        self.window.results = [sample_result(f"name{i}", status="Unknown") for i in range(10)]
        self.window.refresh_table()
        self.window.batch_limit.set("5")
        with patch.object(app, "run_checks") as run:
            self.window.retry_unknown()
        run.assert_not_called()
        self.assertEqual(len(self.window.results), 10)
        self.messages.showerror.assert_called_once()
        self.window.batch_limit.set("10")
        def checked(site, name, timeout, **options):
            return sample_result(name, site.name)
        with patch.object(app, "check_one", side_effect=checked):
            self.window.retry_unknown()
            self.pump_until(lambda: not self.window.running)
        self.assertTrue(all(result.status == "Taken" for result in self.window.results))

    def test_gui_import_uses_the_current_limit(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "names.txt"
            path.write_text("\n".join(f"name{i}" for i in range(25)), encoding="utf-8")
            self.dialogs.askopenfilename.return_value = str(path)
            self.window.input.insert("1.0", "keep_me")
            self.window.batch_limit.set("20")
            self.window.import_names()
            self.assertEqual(self.window.input.get("1.0", "end").strip(), "keep_me")
            self.window.batch_limit.set("25")
            self.window.import_names()
            self.assertEqual(len(self.window.input.get("1.0", "end").split()), 25)

    def test_platform_picker_filters_presets_and_preserves_selections(self):
        self.window.open_platforms()
        self.assertEqual(len(self.window.platform_visible), 32)
        self.assertEqual(sum(variable.get() for variable in self.window.site_vars.values()), 5)
        self.window.choose_platform_preset("none")
        self.assertTrue(all(not variable.get() for variable in self.window.site_vars.values()))
        self.window.platform_search.set("discord")
        self.window.refresh_platforms()
        self.assertEqual([site.key for site in self.window.platform_visible], ["discord"])
        self.window.site_vars["discord"].set(True)
        self.window.platform_search.set("")
        self.window.platform_category.set("Gaming")
        self.window.platform_mode.set("Automatic")
        self.window.refresh_platforms()
        self.assertEqual({site.key for site in self.window.platform_visible}, {"roblox", "chesscom"})
        self.assertTrue(self.window.site_vars["discord"].get())
        self.assertIn("1 manual", self.window.platform_summary.get())
        self.window.choose_platform_preset("auto")
        self.assertFalse(self.window.site_vars["discord"].get())
        self.window.choose_platform_preset("all")
        self.assertEqual(sum(variable.get() for variable in self.window.site_vars.values()), 32)

    def test_platform_picker_finds_aliases_and_new_categories(self):
        self.window.open_platforms()
        for query, key in (("Fortnite", "epicgames"), ("Twitter", "x"), ("PSN", "playstation")):
            self.window.platform_search.set(query)
            self.window.refresh_platforms()
            self.assertEqual([site.key for site in self.window.platform_visible], [key])
        self.window.platform_search.set("")
        self.window.platform_category.set("Payments")
        self.window.refresh_platforms()
        self.assertEqual({site.key for site in self.window.platform_visible}, {"cashapp", "venmo", "paypal"})
        self.window.choose_platform_preset("all")
        self.assertIn("27 manual", self.window.platform_summary.get())

    def test_500_generated_names_check_on_manual_platform_without_network(self):
        self.window.choose_platform_preset("none")
        self.window.site_vars["instagram"].set(True)
        self.window.open_generator()
        self.window.generator_vars["count"].set("500")
        self.window.generator_vars["order"].set("Ordered")
        with patch.object(app, "request_api") as request:
            self.window.generate_candidates(check=True)
            self.pump_until(lambda: not self.window.running)
        self.assertEqual(len(self.window.results), 500)
        self.assertTrue(all(len(result.username) == 3 for result in self.window.results))
        self.assertTrue(all(result.status == "Manual check" for result in self.window.results))
        self.assertEqual(int(self.window.progress["value"]), 500)
        self.assertEqual(len(self.window.table.get_children()), 500)
        request.assert_not_called()

    def test_large_result_table_preserves_rows_selection_and_scroll(self):
        self.window.results = [sample_result(f"name{i:04d}") for i in range(2500)]
        self.window.refresh_table()
        selected = self.window.table.get_children()[1000]
        self.window.table.selection_set(selected)
        self.window.table.see(selected)
        self.root.update()
        top_row = self.window.table.identify_row(50)
        self.window.results.extend(sample_result(f"name{i:04d}") for i in range(2500, 3000))
        self.window.refresh_table()
        self.root.update()
        self.assertEqual(self.window.table.selection(), (selected,))
        self.assertEqual(self.window.selected_result().username, "name1000")
        self.assertEqual(self.window.table.identify_row(50), top_row)
        self.assertEqual(len(self.window.table.get_children()), 3000)

    def test_generator_pages_and_reset_do_not_send_requests(self):
        with patch.object(app, "run_checks") as run:
            self.window.open_generator()
            self.window.generator_vars["charset"].set("Letters")
            self.window.generator_vars["pattern"].set("a??")
            self.window.generator_vars["count"].set("3")
            self.window.generator_vars["order"].set("Ordered")
            self.window.generate_candidates()
            self.assertEqual(self.window.input.get("1.0", "end").split(), ["aaa", "aab", "aac"])
            self.window.generate_candidates()
            self.assertEqual(self.window.input.get("1.0", "end").split(), ["aad", "aae", "aaf"])
            self.assertIn("6 / 676", self.window.generator_progress.get())
            self.window.reset_generator()
            self.window.generate_candidates()
            self.assertEqual(self.window.input.get("1.0", "end").split(), ["aaa", "aab", "aac"])
            run.assert_not_called()

    def test_generate_and_check_uses_three_character_names_and_existing_controls(self):
        for key, variable in self.window.site_vars.items():
            variable.set(key == "github")
        self.window.open_generator()
        self.window.generator_vars["pattern"].set("a??")
        self.window.generator_vars["count"].set("2")
        self.window.generator_vars["order"].set("Ordered")
        def check(site, name, timeout, **options):
            return sample_result(name, site.name, "Not found")
        with patch.object(app, "check_one", side_effect=check) as lookup:
            self.window.generate_candidates(check=True)
            self.assertTrue(self.window.running)
            self.assertTrue(all("disabled" in button.state() for button in self.window.generator_actions))
            self.pump_until(lambda: not self.window.running)
        self.assertEqual([r.username for r in self.window.results], ["aaa", "aab"])
        self.assertEqual(lookup.call_count, 2)
        self.assertTrue(all(r.status == "Not found" for r in self.window.results))
        self.assertTrue(all("disabled" not in button.state() for button in self.window.generator_actions))

    def test_generator_validation_does_not_consume_names_or_replace_input(self):
        self.window.open_generator()
        self.window.input.insert("1.0", "keep_me")
        self.window.generator_vars["pattern"].set("??")
        self.window.generate_candidates()
        self.assertEqual(self.window.input.get("1.0", "end").strip(), "keep_me")
        self.assertIsNone(self.window.generator)
        self.window.generator_vars["pattern"].set("???")
        for variable in self.window.site_vars.values():
            variable.set(False)
        self.window.generate_candidates(check=True)
        self.assertIsNone(self.window.generator)
        self.assertFalse(self.window.running)
        self.assertEqual(self.messages.showerror.call_count, 2)

    def test_generator_settings_changes_exhaustion_and_reopen(self):
        self.window.open_generator()
        self.window.generator_vars["pattern"].set("abc")
        self.window.generate_candidates()
        self.assertEqual(self.window.input.get("1.0", "end").strip(), "abc")
        self.window.generate_candidates()
        self.assertIn("All matching names", self.window.generator_progress.get())
        self.window.generator_dialog.destroy()
        self.window.open_generator()
        self.window.generator_vars["pattern"].set("xyz")
        self.window.generate_candidates()
        self.assertEqual(self.window.input.get("1.0", "end").strip(), "xyz")
        self.assertEqual(self.window.generator.position, 1)

    def test_invalid_input_and_timeout_never_start_a_batch(self):
        self.window.start()
        self.assertFalse(self.window.running)
        self.messages.showerror.assert_called_once()
        self.window.input.insert("1.0", "example")
        self.window.timeout.set("nan")
        self.window.start()
        self.assertFalse(self.window.running)
        self.assertEqual(self.messages.showerror.call_count, 2)

    def test_desktop_http_filter_copy_export_open_and_import(self):
        server = ThreadingHTTPServer(("127.0.0.1", 0), LocalHandler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        def request(site, name):
            endpoint = "/profile" if name == "example" else "/missing"
            return urllib.request.Request(f"http://127.0.0.1:{server.server_port}" + endpoint)
        try:
            for key, variable in self.window.site_vars.items():
                variable.set(key == "github")
            self.window.input.insert("1.0", "example\nmissing")
            with patch.object(app, "build_request", side_effect=request):
                self.window.start()
                self.pump_until(lambda: not self.window.running)
            self.assertEqual({r.status for r in self.window.results}, {"Taken", "Not found"})
            self.assertEqual(int(self.window.progress["value"]), 2)
            self.window.status_filter.set("Not found")
            self.root.update()
            self.assertEqual([r.username for r in self.window.visible_results], ["missing"])
            self.window.copy_results()
            self.assertIn("missing", self.root.clipboard_get())
            self.assertNotIn("example", self.root.clipboard_get())
            row = self.window.table.get_children()[0]
            self.window.table.selection_set(row)
            self.window.select_row()
            with patch.object(app.webbrowser, "open", return_value=True) as browser:
                self.window.open_profile()
            browser.assert_called_once_with("https://github.com/missing")
            with tempfile.TemporaryDirectory() as folder:
                path = Path(folder) / "filtered.json"
                self.dialogs.asksaveasfilename.return_value = str(path)
                self.window.save_results()
                self.assertEqual([r["username"] for r in json.loads(path.read_text())], ["missing"])
                self.window.clear()
                self.dialogs.askopenfilename.return_value = str(path)
                self.window.import_names()
                self.assertEqual(self.window.input.get("1.0", "end").strip(), "missing")
                self.assertEqual(self.window.results, [])
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)

    def test_unknown_retry_preserves_successes_and_targets_exact_pairs(self):
        self.window.results = [sample_result("first", "GitHub", "Unknown"),
                               sample_result("first", "GitLab"), sample_result("second", "GitHub"),
                               sample_result("second", "GitLab", "Unknown")]
        successful = {r for r in self.window.results if r.status == "Taken"}
        self.window.refresh_table()
        calls = []
        def check(site, name, timeout, **options):
            calls.append((name, site.name))
            return sample_result(name, site.name)
        with patch.object(app, "check_one", side_effect=check):
            self.window.retry_unknown()
            self.pump_until(lambda: not self.window.running)
        self.assertEqual(set(calls), {("first", "GitHub"), ("second", "GitLab")})
        self.assertEqual(len(self.window.results), 4)
        self.assertTrue(successful.issubset(set(self.window.results)))
        self.assertTrue(all(r.status == "Taken" for r in self.window.results))

    def test_stop_remains_responsive_and_prevents_overlapping_batches(self):
        started, release = threading.Event(), threading.Event()
        def check(site, name, timeout, **options):
            started.set()
            release.wait(4)
            return sample_result(name, site.name)
        for key, variable in self.window.site_vars.items():
            variable.set(key == "github")
        self.window.input.insert("1.0", "example\nsecond")
        try:
            with patch.object(app, "check_one", side_effect=check) as lookup:
                self.window.start()
                self.pump_until(started.is_set)
                self.window.stop()
                self.pump_until(lambda: not self.window.running)
                self.assertFalse(self.window.workers_done.is_set())
                self.assertIn("disabled", self.window.check_button.state())
                self.window.start()
                self.assertEqual(lookup.call_count, 1)
                release.set()
                self.pump_until(self.window.workers_done.is_set)
                # The periodic UI poll re-enables buttons after workers exit.
                self.pump_until(lambda: "disabled" not in self.window.check_button.state())
                self.assertEqual(self.window.results, [])
        finally:
            release.set()
            self.window.workers_done.wait(2)

    def test_sorting_search_and_no_matching_rows(self):
        self.window.results = [sample_result("zeta"), sample_result("alpha")]
        self.window.refresh_table()
        self.window.sort_column("username")
        self.assertEqual([r.username for r in self.window.visible_results], ["alpha", "zeta"])
        self.window.sort_column("username")
        self.assertEqual([r.username for r in self.window.visible_results], ["zeta", "alpha"])
        self.window.search.set("ALPHA")
        self.assertEqual([r.username for r in self.window.visible_results], ["alpha"])
        self.window.search.set("no match")
        self.assertEqual(self.window.visible_results, [])
        self.assertIn("disabled", self.window.copy_button.state())
        self.assertIn("disabled", self.window.save_button.state())
        self.assertIn("disabled", self.window.open_button.state())

    def test_api_tokens_are_masked_validated_and_excluded_from_saved_files(self):
        with tempfile.TemporaryDirectory() as folder:
            self.window.preferences_file = Path(folder) / "settings.json"
            self.window.open_api_access()
            self.assertEqual(self.window.api_entries["github"].cget("show"), "*")
            self.window.api_token_vars["github"].set("bad token")
            self.window.apply_api_access()
            self.messages.showerror.assert_called_once()
            self.assertEqual(self.window.access.tokens(), {})
            self.window.api_token_vars["github"].set("github-test-private-token")
            self.window.api_token_vars["gitlab"].set("gitlab-test-private-token")
            self.window.apply_api_access()
            self.assertEqual(self.window.access.tokens(), {"github": "github-test-private-token", "gitlab": "gitlab-test-private-token"})
            self.window.save_settings()
            saved = self.window.preferences_file.read_text()
            self.assertNotIn("private-token", saved)
            self.assertNotIn("token", saved)
            self.window.open_api_access()
            self.assertEqual(self.window.api_token_vars["github"].get(), "github-test-private-token")
            self.window.api_dialog.geometry("480x410")
            self.window.appearance.set("Dark")
            self.root.update()
            button = self.window.api_apply_button
            self.assertLessEqual(button.winfo_rooty() + button.winfo_height(),
                                 self.window.api_dialog.winfo_rooty() + self.window.api_dialog.winfo_height())
            self.window.api_dialog.destroy()
            self.window.preferences_file = None

    def test_cooldown_stays_responsive_and_continue_revisits_unfinished_names(self):
        moment = [1000.0]
        self.window.access = app.ApiAccess(clock=lambda: moment[0])
        for key, variable in self.window.site_vars.items():
            variable.set(key == "github")
        self.window.input.insert("1.0", "first\nsecond")
        count = [0]
        def lookup(request, timeout):
            count[0] += 1
            return (response(429, {}, headers={"retry-after": "60"}) if count[0] == 1 else
                    response(404, {"message": "Not Found"}))
        with patch.object(app, "request_api", side_effect=lookup):
            self.window.start()
            self.pump_until(lambda: "Cooldown" in self.window.summary.get())
            self.assertEqual(self.window.results, [])
            self.assertEqual(len(self.window.pending_pairs), 2)
            self.window.stop()
            self.pump_until(lambda: not self.window.running and self.window.workers_done.is_set())
            moment[0] += 60
            self.window.continue_checks()
            self.pump_until(lambda: not self.window.running)
        self.assertEqual(count[0], 3)
        self.assertEqual([r.username for r in self.window.results], ["first", "second"])
        self.assertEqual(self.window.pending_pairs, set())

    def test_api_token_changes_are_rejected_while_checking(self):
        self.window.open_api_access()
        self.window.api_token_vars["github"].set("github-test-private-token")
        self.window.running = True
        try:
            self.window.apply_api_access()
            self.assertEqual(self.window.access.tokens(), {})
            self.messages.showinfo.assert_called_once()
        finally:
            self.window.running = False
            self.window.api_dialog.destroy()

    def test_minimum_window_keeps_sidebar_controls_and_tall_results_visible(self):
        self.root.geometry("840x720")
        for mode in ("Light", "Dark"):
            self.window.appearance.set(mode)
            self.root.update()
            width, height = self.root.winfo_width(), self.root.winfo_height()
            self.assertTrue(self.window.compact_layout)
            self.assertGreaterEqual(self.window.table.winfo_height(), 300)
            self.assertLessEqual(self.window.input.winfo_rootx() + self.window.input.winfo_width(),
                                 self.window.table.winfo_rootx())
            self.assertGreater(self.window.platform_button.winfo_rooty(),
                               self.window.check_button.winfo_rooty())
            for widget in (self.window.table, self.window.check_button, self.window.stop_button,
                           self.window.import_button, self.window.retry_button, self.window.save_button,
                           self.window.pause_button, self.window.continue_button, self.window.cache_toggle,
                           self.window.clear_cache_button, self.window.copy_names_button, self.window.open_session_button,
                           self.window.compare_button, self.window.input, self.window.generator_button,
                           self.window.platform_button, self.window.batch_limit_input, self.window.clear_button,
                           self.window.open_button, self.window.copy_button, self.window.api_button):
                x = widget.winfo_rootx() - self.root.winfo_rootx()
                y = widget.winfo_rooty() - self.root.winfo_rooty()
                with self.subTest(widget=widget, theme=mode):
                    self.assertGreaterEqual(x, 0)
                    self.assertGreaterEqual(y, 0)
                    self.assertLessEqual(x + widget.winfo_width(), width)
                    self.assertLessEqual(y + widget.winfo_height(), height)

    def test_import_and_export_failures_keep_existing_results(self):
        self.window.results = [sample_result()]
        self.window.refresh_table()
        self.dialogs.askopenfilename.return_value = "missing.txt"
        self.window.import_names()
        self.assertEqual(len(self.window.results), 1)
        self.messages.showerror.assert_called_once()
        self.dialogs.asksaveasfilename.return_value = "results.json"
        with patch.object(app, "export_results", side_effect=OSError("read-only")):
            self.window.save_results()
        self.assertEqual(len(self.window.results), 1)
        self.assertEqual(self.messages.showerror.call_count, 2)


if __name__ == "__main__":
    unittest.main()
