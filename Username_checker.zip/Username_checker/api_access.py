"""Optional API credentials and interruptible, per-platform cooldowns."""

from __future__ import annotations

import math
import os
import threading
import time
import urllib.parse
from datetime import timezone
from email.utils import parsedate_to_datetime


TOKEN_ENVIRONMENT = {"github": "GITHUB_TOKEN", "gitlab": "GITLAB_TOKEN"}
TOKEN_HOSTS = {"github": "api.github.com", "gitlab": "gitlab.com"}
DEFAULT_BACKOFF = 60.0
MAX_RATE_RETRIES = 3


def validated_tokens(tokens):
    """Validate header values without putting a credential into an error message."""
    if not isinstance(tokens, dict) or any(key not in TOKEN_HOSTS for key in tokens):
        raise ValueError("API tokens are supported for GitHub and GitLab only.")
    cleaned = {}
    for key, value in tokens.items():
        if not isinstance(value, str):
            raise ValueError(f"{key.title()} token must be text.")
        token = value.strip()
        if token and (len(token) > 4096 or any(not 33 <= ord(char) <= 126 for char in token)):
            raise ValueError(f"Invalid {key.title()} token. Paste the token without spaces or line breaks.")
        if token:
            cleaned[key] = token
    return cleaned


def environment_tokens(environ=None):
    source = os.environ if environ is None else environ
    return validated_tokens({key: source.get("USERNAME_CHECKER_" + variable, source.get(variable, ""))
                             for key, variable in TOKEN_ENVIRONMENT.items()})


def _headers(response):
    return {key.lower(): value.strip() for key, value in response.headers.items()
            if isinstance(key, str) and isinstance(value, str)}


def is_rate_limited(response):
    if response.status == 429:
        return True
    if response.status != 403:
        return False
    headers = _headers(response)
    message = response.data.get("message", "") if isinstance(response.data, dict) else ""
    return (headers.get("x-ratelimit-remaining", headers.get("ratelimit-remaining")) == "0"
            or isinstance(message, str) and any(text in message.lower() for text in
                                               ("api rate limit exceeded", "secondary rate limit")))


def _number(value):
    try:
        result = float(value)
        return result if math.isfinite(result) and result >= 0 else None
    except (ValueError, TypeError, OverflowError):
        return None


def _date(value):
    try:
        date = parsedate_to_datetime(value)
        if date.tzinfo is None:
            date = date.replace(tzinfo=timezone.utc)
        timestamp = date.timestamp()
        return timestamp if math.isfinite(timestamp) else None
    except (ValueError, TypeError, OverflowError, OSError, AttributeError):
        return None


def cooldown_seconds(response, now):
    """Honor Retry-After (seconds or HTTP date), then documented reset headers."""
    headers = _headers(response)
    server_now = _date(headers.get("date"))
    if server_now is not None:
        now = server_now
    retry = headers.get("retry-after")
    if retry is not None:
        delay = _number(retry)
        if delay is not None:
            return delay
        reset = _date(retry)
        if reset is not None:
            return max(0.0, reset - now)
    for key in ("x-ratelimit-reset", "ratelimit-reset"):
        reset = _number(headers.get(key))
        if reset is not None:
            return max(0.0, reset - now)
    reset = _date(headers.get("ratelimit-resettime"))
    return max(0.0, reset - now) if reset is not None else None


class ApiAccess:
    """Credentials never enter preferences, exports, or checkpoint records."""

    def __init__(self, tokens=None, *, clock=time.monotonic, wall_clock=time.time, on_cooldown=None):
        self.lock = threading.Lock()
        self.clock, self.wall_clock, self.on_cooldown = clock, wall_clock, on_cooldown
        self._tokens = validated_tokens({} if tokens is None else tokens)
        self.deadlines, self.failures, self.exhausted = {}, {}, set()

    def tokens(self):
        with self.lock:
            return dict(self._tokens)

    def set_tokens(self, tokens):
        cleaned = validated_tokens(tokens)
        with self.lock:
            for key in TOKEN_HOSTS:
                if cleaned.get(key) != self._tokens.get(key):
                    self.deadlines.pop(key, None)
                    self.failures.pop(key, None)
                    self.exhausted.discard(key)
            self._tokens = cleaned

    def authorize(self, key, request):
        with self.lock:
            token = self._tokens.get(key)
        if not token:
            return
        url = urllib.parse.urlsplit(request.full_url)
        if (url.scheme != "https" or url.hostname != TOKEN_HOSTS.get(key)
                or url.port not in (None, 443) or url.username or url.password):
            raise ValueError("API credentials can only be sent to the platform's official HTTPS endpoint.")
        request.add_header("Authorization" if key == "github" else "PRIVATE-TOKEN",
                           "Bearer " + token if key == "github" else token)

    def observe(self, key, response):
        limited = is_rate_limited(response)
        headers = _headers(response)
        exhausted = headers.get("x-ratelimit-remaining", headers.get("ratelimit-remaining")) == "0"
        delay = cooldown_seconds(response, self.wall_clock()) if limited or exhausted else None
        with self.lock:
            attempts = self.failures.get(key, 0)
            if limited:
                if delay is None:
                    delay = DEFAULT_BACKOFF * 2 ** min(attempts, 6)
                self.failures[key] = attempts + 1
            else:
                self.failures.pop(key, None)
            if delay is not None:
                self.deadlines[key] = max(self.deadlines.get(key, 0), self.clock() + delay)
        if delay is not None and self.on_cooldown is not None:
            self.on_cooldown(key, delay)

    def begin(self, key):
        with self.lock:
            self.exhausted.discard(key)

    def give_up(self, key):
        with self.lock:
            self.exhausted.add(key)

    def exhausted_sites(self):
        with self.lock:
            return set(self.exhausted)

    def continue_after_cooldown(self, key):
        """A continuous finder can recover later without spinning on a zero reset."""
        with self.lock:
            now = self.clock()
            delay = max(0.0, self.deadlines.get(key, 0) - now)
            if delay <= 0:
                delay = DEFAULT_BACKOFF * 2 ** min(max(0, self.failures.get(key, 1) - 1), 6)
            self.deadlines[key] = now + delay
            self.exhausted.discard(key)
        if self.on_cooldown is not None:
            self.on_cooldown(key, delay)

    def remaining(self):
        with self.lock:
            now = self.clock()
            return {key: max(1, math.ceil(deadline - now)) for key, deadline in self.deadlines.items()
                    if deadline > now}

    def wait(self, key, cancel, pause=None):
        while not cancel.is_set():
            if pause is not None and pause.is_set():
                if cancel.wait(.05):
                    return False
                continue
            with self.lock:
                remaining = self.deadlines.get(key, 0) - self.clock()
            if remaining <= 0:
                return True
            if cancel.wait(min(remaining, .25)):
                return False
        return False
