@echo off
setlocal
cd /d "%~dp0"
py -3 -c "import sys; assert sys.version_info >= (3, 10)" >nul 2>&1
if not errorlevel 1 (
    py -3 "%~dp0username_checker.py" --gui
    if errorlevel 1 goto failed
    exit /b 0
)
python -c "import sys; assert sys.version_info >= (3, 10)" >nul 2>&1
if not errorlevel 1 (
    python "%~dp0username_checker.py" --gui
    if errorlevel 1 goto failed
    exit /b 0
)
echo Python 3.10 or newer was not found.
echo Install Python from https://www.python.org/downloads/
echo Include Tcl/Tk in the installer, then open this launcher again.
pause
exit /b 2

:failed
echo.
echo The app could not start. The error message is shown above.
pause
exit /b 1
