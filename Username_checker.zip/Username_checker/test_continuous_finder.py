"""Continuous discovery, strict matching, bounded memory, and restart regressions."""

import contextlib
import io
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import api_access
import username_checker as app


def result(site, name, status="Not found"):
    return app.Result(name, site.name, status, site.url_for(name),
                      app.NOT_FOUND_DETAIL if status == "Not found" else "Account lookup result.",
                      "2026-10-16T04:00:00+00:00")


class ContinuousFinderTests(unittest.TestCase):
    def job(self, names, rule="any", *, chunk_size=2, keys=("github", "gitlab"), access=None):
        job = app.LargeBatchJob(iter(names), len(names), [app.SITE_BY_KEY[key] for key in keys],
                                match_rule=rule, chunk_size=chunk_size, access=access,
                                source_spec={"kind": "names", "names": names})
        self.addCleanup(job.close)
        return job

    def finish(self, job, check=None):
        check = check or (lambda site, name, timeout, **options: result(site, name))
        with patch.object(app, "check_one", side_effect=check):
            self.assertTrue(job.start())
            self.assertTrue(job.done.wait(4))
            self.assertTrue(job.workers_done.wait(2))
        self.assertEqual(job.error, "")

    def test_any_rule_collects_only_real_not_found_results(self):
        names = ["first", "second", "third", "fourth"]
        statuses = {("first", "github"): "Not found", ("second", "gitlab"): "Not found",
                    ("second", "github"): "Unknown", ("fourth", "github"): "Invalid"}
        job = self.job(names)
        self.finish(job, lambda site, name, timeout, **options: result(site, name, statuses.get((name, site.key), "Taken")))
        self.assertEqual([(r.username, r.site) for r in job.matches.read()], [("first", "GitHub"), ("second", "GitLab")])
        self.assertEqual(job.match_snapshot()[:3], (2, 4, 2))
        self.assertEqual(len(list(job.journal.read())), 8)

    def test_all_rule_requires_every_selected_platform_to_report_not_found(self):
        names = ["first", "second", "third", "fourth"]
        def check(site, name, timeout, **options):
            status = "Not found" if name == "first" or site.key == "github" else {
                "second": "Taken", "third": "Unknown", "fourth": "Invalid"}[name]
            return result(site, name, status)
        job = self.job(names, "all")
        self.finish(job, check)
        self.assertEqual(job.match_snapshot()[:3], (1, 4, 2))
        self.assertEqual([(r.username, r.site) for r in job.matches.read()], [("first", "GitHub"), ("first", "GitLab")])

    def test_multiple_small_chunks_do_not_cap_or_repeat_the_search(self):
        names = [f"name{i}" for i in range(25)]
        job = self.job(names, chunk_size=1)
        self.finish(job)
        self.assertEqual(job.completed, 50)
        self.assertEqual(job.found_count, 25)
        self.assertEqual(list(app.unique_chunk_names(job.matches.read_chunks())), names)
        self.assertLessEqual(len(job.match_results), 1)

    def test_found_preview_is_bounded_but_all_matches_remain_exportable(self):
        names = [f"name{i}" for i in range(801)]
        job = self.job(names, "all", chunk_size=50)
        self.finish(job)
        found, checked, rows, preview = job.match_snapshot()
        self.assertEqual((found, checked, rows), (801, 801, 1602))
        self.assertEqual(len(preview), app.RESULT_PREVIEW_SIZE)
        self.assertEqual(list(app.unique_chunk_names(job.matches.read_chunks())), names)
        self.assertLessEqual(len(job.match_results), 50)

    def test_stop_and_continue_keep_partial_all_platform_matches(self):
        job = self.job(["first", "second", "third"], "all", chunk_size=3)
        original = job._record
        def record(value):
            original(value)
            if job.completed == 1:
                job.stop()
        with patch.object(job, "_record", side_effect=record):
            self.finish(job)
        self.assertEqual(job.completed, 1)
        self.assertEqual(job.found_count, 0)
        self.finish(job)
        self.assertEqual(job.match_snapshot()[:3], (3, 3, 6))
        records = list(job.matches.read())
        self.assertEqual(len({(r.username, r.site) for r in records}), 6)

    def test_a_live_match_snapshot_does_not_change_when_searching_continues(self):
        names = [f"name{i}" for i in range(10)]
        job = self.job(names, keys=("github",))
        original = job._record
        def record(value):
            original(value)
            if job.completed == 3:
                job.stop()
        with patch.object(job, "_record", side_effect=record):
            self.finish(job)
        prefix = job.matches.read()
        self.finish(job)
        self.assertEqual([r.username for r in prefix], names[:3])
        self.assertEqual([r.username for r in job.matches.read()], names)

    def test_huge_exact_length_space_stays_lazy_and_stops_promptly(self):
        search = app.CharacterSearch("custom", characters="ab", length=100)
        job = app.LargeBatchJob(search.iter_take(0), search.total, [app.SITE_BY_KEY["github"]], match_rule="any", chunk_size=3)
        self.addCleanup(job.close)
        original = job._record
        def record(value):
            original(value)
            if job.completed == 20:
                job.stop()
        with patch.object(job, "_record", side_effect=record):
            self.finish(job)
        self.assertEqual(job.completed, 20)
        self.assertLessEqual(search.position, 21)
        self.assertLessEqual(len(job.match_results), 3)
        found = list(job.matches.read())
        self.assertTrue(all(len(r.username) == 100 for r in found))
        self.assertEqual(len({r.username for r in found}), 20)

    def test_checkpoint_rebuilds_found_names_and_incomplete_all_platform_matches(self):
        names = [f"name{i}" for i in range(6)]
        job = self.job(names, "all", chunk_size=2)
        original = job._record
        def record(value):
            original(value)
            if job.completed == 5:
                job.stop()
        with patch.object(job, "_record", side_effect=record):
            self.finish(job)
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "finder.ucsession"
            job.save_checkpoint(path)
            with patch.object(app, "request_api") as request:
                restored, _ = app.load_checkpoint(path)
            self.addCleanup(restored.close)
            request.assert_not_called()
            self.assertEqual((restored.match_rule, restored.chunk_size), ("all", 2))
            self.assertEqual(restored.match_snapshot()[:3], job.match_snapshot()[:3])
            self.finish(restored)
        self.assertEqual(restored.match_snapshot()[:3], (6, 6, 12))
        self.assertEqual(list(app.unique_chunk_names(restored.matches.read_chunks())), names)
        self.assertEqual(len(list(restored.journal.read())), 12)

    def test_bad_finder_metadata_is_rejected_without_requests(self):
        job = self.job(["first", "second"], "all")
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "finder.ucsession"
            job.save_checkpoint(path)
            with sqlite3.connect(path) as connection:
                original = json.loads(connection.execute("SELECT state FROM metadata WHERE id=1").fetchone()[0])
            for value in ({}, None, [], {"match_rule": "other", "chunk_size": 2},
                          {"match_rule": "all", "chunk_size": 0}, {"match_rule": "all", "chunk_size": True}):
                state = dict(original, finder=value)
                with sqlite3.connect(path) as connection:
                    connection.execute("UPDATE metadata SET state=? WHERE id=1", (json.dumps(state),))
                with patch.object(app, "request_api") as request, self.assertRaises(ValueError):
                    app.load_checkpoint(path)
                request.assert_not_called()

    def test_continuous_search_recovers_after_bounded_rate_retries(self):
        moment = [1000.0]
        access = app.ApiAccess(clock=lambda: moment[0])
        job = self.job(["first", "second"], keys=("github",), access=access)
        requests = []
        def lookup(request, timeout):
            requests.append(request.full_url)
            return (app.APIResponse(429, {}, {"retry-after": "0"}) if len(requests) <= 2 else
                    app.APIResponse(404, {"message": "Not Found"}, {}))
        def wait(seconds):
            moment[0] += seconds
            return False
        original = job._run
        def run():
            with patch.object(job.cancel, "wait", side_effect=wait):
                original()
        with patch.object(api_access, "DEFAULT_BACKOFF", 1), patch.object(app, "MAX_RATE_RETRIES", 1), \
                patch.object(app, "request_api", side_effect=lookup), patch.object(job, "_run", side_effect=run):
            job.start()
            self.assertTrue(job.done.wait(3))
        self.assertEqual(job.match_snapshot()[:3], (2, 2, 2))
        self.assertEqual(len(requests), 4)
        self.assertGreaterEqual(moment[0], 1002)
        self.assertEqual(job.reason, "")

    def test_persistent_throttling_still_allows_stop_without_losing_names(self):
        access = app.ApiAccess()
        job = self.job(["first", "second"], keys=("github",), access=access)
        access.on_cooldown = lambda key, seconds: job.stop() if seconds > 0 else None
        with patch.object(app, "request_api", return_value=app.APIResponse(429, {}, {"retry-after": "0"})):
            job.start()
            self.assertTrue(job.done.wait(3))
            self.assertTrue(job.workers_done.wait(2))
        self.assertEqual(job.completed, 0)
        self.assertEqual(len(job.pending_pairs), 2)
        self.assertGreater(access.remaining()["github"], 0)

    def test_invalid_modes_and_chunks_fail_before_starting(self):
        for options in ({"match_rule": "other"}, {"match_rule": "all", "generate_only": True},
                        {"match_rule": "any", "chunk_size": 0}, {"match_rule": "any", "chunk_size": 501}):
            with self.assertRaises(ValueError):
                app.LargeBatchJob(iter(["first"]), 1, [app.SITE_BY_KEY["github"]], **options)
        with self.assertRaises(ValueError):
            app.LargeBatchJob(iter(["first"]), 1, [app.SITE_BY_KEY["instagram"]], match_rule="any")

    def test_finder_cleanup_removes_both_journals(self):
        job = self.job(["first"])
        paths = [job.journal.path.parent, job.matches.path.parent]
        self.finish(job)
        job.close()
        self.assertTrue(all(not path.exists() for path in paths))


class ContinuousFinderCliTests(unittest.TestCase):
    def test_reopened_finder_session_keeps_its_match_rule_and_exports_saved_finds(self):
        names = ["aaa", "aab", "aba"]
        job = app.LargeBatchJob(iter(names), 3, app.select_sites("github,gitlab"), match_rule="all", chunk_size=2,
                                source_spec={"kind": "names", "names": names})
        self.addCleanup(job.close)
        original = job._record
        def record(value):
            original(value)
            if job.completed == 3:
                job.stop()
        with patch.object(app, "check_one", side_effect=lambda site, name, timeout, **options: result(site, name)), \
                patch.object(job, "_record", side_effect=record):
            job.start()
            self.assertTrue(job.done.wait(3))
            self.assertTrue(job.workers_done.wait(2))
        with tempfile.TemporaryDirectory() as folder:
            session, output = Path(folder) / "finder.ucsession", Path(folder) / "found.txt"
            job.save_checkpoint(session)
            stdout = io.StringIO()
            with patch.object(app, "check_one", side_effect=lambda site, name, timeout, **options: result(site, name)), \
                    contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(io.StringIO()):
                code = app.main(["--resume", str(session), "--json", "--names-only", "--output", str(output)])
            self.assertEqual(output.read_text().splitlines(), names)
        self.assertEqual(code, 0)
        self.assertEqual(json.loads(stdout.getvalue()), names)

    def test_find_ignores_the_total_batch_cap_and_exports_only_matches(self):
        stdout, stderr, requests = io.StringIO(), io.StringIO(), []
        def lookup(request, timeout):
            name = request.full_url.rsplit("/", 1)[-1]
            requests.append(name)
            return (app.APIResponse(404, {"message": "Not Found"}, {}) if name.endswith("a") else
                    app.APIResponse(200, {"login": name, "id": 1}, {}))
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "found.txt"
            with patch.object(app, "request_api", side_effect=lookup), contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                code = app.main(["--find", "--length", "3", "--charset", "custom", "--characters", "ab",
                                 "--sites", "github,instagram", "--batch-limit", "2", "--json", "--output", str(path)])
            names = path.read_text().splitlines()
        self.assertEqual(code, 0)
        self.assertEqual(len(requests), 8)
        self.assertEqual(len(set(requests)), 8)
        self.assertEqual(names, ["aaa", "aba", "baa", "bba"])
        self.assertEqual([r["username"] for r in json.loads(stdout.getvalue())], names)

    def test_invalid_continuous_cli_options_never_send_requests(self):
        cases = [["--find", "--count", "20"], ["--find", "--generate-only"], ["--find", "--sites", "instagram"],
                 ["--find", "--length", "254"], ["--generate", "--match", "all"], ["--find", "--status", "taken"]]
        with patch.object(app, "request_api") as request:
            for arguments in cases:
                with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as error:
                    app.main(arguments)
                self.assertEqual(error.exception.code, 2)
        request.assert_not_called()


if __name__ == "__main__":
    unittest.main()
