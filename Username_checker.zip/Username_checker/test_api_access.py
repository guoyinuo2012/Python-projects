"""Offline tests for credentials, cooldown scheduling, and resumable retries."""

import contextlib
import io
import json
import os
import tempfile
import threading
import unittest
import urllib.request
from datetime import datetime, timezone
from email.utils import format_datetime
from pathlib import Path
from unittest.mock import patch

import api_access as api
import username_checker as app


def response(status, data=None, headers=None):
    return app.APIResponse(status, {} if data is None else data, headers or {})


class Clock:
    def __init__(self):
        self.now = 1000.0

    def monotonic(self):
        return self.now

    def wall(self):
        return 1700000000.0 + self.now - 1000.0

    def advance(self, seconds):
        self.now += seconds
        return False

    def access(self, **options):
        return api.ApiAccess(clock=self.monotonic, wall_clock=self.wall, **options)


class TokenTests(unittest.TestCase):
    def test_environment_tokens_and_explicit_app_overrides(self):
        values = {"GITHUB_TOKEN": "github-test", "GITLAB_TOKEN": "gitlab-test"}
        self.assertEqual(api.environment_tokens(values), {"github": "github-test", "gitlab": "gitlab-test"})
        values["USERNAME_CHECKER_GITHUB_TOKEN"] = ""
        values["USERNAME_CHECKER_GITLAB_TOKEN"] = "override-test"
        self.assertEqual(api.environment_tokens(values), {"gitlab": "override-test"})
        self.assertEqual(api.environment_tokens({}), {})

    def test_invalid_header_values_fail_without_exposing_the_token(self):
        for token in ("secret\nInjected: value", "secret token", "secret\x00token", "ésecret", "x" * 4097):
            with self.subTest(kind=repr(token[:16])):
                with self.assertRaises(ValueError) as error:
                    api.ApiAccess({"github": token})
                self.assertNotIn(token, str(error.exception))
        for tokens in ([], {"roblox": "secret"}, {"github": None}):
            with self.assertRaises(ValueError):
                api.ApiAccess(tokens)

    def test_tokens_use_only_the_matching_official_endpoint_and_headers(self):
        access = api.ApiAccess({"github": "github-test", "gitlab": "gitlab-test"})
        for key in ("github", "gitlab", "roblox", "bluesky", "chesscom"):
            request = app.build_request(app.SITE_BY_KEY[key], "example")
            access.authorize(key, request)
            headers = {name.lower(): value for name, value in request.header_items()}
            self.assertEqual(headers.get("authorization"), "Bearer github-test" if key == "github" else None)
            self.assertEqual(headers.get("private-token"), "gitlab-test" if key == "gitlab" else None)
        for url in ("http://api.github.com/users/example", "https://other.example/users/example",
                    "https://api.github.com.other.example/users/example", "https://api.github.com:444/users/example",
                    "https://someone@api.github.com/users/example"):
            request = urllib.request.Request(url)
            with self.assertRaises(ValueError):
                access.authorize("github", request)
            self.assertNotIn("Authorization", dict(request.header_items()))

    def test_invalid_token_changes_are_atomic_and_token_snapshots_are_independent(self):
        clock = Clock()
        access = clock.access(tokens={"github": "old-test", "gitlab": "gitlab-test"})
        access.observe("github", response(429, headers={"retry-after": "30"}))
        access.observe("gitlab", response(429, headers={"retry-after": "60"}))
        snapshot = access.tokens()
        snapshot["github"] = "changed-outside"
        with self.assertRaises(ValueError):
            access.set_tokens({"github": "bad token"})
        self.assertEqual(access.tokens()["github"], "old-test")
        access.set_tokens({"github": "new-test", "gitlab": "gitlab-test"})
        self.assertEqual(access.remaining(), {"gitlab": 60})
        self.assertNotIn("new-test", repr(access))

    def test_invalid_names_and_manual_sites_never_send_tokens_or_requests(self):
        access = api.ApiAccess({"github": "github-test"})
        with patch.object(app, "request_api") as request:
            results = app.run_checks(["_invalid"], [app.SITE_BY_KEY["github"], app.SITE_BY_KEY["instagram"]], access=access)
        self.assertEqual({result.status for result in results}, {"Invalid", "Manual check"})
        request.assert_not_called()


class HeaderTests(unittest.TestCase):
    def test_retry_after_accepts_seconds_and_http_dates_with_precedence(self):
        now = 1700000000.0
        date = format_datetime(datetime.fromtimestamp(now + 90, timezone.utc), usegmt=True)
        for header, expected in (("45", 45), (".25", .25), (date, 90)):
            reply = response(429, headers={"Retry-After": header, "X-RateLimit-Reset": str(now + 500)})
            self.assertEqual(api.cooldown_seconds(reply, now), expected)
        self.assertEqual(api.cooldown_seconds(response(429, headers={"retry-after": "0"}), now), 0)

    def test_reset_headers_and_past_dates(self):
        now = 1700000000.0
        for key in ("x-ratelimit-reset", "ratelimit-reset"):
            self.assertEqual(api.cooldown_seconds(response(403, headers={key: str(now + 60)}), now), 60)
        past = format_datetime(datetime.fromtimestamp(now - 60, timezone.utc), usegmt=True)
        self.assertEqual(api.cooldown_seconds(response(429, headers={"retry-after": past}), now), 0)
        future = format_datetime(datetime.fromtimestamp(now + 120, timezone.utc), usegmt=True)
        self.assertEqual(api.cooldown_seconds(response(429, headers={"ratelimit-resettime": future}), now), 120)

    def test_response_date_accounts_for_a_client_clock_that_is_ahead(self):
        server_now = 1700000000.0
        date = format_datetime(datetime.fromtimestamp(server_now, timezone.utc), usegmt=True)
        reply = response(403, headers={"date": date, "x-ratelimit-reset": str(server_now + 60)})
        self.assertEqual(api.cooldown_seconds(reply, server_now + 3600), 60)

    def test_malformed_headers_are_ignored_and_fallback_increases(self):
        for value in ("bad", "nan", "inf", "-1", "1e9999", ""):
            reply = response(429, headers={"retry-after": value, "x-ratelimit-reset": value})
            self.assertIsNone(api.cooldown_seconds(reply, 1700000000.0))
        clock, notices = Clock(), []
        access = clock.access(on_cooldown=lambda key, seconds: notices.append(seconds))
        for expected in (60, 120, 240):
            access.observe("github", response(429))
            self.assertEqual(access.remaining(), {"github": expected})
            clock.advance(expected)
        access.observe("github", response(200))
        access.observe("github", response(429))
        self.assertEqual(notices, [60, 120, 240, 60])

    def test_primary_secondary_and_ordinary_access_errors_are_distinguished(self):
        for reply in (response(429), response(403, headers={"x-ratelimit-remaining": "0"}),
                      response(403, {"message": "You have exceeded a secondary rate limit."}),
                      response(403, {"message": "API rate limit exceeded for this address."})):
            self.assertTrue(api.is_rate_limited(reply))
        for reply in (response(401), response(403, {"message": "Forbidden"}), response(500)):
            self.assertFalse(api.is_rate_limited(reply))

    def test_last_successful_request_can_schedule_the_next_cooldown(self):
        clock = Clock()
        access = clock.access()
        access.observe("github", response(200, headers={"x-ratelimit-remaining": "0", "x-ratelimit-reset": str(clock.wall() + 12)}))
        self.assertEqual(access.remaining(), {"github": 12})
        clock.advance(12)
        self.assertEqual(access.remaining(), {})


class SchedulingTests(unittest.TestCase):
    def test_throttled_name_is_retried_without_publishing_or_caching_a_failure(self):
        clock, notices = Clock(), []
        access = clock.access(on_cooldown=lambda key, seconds: notices.append((key, seconds)))
        cancel, stats, cache = threading.Event(), app.CheckStats(), app.ResultCache()
        replies = [response(429, headers={"retry-after": "1"}), response(404, {"message": "Not Found"}),
                   response(404, {"message": "Not Found"})]
        with patch.object(cancel, "wait", side_effect=clock.advance), patch.object(app, "request_api", side_effect=replies) as request:
            results = app.run_checks(["first", "second"], [app.SITE_BY_KEY["github"]], access=access, cancel=cancel, cache=cache, stats=stats)
        self.assertEqual([r.username for r in results], ["first", "second"])
        self.assertTrue(all(r.status == "Not found" for r in results))
        self.assertEqual([call.args[0].full_url.rsplit("/", 1)[-1] for call in request.call_args_list], ["first", "first", "second"])
        self.assertEqual(stats.snapshot()["requests"], 3)
        self.assertEqual(len(cache.entries), 2)
        self.assertEqual(notices, [("github", 1)])

    def test_secondary_limit_can_retry_to_an_authenticated_success(self):
        access = api.ApiAccess({"github": "github-test"})
        replies = [response(403, {"message": "You have exceeded a secondary rate limit."}, {"retry-after": "0"}),
                   response(200, {"login": "example", "id": 5})]
        with patch.object(app, "request_api", side_effect=replies) as request:
            results = app.run_checks(["example"], [app.SITE_BY_KEY["github"]], access=access)
        self.assertEqual([r.status for r in results], ["Taken"])
        self.assertTrue(all(call.args[0].get_header("Authorization") == "Bearer github-test" for call in request.call_args_list))

    def test_bulk_retry_keeps_the_same_names_and_does_not_repeat_completed_chunks(self):
        payloads = []
        def lookup(request, timeout):
            payloads.append(json.loads(request.data)["usernames"])
            return response(429, headers={"retry-after": "0"}) if len(payloads) == 1 else response(200, {"data": []})
        names = [f"name{i}" for i in range(250)]
        with patch.object(app, "request_api", side_effect=lookup):
            results = app.run_checks(names, [app.SITE_BY_KEY["roblox"]])
        self.assertEqual([len(names) for names in payloads], [100, 100, 100, 50])
        self.assertEqual(payloads[0], payloads[1])
        self.assertEqual([r.username for r in results], names)

    def test_cooldown_is_retained_between_large_batch_chunks(self):
        clock, moments = Clock(), []
        access = clock.access()
        names = [f"name{i}" for i in range(4)]
        job = app.LargeBatchJob(iter(names), len(names), [app.SITE_BY_KEY["github"]], access=access)
        self.addCleanup(job.close)
        def lookup(request, timeout):
            moments.append(clock.now)
            headers = {"x-ratelimit-remaining": "0", "x-ratelimit-reset": str(clock.wall() + 2)} if len(moments) == 2 else {}
            return response(404, {"message": "Not Found"}, headers)
        original = job._run
        def run():
            with patch.object(job.cancel, "wait", side_effect=clock.advance):
                original()
        with patch.object(app, "CHECK_CHUNK_SIZE", 2), patch.object(job, "_run", side_effect=run), patch.object(app, "request_api", side_effect=lookup):
            job.start()
            self.assertTrue(job.done.wait(3))
        self.assertEqual(moments, [1000, 1000, 1002, 1002])
        self.assertEqual(job.completed, 4)

    def test_other_platforms_finish_while_a_limited_platform_waits(self):
        cancel, limited = threading.Event(), threading.Event()
        access = api.ApiAccess(on_cooldown=lambda key, seconds: limited.set())
        def lookup(request, timeout):
            if request.host == "api.github.com":
                return response(429, headers={"retry-after": "60"})
            self.assertTrue(limited.wait(2))
            return response(200, [{"username": "example", "id": 2}])
        def record(result):
            if result.site == "GitLab":
                cancel.set()
        with patch.object(app, "request_api", side_effect=lookup):
            results = app.run_checks(["example"], [app.SITE_BY_KEY["github"], app.SITE_BY_KEY["gitlab"]],
                                     access=access, cancel=cancel, on_result=record)
        self.assertEqual([(r.site, r.status) for r in results], [("GitLab", "Taken")])
        self.assertIn("github", access.remaining())

    def test_stop_during_a_cooldown_preserves_names_for_continue(self):
        clock, limited = Clock(), threading.Event()
        access = clock.access(on_cooldown=lambda key, seconds: limited.set())
        job = app.LargeBatchJob(iter(["first", "second"]), 2, [app.SITE_BY_KEY["github"]], access=access)
        self.addCleanup(job.close)
        with patch.object(app, "request_api", return_value=response(429, headers={"retry-after": "60"})):
            job.start()
            self.assertTrue(limited.wait(2))
            job.stop()
            self.assertTrue(job.done.wait(2))
            self.assertTrue(job.workers_done.wait(2))
        self.assertEqual(job.completed, 0)
        self.assertEqual(len(job.pending_pairs), 2)
        clock.advance(60)
        with patch.object(app, "request_api", return_value=response(404, {"message": "Not Found"})) as request:
            self.assertTrue(job.start())
            self.assertTrue(job.done.wait(3))
        self.assertEqual(request.call_count, 2)
        self.assertEqual([r.username for r in job.journal.read()], ["first", "second"])

    def test_exhausted_checkpoint_preserves_every_name_without_storing_credentials(self):
        secret = "github-test-private-token"
        names = ["first", "second", "third"]
        job = app.LargeBatchJob(iter(names), 3, [app.SITE_BY_KEY["github"]],
                                source_spec={"kind": "names", "names": names}, access=api.ApiAccess({"github": secret}))
        self.addCleanup(job.close)
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "resume.ucsession"
            with patch.object(app, "request_api", return_value=response(429, headers={"retry-after": "0"})) as request:
                job.start()
                self.assertTrue(job.done.wait(3))
            self.assertEqual(request.call_count, api.MAX_RATE_RETRIES + 1)
            self.assertEqual(job.completed, 0)
            job.save_checkpoint(path)
            self.assertNotIn(secret.encode(), path.read_bytes())
            restored, _ = app.load_checkpoint(path)
            self.addCleanup(restored.close)
            self.assertEqual(restored.access.tokens(), {})
            with patch.object(app, "request_api", return_value=response(404, {"message": "Not Found"})) as request:
                restored.start()
                self.assertTrue(restored.done.wait(3))
            self.assertEqual(request.call_count, 3)
            self.assertEqual([r.username for r in restored.journal.read()], names)

    def test_cli_uses_environment_tokens_and_keeps_cooldowns_out_of_json(self):
        stdout, stderr = io.StringIO(), io.StringIO()
        replies = [response(429, headers={"retry-after": "0"}), response(404, {"message": "Not Found"})]
        with patch.dict(os.environ, {"GITHUB_TOKEN": "github-test-private-token", "USERNAME_CHECKER_GITHUB_TOKEN": "github-test-private-token"}), \
                patch.object(app, "request_api", side_effect=replies) as request, \
                contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            code = app.main(["example", "--sites", "github", "--json"])
        self.assertEqual(code, 0)
        self.assertEqual([r["status"] for r in json.loads(stdout.getvalue())], ["Not found"])
        self.assertIn("cooldown", stderr.getvalue())
        self.assertNotIn("github-test-private-token", stdout.getvalue() + stderr.getvalue())
        self.assertEqual(request.call_args.args[0].get_header("Authorization"), "Bearer github-test-private-token")

    def test_cli_exhaustion_reports_incomplete_work_as_a_failure(self):
        stdout, stderr = io.StringIO(), io.StringIO()
        with patch.object(app, "request_api", return_value=response(429, headers={"retry-after": "0"})), \
                contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            code = app.main(["first", "second", "--sites", "github", "--json"])
        self.assertEqual(code, 1)
        self.assertEqual(json.loads(stdout.getvalue()), [])
        self.assertIn("retries exhausted", stderr.getvalue())


if __name__ == "__main__":
    unittest.main()
