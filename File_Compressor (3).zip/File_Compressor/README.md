# File Compressor

## Start on Windows

1. Extract the ZIP.
2. Open the File_Compressor folder.
3. Double-click file_compressor.py.
4. Choose an input and a new output filename, then click Compress or Decompress.

Python 3.10+ with Tkinter must be installed, and .py files associated with Python.

file_compressor.py contains the desktop GUI, CLI, and automated tests.
This README is kept separately in the same folder.
Requires Python 3.10+ and uses only the standard library.

OPEN THE GUI
    Windows: double-click file_compressor.py to open the window directly.
    No terminal commands are required for normal use. Windows may show a console
window alongside the GUI; keep it open while using the application.
    python file_compressor.py
    python file_compressor.py --gui
Install Python 3.10+ with Tcl/Tk and Python file associations enabled.
If Windows asks which app to use, choose Python (python.exe) and set it
as the default for .py files. Startup errors appear in a Windows message box.
This is Python source, not a standalone executable; Python must be installed.
The python.org Windows installer includes Tkinter when Tcl/Tk is selected.
On Debian/Ubuntu, the GUI may need the system package python3-tk.
The CLI and tests do not require Tkinter or a graphical display.

CLI
    python file_compressor.py -i example.txt -o example.txt.gz
    python file_compressor.py -d -i example.txt.gz -o restored.txt
    python file_compressor.py --help

TESTS
    python file_compressor.py --self-test

HOW IT WORKS
Buffered files and shutil.copyfileobj stream data in 128 KiB chunks.
The gzip module supplies compression, checksum validation, and multi-member
Gzip decoding. The GUI uses Tkinter/ttk, a worker thread, and a result queue;
all GUI updates happen on the main thread. Metrics include elapsed time,
input/output bytes, and compressed size / uncompressed size as a percentage.
An empty original has no meaningful ratio; incompressible data can grow.

VALIDATION
Eight embedded tests and separate CLI round-trip / exit-code checks passed
on Linux. Native GUI window/dialog interaction and Windows execution have
not been tested in this environment.

FILE SAFETY AND LIMITS
The input is never modified. Existing output files, including symlinks, are
refused. Output is staged beside the destination and fsynced before a hard
link publishes the completed file without overwriting. The filesystem must
support hard links (e.g. NTFS, ext4, APFS); FAT/exFAT are not supported for
output. The program reports an error rather than using an unsafe fallback.
Normal failures remove staged output. Abrupt termination or cleanup failures
can leave a .file-compressor-*.tmp file. Directory entries are not fsynced,
so this is not a full power-loss durability guarantee. Keep the input stable
while processing. Parent directories must already exist. Single files only;
no archives, encryption, metadata preservation, or decompression size cap.
The GUI shows an activity indicator, not an estimated percentage. Window
closing is blocked during processing; there is no cancellation control.