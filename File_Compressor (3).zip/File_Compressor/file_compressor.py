#!/usr/bin/env python3
"""File Compressor desktop GUI and CLI. See README.md for instructions."""
from __future__ import annotations

import argparse
from contextlib import suppress
from dataclasses import dataclass
import gzip
import os
from pathlib import Path
import queue
import shutil
import stat
import sys
import tempfile
import threading
import time
import zlib

BUFFER_SIZE = 128 * 1024
PROCESS_ERRORS = (OSError, EOFError, zlib.error)


@dataclass(frozen=True)
class Stats:
    input_size: int
    output_size: int
    elapsed: float
    decompress: bool

    def report(self) -> str:
        original, compressed = (
            (self.output_size, self.input_size) if self.decompress
            else (self.input_size, self.output_size)
        )
        lines = [
            f"Elapsed: {self.elapsed * 1000:.3f} ms",
            f"Input file size: {self.input_size:,} bytes",
            f"Final file size: {self.output_size:,} bytes",
            f"Original (uncompressed): {original:,} bytes",
        ]
        if original:
            ratio = compressed / original * 100
            lines.extend([f"Compression ratio (gzip/original): {ratio:.2f}%",
                          f"Space saved: {100 - ratio:.2f}%"])
        else:
            lines.append("Compression ratio: N/A (empty original)")
        return "\n".join(lines)


def process_file(input_path: Path, output_path: Path, decompress: bool = False) -> Stats:
    """Stream one file and publish completed output without overwriting."""
    started = time.perf_counter()
    input_path, output_path = Path(input_path), Path(output_path)
    if os.path.lexists(output_path):
        raise FileExistsError("Output already exists; choose a new filename.")
    if not stat.S_ISREG(input_path.stat().st_mode):
        raise OSError("Input must be a regular file.")
    temporary_path = None
    try:
        with input_path.open("rb", buffering=BUFFER_SIZE) as source:
            original_size = os.fstat(source.fileno()).st_size
            if decompress:
                # gzip accepts an empty input; our CLI requires a real Gzip file.
                if source.read(2) != b"\x1f\x8b":
                    raise gzip.BadGzipFile("Input is not a Gzip file.")
                source.seek(0)
            with tempfile.NamedTemporaryFile(
                mode="w+b", buffering=BUFFER_SIZE, delete=False,
                dir=output_path.parent, prefix=".file-compressor-", suffix=".tmp",
            ) as destination:
                temporary_path = Path(destination.name)
                if decompress:
                    with gzip.GzipFile(fileobj=source, mode="rb") as decoder:
                        shutil.copyfileobj(decoder, destination, length=BUFFER_SIZE)
                else:
                    # Explicit name and mtime avoid leaking the temporary filename.
                    with gzip.GzipFile(filename="", fileobj=destination,
                                       mode="wb", compresslevel=6, mtime=0) as encoder:
                        shutil.copyfileobj(source, encoder, length=BUFFER_SIZE)
                destination.flush()
                os.fsync(destination.fileno())
                final_size = os.fstat(destination.fileno()).st_size
        # A competing process creating the output also causes FileExistsError.
        # Never use os.replace here: it would overwrite an existing destination.
        os.link(temporary_path, output_path)
        return Stats(original_size, final_size, time.perf_counter() - started, decompress)
    finally:
        if temporary_path is not None:
            # Cleanup errors should not mask processing errors or successful output.
            with suppress(OSError):
                temporary_path.unlink()


def compress_file(input_path: Path, output_path: Path) -> Stats:
    return process_file(input_path, output_path)


def decompress_file(input_path: Path, output_path: Path) -> Stats:
    return process_file(input_path, output_path, decompress=True)


class CompressorApp:
    """A native desktop UI; only its worker touches compression logic."""

    def __init__(self, root):
        import tkinter as tk
        from tkinter import ttk

        self.root = root
        self.ttk = ttk
        self.busy = False
        self.results = queue.Queue()
        self.mode = tk.StringVar(value="compress")
        self.input_path = tk.StringVar()
        self.output_path = tk.StringVar()
        self.status = tk.StringVar(value="Choose a file to get started.")
        self.report = tk.StringVar()
        self.controls = []
        root.title("File Compressor")
        root.geometry("680x610")
        root.minsize(540, 580)
        root.protocol("WM_DELETE_WINDOW", self.close)
        style = ttk.Style(root)
        if "vista" in style.theme_names():
            style.theme_use("vista")
        style.configure("Title.TLabel", font=("Segoe UI", 19, "bold"))
        style.configure("Heading.TLabel", font=("Segoe UI", 10, "bold"))
        style.configure("TButton", padding=(12, 6))
        panel = ttk.Frame(root, padding=24)
        panel.pack(fill="both", expand=True)
        panel.columnconfigure(0, weight=1)
        ttk.Label(panel, text="File Compressor", style="Title.TLabel").grid(
            row=0, column=0, columnspan=2, sticky="w")
        ttk.Label(panel, text="Compress and restore local files with Gzip.").grid(
            row=1, column=0, columnspan=2, sticky="w", pady=(6, 22))
        modes = ttk.Frame(panel)
        modes.grid(row=2, column=0, columnspan=2, sticky="w", pady=(0, 20))
        for label, value in [("Compress", "compress"), ("Decompress", "decompress")]:
            button = ttk.Radiobutton(modes, text=label, value=value,
                                     variable=self.mode, command=self.mode_changed)
            button.pack(side="left", padx=(0, 22))
            self.controls.append(button)
        for row, title, variable, callback in [
            (3, "Input file", self.input_path, self.choose_input),
            (6, "Output file", self.output_path, self.choose_output),
        ]:
            ttk.Label(panel, text=title, style="Heading.TLabel").grid(
                row=row, column=0, sticky="w", pady=(0, 7))
            field = ttk.Entry(panel, textvariable=variable, state="readonly")
            field.grid(row=row + 1, column=0, sticky="ew", padx=(0, 10))
            button = ttk.Button(panel, text="Browse…", command=callback)
            button.grid(row=row + 1, column=1)
            self.controls.append(button)
            ttk.Frame(panel, height=16).grid(row=row + 2, column=0)
        ttk.Label(panel, text="Existing files are never overwritten.").grid(
            row=9, column=0, columnspan=2, sticky="w", pady=(0, 15))
        self.start_button = ttk.Button(panel, text="Compress file", command=self.start)
        self.start_button.grid(row=10, column=0, columnspan=2, sticky="w")
        self.controls.append(self.start_button)
        self.progress = ttk.Progressbar(panel, mode="indeterminate")
        self.progress.grid(row=11, column=0, columnspan=2, sticky="ew", pady=(18, 10))
        self.status_label = ttk.Label(panel, textvariable=self.status, wraplength=580)
        self.status_label.grid(row=12, column=0, columnspan=2, sticky="w")
        ttk.Separator(panel).grid(row=13, column=0, columnspan=2, sticky="ew", pady=15)
        ttk.Label(panel, textvariable=self.report, justify="left").grid(
            row=14, column=0, columnspan=2, sticky="nw")
        root.bind("<Control-o>", lambda _event: self.choose_input())
        root.bind("<Control-s>", lambda _event: self.choose_output())
        root.bind("<Return>", lambda _event: self.start())
        root.after(100, self.poll)

    def mode_changed(self):
        self.output_path.set("")
        self.report.set("")
        self.start_button.configure(
            text="Decompress file" if self.mode.get() == "decompress" else "Compress file")
        self.status.set("Choose an output filename for this mode.")

    def choose_input(self):
        from tkinter import filedialog
        if self.busy:
            return
        path = filedialog.askopenfilename(parent=self.root, title="Choose input file")
        if path:
            self.input_path.set(path)
            self.output_path.set("")
            self.report.set("")
            self.status.set("Choose an output filename.")

    def choose_output(self):
        from tkinter import filedialog
        if self.busy:
            return
        source = Path(self.input_path.get()) if self.input_path.get() else None
        name = "output.gz"
        if source:
            name = (source.stem if source.suffix.lower() == ".gz" else source.name + ".decoded") \
                if self.mode.get() == "decompress" else source.name + ".gz"
        path = filedialog.asksaveasfilename(
            parent=self.root, title="Choose a NEW output file",
            initialdir=str(source.parent) if source else None,
            initialfile=name, confirmoverwrite=False)
        if path:
            self.output_path.set(path)
            self.report.set("")
            self.status.set("Ready.")

    def start(self):
        if self.busy:
            return
        if not self.input_path.get() or not self.output_path.get():
            self.status.set("Choose both an input file and an output filename.")
            return
        source, destination = Path(self.input_path.get()), Path(self.output_path.get())
        decompress = self.mode.get() == "decompress"
        self.report.set("")
        self.busy = True
        self.status.set("Processing… Please keep this window open.")
        for control in self.controls:
            control.state(["disabled"])
        self.progress.start(12)
        worker = threading.Thread(target=self.work, args=(source, destination, decompress),
                                  name="file-compressor", daemon=False)
        try:
            worker.start()
        except RuntimeError as error:
            self.results.put((False, str(error)))

    def work(self, source, destination, decompress):
        # Never call Tkinter from this worker.
        try:
            self.results.put((True, process_file(source, destination, decompress)))
        except Exception as error:
            # Keep unexpected worker failures visible instead of leaving a stuck UI.
            self.results.put((False, str(error) or type(error).__name__))

    def poll(self):
        try:
            success, result = self.results.get_nowait()
        except queue.Empty:
            pass
        else:
            self.busy = False
            self.progress.stop()
            for control in self.controls:
                control.state(["!disabled"])
            self.status.set("Completed." if success else f"Error: {result}")
            self.report.set(result.report() if success else "")
        self.root.after(100, self.poll)

    def close(self):
        if self.busy:
            self.status.set("Please wait for processing to finish before closing.")
        else:
            self.root.destroy()


def show_startup_error(message: str) -> None:
    """Make failures visible even when pythonw has no stderr console."""
    if os.name == "nt":
        import ctypes
        with suppress(OSError, AttributeError):
            ctypes.windll.user32.MessageBoxW(None, message, "File Compressor", 0x10)
            return
    if sys.stderr is not None:
        print(message, file=sys.stderr)


def launch_gui() -> int:
    root = None
    try:
        import tkinter as tk
        root = tk.Tk()
        # Unexpected UI callback errors must also be visible without a console.
        root.report_callback_exception = lambda kind, error, _trace: show_startup_error(
            f"{kind.__name__}: {error}")
        CompressorApp(root)
        root.mainloop()
        return 0
    except ImportError:
        show_startup_error("GUI unavailable. Install Python with Tkinter/Tcl-Tk support.")
        return 1
    except Exception as error:
        show_startup_error(f"Could not open File Compressor:\n{type(error).__name__}: {error}")
        return 1
    finally:
        if root is not None:
            with suppress(Exception):
                root.destroy()


def self_test() -> int:
    """Run embedded tests without requiring a desktop or extra packages."""
    import unittest
    from unittest.mock import patch

    class FileTests(unittest.TestCase):
        def setUp(self):
            self.directory = tempfile.TemporaryDirectory()
            self.addCleanup(self.directory.cleanup)
            self.root = Path(self.directory.name)
            self.source = self.root / "source.bin"
            self.packed = self.root / "packed.gz"
            self.output = self.root / "output.bin"

        def test_binary_and_empty_round_trips(self):
            for data in [b"", bytes(range(256)) * 4096]:
                with self.subTest(size=len(data)):
                    self.source.write_bytes(data)
                    compress_file(self.source, self.packed)
                    self.assertEqual(gzip.decompress(self.packed.read_bytes()), data)
                    metrics = decompress_file(self.packed, self.output)
                    self.assertEqual(self.output.read_bytes(), data)
                    self.assertEqual(metrics.output_size, len(data))
                    self.assertEqual(self.source.read_bytes(), data)
                    self.packed.unlink()
                    self.output.unlink()

        def test_existing_output_and_same_path(self):
            self.source.write_bytes(b"keep source")
            self.packed.write_bytes(b"keep output")
            with self.assertRaises(FileExistsError):
                compress_file(self.source, self.packed)
            with self.assertRaises(FileExistsError):
                compress_file(self.source, self.source)
            self.assertEqual(self.packed.read_bytes(), b"keep output")
            self.assertEqual(self.source.read_bytes(), b"keep source")

        def test_bad_truncated_and_corrupt_input(self):
            valid = gzip.compress(b"payload")
            corrupt = bytearray(valid)
            corrupt[-8] ^= 1
            for data in [b"", b"not gzip", valid[:-1], corrupt]:
                with self.subTest(data=data):
                    self.packed.write_bytes(data)
                    with self.assertRaises(PROCESS_ERRORS):
                        decompress_file(self.packed, self.output)
                    self.assertFalse(self.output.exists())
                    self.assertFalse(list(self.root.glob(".file-compressor-*.tmp")))

        def test_concatenated_members(self):
            self.packed.write_bytes(gzip.compress(b"hello") + gzip.compress(b"world"))
            decompress_file(self.packed, self.output)
            self.assertEqual(self.output.read_bytes(), b"helloworld")

        def test_missing_input(self):
            with self.assertRaises(FileNotFoundError):
                compress_file(self.source, self.output)
            self.assertFalse(self.output.exists())

        def test_publication_race_preserves_competing_file(self):
            self.source.write_bytes(b"payload")
            link = os.link
            def race(source, destination):
                Path(destination).write_bytes(b"competitor")
                return link(source, destination)
            with patch.object(os, "link", side_effect=race):
                with self.assertRaises(FileExistsError):
                    compress_file(self.source, self.output)
            self.assertEqual(self.output.read_bytes(), b"competitor")
            self.assertFalse(list(self.root.glob(".file-compressor-*.tmp")))

        def test_gui_worker_reports_success_and_failure(self):
            app = CompressorApp.__new__(CompressorApp)
            app.results = queue.Queue()
            self.source.write_bytes(b"worker payload")
            worker = threading.Thread(target=app.work, args=(self.source, self.packed, False))
            worker.start()
            worker.join(10)
            self.assertFalse(worker.is_alive())
            success, result = app.results.get(timeout=1)
            self.assertTrue(success)
            self.assertIsInstance(result, Stats)
            app.work(self.root / "missing", self.output, False)
            success, result = app.results.get(timeout=1)
            self.assertFalse(success)
            self.assertTrue(result)

        def test_metrics_handle_empty_and_expansion(self):
            self.assertIn("N/A", Stats(0, 20, 0.01, False).report())
            self.assertIn("200.00%", Stats(10, 20, 0.01, False).report())
            self.assertIn("50.00%", Stats(10, 20, 0.01, True).report())

    suite = unittest.defaultTestLoader.loadTestsFromTestCase(FileTests)
    return 0 if unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful() else 1


def main(argv=None) -> int:
    arguments = list(sys.argv[1:] if argv is None else argv)
    if not arguments or arguments == ["--gui"]:
        return launch_gui()
    if arguments == ["--self-test"]:
        return self_test()
    parser = argparse.ArgumentParser(
        description="Stream a local file to or from Gzip.",
        epilog="Run without arguments (or --gui) for the GUI; --self-test runs tests.")
    parser.add_argument("-i", "--input", type=Path, required=True)
    parser.add_argument("-o", "--output", type=Path, required=True)
    parser.add_argument("-d", "--decompress", action="store_true")
    args = parser.parse_args(arguments)
    try:
        print(process_file(args.input, args.output, args.decompress).report())
        return 0
    except PROCESS_ERRORS as error:
        print(f"Error: {error}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main())
