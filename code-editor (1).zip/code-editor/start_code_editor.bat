@echo off
setlocal
cd /d "%~dp0"
set "CODE_EDITOR_FROM_BATCH=1"
if not exist "editor_app\app.py" (
    echo The editor_app folder is missing.
    echo Right-click the downloaded ZIP, choose Extract All, then open this launcher from the extracted folder.
    pause
    exit /b 1
)
where py >nul 2>&1
if not errorlevel 1 (
    py -3 "%~dp0code_editor.py" %*
) else (
    where python >nul 2>&1
    if errorlevel 1 (
        echo Python was not found. Install Python 3.10 or newer with Tcl/Tk and the Python launcher.
        pause
        exit /b 1
    )
    python "%~dp0code_editor.py" %*
)
set "CODE_EDITOR_EXIT=%ERRORLEVEL%"
if not "%CODE_EDITOR_EXIT%"=="0" (
    echo.
    echo Code editor could not start. Copy the error above and send it back for diagnosis.
    pause
)
exit /b %CODE_EDITOR_EXIT%
