# Code editor

A local desktop code editor built with Python and Tkinter. All application code is Python; no JavaScript, Electron, Node.js, browser, pip packages, or network services are required. Tkinter itself uses Python's native Tcl/Tk GUI runtime.

## Start

1. Install Python **3.10 or newer** with Tcl/Tk support.
2. Right-click the ZIP and choose **Extract All**. Keep the whole extracted folder; the launcher needs the `editor_app` folder beside it.
3. On Windows, double-click **`start_code_editor.bat`** in the extracted folder. It checks the folder and interpreter, and keeps startup errors visible.
4. Or open a terminal inside `code-editor` and run:

```sh
python code_editor.py
```

On Windows, `py code_editor.py` also works. On Linux/macOS you may need `python3`. On Linux, a distribution's separate `python3-tk` package may be required. Check Tk with `python -m tkinter`. A graphical desktop is required.

Open a folder or file immediately:

```sh
python code_editor.py /path/to/project
python code_editor.py /path/to/main.py
```

If startup fails, the launcher prints the error and saves a full traceback in `code-editor-startup-error.log` under the system temporary directory (on Windows, `%TEMP%`). Direct `.py` startup on Windows also shows an error dialog. Send the displayed error or log text for diagnosis; the window closing alone does not identify the cause.

There are no third-party Python dependencies. Install the separate **Git command-line program** if you want source control.

## Features

- Neutral charcoal desktop interface, compact toolbar, file explorer, tabs, dirty indicators, two editor groups, command palette and quick open.
- Real local file editing, atomic saves, Save As/All, undo/redo, external-change detection and an explicit confirmation before overwriting disk changes.
- UTF-8, UTF-8 BOM, UTF-16 LE/BE BOM; LF/CRLF/CR conversion. Files over 20 MiB are rejected. Large files disable syntax highlighting.
- Python token-based syntax highlighting; simple coloring for other source formats; auto-indentation, block indent/outdent and identifier completion. Python function/class outline and go-to-line.
- File and workspace search with literal/regex, case and whole-word modes; replacement diff previews; dirty buffers remain unsaved while clean files are saved after replacement.
- Lazy explorer folders, new files/folders, rename/move, copy path and recoverable Code editor trash.
- Git status, working/staged diffs, stage/unstage, commits and local branch creation/switching.
- Asynchronous command output, stdin input, Python execution, configured tasks, stop controls and Python `pdb` debugging.
- User/workspace settings; automatic session checkpoints, restoring tabs and unsaved buffers after restart.
- Declarative extensions with informational commands and simple theme colors.

## Responsiveness

Mouse-wheel scrolling eases between positions; using the scrollbar or typing cancels the easing immediately. Gutter redraws and typing updates are combined rather than repeated for every event. Syntax parsing runs in background workers and colors are applied in small batches; results from older edits are discarded.

Folder contents load in the background and appear in batches. Already loaded folders are reused until Refresh. Disk checks run off the UI thread and avoid rereading unchanged files. Recovery writes run on one background worker, and process output is combined into bounded screen updates. Saves, closes, searches and launches flush pending edits before using them.

## Editing and navigation

| Action | Shortcut |
|---|---|
| New / Open / Save / Close tab | Ctrl+N / Ctrl+O / Ctrl+S / Ctrl+W |
| Save As | Ctrl+Shift+S |
| Quick Open | Ctrl+P |
| Command palette | Ctrl+Shift+P |
| Find/replace in file | Ctrl+F |
| Go to line | Ctrl+G |
| Identifier completion | Ctrl+Space |
| Run / debug Python | F5 / F6 |
| Indent / outdent | Tab / Shift+Tab |

On macOS the app's file/navigation shortcuts use Command. Native text editing shortcuts follow Tk/platform behavior. Use the View menu or right-click a tab to move it to the other editor group. Hide or show Output from the status bar or **View → Toggle output panel**. Debug buttons appear only while a debug session is active. Moving recreates the view and resets that tab's undo history.

Choose a project with **Open folder** in the toolbar or **File → Open Folder**. Expand folders and double-click a file to edit it. Tabs can contain files outside the project, but workspace file operations and tasks cannot escape the project through `..` or symlinks. Right-click an explorer entry for actions. The menu's Tools commands choose line-ending style; save to apply it.

## Command console and Python debugger

Choose **Run → Run Python file** to save and execute the current `.py` file using the same interpreter as the editor. Enter a shell command in the bottom entry when no process is running. While a process is running, the entry sends standard input to that process. Output streams without blocking the UI; **Stop** terminates the active process group/tree.

This is a **pipe-based command console**, not a PTY terminal emulator. Full-screen terminal apps, terminal cursor control and raw keyboard applications are unsupported. Each command is a new process: shell `cd` and environment changes do not persist between commands. Use task `cwd`/`env` or run commands through your external terminal for those workflows.

Click the editor's line-number gutter to toggle breakpoint dots, then press **F6**. `pdb` pauses at entry. Use Continue, Over, Into, Out, Stack and Locals. Enter native pdb commands in the console, for example `p value`, `pp locals()`, `where`, `up`, `down`, `break 12`, `continue`, or `quit`. Debug expressions execute Python in your program's context. Breakpoint changes in the gutter apply to the next debug launch; use pdb commands to change them in a running session. Breakpoint line numbers do not automatically follow edits and are not persisted. `pdb` normally restarts a finished program until you quit.

Workspace trust is prompted before running commands/debugging/tasks/Git, and resets when the workspace changes or the app restarts. Trust does not sandbox code. Nothing runs automatically on folder open.

## Task configurations

Use **Run → Open task configuration** to create `.code-editor/tasks.json`. Edit it, save it, then choose **Run → Run Task** to select a task or debug launch. Example:

```json
{
  "tasks": [
    {
      "name": "Tests",
      "command": "python -m unittest discover -s tests -v",
      "cwd": ".",
      "env": {"CODE_EDITOR_MODE": "development"}
    }
  ],
  "launches": [
    {
      "name": "Python: main",
      "program": "main.py",
      "python": "python",
      "args": []
    }
  ]
}
```

Choose an interpreter available on your machine, or give its full path. Configured debug launches use `pdb`, not debugpy. Task commands use the operating system's default shell; quoting must match that shell. Only one task, command or debug process runs at a time.

## Git

Open a Git repository and select the Git sidebar. Refresh status explicitly, select a change, inspect its working/staged diff, stage or unstage it, then enter a message and commit. Configure your Git name/email externally first. App-created commits disable Git hooks. Branch changes leave unsaved buffers untouched; disk-change detection will warn before saving over switched contents. Remote operations, conflict resolution and advanced Git workflows remain available through shell commands or an external Git tool.

In Git repositories, search/quick-open use `git ls-files` and honor Git's ignore rules (tracked files are still included). Outside a repository, scanning excludes `.git`, `.venv`, `venv`, `__pycache__`, `node_modules`, `dist` and `build`; it does not parse `.gitignore` itself. Search caps results at 1,000 and is line-oriented; Quick Open lists the first 10,000 files. Regex uses Python's `re` syntax. Replacement previews can become stale; applying validates buffers and file fingerprints. Multi-file replacement is not a transaction: earlier successful files remain changed if a later file fails.

## Settings, recovery and trash

Open **View → Settings** to edit exactly `font_size` (8–36), `tab_size` (1–8) and `word_wrap` (boolean). User settings live in the data directory; workspace overrides live in `.code-editor/settings.json`.

New installations use the following data directory. Existing installations reuse the earlier `forge-editor-python` directory when present, preserving settings, recovery and trash. Existing `.forge` project configurations are also recognized; a matching `.code-editor` configuration takes precedence.

The new data directory is:

- Windows: `%LOCALAPPDATA%/code-editor`
- macOS: `~/Library/Application Support/code-editor`
- Linux: `${XDG_CONFIG_HOME:-~/.config}/code-editor`

Changed sessions checkpoint every second as plaintext source in `session.json`; unchanged sessions are not rewritten. Closing offers Save All, Keep for Recovery or Cancel. Recovery preserves unsaved text and the original disk fingerprint, so a newer external edit cannot be silently overwritten. Clean tabs reopen current disk contents. An abrupt power loss can lose changes since the most recent checkpoint. Protect this directory as you protect your source files.

the editor's trash is **application-managed**, not the OS recycle bin. Each trashed entry is under the data directory's `trash/<unique-id>/`, alongside `origin.json` containing its original path. Restore by moving the entry back manually. There is no permanent-delete action.

## Declarative extensions

Create `.code-editor/extensions/hello/manifest.json`, then run **Load declarative extensions** from the command palette:

```json
{
  "name": "Example extension",
  "commands": [{"title": "Say hello", "message": "Hello from Python Code editor!"}],
  "theme": {"background": "#202632", "foreground": "#dce3ee"}
}
```

Commands print informational messages. Themes apply to currently open views and last for the session. Executable plugins, the original Electron extension format and VS Code extensions are unsupported.

## Tests

Run from this folder:

```sh
python -m unittest discover -s tests -v
```

Tests use temporary files/repositories and real subprocesses. Core tests cover encodings, saving/conflicts, recovery, boundary checks, search/replacement, Git staging/diffs/branches/hooks, console I/O, process cleanup and pdb breakpoints/stepping. UI tests exercise real Tk widgets when a desktop is available; otherwise they report explicit skips. See `VERIFICATION.md` for the actual results from this build.

## Differences from the Electron edition

This is a Python rewrite of the core workbench, not identical feature parity. Tk replaces Monaco; completion is identifier-based, not an LSP/type service. `pdb` replaces the debugpy visual debugger; stack/variables appear in console text. A command console replaces the native PTY. There are two editor groups and no tab drag-and-drop. Keybindings are fixed, only three settings are exposed, extensions have a smaller declarative format, and no installers are bundled. Remote development, collaboration, VS Code extension compatibility, multi-cursor editing and automatic updates are not implemented. Standard Windows/macOS/Linux Python launch paths are provided; only Linux service execution was verified in this build.

## Source layout

- `code_editor.py`: launcher.
- `editor_app/app.py`: desktop workbench, dialogs and commands.
- `editor_app/editor.py`: text editor and syntax/navigation behavior.
- `editor_app/core.py`: documents, atomic saves, search, replacement, persistence and Git.
- `editor_app/processes.py`: asynchronous subprocess console.
- `tests/`: service, process/debugger and desktop smoke tests.

MIT licensed. Independent project; not affiliated with Microsoft or VS Code.
