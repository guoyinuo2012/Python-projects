"""Regression checks for the non-Tk parts of UI responsiveness."""
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from editor_app.core import fingerprint
from editor_app.performance import DiskMonitor, ScrollMotion, directory_entries, syntax_spans


class MotionTests(unittest.TestCase):
    def test_scroll_approaches_target_without_overshoot(self):
        motion = ScrollMotion()
        motion.add(0, 0.4, 0.8)
        position = 0
        for _ in range(100):
            previous = position
            position, moving = motion.step(position)
            self.assertGreaterEqual(position, previous)
            self.assertLessEqual(position, 0.4)
            if not moving:
                break
        self.assertFalse(moving)
        self.assertAlmostEqual(position, 0.4)

    def test_wheel_events_accumulate_and_clamp(self):
        motion = ScrollMotion()
        motion.add(0.1, 0.2, 0.8)
        motion.add(0.15, 0.2, 0.8)
        self.assertAlmostEqual(motion.target, 0.5)
        motion.add(0.15, 10, 0.8)
        self.assertEqual(motion.target, 0.8)
        motion.add(0.2, -10, 0.8)
        self.assertEqual(motion.target, 0)

    def test_reset_stops_animation(self):
        motion = ScrollMotion()
        motion.add(0, 0.5, 1)
        motion.reset()
        self.assertEqual(motion.step(0.2), (0.2, False))


class SyntaxTests(unittest.TestCase):
    def test_python_keyword_comment_string_and_number(self):
        spans = syntax_spans('def main():\n    x = "text" # note\n    return 42\n', '.py')
        self.assertEqual({tag for tag, _, _ in spans}, {'keyword', 'string', 'comment', 'number'})
        self.assertIn(('keyword', '1.0', '1.3'), spans)
        self.assertIn(('number', '3.11', '3.13'), spans)

    def test_incomplete_code_keeps_useful_spans(self):
        spans = syntax_spans('def main():\n    x = 4\n    value = (', '.py')
        self.assertIn(('keyword', '1.0', '1.3'), spans)
        self.assertTrue(any(tag == 'number' for tag, _, _ in spans))

    def test_generic_highlighting(self):
        spans = syntax_spans('const x = "hello"; // comment\nlet y = 2;', '.js')
        self.assertEqual({tag for tag, _, _ in spans}, {'keyword', 'string', 'comment', 'number'})

    def test_large_files_skip_expensive_highlighting(self):
        self.assertEqual(syntax_spans('x' * 300001, '.py'), [])


class FilesystemWorkTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def test_directory_sort_and_exclusions(self):
        (self.root / 'z_folder').mkdir()
        (self.root / '.git').mkdir()
        (self.root / '__pycache__').mkdir()
        (self.root / 'b.py').write_text('')
        (self.root / 'A.py').write_text('')
        entries = directory_entries(self.root)
        self.assertEqual([path.name for path, _, _ in entries], ['z_folder', 'A.py', 'b.py'])
        self.assertTrue(entries[0][1])

    def test_disk_checks_do_not_reread_unchanged_files(self):
        path = self.root / 'main.py'
        path.write_text('first')
        monitor = DiskMonitor()
        original_open = Path.open
        reads = []
        def opened(file, *args, **kwargs):
            if args and args[0] == 'rb':
                reads.append(file)
            return original_open(file, *args, **kwargs)
        with patch.object(Path, 'open', opened):
            self.assertEqual(monitor.scan([path])[path], fingerprint(b'first'))
            self.assertEqual(monitor.scan([path])[path], fingerprint(b'first'))
            self.assertEqual(len(reads), 1)
            path.write_text('changed content')
            self.assertEqual(monitor.scan([path])[path], fingerprint(b'changed content'))
            self.assertEqual(len(reads), 2)

    def test_deleted_file_is_reported(self):
        path = self.root / 'main.py'
        path.write_text('first')
        monitor = DiskMonitor()
        monitor.scan([path])
        path.unlink()
        self.assertEqual(monitor.scan([path]), {path: None})

    def test_closed_documents_leave_the_cache(self):
        path = self.root / 'main.py'
        path.write_text('first')
        monitor = DiskMonitor()
        monitor.scan([path])
        self.assertIn(path, monitor._cache)
        monitor.scan([])
        self.assertNotIn(path, monitor._cache)
