"""Startup errors must stay diagnosable even before Tk can be imported."""
import contextlib
import io
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

import code_editor


class LauncherTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def test_success_returns_without_error_reporting(self):
        module = types.ModuleType('editor_app.app')
        module.main = lambda: 0
        with patch.dict(sys.modules, {'editor_app.app': module}):
            with patch.object(code_editor, 'report_startup_error') as report:
                self.assertEqual(code_editor.main(), 0)
                report.assert_not_called()

    def test_old_python_reports_actionable_error(self):
        with patch.object(sys, 'version_info', (3, 9)):
            with patch.object(code_editor, 'report_startup_error', return_value=1) as report:
                self.assertEqual(code_editor.main(), 1)
                self.assertIn('3.10', str(report.call_args.args[0]))

    def test_failure_writes_traceback_and_instructions(self):
        module = types.ModuleType('editor_app.app')
        def fail():
            raise RuntimeError('startup test failure')
        module.main = fail
        output = io.StringIO()
        with patch.dict(sys.modules, {'editor_app.app': module}):
            with patch.dict(os.environ, {'CODE_EDITOR_FROM_BATCH': '1'}):
                with patch.object(tempfile, 'gettempdir', return_value=str(self.root)):
                    with contextlib.redirect_stderr(output):
                        self.assertEqual(code_editor.main(), 1)
        text = output.getvalue()
        self.assertIn('Extract the ENTIRE ZIP', text)
        self.assertIn('startup test failure', text)
        log = self.root / 'code-editor-startup-error.log'
        self.assertIn('RuntimeError: startup test failure', log.read_text())

    def test_missing_package_is_reported_in_real_process(self):
        launcher = self.root / 'code_editor.py'
        launcher.write_text(Path(code_editor.__file__).read_text(), encoding='utf-8')
        environment = dict(os.environ, CODE_EDITOR_FROM_BATCH='1', TMPDIR=str(self.root), TEMP=str(self.root), TMP=str(self.root))
        environment.pop('PYTHONPATH', None)
        result = subprocess.run([sys.executable, '-I', str(launcher)], cwd=self.root,
                                env=environment, capture_output=True, text=True, timeout=5)
        self.assertEqual(result.returncode, 1)
        self.assertIn('ModuleNotFoundError', result.stderr)
        self.assertIn('beside the editor_app folder', result.stderr)
        self.assertTrue((self.root / 'code-editor-startup-error.log').is_file())

    def test_log_failure_does_not_hide_original_error(self):
        output = io.StringIO()
        with patch.dict(os.environ, {'CODE_EDITOR_FROM_BATCH': '1'}):
            with patch.object(Path, 'write_text', side_effect=OSError('read only')):
                with contextlib.redirect_stderr(output):
                    try:
                        raise ValueError('original problem')
                    except ValueError as exc:
                        self.assertEqual(code_editor.report_startup_error(exc), 1)
        self.assertIn('original problem', output.getvalue())
        self.assertIn('could not be saved', output.getvalue())
