"""Real Tk smoke workflows; skipped automatically without a display."""
from pathlib import Path
import tempfile
import tkinter as tk
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from editor_app.app import CodeEditor
try:
    _probe = tk.Tk()
    _probe.destroy()
    DISPLAY_AVAILABLE = True
except tk.TclError:
    DISPLAY_AVAILABLE = False

@unittest.skipUnless(DISPLAY_AVAILABLE, 'No graphical display available')
class UITests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.app = CodeEditor(state_dir=self.root / 'state', restore=False)
        self.app.update()
    def tearDown(self):
        self.app.closing = True
        self.app.destroy()
        self.temp.cleanup()

    def wait_until(self, predicate, timeout=2):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            self.app.update()
            if predicate():
                return
            time.sleep(0.01)
        self.fail('The UI did not finish its scheduled work.')
    def test_edit_save_reload(self):
        path = self.root / 'main.py'
        path.write_text('x = 1\n')
        editor = self.app.open_file(path)
        editor.text.insert('end-1c', '# edit\n')
        self.wait_until(lambda: editor.doc.dirty)
        self.app.save_editor(editor)
        self.assertIn('# edit', path.read_text())
        self.assertFalse(editor.doc.dirty)
        self.app.reload_active()
        self.assertEqual(editor.text.get('1.0', 'end-1c'), path.read_text())
    def test_split_preserves_content(self):
        editor = self.app.active()
        editor.text.insert('1.0', 'unsaved')
        self.app.update()
        self.app.move_group()
        self.app.update()
        self.assertEqual(len(self.app.notebooks), 2)
        self.assertEqual(self.app.active().doc.text, 'unsaved')
    def test_close_cancel(self):
        editor = self.app.active()
        editor.text.insert('1.0', 'unsaved')
        self.app.update()
        with patch('editor_app.app.messagebox.askyesnocancel', return_value=None):
            self.assertFalse(self.app.close_editor(editor))
        self.assertIn(editor, self.app.editors)
    def test_outline(self):
        self.app.active().set_content('class Example:\n    def method(self):\n        pass\n')
        self.app.refresh_outline()
        self.assertEqual(self.app.symbols, [('Example',1),('method',2)])
    def test_rename(self):
        path = self.root / 'old.py'
        path.write_text('print(1)')
        self.app.set_workspace(self.root)
        editor = self.app.open_file(path)
        self.app.relocate(path, self.root / 'new.py')
        self.assertEqual(editor.doc.path, self.root / 'new.py')
        self.assertFalse(path.exists())

    def test_save_flushes_edits_without_waiting_for_modified_event(self):
        path = self.root / 'immediate.py'
        path.write_text('old')
        editor = self.app.open_file(path)
        editor.text.insert('end-1c', ' edit')
        # Save before the queued <<Modified>> event is processed.
        self.app.save_editor(editor)
        self.assertEqual(path.read_text(), 'old edit')
        self.assertFalse(editor.doc.dirty)

    def test_close_checks_pending_edits(self):
        editor = self.app.active()
        editor.text.insert('1.0', 'pending')
        with patch('editor_app.app.messagebox.askyesnocancel', return_value=None) as dialog:
            self.assertFalse(self.app.close_editor(editor))
        dialog.assert_called_once()
        self.assertEqual(editor.doc.text, 'pending')

    def test_output_panel_can_be_hidden_and_restored(self):
        panel = str(self.app.console)
        self.assertIn(panel, self.app.center.panes())
        self.app.toggle_output()
        self.assertNotIn(panel, self.app.center.panes())
        self.app.show_output()
        self.assertIn(panel, self.app.center.panes())

    def test_debug_controls_are_hidden_when_idle(self):
        self.app.update_console_controls()
        self.app.update()
        self.assertFalse(self.app.debug_controls.winfo_ismapped())
        self.assertIn('disabled', self.app.stop_button.state())

    def test_window_uses_requested_name(self):
        self.assertTrue(self.app.title().endswith('Code editor'))
        self.assertNotIn('Forge', self.app.title())

    def test_wheel_animation_can_be_cancelled(self):
        editor = self.app.active()
        editor.set_content('line\n' * 200)
        self.app.update()
        editor.wheel(SimpleNamespace(delta=-120, num=None))
        self.assertIsNotNone(editor._scroll_job)
        editor.cancel_scroll()
        self.assertIsNone(editor._scroll_job)
        self.assertIsNone(editor.motion.target)

    def test_old_highlight_results_cannot_repaint_new_content(self):
        editor = self.app.active()
        callbacks = []
        with patch.object(self.app, 'background', side_effect=lambda fn, done: callbacks.append(done)):
            editor.set_content('def old():\n    pass\n')
            editor.set_content('plain text')
            callbacks[0]([('keyword', '1.0', '1.3')])
        self.assertEqual(editor.text.tag_ranges('keyword'), ())

    def test_recovery_snapshots_pending_edits(self):
        editor = self.app.active()
        editor.text.insert('1.0', 'pending snapshot')
        self.app.checkpoint(schedule=False)
        self.app._recovery_future.result(timeout=2)
        self.assertEqual(self.app.store.recover()[1][0].text, 'pending snapshot')

    def test_folder_results_from_old_workspace_are_ignored(self):
        first, second = self.root / 'first', self.root / 'second'
        first.mkdir()
        second.mkdir()
        (first / 'old.py').write_text('')
        (second / 'current.py').write_text('')
        self.app.set_workspace(first)
        self.app.set_workspace(second)
        self.wait_until(lambda: self.app._tree_loaded)
        paths = set(self.app.tree_paths.values())
        self.assertIn(second / 'current.py', paths)
        self.assertNotIn(first / 'old.py', paths)
