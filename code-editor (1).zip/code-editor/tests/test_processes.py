import os
from pathlib import Path
import queue
import sys
import tempfile
import time
import unittest
from editor_app.processes import ProcessSession

class ProcessFixture(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.session = ProcessSession()
    def tearDown(self):
        thread = self.session.stop()
        if thread: thread.join(timeout=8)
        if self.session.process: self.session.process.wait(timeout=8)
        self.temp.cleanup()
    def collect(self, marker=None, timeout=8):
        output = ''
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            try: kind, value = self.session.events.get(timeout=0.1)
            except queue.Empty: continue
            if kind == 'exit': return output, value
            output += value
            if marker and marker in output: return output, None
        self.fail(f'Process timeout; output={output!r}')


class ProcessTests(ProcessFixture):
    def test_output(self):
        self.session.start([sys.executable, '-u', '-c', 'print("hello ไทย")'], self.root)
        output, code = self.collect()
        self.assertEqual(code, 0)
        self.assertIn('hello ไทย', output)
    def test_prompt_stdin(self):
        self.session.start([sys.executable, '-u', '-c', 'print(input("prompt>"))'], self.root)
        self.collect(marker='prompt>')
        self.session.send('answer')
        rest, code = self.collect()
        self.assertIn('answer', rest)
        self.assertEqual(code, 0)
    def test_env_cwd(self):
        self.session.start([sys.executable, '-u', '-c', 'import os; print(os.getcwd()); print(os.environ["CODE_EDITOR_TEST"])'],
                           self.root, {'CODE_EDITOR_TEST':'value'})
        output, code = self.collect()
        self.assertIn(str(self.root), output)
        self.assertIn('value', output)
        self.assertEqual(code, 0)
    def test_stop_double_start(self):
        self.session.start([sys.executable, '-u', '-c', 'import time; print("ready"); time.sleep(60)'], self.root)
        self.collect(marker='ready')
        with self.assertRaises(RuntimeError): self.session.start([sys.executable], self.root)
        self.session.stop()
        _, code = self.collect()
        self.assertNotEqual(code, 0)
    def test_failure(self):
        self.session.start([sys.executable, '-u', '-c', 'raise ValueError("intentional")'], self.root)
        output, code = self.collect()
        self.assertIn('ValueError: intentional', output)
        self.assertEqual(code, 1)
    def test_pdb_breakpoint_step_locals(self):
        path = self.root / 'main.py'
        path.write_text('x = 1\nx += 2\nprint(x)\n')
        self.session.start([sys.executable, '-u', '-m', 'pdb', '-c', f'break {path}:2', str(path)], self.root)
        self.collect(marker='(Pdb)')
        self.session.send('continue')
        output, _ = self.collect(marker='(Pdb)')
        self.assertIn('x += 2', output)
        self.session.send('next')
        self.collect(marker='(Pdb)')
        self.session.send('p x')
        output, _ = self.collect(marker='(Pdb)')
        self.assertIn('3', output)
        self.session.send('quit')
        self.collect()
    def test_send_without_process(self):
        with self.assertRaises(RuntimeError): self.session.send('hello')

class ProcessCleanupTests(ProcessFixture):
    def test_missing_executable_does_not_leave_session_busy(self):
        with self.assertRaises(OSError):
            self.session.start([str(self.root / 'missing-executable')], self.root)
        self.assertFalse(self.session.busy)
        self.session.start([sys.executable, '-u', '-c', 'print("retry")'], self.root)
        output, code = self.collect()
        self.assertEqual(code, 0)
        self.assertIn('retry', output)

    @unittest.skipIf(os.name == 'nt', 'POSIX process-group lifecycle')
    def test_stop_child_after_parent_exits(self):
        child = 'import signal,time; signal.signal(signal.SIGTERM, signal.SIG_IGN); print("child-ready", flush=True); time.sleep(60)'
        parent = f'import subprocess,sys; subprocess.Popen([sys.executable,"-u","-c",{child!r}])'
        self.session.start([sys.executable, '-u', '-c', parent], self.root)
        self.collect(marker='child-ready')
        self.session.process.wait(timeout=3)
        self.assertFalse(self.session.running)
        self.assertTrue(self.session.busy)
        stop_thread = self.session.stop()
        self.assertIsNotNone(stop_thread)
        stop_thread.join(timeout=6)
        _, code = self.collect()
        self.assertEqual(code, 0)
        self.assertTrue(self.session._finished.wait(timeout=1))
        self.assertFalse(self.session.busy)

    def test_closed_stdin_still_finishes_output_cleanup(self):
        command = 'import os,time; os.close(0); print("input-closed", flush=True); time.sleep(0.2)'
        self.session.start([sys.executable, '-u', '-c', command], self.root)
        self.collect(marker='input-closed')
        with self.assertRaises(RuntimeError):
            self.session.send('hello')
        _, code = self.collect()
        self.assertEqual(code, 0)
        self.assertTrue(self.session._finished.wait(timeout=1))
