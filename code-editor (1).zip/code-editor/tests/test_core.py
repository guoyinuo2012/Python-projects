import os
from pathlib import Path
import re
import shutil
import tempfile
import unittest
from editor_app.core import (ConflictError, Document, StateStore, apply_replacement, atomic_write,
                        contained, decode, encode, git, git_status, pattern, project_files,
                        replacements, search)

class TemporaryWorkspace(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
    def tearDown(self):
        self.temp.cleanup()
    def file(self, name='main.py', content='print("hi")\n'):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding='utf-8')
        return path


class CoreTests(TemporaryWorkspace):
    def test_encoding_roundtrips(self):
        for enc in ('utf-8','utf-8-sig','utf-16-le','utf-16-be'):
            for eol in ('\n','\r\n','\r'):
                with self.subTest(enc=enc, eol=eol):
                    text = 'Hello ไทย 中文\nnext\n'
                    self.assertEqual(decode(encode(text, enc, eol)), (text, enc, eol))
    def test_binary_rejected(self):
        with self.assertRaises(ValueError): decode(b'a\x00b')
    def test_legacy_rejected(self):
        with self.assertRaises(UnicodeError): decode(b'\x80\x81')
    def test_edit_save(self):
        doc = Document.load(self.file())
        self.assertFalse(doc.dirty)
        doc.text += '# edited\n'
        self.assertTrue(doc.dirty)
        doc.save()
        self.assertFalse(doc.dirty)
        self.assertEqual(doc.path.read_text(), doc.text)
    def test_external_change_conflict(self):
        path = self.file()
        doc = Document.load(path)
        path.write_text('external')
        doc.text = 'my edit'
        with self.assertRaises(ConflictError): doc.save()
        self.assertEqual(path.read_text(), 'external')
        doc.save(force=True)
        self.assertEqual(path.read_text(), 'my edit')
    def test_deleted_file_conflict(self):
        path = self.file()
        doc = Document.load(path)
        path.unlink()
        with self.assertRaises(ConflictError): doc.save()
    def test_save_as(self):
        doc = Document(text='hello')
        doc.save(self.root / 'sub/new.txt')
        self.assertEqual(doc.path.read_text(), 'hello')
        self.assertFalse(doc.dirty)
    @unittest.skipIf(os.name == 'nt', 'POSIX modes')
    def test_atomic_preserves_permissions(self):
        path = self.file()
        path.chmod(0o755)
        atomic_write(path, b'new')
        self.assertEqual(path.stat().st_mode & 0o777, 0o755)
        self.assertEqual(list(self.root.glob('.code-editor-*')), [])
    def test_boundary(self):
        self.assertEqual(contained(self.root, self.root / 'x'), self.root / 'x')
        with self.assertRaises(ValueError): contained(self.root, self.root / '../outside')
    @unittest.skipIf(os.name == 'nt', 'Symlink permissions')
    def test_symlink_boundary(self):
        (self.root / 'escape').symlink_to(self.root.parent, target_is_directory=True)
        with self.assertRaises(ValueError): contained(self.root, self.root / 'escape/file')
    def test_recovery(self):
        dirty = Document.load(self.file('dirty.py'))
        clean = Document.load(self.file('clean.py'))
        dirty.text = 'unsaved text'
        store = StateStore(self.root / 'state')
        store.checkpoint([dirty, clean, Document(text='untitled edit')], self.root)
        clean.path.write_text('new disk text')
        workspace, docs = store.recover()
        self.assertEqual(workspace, self.root)
        self.assertEqual([d.text for d in docs], ['unsaved text', 'new disk text', 'untitled edit'])
        self.assertTrue(docs[0].dirty)
        self.assertFalse(docs[1].dirty)
        docs[0].save()
        self.assertEqual(dirty.path.read_text(), 'unsaved text')
    def test_corrupt_state(self):
        store = StateStore(self.root)
        (self.root / 'session.json').write_text('{broken')
        self.assertEqual(store.recover(), (None, []))
    def test_bad_state_item(self):
        store = StateStore(self.root)
        store.write('session.json', {'documents':[{}, {'text':'a','saved_text':'b'}]})
        self.assertEqual(store.recover(), (None, []))
    def test_search_modes(self):
        self.file(content='cat Cat concatenate\na.b aXb\n')
        self.assertEqual(len(search(self.root, pattern('cat', word=True))[0]), 2)
        self.assertEqual(len(search(self.root, pattern('cat', case=True, word=True))[0]), 1)
        self.assertEqual(len(search(self.root, pattern('a.b'))[0]), 1)
    def test_search_buffers_and_limits(self):
        path = self.file(content='disk')
        hits, limited = search(self.root, pattern('edit'), {path:'edit edit edit'}, limit=2)
        self.assertEqual(len(hits), 2)
        self.assertTrue(limited)
        self.assertEqual(hits[1].column, 5)
    def test_search_binary_cancel(self):
        self.file()
        (self.root / 'binary').write_bytes(b'\x00hello')
        self.assertEqual(search(self.root, pattern('hello'))[0], [])
        self.assertEqual(search(self.root, pattern('hi'), cancelled=lambda: True), ([], True))
    def test_invalid_regex(self):
        with self.assertRaises(re.error): pattern('[', regex=True)
        with self.assertRaises(ValueError): pattern('')
    def test_regex_replace(self):
        path = self.file(content='one=1 two=2')
        changes = replacements(self.root, pattern(r'(\w+)=(\d)', regex=True), r'\1: \2', [])
        self.assertEqual(changes[0].count, 2)
        apply_replacement(changes[0])
        self.assertEqual(path.read_text(), 'one: 1 two: 2')
    def test_clean_replace_saves(self):
        doc = Document.load(self.file(content='old value'))
        change = replacements(self.root, pattern('old'), 'new', [doc])[0]
        apply_replacement(change, doc)
        self.assertEqual(doc.path.read_text(), 'new value')
        self.assertFalse(doc.dirty)
    def test_dirty_replace_stays_unsaved(self):
        doc = Document.load(self.file(content='disk value'))
        doc.text = 'old unsaved'
        change = replacements(self.root, pattern('old'), 'new', [doc])[0]
        apply_replacement(change, doc)
        self.assertEqual(doc.text, 'new unsaved')
        self.assertEqual(doc.path.read_text(), 'disk value')
    def test_preview_disk_conflict(self):
        path = self.file(content='old')
        change = replacements(self.root, pattern('old'), 'new', [])[0]
        path.write_text('external')
        with self.assertRaises(ConflictError): apply_replacement(change)
        self.assertEqual(path.read_text(), 'external')
    def test_preview_buffer_conflict(self):
        doc = Document.load(self.file(content='old'))
        change = replacements(self.root, pattern('old'), 'new', [doc])[0]
        doc.text = 'changed'
        with self.assertRaises(ConflictError): apply_replacement(change, doc)
    def test_clean_replace_rollback(self):
        doc = Document.load(self.file(content='old'))
        change = replacements(self.root, pattern('old'), 'new', [doc])[0]
        doc.path.write_text('external')
        with self.assertRaises(ConflictError): apply_replacement(change, doc)
        self.assertEqual(doc.text, 'old')
    def test_utf16_replace(self):
        path = self.root / 'unicode.txt'
        path.write_bytes(encode('hello ไทย\n', 'utf-16-le', '\r\n'))
        self.assertEqual(len(search(self.root, pattern('ไทย'))[0]), 1)
        apply_replacement(replacements(self.root, pattern('hello'), 'hi', [])[0])
        self.assertEqual(decode(path.read_bytes()), ('hi ไทย\n', 'utf-16-le', '\r\n'))

@unittest.skipUnless(shutil.which('git'), 'Git unavailable')
class GitTests(TemporaryWorkspace):
    def setUp(self):
        super().setUp()
        git(self.root, 'init', '-q')
        git(self.root, 'config', 'user.email', 'test@example.invalid')
        git(self.root, 'config', 'user.name', 'Code editor Test')
    def initial(self):
        git(self.root, 'add', '.')
        git(self.root, 'commit', '-m', 'initial')
    def test_stage_diff_unstage(self):
        path = self.file('space file.py', 'first\n')
        self.assertIn(('??', path.name), git_status(self.root))
        git(self.root, 'add', '--', path.name)
        self.assertIn(('A ', path.name), git_status(self.root))
        self.initial()
        path.write_text('second\n')
        self.assertIn('-first', git(self.root, 'diff', '--', path.name))
        git(self.root, 'add', '--', path.name)
        self.assertIn('+second', git(self.root, 'diff', '--cached', '--', path.name))
        git(self.root, 'reset', '-q', 'HEAD', '--', path.name)
        self.assertIn((' M', path.name), git_status(self.root))
    def test_rename(self):
        path = self.file('before name.txt')
        self.initial()
        git(self.root, 'mv', path.name, 'after name.txt')
        self.assertEqual(git_status(self.root), [('R ', 'after name.txt')])
    def test_ignore(self):
        self.file('.gitignore', '*.tmp\nignored/\n')
        self.file('skip.tmp')
        self.file('ignored/x.py')
        self.file('tracked.tmp')
        git(self.root, 'add', '-f', '--', 'tracked.tmp')
        names = {str(p.relative_to(self.root)) for p in project_files(self.root)}
        self.assertIn('tracked.tmp', names)
        self.assertNotIn('skip.tmp', names)
        self.assertNotIn('ignored/x.py', names)
    def test_branch(self):
        self.file('main.py')
        self.initial()
        git(self.root, 'switch', '-c', 'feature/test')
        self.assertEqual(git(self.root, 'branch', '--show-current').strip(), 'feature/test')
    @unittest.skipIf(os.name == 'nt', 'POSIX hook')
    def test_hooks_disabled(self):
        self.file('main.py')
        hook = self.root / '.git/hooks/pre-commit'
        hook.write_text('#!/bin/sh\nexit 1\n')
        hook.chmod(0o755)
        self.initial()
        self.assertTrue(git(self.root, 'rev-parse', 'HEAD').strip())

class RecoveryFormatTests(TemporaryWorkspace):
    def test_format_only_changes_recover(self):
        doc = Document.load(self.file(content='line\n'))
        doc.eol = '\r\n'
        self.assertTrue(doc.dirty)
        store = StateStore(self.root / 'state')
        store.checkpoint([doc], self.root)
        _, docs = store.recover()
        self.assertTrue(docs[0].dirty)
        docs[0].save()
        self.assertEqual(doc.path.read_bytes(), b'line\r\n')
        self.assertFalse(docs[0].dirty)
    def test_null_documents_state(self):
        store = StateStore(self.root)
        store.write('session.json', {'documents':None})
        self.assertEqual(store.recover(), (None, []))
    def test_invalid_document_types(self):
        store = StateStore(self.root)
        store.write('session.json', {'documents':[None, 1, 'bad', {'text':23,'saved_text':'a'}]})
        self.assertEqual(store.recover(), (None, []))


class CleanupRegressionTests(TemporaryWorkspace):
    def test_unchanged_checkpoint_does_not_rewrite(self):
        from unittest.mock import patch
        store = StateStore(self.root / 'state')
        doc = Document(text='unsaved')
        with patch('editor_app.core.atomic_write', wraps=atomic_write) as writer:
            store.checkpoint([doc], self.root)
            store.checkpoint([doc], self.root)
            self.assertEqual(writer.call_count, 1)
            doc.text = 'changed'
            store.checkpoint([doc], self.root)
            self.assertEqual(writer.call_count, 2)
        self.assertEqual(store.recover()[1][0].text, 'changed')

    def test_checkpoint_recreates_deleted_recovery_file(self):
        store = StateStore(self.root / 'state')
        doc = Document(text='unsaved')
        store.checkpoint([doc], self.root)
        (store.directory / 'session.json').unlink()
        store.checkpoint([doc], self.root)
        self.assertEqual(store.recover()[1][0].text, 'unsaved')

    def test_failed_checkpoint_can_be_retried(self):
        from unittest.mock import patch
        store = StateStore(self.root / 'state')
        with patch('editor_app.core.atomic_write', side_effect=OSError('disk full')):
            with self.assertRaises(OSError):
                store.checkpoint([Document(text='unsaved')], self.root)
        store.checkpoint([Document(text='unsaved')], self.root)
        self.assertEqual(store.recover()[1][0].text, 'unsaved')

    def test_bad_replacement_expression_is_reported(self):
        self.file(content='old')
        with self.assertRaises(re.error):
            replacements(self.root, pattern('(old)', regex=True), r'\9', [])

    def test_search_can_cancel_inside_a_file(self):
        self.file(content='no match\n' * 100)
        calls = 0
        def cancelled():
            nonlocal calls
            calls += 1
            return calls >= 4
        self.assertEqual(search(self.root, pattern('absent'), cancelled=cancelled), ([], True))
        self.assertEqual(calls, 4)

class ConfigurationCompatibilityTests(TemporaryWorkspace):
    def test_new_projects_use_new_config_directory(self):
        from editor_app.core import configuration_path
        self.assertEqual(configuration_path(self.root, 'tasks.json'), self.root / '.code-editor/tasks.json')

    def test_existing_config_is_reused(self):
        from editor_app.core import configuration_path
        legacy = self.file('.forge/tasks.json', '{"tasks":[]}')
        self.assertEqual(configuration_path(self.root, 'tasks.json'), legacy)

    def test_new_config_overrides_legacy_config(self):
        from editor_app.core import configuration_path
        self.file('.forge/settings.json', '{}')
        current = self.file('.code-editor/settings.json', '{}')
        self.assertEqual(configuration_path(self.root, 'settings.json'), current)

    def test_existing_user_data_remains_available(self):
        from editor_app.core import user_data_dir
        from unittest.mock import patch
        legacy = self.root / 'forge-editor-python'
        legacy.mkdir()
        with patch('editor_app.core.sys.platform', 'linux'):
            with patch('editor_app.core.os.name', 'posix'):
                with patch.dict(os.environ, {'XDG_CONFIG_HOME': str(self.root)}):
                    self.assertEqual(user_data_dir(), legacy)
