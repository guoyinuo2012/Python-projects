"""Stream subprocess output without accessing Tk from worker threads."""
from __future__ import annotations

import codecs
import os
from pathlib import Path
import queue
import signal
import subprocess
import threading


class ProcessSession:
    def __init__(self) -> None:
        self.events: queue.Queue[tuple[str, str | int]] = queue.Queue()
        self.process: subprocess.Popen | None = None
        self._lock = threading.Lock()
        self._finished = threading.Event()
        self._finished.set()
        self._stop_thread: threading.Thread | None = None

    @property
    def running(self) -> bool:
        return self.process is not None and self.process.poll() is None

    @property
    def busy(self) -> bool:
        """Include pending output and children that still hold the output pipe."""
        return not self._finished.is_set()

    def start(
        self,
        command: list[str] | str,
        cwd: Path,
        env: dict[str, str] | None = None,
        shell: bool = False,
    ) -> None:
        if self.busy:
            raise RuntimeError('Stop the current process and wait for its output first.')
        environment = dict(os.environ, PYTHONUNBUFFERED='1', TERM='dumb', NO_COLOR='1')
        environment.update(env or {})
        options = (
            {'creationflags': subprocess.CREATE_NEW_PROCESS_GROUP}
            if os.name == 'nt'
            else {'start_new_session': True}
        )
        proc = subprocess.Popen(
            command,
            cwd=cwd,
            env=environment,
            shell=shell,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            **options,
        )
        self.process = proc
        self._stop_thread = None
        self._finished.clear()
        threading.Thread(target=self._read, args=(proc,), daemon=True).start()

    def _read(self, proc: subprocess.Popen) -> None:
        decoder = codecs.getincrementaldecoder('utf-8')('replace')
        try:
            while data := os.read(proc.stdout.fileno(), 4096):
                self.events.put(('output', decoder.decode(data)))
            tail = decoder.decode(b'', final=True)
            if tail:
                self.events.put(('output', tail))
        except OSError as exc:
            self.events.put(('output', f'\n[Output error: {exc}]\n'))
        finally:
            code = proc.wait()
            proc.stdout.close()
            with self._lock:
                try:
                    proc.stdin.close()
                except OSError:
                    # A failed send may leave buffered bytes for a closed pipe.
                    pass
            # Queue the final event before permitting another process to start.
            self.events.put(('exit', code))
            self._finished.set()

    def send(self, text: str) -> None:
        with self._lock:
            if not self.running:
                raise RuntimeError('No running process.')
            try:
                self.process.stdin.write((text + '\n').encode('utf-8'))
                self.process.stdin.flush()
            except (BrokenPipeError, ValueError) as exc:
                raise RuntimeError('The process closed its input.') from exc

    def stop(self) -> threading.Thread | None:
        proc = self.process
        if proc is None or not self.busy:
            return None
        if self._stop_thread is not None and self._stop_thread.is_alive():
            return self._stop_thread

        def terminate() -> None:
            try:
                if os.name == 'nt':
                    subprocess.run(
                        ['taskkill', '/PID', str(proc.pid), '/T', '/F'],
                        capture_output=True,
                        timeout=5,
                    )
                    if proc.poll() is None:
                        proc.kill()
                else:
                    # The group can outlive its parent process.
                    os.killpg(proc.pid, signal.SIGTERM)
                    if not self._finished.wait(timeout=2):
                        os.killpg(proc.pid, signal.SIGKILL)
                proc.wait(timeout=2)
            except (OSError, subprocess.TimeoutExpired):
                pass

        self._stop_thread = threading.Thread(target=terminate, daemon=True)
        self._stop_thread.start()
        return self._stop_thread
