"""Filesystem, search, persistence and Git services independent of the UI."""
from __future__ import annotations

import hashlib
import json
import os
import re
import stat
import subprocess
import sys
import tempfile
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path

MAX_FILE = 20 * 1024 * 1024
SKIP_DIRS = {'.git', '.venv', 'venv', '__pycache__', 'node_modules', 'dist', 'build'}


class ConflictError(RuntimeError):
    """Disk contents changed since the document was loaded."""


def fingerprint(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def decode(data: bytes) -> tuple[str, str, str]:
    if len(data) > MAX_FILE:
        raise ValueError('Files above 20 MiB are not supported.')
    if data.startswith(b'\xff\xfe'):
        encoding = 'utf-16-le'
        text = data[2:].decode(encoding)
    elif data.startswith(b'\xfe\xff'):
        encoding = 'utf-16-be'
        text = data[2:].decode(encoding)
    else:
        encoding = 'utf-8-sig' if data.startswith(b'\xef\xbb\xbf') else 'utf-8'
        text = data.decode(encoding)
    if '\x00' in text:
        raise ValueError('Binary files cannot be edited.')
    crlf = text.count('\r\n')
    lone_cr = text.count('\r') - crlf
    lone_lf = text.count('\n') - crlf
    eol = '\r\n' if crlf > max(lone_cr, lone_lf) else ('\r' if lone_cr > lone_lf else '\n')
    return text.replace('\r\n', '\n').replace('\r', '\n'), encoding, eol


def encode(text: str, encoding: str, eol: str) -> bytes:
    data = text.replace('\n', eol).encode(encoding)
    if encoding == 'utf-16-le':
        return b'\xff\xfe' + data
    if encoding == 'utf-16-be':
        return b'\xfe\xff' + data
    return data


def atomic_write(path: Path, data: bytes) -> None:
    """Replace through a same-directory temporary file, preserving mode bits."""
    path = path.resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    mode = stat.S_IMODE(path.stat().st_mode) if path.exists() else None
    fd, temp = tempfile.mkstemp(prefix='.code-editor-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        if mode is not None:
            os.chmod(temp, mode)
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


@dataclass
class Document:
    path: Path | None = None
    text: str = ''
    encoding: str = 'utf-8'
    eol: str = '\n'
    baseline: str | None = None
    saved_text: str = ''
    untitled: str = 'Untitled'
    breakpoints: set[int] = field(default_factory=set)
    saved_encoding: str | None = None
    saved_eol: str | None = None

    def __post_init__(self):
        if self.saved_encoding is None:
            self.saved_encoding = self.encoding
        if self.saved_eol is None:
            self.saved_eol = self.eol

    @property
    def dirty(self) -> bool:
        return (self.text != self.saved_text or self.encoding != self.saved_encoding
                or self.eol != self.saved_eol)

    @property
    def name(self) -> str:
        return self.path.name if self.path else self.untitled

    @classmethod
    def load(cls, path: Path) -> 'Document':
        path = path.resolve()
        if path.stat().st_size > MAX_FILE:
            raise ValueError('Files above 20 MiB are not supported.')
        data = path.read_bytes()
        text, encoding, eol = decode(data)
        return cls(path, text, encoding, eol, fingerprint(data), text)

    def save(self, target: Path | None = None, force: bool = False) -> None:
        path = (target or self.path)
        if path is None:
            raise ValueError('Choose a filename first.')
        path = path.resolve()
        same = self.path is not None and path == self.path
        if same and not force:
            current = fingerprint(path.read_bytes()) if path.exists() else None
            if current != self.baseline:
                raise ConflictError(f'{path.name} changed on disk. Reload or explicitly overwrite.')
        data = encode(self.text, self.encoding, self.eol)
        atomic_write(path, data)
        self.path, self.baseline, self.saved_text = path, fingerprint(data), self.text
        self.saved_encoding, self.saved_eol = self.encoding, self.eol


def user_data_dir() -> Path:
    if os.name == 'nt':
        base = Path(os.environ.get('LOCALAPPDATA', str(Path.home() / 'AppData/Local')))
    elif sys.platform == 'darwin':
        base = Path.home() / 'Library/Application Support'
    else:
        base = Path(os.environ.get('XDG_CONFIG_HOME', str(Path.home() / '.config')))
    directory = base / 'code-editor'
    legacy = base / 'forge-editor-python'
    return legacy if not directory.exists() and legacy.exists() else directory


def configuration_path(root: Path, relative: str) -> Path:
    """Keep existing projects usable while giving new projects the current name."""
    path = root / '.code-editor' / relative
    legacy = root / '.forge' / relative
    return legacy if not path.exists() and legacy.exists() else path


class StateStore:
    def __init__(self, directory: Path | None = None):
        self.directory = directory or user_data_dir()
        self.directory.mkdir(parents=True, exist_ok=True)
        self._last_session: bytes | None = None

    def read(self, name: str, default):
        try:
            return json.loads((self.directory / name).read_text(encoding='utf-8'))
        except (OSError, ValueError):
            return default

    def write(self, name: str, value) -> None:
        atomic_write(self.directory / name, json.dumps(value, ensure_ascii=False, indent=2).encode('utf-8'))

    def checkpoint(self, documents: list[Document], workspace: Path | None) -> None:
        state = {
            'workspace': str(workspace) if workspace else None,
            'documents': [dict(path=str(d.path) if d.path else None, text=d.text,
                               saved_text=d.saved_text, baseline=d.baseline,
                               encoding=d.encoding, eol=d.eol, untitled=d.untitled,
                               saved_encoding=d.saved_encoding, saved_eol=d.saved_eol)
                          for d in documents],
        }
        payload = json.dumps(state, ensure_ascii=False, indent=2).encode('utf-8')
        path = self.directory / 'session.json'
        if payload != self._last_session or not path.exists():
            atomic_write(path, payload)
            self._last_session = payload

    def recover(self) -> tuple[Path | None, list[Document]]:
        state = self.read('session.json', {})
        if not isinstance(state, dict):
            return None, []
        docs = []
        items = state.get('documents', [])
        if not isinstance(items, list):
            items = []
        for item in items:
            try:
                if not isinstance(item, dict):
                    continue
                path = Path(item['path']).resolve() if item.get('path') else None
                if not isinstance(item['text'], str) or not isinstance(item['saved_text'], str):
                    continue
                if item.get('encoding') not in ('utf-8', 'utf-8-sig', 'utf-16-le', 'utf-16-be'):
                    continue
                if item.get('eol') not in ('\n', '\r\n', '\r'):
                    continue
                doc = Document(path=path, text=item['text'], saved_text=item['saved_text'],
                                         baseline=item.get('baseline'), encoding=item['encoding'],
                                         eol=item['eol'], untitled=item.get('untitled', 'Recovered'),
                                         saved_encoding=item.get('saved_encoding'), saved_eol=item.get('saved_eol'))
                if doc.dirty or path is None:
                    docs.append(doc)
                elif path and path.is_file():
                    docs.append(Document.load(path))
            except (OSError, ValueError, KeyError, TypeError):
                continue
        workspace = state.get('workspace')
        return (Path(workspace) if isinstance(workspace, str) and Path(workspace).is_dir() else None), docs


def contained(root: Path, path: Path) -> Path:
    resolved = path.resolve()
    if not resolved.is_relative_to(root.resolve()):
        raise ValueError('This path escapes the workspace (possibly through a symlink).')
    return resolved


def git(root: Path, *args: str, timeout: int = 20) -> str:
    command = ['git', '-c', 'core.hooksPath=' + os.devnull, '-C', str(root), *args]
    result = subprocess.run(command, capture_output=True, timeout=timeout)
    if result.returncode:
        raise RuntimeError(result.stderr.decode('utf-8', 'replace').strip() or 'Git command failed.')
    return result.stdout.decode('utf-8', 'replace')


def git_status(root: Path) -> list[tuple[str, str]]:
    parts = git(root, 'status', '--porcelain=v1', '-z', '--untracked-files=all').split('\0')
    result = []
    i = 0
    while i < len(parts):
        item = parts[i]
        i += 1
        if not item:
            continue
        code, name = item[:2], item[3:]
        result.append((code, name))
        if 'R' in code or 'C' in code:
            i += 1  # porcelain -z emits destination followed by original path
    return result


def project_files(root: Path):
    """Use Git's actual ignore rules when available; fallback excludes build trees."""
    root = root.resolve()
    try:
        names = git(root, 'ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
        paths = (root / name for name in dict.fromkeys(names) if name)
        for path in paths:
            try:
                if path.is_file() and path.resolve().is_relative_to(root):
                    yield path
            except OSError:
                continue
        return
    except (OSError, RuntimeError, subprocess.TimeoutExpired):
        pass
    for directory, dirs, names in os.walk(root, followlinks=False):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not (Path(directory) / d).is_symlink()]
        for name in names:
            path = Path(directory) / name
            if not path.is_symlink():
                yield path


@dataclass
class SearchHit:
    path: Path
    line: int
    column: int
    preview: str


def pattern(query: str, regex: bool = False, case: bool = False, word: bool = False):
    if not query:
        raise ValueError('Enter a search expression.')
    expression = query if regex else re.escape(query)
    if word:
        expression = r'\b(?:' + expression + r')\b'
    return re.compile(expression, 0 if case else re.IGNORECASE)


def search(root: Path, expression, buffers: dict[Path, str] | None = None, limit: int = 1000,
           cancelled=lambda: False) -> tuple[list[SearchHit], bool]:
    hits = []
    buffers = buffers or {}
    for path in project_files(root):
        if cancelled():
            return hits, True
        try:
            resolved = path.resolve()
            text = buffers[resolved] if resolved in buffers else Document.load(path).text
        except (OSError, ValueError):
            continue
        for number, line in enumerate(text.splitlines(), 1):
            if cancelled():
                return hits, True
            for match in expression.finditer(line):
                hits.append(SearchHit(path, number, match.start(), line[:240]))
                if len(hits) >= limit:
                    return hits, True
    return hits, False


@dataclass
class Replacement:
    path: Path
    before: str
    after: str
    baseline: str | None
    count: int


def replacements(root: Path, expression, replacement: str | Callable, documents: list[Document]) -> list[Replacement]:
    buffers = {d.path: d for d in documents if d.path}
    changes = []
    for path in project_files(root):
        path = path.resolve()
        try:
            doc = buffers.get(path) or Document.load(path)
        except (OSError, ValueError):
            continue
        # Invalid replacement expressions must be reported, not silently skipped.
        after, count = expression.subn(replacement, doc.text)
        if count and after != doc.text:
            changes.append(Replacement(path, doc.text, after, doc.baseline, count))
    return changes


def apply_replacement(change: Replacement, document: Document | None = None) -> None:
    if document:
        if document.text != change.before:
            raise ConflictError('The buffer changed after the preview.')
        dirty = document.dirty
        old = document.text
        document.text = change.after
        if not dirty:
            try:
                document.save()
            except Exception:
                document.text = old
                raise
    else:
        doc = Document.load(change.path)
        if doc.baseline != change.baseline:
            raise ConflictError('The file changed after the preview.')
        doc.text = change.after
        doc.save()
