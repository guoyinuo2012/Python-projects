"""the editor's desktop workbench. All UI updates occur on the main Tk thread."""
from __future__ import annotations
import difflib
from concurrent.futures import CancelledError, ThreadPoolExecutor
from dataclasses import replace
import itertools
import json
from pathlib import Path
import queue
import re
import shutil
import sys
import time
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk
import uuid

from .core import (ConflictError, Document, StateStore, apply_replacement, atomic_write,
                   configuration_path, contained, git, git_status, pattern, replacements, search)
from .editor import Editor
from .processes import ProcessSession
from .theme import CODE_FONT, COLORS, UI_FONT
from .performance import DiskMonitor, directory_entries

DEFAULTS = {'font_size':12, 'tab_size':4, 'word_wrap':False}


class CodeEditor(tk.Tk):
    def __init__(self, state_dir=None, restore=True):
        super().__init__()
        self.title('Code editor')
        self.geometry('1280x820')
        self.minsize(960, 600)
        self.configure(bg=COLORS['editor'])
        self.store = StateStore(state_dir)
        self.settings = self.valid_settings(self.store.read('settings.json', {}))
        self.workspace = None
        self.trusted = False
        self.editors = []
        self.counter = 0
        self.events = queue.Queue()
        self.session = ProcessSession()
        self.debugging = False
        self.closing = False
        self.search_generation = 0
        self.search_hits = []
        self.last_active = None
        self.commands = {}
        self.workers = ThreadPoolExecutor(max_workers=2, thread_name_prefix='editor-work')
        self.recovery_worker = ThreadPoolExecutor(max_workers=1, thread_name_prefix='editor-recovery')
        self._recovery_future = None
        self._disk_future = None
        self.disk_monitor = DiskMonitor()
        self._tree_generation = 0
        self._tree_loads = {}
        self._tree_loaded = set()
        self._tab_labels = {}
        self._console_state = None
        self._position_cache = None
        self._title_cache = None
        self.build_styles()
        self.build_ui()
        self.build_commands()
        self.protocol('WM_DELETE_WINDOW', self.close_app)
        if restore:
            workspace, documents = self.store.recover()
            if workspace:
                self.set_workspace(workspace)
            for doc in documents:
                self.add_document(doc)
        if not self.editors:
            self.new_document()
        self.after(60, self.poll)
        self.after(1000, self.checkpoint)
        self.after(2500, self.check_disk)

    @staticmethod
    def valid_settings(value):
        settings = dict(DEFAULTS)
        if isinstance(value, dict):
            for key, lower, upper in [('font_size', 8, 36), ('tab_size', 1, 8)]:
                if type(value.get(key)) is int and lower <= value[key] <= upper:
                    settings[key] = value[key]
            if type(value.get('word_wrap')) is bool:
                settings['word_wrap'] = value['word_wrap']
        return settings

    def build_styles(self):
        style = ttk.Style(self)
        style.theme_use('clam')
        style.configure('.', background=COLORS['panel'], foreground=COLORS['text'], font=UI_FONT)
        style.configure('TFrame', background=COLORS['panel'])
        style.configure('Toolbar.TFrame', background=COLORS['toolbar'])
        style.configure('Toolbar.TLabel', background=COLORS['toolbar'], foreground=COLORS['muted'])
        style.configure('Muted.TLabel', foreground=COLORS['muted'])
        style.configure('TButton', padding=(8, 4), background=COLORS['input'], borderwidth=1,
                        bordercolor=COLORS['border'], relief='flat')
        style.map('TButton', background=[('active', COLORS['hover'])],
                  foreground=[('disabled', COLORS['muted'])])
        style.configure('Toolbutton', padding=(8, 4), background=COLORS['toolbar'],
                        borderwidth=0, relief='flat')
        style.map('Toolbutton', background=[('active', COLORS['hover'])])
        style.configure('TMenubutton', padding=(8, 4), background=COLORS['input'],
                        foreground=COLORS['text'], borderwidth=0)
        style.map('TMenubutton', background=[('active', COLORS['hover'])])
        style.configure('Toolbar.TMenubutton', background=COLORS['toolbar'])
        style.configure('TEntry', fieldbackground=COLORS['input'], foreground=COLORS['text'],
                        insertcolor=COLORS['text'], padding=5, bordercolor=COLORS['border'])
        style.configure('TCheckbutton', padding=2, background=COLORS['panel'])
        style.map('TCheckbutton', background=[('active', COLORS['panel'])])
        style.configure('Treeview', background=COLORS['panel'], fieldbackground=COLORS['panel'],
                        foreground=COLORS['text'], rowheight=24, borderwidth=0)
        style.map('Treeview', background=[('selected', COLORS['selection'])],
                  foreground=[('selected', COLORS['text'])])
        style.configure('TNotebook', background=COLORS['editor'], borderwidth=0)
        style.configure('TNotebook.Tab', padding=(12, 7), background=COLORS['toolbar'],
                        foreground=COLORS['muted'], borderwidth=0)
        style.map('TNotebook.Tab', background=[('selected', COLORS['editor'])],
                  foreground=[('selected', COLORS['text'])])
        style.configure('TPanedwindow', background=COLORS['border'])
        style.configure('TScrollbar', background=COLORS['hover'], troughcolor=COLORS['panel'],
                        borderwidth=0, arrowsize=10, width=12)
        style.configure('TSeparator', background=COLORS['border'])

    def build_ui(self):
        toolbar = ttk.Frame(self, padding=(8, 5), style='Toolbar.TFrame')
        toolbar.pack(fill='x')
        for label, action in [('New file', self.new_document), ('Open folder', self.open_workspace),
                              ('Save', self.save_active)]:
            ttk.Button(toolbar, text=label, style='Toolbutton',
                       command=lambda fn=action: self.safe(fn)).pack(side='left', padx=2)
        ttk.Separator(toolbar, orient='vertical').pack(side='left', fill='y', padx=8)
        self.workspace_label = ttk.Label(toolbar, text='No folder open', style='Toolbar.TLabel', width=22)
        self.workspace_label.pack(side='left', padx=6)
        run_menu = tk.Menu(toolbar, tearoff=False)
        for label, action in [('Run Python file', self.run_python), ('Debug Python file', self.debug_python),
                              ('Run task...', self.run_task)]:
            run_menu.add_command(label=label, command=lambda fn=action: self.safe(fn))
        ttk.Menubutton(toolbar, text='Run', menu=run_menu, style='Toolbar.TMenubutton').pack(side='right', padx=4)
        ttk.Button(toolbar, text='Go to file / command...', style='Toolbutton',
                   command=lambda: self.safe(lambda: self.palette(bool(self.workspace)))).pack(side='right', padx=8)
        ttk.Separator(self).pack(fill='x')
        self.horizontal = ttk.Panedwindow(self, orient='horizontal')
        self.horizontal.pack(fill='both', expand=True)
        self.sidebar = ttk.Notebook(self.horizontal)
        self.horizontal.add(self.sidebar, weight=0)
        self.build_explorer()
        self.build_search()
        self.build_git()
        self.build_outline()
        self.center = ttk.Panedwindow(self.horizontal, orient='vertical')
        self.horizontal.add(self.center, weight=1)
        self.groups = ttk.Panedwindow(self.center, orient='horizontal')
        self.center.add(self.groups, weight=5)
        self.notebooks = []
        self.add_group()
        self.build_console()
        ttk.Separator(self).pack(fill='x')
        statusbar = ttk.Frame(self, padding=(10, 3))
        statusbar.pack(fill='x')
        self.status = tk.StringVar(value='Ready')
        ttk.Label(statusbar, textvariable=self.status, style='Muted.TLabel', width=55).pack(side='left')
        self.position = tk.StringVar()
        ttk.Button(statusbar, text='Output', style='Toolbutton', command=self.toggle_output).pack(side='right', padx=(8, 0))
        ttk.Label(statusbar, textvariable=self.position, style='Muted.TLabel').pack(side='right')
        self.after_idle(self.initial_layout)

    def initial_layout(self):
        self.horizontal.sashpos(0, 260)
        self.center.sashpos(0, max(280, self.center.winfo_height() - 200))

    def add_group(self):
        notebook = ttk.Notebook(self.groups)
        self.groups.add(notebook, weight=1)
        self.notebooks.append(notebook)
        notebook.bind('<<NotebookTabChanged>>', lambda e, n=notebook: self.tab_changed(n))
        notebook.bind('<Button-3>', lambda e: self.tab_menu(e, notebook))
        return notebook

    def build_explorer(self):
        panel = ttk.Frame(self.sidebar, padding=8)
        self.sidebar.add(panel, text='Files')
        row = ttk.Frame(panel)
        row.pack(fill='x', pady=(0, 6))
        new_menu = tk.Menu(row, tearoff=False)
        new_menu.add_command(label='New file', command=lambda: self.safe(lambda: self.create_path(False)))
        new_menu.add_command(label='New folder', command=lambda: self.safe(lambda: self.create_path(True)))
        ttk.Menubutton(row, text='New', menu=new_menu).pack(side='left')
        ttk.Button(row, text='Refresh', command=lambda: self.safe(self.refresh_tree)).pack(side='right')
        tree_frame = ttk.Frame(panel)
        tree_frame.pack(fill='both', expand=True)
        self.tree = ttk.Treeview(tree_frame, show='tree', selectmode='browse')
        scrollbar = ttk.Scrollbar(tree_frame, command=self.tree.yview)
        scrollbar.pack(side='right', fill='y')
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(fill='both', expand=True)
        self.tree.bind('<<TreeviewOpen>>', self.expand_tree)
        self.tree.bind('<Double-1>', self.tree_open)
        self.tree.bind('<Return>', self.tree_open)
        self.tree.bind('<Button-3>', self.tree_menu)
        self.tree_paths = {}

    def build_search(self):
        panel = ttk.Frame(self.sidebar, padding=10)
        self.sidebar.add(panel, text='Search')
        self.query = tk.StringVar()
        self.replace_text = tk.StringVar()
        ttk.Label(panel, text='Workspace search').pack(anchor='w')
        entry = ttk.Entry(panel, textvariable=self.query)
        entry.pack(fill='x', pady=6)
        entry.bind('<Return>', lambda e: self.start_search())
        self.regex, self.match_case, self.whole_word = tk.BooleanVar(), tk.BooleanVar(), tk.BooleanVar()
        options = ttk.Frame(panel)
        options.pack(fill='x')
        for title, var in [('Case', self.match_case), ('Word', self.whole_word), ('Regex', self.regex)]:
            ttk.Checkbutton(options, text=title, variable=var).pack(side='left', padx=(0, 6))
        ttk.Button(panel, text='Search', command=lambda: self.safe(self.start_search)).pack(fill='x', pady=5)
        ttk.Label(panel, text='Replace with', style='Muted.TLabel').pack(anchor='w', pady=(6, 0))
        ttk.Entry(panel, textvariable=self.replace_text).pack(fill='x', pady=5)
        ttk.Button(panel, text='Preview replacement', command=lambda: self.safe(self.preview_replace)).pack(fill='x')
        self.search_label = ttk.Label(panel, text='Up to 1,000 matches')
        self.search_label.pack(anchor='w', pady=8)
        self.results = self.listbox(panel)
        self.results.bind('<Double-1>', self.jump_search)
        self.results.bind('<Return>', self.jump_search)

    def build_git(self):
        panel = ttk.Frame(self.sidebar, padding=10)
        self.sidebar.add(panel, text='Git')
        ttk.Button(panel, text='Refresh status', command=lambda: self.safe(self.refresh_git)).pack(fill='x')
        self.branch_label = ttk.Label(panel, text='Git requires an open workspace')
        self.branch_label.pack(anchor='w', pady=6)
        self.git_entries = []
        actions = ttk.Frame(panel)
        actions.pack(fill='x', pady=6)
        actions.columnconfigure((0, 1), weight=1)
        for index, (label, action) in enumerate([('Diff', 'diff'), ('Staged diff', 'staged'),
                                               ('Stage', 'stage'), ('Unstage', 'unstage')]):
            ttk.Button(actions, text=label, command=lambda value=action: self.safe(lambda: self.git_action(value))).grid(
                row=index // 2, column=index % 2, sticky='ew', padx=2, pady=2)
        ttk.Label(panel, text='Commit message', style='Muted.TLabel').pack(anchor='w')
        self.commit_message = tk.StringVar()
        ttk.Entry(panel, textvariable=self.commit_message).pack(fill='x', pady=5)
        ttk.Button(panel, text='Commit', command=lambda: self.safe(self.commit)).pack(fill='x')
        ttk.Button(panel, text='Branches...', command=lambda: self.safe(self.branches)).pack(fill='x', pady=5)
        self.git_list = self.listbox(panel)
        self.git_list.bind('<Double-1>', lambda event: self.safe(lambda: self.git_action('diff')))

    def build_outline(self):
        panel = ttk.Frame(self.sidebar, padding=10)
        self.sidebar.add(panel, text='Outline')
        ttk.Label(panel, text='Python functions and classes').pack(anchor='w')
        ttk.Button(panel, text='Refresh outline', command=self.refresh_outline).pack(fill='x', pady=6)
        self.outline = self.listbox(panel)
        self.symbols = []
        self.outline.bind('<Double-1>', self.jump_symbol)

    def listbox(self, parent):
        frame = ttk.Frame(parent)
        frame.pack(fill='both', expand=True)
        listing = tk.Listbox(frame, bg=COLORS['panel'], fg=COLORS['text'],
                             font=UI_FONT, selectbackground=COLORS['selection'],
                             borderwidth=0, highlightthickness=0, activestyle='none',
                             exportselection=False)
        scrollbar = ttk.Scrollbar(frame, command=listing.yview)
        scrollbar.pack(side='right', fill='y')
        listing.configure(yscrollcommand=scrollbar.set)
        listing.pack(fill='both', expand=True)
        return listing

    def build_console(self):
        self.console = ttk.Frame(self.center)
        self.center.add(self.console, weight=1)
        self.console_header = ttk.Frame(self.console, padding=(10, 4))
        self.console_header.pack(fill='x')
        ttk.Label(self.console_header, text='Output').pack(side='left')
        self.console_state = tk.StringVar(value='Idle')
        ttk.Label(self.console_header, textvariable=self.console_state, style='Muted.TLabel').pack(side='left', padx=12)
        ttk.Button(self.console_header, text='Hide', style='Toolbutton', command=self.toggle_output).pack(side='right')
        ttk.Button(self.console_header, text='Clear', style='Toolbutton', command=self.clear_console).pack(side='right', padx=4)
        self.stop_button = ttk.Button(self.console_header, text='Stop', style='Toolbutton',
                                      command=lambda: self.safe(self.stop_process), state='disabled')
        self.stop_button.pack(side='right', padx=4)
        self.debug_controls = ttk.Frame(self.console, padding=(8, 2))
        for label, command in [('Continue', 'continue'), ('Step over', 'next'), ('Step into', 'step'),
                               ('Step out', 'return'), ('Stack', 'where'), ('Variables', 'pp locals()')]:
            ttk.Button(self.debug_controls, text=label, style='Toolbutton',
                       command=lambda cmd=command: self.safe(lambda: self.debug_send(cmd))).pack(side='left', padx=2)
        output_frame = ttk.Frame(self.console)
        output_frame.pack(fill='both', expand=True)
        self.output = tk.Text(output_frame, height=7, bg=COLORS['editor'], fg=COLORS['text'],
                              borderwidth=0, highlightthickness=0, font=(CODE_FONT, 10),
                              wrap='word', state='disabled', padx=12, pady=8)
        scrollbar = ttk.Scrollbar(output_frame, command=self.output.yview)
        scrollbar.pack(side='right', fill='y')
        self.output.configure(yscrollcommand=scrollbar.set)
        self.output.pack(fill='both', expand=True)
        self.command_input = tk.StringVar()
        row = ttk.Frame(self.console, padding=(8, 5))
        row.pack(fill='x', side='bottom', before=output_frame)
        ttk.Label(row, text='Command', style='Muted.TLabel').pack(side='left', padx=(0, 8))
        entry = ttk.Entry(row, textvariable=self.command_input, font=(CODE_FONT, 10))
        entry.pack(side='left', fill='x', expand=True)
        entry.bind('<Return>', lambda event: self.safe(self.execute_input))
        self.send_button = ttk.Button(row, text='Run', command=lambda: self.safe(self.execute_input))
        self.send_button.pack(side='right', padx=(6, 0))

    def show_output(self):
        if str(self.console) not in self.center.panes():
            self.center.add(self.console, weight=1)
            self.after_idle(lambda: self.center.sashpos(0, max(280, self.center.winfo_height() - 200)))

    def toggle_output(self):
        if str(self.console) in self.center.panes():
            self.center.forget(self.console)
        else:
            self.show_output()

    def update_console_controls(self):
        busy = self.session.busy
        state = (busy, self.debugging, self.session.running)
        if state == self._console_state:
            return
        self._console_state = state
        self.console_state.set('Debugging' if self.debugging and busy else 'Running' if busy else 'Idle')
        self.stop_button.state(['!disabled'] if busy else ['disabled'])
        self.send_button.configure(text='Send' if self.session.running else 'Run')
        if self.debugging and busy:
            self.debug_controls.pack(fill='x', after=self.console_header)
        else:
            self.debug_controls.pack_forget()

    def build_commands(self):
        self.commands = {
            'New File': self.new_document, 'Open File': self.open_dialog, 'Open Folder': self.open_workspace,
            'Save': self.save_active, 'Save As': lambda: self.save_active(True), 'Save All': self.save_all,
            'Close Tab': self.close_active, 'Split / move tab': self.move_group,
            'Toggle output panel': self.toggle_output,
            'Find / Replace in file': self.find_dialog, 'Go to Line': self.go_line,
            'Quick Open': lambda: self.palette(True), 'Run Python file': self.run_python,
            'Debug Python file': self.debug_python, 'Run Task': self.run_task, 'Stop Process': self.stop_process,
            'Settings': self.settings_dialog, 'Workspace Settings': lambda: self.settings_dialog(True),
            'Refresh Explorer': self.refresh_tree, 'Refresh Git': self.refresh_git,
            'Reload Active File': self.reload_active, 'Toggle Word Wrap': self.toggle_wrap,
            'Select LF line endings': lambda: self.set_eol('\n'),
            'Select CRLF line endings': lambda: self.set_eol('\r\n'),
            'Load declarative extensions': self.load_extensions,
            'Open task configuration': self.open_tasks,
        }
        menubar = tk.Menu(self)
        groups = {'File':['New File','Open File','Open Folder','Save','Save As','Save All','Close Tab'],
                  'Edit':['Find / Replace in file','Go to Line','Reload Active File'],
                  'View':['Quick Open','Split / move tab','Toggle output panel','Toggle Word Wrap','Settings','Workspace Settings'],
                  'Run':['Run Python file','Debug Python file','Run Task','Stop Process','Open task configuration'],
                  'Tools':['Refresh Git','Load declarative extensions','Select LF line endings','Select CRLF line endings']}
        for label, names in groups.items():
            menu = tk.Menu(menubar, tearoff=False)
            for name in names:
                menu.add_command(label=name, command=lambda n=name: self.safe(self.commands[n]))
            menubar.add_cascade(label=label, menu=menu)
        help_menu = tk.Menu(menubar, tearoff=False)
        help_menu.add_command(label='About / Shortcuts', command=lambda: messagebox.showinfo('Code editor',
            'Code editor 1.1.1\n\nCtrl/Cmd+S Save · Ctrl/Cmd+P Quick Open\nCtrl/Cmd+Shift+P Commands\n'
            'Ctrl/Cmd+F Find · Ctrl/Cmd+G Line\nF5 Run · F6 Debug · Ctrl+Space Complete\n'
            'Click line gutter to toggle a Python breakpoint.\n\nStandard-library Tkinter desktop workbench.'))
        menubar.add_cascade(label='Help', menu=help_menu)
        self.configure(menu=menubar)
        modifier = 'Command' if sys.platform == 'darwin' else 'Control'
        bindings = {'n':self.new_document, 'o':self.open_dialog, 's':self.save_active, 'w':self.close_active,
                    'p':lambda: self.palette(True), 'f':self.find_dialog, 'g':self.go_line,
                    'Shift-P':lambda: self.palette(), 'Shift-S':lambda: self.save_active(True)}
        for key, fn in bindings.items():
            self.bind_all(f'<{modifier}-{key}>', lambda e, f=fn: (self.safe(f), 'break')[1])
        self.bind_all('<F5>', lambda e: self.safe(self.run_python))
        self.bind_all('<F6>', lambda e: self.safe(self.debug_python))

    def safe(self, fn):
        try:
            return fn()
        except Exception as exc:
            messagebox.showerror('Code editor', str(exc), parent=self)

    def background(self, fn, done):
        future = self.workers.submit(fn)
        def complete(result):
            try:
                value = result.result()
                if not self.closing:
                    self.events.put(('callback', done, value))
            except CancelledError:
                pass
            except Exception as exc:
                if not self.closing:
                    self.events.put(('error', str(exc)))
        future.add_done_callback(complete)
        return future

    def poll(self):
        if self.closing:
            return
        deadline = time.perf_counter() + 0.012
        for _ in range(30):
            if time.perf_counter() >= deadline:
                break
            try:
                event = self.events.get_nowait()
            except queue.Empty:
                break
            if event[0] == 'callback':
                self.safe(lambda e=event: e[1](e[2]))
            elif event[0] == 'error':
                self.status.set(event[1])
                messagebox.showerror('Code editor', event[1], parent=self)
        chunks = []
        size = 0
        for _ in range(100):
            if size >= 65536 or time.perf_counter() >= deadline:
                break
            try:
                kind, value = self.session.events.get_nowait()
            except queue.Empty:
                break
            if kind == 'output':
                chunks.append(value)
                size += len(value)
            else:
                chunks.append(f'\n[Process exited: {value}]\n')
                self.debugging = False
        if chunks:
            self.append_output(''.join(chunks))
        self.update_console_controls()
        self.after(16 if not self.events.empty() or not self.session.events.empty() else 40, self.poll)

    def active(self):
        focus = self.focus_get()
        for editor in self.editors:
            if focus is editor.text:
                self.last_active = editor
                return editor
        if self.last_active in self.editors:
            return self.last_active
        for notebook in self.notebooks:
            selected = notebook.select()
            for editor in self.editors:
                if str(editor) == selected:
                    return editor
        return None

    def tab_changed(self, notebook):
        selected = notebook.select()
        for editor in self.editors:
            if str(editor) == selected:
                self.last_active = editor
                editor.text.focus_set()
                self.update_status()
                break

    def add_document(self, doc, group=None):
        self.counter += 1
        if not doc.path and doc.untitled == 'Untitled':
            doc.untitled = f'Untitled-{self.counter}'
        group = group or self.notebooks[0]
        editor = Editor(group, doc, self)
        self.editors.append(editor)
        group.add(editor, text=doc.name)
        group.select(editor)
        self.last_active = editor
        editor.text.focus_set()
        self.update_titles()
        return editor

    def new_document(self):
        return self.add_document(Document())

    def documents(self):
        for editor in self.editors:
            editor.sync()
        return [editor.doc for editor in self.editors]

    def open_dialog(self):
        paths = filedialog.askopenfilenames(parent=self, initialdir=self.workspace or Path.home())
        for path in paths:
            self.safe(lambda p=path: self.open_file(Path(p)))

    def open_file(self, path):
        path = path.resolve()
        for editor in self.editors:
            if editor.doc.path == path:
                for notebook in self.notebooks:
                    if str(editor) in notebook.tabs():
                        notebook.select(editor)
                self.last_active = editor
                editor.text.focus_set()
                return editor
        if path.stat().st_size > 2 * 1024 * 1024:
            if not messagebox.askyesno('Large file', 'Open this large file? Highlighting will be disabled.', parent=self):
                return None
        return self.add_document(Document.load(path))

    def update_titles(self):
        for editor in self.editors:
            label = ('● ' if editor.doc.dirty else '') + editor.doc.name
            if self._tab_labels.get(str(editor)) == label:
                continue
            for notebook in self.notebooks:
                if str(editor) in notebook.tabs():
                    notebook.tab(editor, text=label)
                    self._tab_labels[str(editor)] = label
        self.update_status()

    def update_status(self):
        editor = self.active()
        if not editor:
            if self._position_cache != '':
                self.position.set('')
                self._position_cache = ''
            if self._title_cache != 'Code editor':
                self.title('Code editor')
                self._title_cache = 'Code editor'
            return
        row, col = editor.text.index('insert').split('.')
        eol = {'\n':'LF','\r\n':'CRLF','\r':'CR'}[editor.doc.eol]
        position = f'Ln {row}, Col {int(col)+1}  ·  {editor.doc.encoding.upper()}  ·  {eol}'
        if self._position_cache != position:
            self.position.set(position)
            self._position_cache = position
        title = f'{editor.doc.name}{" *" if editor.doc.dirty else ""} — Code editor'
        if self._title_cache != title:
            self.title(title)
            self._title_cache = title

    def save_editor(self, editor, save_as=False):
        editor.sync()
        target = None
        if save_as or not editor.doc.path:
            chosen = filedialog.asksaveasfilename(parent=self, initialdir=self.workspace or Path.home(),
                                                 initialfile=editor.doc.name)
            if not chosen:
                return False
            target = Path(chosen).resolve()
            if any(e is not editor and e.doc.path == target for e in self.editors):
                raise ValueError('That file is already open in another tab.')
        try:
            editor.doc.save(target)
        except ConflictError:
            if not messagebox.askyesno('File changed on disk',
                'Overwrite the newer disk contents with this buffer?', parent=self):
                return False
            editor.doc.save(target, force=True)
        editor.highlight()
        self.update_titles()
        self.status.set(f'Saved {editor.doc.path}')
        if target is not None:
            self.refresh_tree()
        self.checkpoint(schedule=False)
        return True

    def save_active(self, save_as=False):
        editor = self.active()
        return self.save_editor(editor, save_as) if editor else False

    def save_all(self):
        for editor in list(self.editors):
            editor.sync()
            if editor.doc.dirty and not self.save_editor(editor):
                return False
        return True

    def close_editor(self, editor):
        editor.sync()
        if editor.doc.dirty:
            decision = messagebox.askyesnocancel('Unsaved changes', f'Save {editor.doc.name} before closing?', parent=self)
            if decision is None or (decision and not self.save_editor(editor)):
                return False
        self.editors.remove(editor)
        self._tab_labels.pop(str(editor), None)
        for notebook in self.notebooks:
            if str(editor) in notebook.tabs():
                notebook.forget(editor)
        editor.destroy()
        if self.last_active is editor:
            self.last_active = None
        self.checkpoint(schedule=False)
        self.update_status()
        return True

    def close_active(self):
        editor = self.active()
        if editor:
            self.close_editor(editor)

    def tab_menu(self, event, notebook):
        try:
            index = notebook.index(f'@{event.x},{event.y}')
            notebook.select(index)
        except tk.TclError:
            return
        menu = tk.Menu(self, tearoff=False)
        menu.add_command(label='Close tab', command=lambda: self.safe(self.close_active))
        menu.add_command(label='Move to other group', command=lambda: self.safe(self.move_group))
        menu.tk_popup(event.x_root, event.y_root)

    def move_group(self):
        editor = self.active()
        if not editor:
            return
        editor.sync()
        if len(self.notebooks) == 1:
            self.add_group()
        origin = next(n for n in self.notebooks if str(editor) in n.tabs())
        target = next(n for n in self.notebooks if n is not origin)
        # Tk widgets cannot be reparented: recreate this view using the same document.
        doc = editor.doc
        insert = editor.text.index('insert')
        origin.forget(editor)
        self.editors.remove(editor)
        self._tab_labels.pop(str(editor), None)
        editor.destroy()
        new = self.add_document(doc, target)
        new.text.mark_set('insert', insert)
        new.text.see('insert')
        self.status.set('Moved to the other editor group (undo history starts fresh).')

    def reload_active(self):
        editor = self.active()
        if not editor or not editor.doc.path:
            return
        if editor.doc.dirty and not messagebox.askyesno('Reload', 'Discard unsaved changes and reload?', parent=self):
            return
        editor.doc = Document.load(editor.doc.path)
        editor.set_content(editor.doc.text)

    def open_workspace(self):
        chosen = filedialog.askdirectory(parent=self, initialdir=self.workspace or Path.home())
        if chosen:
            self.set_workspace(Path(chosen))

    def set_workspace(self, path):
        self.workspace = path.resolve()
        self.trusted = False
        for label in list(self.commands):
            if label.startswith('Extension: '):
                del self.commands[label]
        self.search_generation += 1
        self.results.delete(0, 'end')
        self.search_hits = []
        self.git_list.delete(0, 'end')
        self.git_entries = []
        self.settings = self.valid_settings(self.store.read('settings.json', {}))
        config = configuration_path(self.workspace, 'settings.json')
        if config.is_file():
            try:
                self.settings = self.valid_settings(dict(self.settings, **json.loads(config.read_text(encoding='utf-8'))))
            except (ValueError, TypeError, OSError):
                self.status.set('Invalid workspace settings; using user settings.')
        self.apply_settings()
        self.workspace_label.configure(text=self.workspace.name)
        self.refresh_tree()

    def require_workspace(self):
        if not self.workspace:
            raise ValueError('Open a project folder first.')
        return self.workspace

    def trust(self):
        root = self.workspace or (self.active().doc.path.parent if self.active() and self.active().doc.path else Path.cwd())
        if not self.trusted:
            if not messagebox.askyesno('Trust local code',
                f'Allow commands and Git to execute with your account permissions?\n\n{root}\n\nOnly trust code you know.', parent=self):
                return False
            self.trusted = True
        return True

    def refresh_tree(self):
        self._tree_generation += 1
        self._tree_loads.clear()
        self._tree_loaded.clear()
        self.tree.delete(*self.tree.get_children())
        self.tree_paths.clear()
        if self.workspace:
            root = self.tree.insert('', 'end', text=self.workspace.name, open=True)
            self.tree_paths[root] = self.workspace
            self.fill_tree(root)

    def fill_tree(self, item):
        path = self.tree_paths.get(item)
        generation = self._tree_generation
        if path is None or item in self._tree_loaded or self._tree_loads.get(item) == generation:
            return
        self._tree_loads[item] = generation

        def scan():
            try:
                return directory_entries(path), None
            except OSError as exc:
                return [], str(exc)

        def loaded(result):
            if generation != self._tree_generation or not self.tree.exists(item):
                return
            entries, error = result
            for child in self.tree.get_children(item):
                self.tree.delete(child)
            if error:
                self._tree_loads.pop(item, None)
                self.status.set(error)
                return

            def insert_batch(offset=0):
                if self.closing or generation != self._tree_generation or not self.tree.exists(item):
                    return
                for entry, directory, symlink in entries[offset:offset + 80]:
                    child = self.tree.insert(item, 'end', text=entry.name)
                    self.tree_paths[child] = entry
                    if directory and not symlink:
                        self.tree.insert(child, 'end', text='Loading...')
                offset += 80
                if offset < len(entries):
                    self.after(16, lambda: insert_batch(offset))
                else:
                    self._tree_loads.pop(item, None)
                    self._tree_loaded.add(item)
            insert_batch()

        self.background(scan, loaded)

    def expand_tree(self, event):
        self.fill_tree(self.tree.focus())

    def selected_path(self):
        items = self.tree.selection()
        return self.tree_paths.get(items[0]) if items else self.workspace

    def tree_open(self, event=None):
        path = self.selected_path()
        if path and path.is_file():
            self.safe(lambda: self.open_file(path))

    def tree_menu(self, event):
        item = self.tree.identify_row(event.y)
        if item:
            self.tree.selection_set(item)
        menu = tk.Menu(self, tearoff=False)
        for title, fn in [('Open', self.tree_open), ('Rename', self.rename_path), ('Move to…', self.move_path),
                          ('Move to recoverable trash', self.trash_path), ('Copy path', self.copy_path),
                          ('New file', lambda: self.create_path(False)), ('New folder', lambda: self.create_path(True))]:
            menu.add_command(label=title, command=lambda f=fn: self.safe(f))
        menu.tk_popup(event.x_root, event.y_root)

    def copy_path(self):
        path = self.selected_path()
        if path:
            self.clipboard_clear()
            self.clipboard_append(str(path))

    def create_path(self, directory):
        root = self.require_workspace()
        parent = self.selected_path() or root
        if not parent.is_dir():
            parent = parent.parent
        name = simpledialog.askstring('Create', 'Relative name:', parent=self)
        if not name:
            return
        path = contained(root, parent / name)
        if path.exists():
            raise ValueError('That path already exists.')
        if directory:
            path.mkdir(parents=True)
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open('x', encoding='utf-8'):
                pass
            self.open_file(path)
        self.refresh_tree()

    def relocate(self, source, destination):
        root = self.require_workspace()
        contained(root, source)
        destination = contained(root, destination)
        if source.resolve() == root:
            raise ValueError('The workspace root cannot be moved.')
        if destination.exists():
            raise ValueError('The destination already exists.')
        if source.is_dir() and destination.is_relative_to(source.resolve()):
            raise ValueError('A folder cannot be moved into itself.')
        affected = [(e, e.doc.path.relative_to(source.resolve())) for e in self.editors
                    if e.doc.path and e.doc.path.is_relative_to(source.resolve())]
        source.rename(destination)
        for editor, relative in affected:
            editor.doc.path = destination / relative
        self.refresh_tree()
        self.update_titles()

    def rename_path(self):
        source = self.selected_path()
        if not source:
            return
        name = simpledialog.askstring('Rename', 'New name:', initialvalue=source.name, parent=self)
        if name:
            self.relocate(source, source.parent / name)

    def move_path(self):
        source = self.selected_path()
        if not source:
            return
        folder = filedialog.askdirectory(parent=self, initialdir=self.workspace)
        if folder:
            self.relocate(source, Path(folder) / source.name)

    def trash_path(self):
        source = self.selected_path()
        if not source:
            return
        root = self.require_workspace()
        contained(root, source)
        if source.resolve() == root:
            raise ValueError('The workspace root cannot be trashed.')
        affected = [e for e in self.editors if e.doc.path and e.doc.path.is_relative_to(source.resolve())]
        if not messagebox.askyesno('Trash', f'Move {source.name} to the editor’s recoverable trash?', parent=self):
            return
        for editor in affected:
            if not self.close_editor(editor):
                return
        trash = self.store.directory / 'trash' / uuid.uuid4().hex
        trash.mkdir(parents=True)
        atomic_write(trash / 'origin.json', json.dumps({'original_path':str(source)}).encode())
        shutil.move(str(source), str(trash / source.name))
        self.refresh_tree()
        self.status.set(f'Moved to {trash}. Restore manually by moving it back.')

    def search_pattern(self):
        return pattern(self.query.get(), self.regex.get(), self.match_case.get(), self.whole_word.get())

    def start_search(self):
        root = self.require_workspace()
        expression = self.search_pattern()
        self.search_generation += 1
        generation = self.search_generation
        buffers = {doc.path: doc.text for doc in self.documents() if doc.path}
        self.search_label.configure(text='Searching…')
        def done(result):
            if generation != self.search_generation:
                return
            hits, truncated = result
            self.search_hits = hits
            self.results.delete(0, 'end')
            if hits:
                self.results.insert('end', *(f'{hit.path.relative_to(root)}:{hit.line}  {hit.preview.strip()}' for hit in hits))
            self.search_label.configure(text=f'{len(hits)} matches' + (' · limit/cancel reached' if truncated else ''))
        self.background(lambda: search(root, expression, buffers, cancelled=lambda: generation != self.search_generation), done)

    def jump_search(self, event=None):
        selected = self.results.curselection()
        if selected:
            hit = self.search_hits[selected[0]]
            editor = self.open_file(hit.path)
            if editor:
                editor.text.mark_set('insert', f'{hit.line}.{hit.column}')
                editor.text.see('insert')

    def preview_replace(self):
        root, expression = self.require_workspace(), self.search_pattern()
        # Snapshot on the main thread; the worker must never access Tk variables.
        docs = [replace(doc) for doc in self.documents()]
        literal = self.replace_text.get()
        replacement = literal if self.regex.get() else lambda match: literal
        self.background(lambda: replacements(root, expression, replacement, docs), self.show_replacements)

    def show_replacements(self, changes):
        if not changes:
            self.status.set('No replacements to apply.')
            return
        content = '\n'.join(''.join(difflib.unified_diff(c.before.splitlines(True), c.after.splitlines(True),
                           fromfile=str(c.path), tofile=str(c.path))) for c in changes)
        window = self.text_window('Replacement preview', content)
        def apply():
            failures = []
            for change in changes:
                editor = next((e for e in self.editors if e.doc.path == change.path), None)
                try:
                    apply_replacement(change, editor.doc if editor else None)
                    if editor:
                        editor.set_content(editor.doc.text)
                except Exception as exc:
                    failures.append(f'{change.path}: {exc}')
            window.destroy()
            self.update_titles()
            self.status.set(f'Applied replacements in {len(changes)-len(failures)} files.')
            if failures:
                self.text_window('Replacement failures (other files remain changed)', '\n'.join(failures))
        ttk.Button(window, text=f'Apply {sum(c.count for c in changes)} replacements in {len(changes)} files',
                   command=lambda: self.safe(apply)).pack(pady=8)

    def text_window(self, title, content):
        window = tk.Toplevel(self)
        window.configure(bg=COLORS['panel'])
        window.title(title)
        window.geometry('850x600')
        text = tk.Text(window, bg=COLORS['editor'], fg=COLORS['text'], font=(CODE_FONT, 11), wrap='none')
        text.pack(fill='both', expand=True, padx=8, pady=8)
        text.insert('1.0', content)
        text.configure(state='disabled')
        return window

    def find_dialog(self):
        editor = self.active()
        if not editor:
            return
        editor.sync()
        window = tk.Toplevel(self)
        window.configure(bg=COLORS['panel'])
        window.title('Find / Replace in file')
        window.geometry('500x260')
        query, replace = tk.StringVar(), tk.StringVar()
        regex, case = tk.BooleanVar(), tk.BooleanVar()
        for title, variable in [('Find', query), ('Replace', replace)]:
            ttk.Label(window, text=title).pack(anchor='w', padx=12)
            ttk.Entry(window, textvariable=variable).pack(fill='x', padx=12, pady=4)
        row = ttk.Frame(window)
        row.pack(fill='x', padx=12)
        ttk.Checkbutton(row, text='Regex', variable=regex).pack(side='left')
        ttk.Checkbutton(row, text='Case sensitive', variable=case).pack(side='left')
        note = ttk.Label(window, text='')
        note.pack(pady=4)
        def find():
            expression = pattern(query.get(), regex.get(), case.get())
            text = editor.doc.text
            editor.text.tag_remove('found', '1.0', 'end')
            matches = list(expression.finditer(text))[:2000]
            for match in matches:
                editor.text.tag_add('found', f'1.0+{match.start()}c', f'1.0+{match.end()}c')
            offset = len(editor.text.get('1.0', 'insert'))
            chosen = next((m for m in matches if m.start() >= offset), matches[0] if matches else None)
            if chosen:
                editor.text.mark_set('insert', f'1.0+{chosen.end()}c')
                editor.text.see(f'1.0+{chosen.start()}c')
            note.configure(text=f'{len(matches)} matches (up to 2,000 highlighted)')
        def apply():
            expression = pattern(query.get(), regex.get(), case.get())
            after, count = expression.subn(replace.get() if regex.get() else lambda m: replace.get(), editor.doc.text)
            if count and messagebox.askyesno('Replace all', f'Replace {count} matches in this buffer?', parent=window):
                editor.text.edit_separator()
                editor.set_content(after)
                editor.text.edit_separator()
                note.configure(text=f'Replaced {count} matches. Save to write to disk.')
        buttons = ttk.Frame(window)
        buttons.pack(pady=8)
        ttk.Button(buttons, text='Find next', command=lambda: self.safe(find)).pack(side='left', padx=5)
        ttk.Button(buttons, text='Replace all', command=lambda: self.safe(apply)).pack(side='left', padx=5)
        def close():
            if editor in self.editors:
                editor.text.tag_remove('found', '1.0', 'end')
            window.destroy()
        window.protocol('WM_DELETE_WINDOW', close)

    def go_line(self):
        editor = self.active()
        if editor:
            line = simpledialog.askinteger('Go to line', 'Line number:', minvalue=1, parent=self)
            if line:
                editor.text.mark_set('insert', f'{line}.0')
                editor.text.see('insert')
                editor.text.focus_set()

    def palette(self, files=False):
        window = tk.Toplevel(self)
        window.configure(bg=COLORS['panel'])
        window.title('Quick Open' if files else 'Command Palette')
        window.geometry('660x430')
        query = tk.StringVar()
        entry = ttk.Entry(window, textvariable=query, font=(UI_FONT[0], 12))
        entry.pack(fill='x', padx=14, pady=14)
        listing = tk.Listbox(window, bg=COLORS['editor'], fg=COLORS['text'], font=UI_FONT, activestyle='none')
        listing.pack(fill='both', expand=True, padx=14, pady=(0, 14))
        choices, filtered = [], []
        def refresh(*args):
            filtered[:] = [c for c in choices if query.get().lower() in c.lower()][:300]
            listing.delete(0, 'end')
            if filtered:
                listing.insert('end', *filtered)
            if filtered:
                listing.selection_set(0)
        def invoke(event=None):
            selected = listing.curselection()
            if selected:
                item = filtered[selected[0]]
                window.destroy()
                self.safe(lambda: self.open_file(root / item) if files else self.commands[item]())
            return 'break'
        query.trace_add('write', refresh)
        listing.bind('<Double-1>', invoke)
        listing.bind('<Return>', invoke)
        entry.bind('<Return>', invoke)
        entry.bind('<Down>', lambda e: listing.focus_set())
        window.bind('<Escape>', lambda e: window.destroy())
        if files:
            root = self.require_workspace()
            from .core import project_files
            def done(items):
                if window.winfo_exists():
                    choices[:] = items
                    refresh()
            self.background(lambda: [str(p.relative_to(root)) for p in itertools.islice(project_files(root), 10000)], done)
        else:
            choices[:] = sorted(self.commands)
            refresh()
        entry.focus_set()

    def refresh_outline(self):
        editor = self.active()
        self.symbols = editor.symbols() if editor else []
        self.outline.delete(0, 'end')
        for name, line in self.symbols:
            self.outline.insert('end', f'{name}  ·  {line}')

    def jump_symbol(self, event=None):
        selected = self.outline.curselection()
        if selected and self.active():
            _, line = self.symbols[selected[0]]
            self.active().text.mark_set('insert', f'{line}.0')
            self.active().text.see('insert')

    def refresh_git(self):
        root = self.require_workspace()
        if not self.trust():
            return
        def done(result):
            if self.workspace != root:
                return
            branch, entries = result
            self.branch_label.configure(text=branch.strip() or 'Detached HEAD')
            self.git_entries = entries
            self.git_list.delete(0, 'end')
            for code, name in entries:
                self.git_list.insert('end', f'{code}  {name}')
        self.background(lambda: (git(root, 'branch', '--show-current'), git_status(root)), done)

    def git_action(self, action):
        root = self.require_workspace()
        if not self.trust():
            return
        selected = self.git_list.curselection()
        if not selected:
            raise ValueError('Select a changed file first.')
        code, name = self.git_entries[selected[0]]
        if action == 'diff' and code == '??':
            self.text_window(f'Untracked: {name}', Document.load(root / name).text)
            return
        args = {'diff':['diff', '--', name], 'staged':['diff', '--cached', '--', name],
                'stage':['add', '--', name], 'unstage':['reset', '-q', 'HEAD', '--', name]}[action]
        def run():
            if action == 'unstage':
                try:
                    git(root, 'rev-parse', '--verify', 'HEAD')
                except RuntimeError:
                    return git(root, 'rm', '--cached', '--', name)
            return git(root, *args)
        def done(output):
            if action in ('diff', 'staged'):
                self.text_window(name + ' — ' + action, output or '(No changes in this diff)')
            else:
                self.refresh_git()
        self.background(run, done)

    def commit(self):
        root = self.require_workspace()
        if not self.trust():
            return
        message = self.commit_message.get().strip()
        if not message:
            raise ValueError('Enter a commit message.')
        def done(output):
            self.append_output(output)
            self.commit_message.set('')
            self.refresh_git()
        self.background(lambda: git(root, 'commit', '-m', message, timeout=60), done)

    def branches(self):
        root = self.require_workspace()
        if not self.trust():
            return
        def choose(output):
            window = self.text_window('Branches', output)
            name = tk.StringVar()
            ttk.Entry(window, textvariable=name).pack(fill='x', padx=12)
            def switch(create):
                branch = name.get().strip()
                if not branch:
                    raise ValueError('Enter a branch name.')
                git(root, 'check-ref-format', '--branch', branch)
                window.destroy()
                self.background(lambda: git(root, 'switch', *(['-c', branch] if create else [branch])),
                                lambda out: self.refresh_git())
            buttons = ttk.Frame(window)
            buttons.pack(pady=8)
            ttk.Button(buttons, text='Switch', command=lambda: self.safe(lambda: switch(False))).pack(side='left', padx=6)
            ttk.Button(buttons, text='Create', command=lambda: self.safe(lambda: switch(True))).pack(side='left', padx=6)
        self.background(lambda: git(root, 'branch', '--list'), choose)

    def append_output(self, value):
        self.output.configure(state='normal')
        # Strip terminal control codes: this console is a stream, not a terminal emulator.
        value = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', str(value))
        self.output.insert('end', value)
        if int(self.output.index('end-1c').split('.')[0]) > 10000:
            self.output.delete('1.0', '2000.0')
        self.output.see('end')
        self.output.configure(state='disabled')

    def clear_console(self):
        self.output.configure(state='normal')
        self.output.delete('1.0', 'end')
        self.output.configure(state='disabled')

    def launch(self, command, cwd=None, env=None, shell=False, debugging=False):
        if self.session.busy:
            raise ValueError('Stop the current process before starting another.')
        if not self.trust():
            return False
        # Drain the previous session before replacing it.
        while not self.session.events.empty():
            kind, value = self.session.events.get_nowait()
            if kind == 'output':
                self.append_output(value)
        self.session = ProcessSession()
        self.session.start(command, cwd or self.workspace or Path.cwd(), env, shell)
        self.debugging = debugging
        self.show_output()
        self.update_console_controls()
        self.append_output('\n$ ' + (command if isinstance(command, str) else ' '.join(command)) + '\n')
        return True

    def execute_input(self):
        command = self.command_input.get()
        if not command.strip():
            return
        if self.session.running:
            self.session.send(command)
            self.append_output(command + '\n')
        else:
            self.launch(command, shell=True)
        self.command_input.set('')

    def stop_process(self):
        self.session.stop()
        self.status.set('Stopping process and its subprocesses…')

    def python_target(self):
        editor = self.active()
        if not editor:
            raise ValueError('Open a Python file first.')
        editor.sync()
        if editor.doc.path is None or editor.doc.dirty:
            if not self.save_editor(editor):
                return None
        if editor.doc.path.suffix.lower() not in ('.py', '.pyw'):
            raise ValueError('Select a .py or .pyw file.')
        return editor

    def run_python(self):
        editor = self.python_target()
        if editor:
            self.launch([sys.executable, '-u', str(editor.doc.path)], self.workspace or editor.doc.path.parent)

    def debug_python(self):
        editor = self.python_target()
        if not editor:
            return
        command = [sys.executable, '-u', '-m', 'pdb']
        for line in sorted(editor.doc.breakpoints):
            command.extend(['-c', f'break {editor.doc.path}:{line}'])
        command.append(str(editor.doc.path))
        self.launch(command, self.workspace or editor.doc.path.parent, debugging=True)

    def debug_send(self, command):
        if not self.debugging or not self.session.running:
            raise ValueError('Start a Python debug session first.')
        self.session.send(command)

    def task_config(self):
        path = configuration_path(self.require_workspace(), 'tasks.json')
        if not path.exists():
            raise ValueError('Use Run → Open task configuration to create a task file first.')
        value = json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(value, dict):
            raise ValueError('Task configuration must be a JSON object.')
        return value

    def open_tasks(self):
        path = configuration_path(self.require_workspace(), 'tasks.json')
        if not path.exists():
            atomic_write(path, json.dumps({'tasks':[{'name':'Tests','command':f'"{sys.executable}" -m unittest discover -s tests',
                'cwd':'.','env':{}}], 'launches':[{'name':'Python: main','program':'main.py',
                'python':sys.executable,'args':[]}]}, indent=2).encode())
        self.open_file(path)
        self.refresh_tree()

    def run_task(self):
        root = self.require_workspace()
        config = self.task_config()
        entries = [('Task', t) for t in config.get('tasks', [])] + [('Debug', t) for t in config.get('launches', [])]
        if not entries:
            raise ValueError('No tasks or launches are configured.')
        window = tk.Toplevel(self)
        window.configure(bg=COLORS['panel'])
        window.title('Choose task / debug launch')
        for kind, item in entries:
            def start(k=kind, task=item):
                cwd = contained(root, root / task.get('cwd', '.'))
                if not cwd.is_dir():
                    raise ValueError('Task working directory does not exist.')
                env = task.get('env', {})
                if not isinstance(env, dict) or any(not isinstance(k, str) or not isinstance(v, str) for k, v in env.items()):
                    raise ValueError('Task env must map strings to strings.')
                if k == 'Task':
                    command = task['command']
                    if not isinstance(command, str) or not command:
                        raise ValueError('Task command must be a nonempty string.')
                    launched = self.launch(command, cwd, env, shell=True)
                else:
                    program = contained(root, root / task['program'])
                    args = task.get('args', [])
                    if not isinstance(args, list) or not all(isinstance(a, str) for a in args):
                        raise ValueError('Launch args must be a list of strings.')
                    python = task.get('python', sys.executable)
                    if not isinstance(python, str):
                        raise ValueError('Interpreter must be a string.')
                    if not self.save_all():
                        return
                    command = [python, '-u', '-m', 'pdb']
                    for editor in self.editors:
                        if editor.doc.path:
                            for line in sorted(editor.doc.breakpoints):
                                command.extend(['-c', f'break {editor.doc.path}:{line}'])
                    command += [str(program), *args]
                    launched = self.launch(command, cwd, env, debugging=True)
                if launched:
                    window.destroy()
            ttk.Button(window, text=f'{kind}: {item.get("name", "Unnamed")}',
                       command=lambda f=start: self.safe(f)).pack(fill='x', padx=16, pady=6)

    def settings_dialog(self, workspace=False):
        path = configuration_path(self.require_workspace(), 'settings.json') if workspace else self.store.directory / 'settings.json'
        window = tk.Toplevel(self)
        window.configure(bg=COLORS['panel'])
        window.title('Workspace settings' if workspace else 'User settings')
        window.geometry('500x370')
        ttk.Label(window, text='font_size: 8–36  ·  tab_size: 1–8  ·  word_wrap: true/false').pack(padx=10, pady=10)
        text = tk.Text(window, bg=COLORS['editor'], fg=COLORS['text'], insertbackground='white', font=(CODE_FONT, 12))
        text.pack(fill='both', expand=True, padx=10)
        text.insert('1.0', json.dumps(self.settings, indent=2))
        def save():
            value = json.loads(text.get('1.0', 'end-1c'))
            validated = self.valid_settings(value)
            if (not isinstance(value, dict) or value != validated
                    or any(type(value.get(k)) is not type(v) for k, v in validated.items())):
                raise ValueError('Use exactly the three documented settings with valid values.')
            atomic_write(path, json.dumps(validated, indent=2).encode())
            self.settings = validated
            self.apply_settings()
            window.destroy()
        ttk.Button(window, text='Save settings', command=lambda: self.safe(save)).pack(pady=10)

    def apply_settings(self):
        for editor in self.editors:
            editor.apply_settings()

    def toggle_wrap(self):
        self.settings['word_wrap'] = not self.settings['word_wrap']
        self.apply_settings()

    def set_eol(self, eol):
        editor = self.active()
        if editor:
            editor.doc.eol = eol
            self.status.set('Line ending selected; use Save to write it to disk.')
            self.update_titles()

    def load_extensions(self):
        root = self.require_workspace()
        directory = configuration_path(root, 'extensions')
        count = 0
        if directory.is_dir():
            for manifest in directory.glob('*/manifest.json'):
                value = json.loads(manifest.read_text(encoding='utf-8'))
                for command in value.get('commands', []):
                    title, message = command['title'], command['message']
                    if not isinstance(title, str) or not isinstance(message, str):
                        raise ValueError('Extension command title/message must be strings.')
                    label = f'Extension: {value.get("name", manifest.parent.name)} / {title}'
                    self.commands[label] = lambda m=message: self.append_output(m + '\n')
                    count += 1
                theme = value.get('theme', {})
                if theme:
                    background, foreground = theme.get('background', COLORS['editor']), theme.get('foreground', COLORS['text'])
                    self.winfo_rgb(background)
                    self.winfo_rgb(foreground)
                    for editor in self.editors:
                        editor.text.configure(background=background, foreground=foreground)
        self.status.set(f'Loaded {count} declarative extension commands. Theme changes are session-only.')

    def checkpoint(self, schedule=True):
        if self.closing:
            return
        if self._recovery_future is None or self._recovery_future.done():
            # Copies contain plain Python data; the writer never touches Tk.
            documents = [replace(doc) for doc in self.documents()]
            self._recovery_future = self.recovery_worker.submit(self.store.checkpoint, documents, self.workspace)
            def completed(future):
                try:
                    future.result()
                except CancelledError:
                    pass
                except OSError as exc:
                    if not self.closing:
                        self.events.put(('callback', lambda message: self.status.set(message),
                                         f'Recovery write failed: {exc}'))
            self._recovery_future.add_done_callback(completed)
        if schedule:
            self.after(1000, self.checkpoint)

    def check_disk(self):
        if self.closing:
            return
        if self._disk_future is None or self._disk_future.done():
            snapshots = [(doc.path, doc.baseline, doc.name) for doc in self.documents() if doc.path]
            def done(result):
                current = {doc.path: doc.baseline for doc in self.documents() if doc.path}
                for path, baseline, name in snapshots:
                    if path in result and path in current and current[path] == baseline and result[path] != baseline:
                        self.status.set(f'{name} changed on disk. Reload or review it before saving.')
            self._disk_future = self.background(lambda: self.disk_monitor.scan([path for path, _, _ in snapshots]), done)
        self.after(2500, self.check_disk)

    def close_app(self):
        self.documents()
        if any(e.doc.dirty for e in self.editors):
            result = messagebox.askyesnocancel('Close Code editor',
                'Save all changes before closing?\nYes: save all · No: keep unsaved buffers for recovery · Cancel: stay open', parent=self)
            if result is None:
                return
            if result:
                try:
                    if not self.save_all():
                        return
                except Exception as exc:
                    messagebox.showerror('Save failed', str(exc), parent=self)
                    return
        if self.session.busy and not messagebox.askyesno('Running process', 'Stop the running process and close?', parent=self):
            return
        try:
            if self._recovery_future is not None:
                try:
                    self._recovery_future.result()
                except OSError:
                    pass  # Retry with the final, current snapshot below.
            self.store.checkpoint(self.documents(), self.workspace)
        except OSError as exc:
            messagebox.showerror('Recovery failed', f'Could not save recovery: {exc}\nPlease save your files first.', parent=self)
            return
        thread = self.session.stop()
        if thread:
            thread.join(timeout=8)
        self.closing = True
        self.destroy()

    def destroy(self):
        self.closing = True
        for job in self.tk.call('after', 'info'):
            self.after_cancel(job)
        self.workers.shutdown(wait=False, cancel_futures=True)
        self.recovery_worker.shutdown(wait=True, cancel_futures=True)
        super().destroy()


def main():
    app = CodeEditor()
    if len(sys.argv) > 1:
        path = Path(sys.argv[1]).resolve()
        if path.is_dir():
            app.set_workspace(path)
        else:
            app.open_file(path)
    app.mainloop()
    return 0
