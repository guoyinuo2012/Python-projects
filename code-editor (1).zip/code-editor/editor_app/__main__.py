"""Use the same diagnostic launcher for python -m editor_app."""
from code_editor import main
raise SystemExit(main())
