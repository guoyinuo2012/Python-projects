"""Shared colors and fonts for the desktop interface."""
import sys

COLORS = {
    'editor': '#1e1e1e',
    'panel': '#252526',
    'toolbar': '#2d2d30',
    'border': '#3c3c3c',
    'text': '#d4d4d4',
    'muted': '#969696',
    'input': '#313131',
    'selection': '#3a4b5b',
    'hover': '#383838',
    'accent': '#75a9d2',
}
UI_FONT = ('Segoe UI' if sys.platform == 'win32' else 'Helvetica' if sys.platform == 'darwin' else 'DejaVu Sans', 10)
CODE_FONT = 'Consolas' if sys.platform == 'win32' else 'Menlo' if sys.platform == 'darwin' else 'DejaVu Sans Mono'
