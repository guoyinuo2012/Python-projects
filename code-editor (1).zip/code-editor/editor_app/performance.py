"""Pure helpers for background work and bounded UI updates."""
from __future__ import annotations

import hashlib
import io
import keyword
import os
from pathlib import Path
import re
import tokenize

SYNTAX_TAGS = ('keyword', 'string', 'comment', 'number')
GENERIC_SYNTAX = {
    'string': re.compile(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\''),
    'comment': re.compile(r'(?m)//[^\n]*|/\*[\s\S]*?\*/|#[^\n]*|<!--[^>]*-->'),
    'number': re.compile(r'\b\d+(?:\.\d+)?\b'),
    'keyword': re.compile(r'\b(?:function|const|let|var|class|return|if|else|for|while|import|from|export|true|false|null)\b'),
}


def syntax_spans(text: str, extension: str) -> list[tuple[str, str, str]]:
    """Tokenize a snapshot without calling Tk. Large files remain plain text."""
    if len(text) > 300_000:
        return []
    spans = []
    if extension in ('.py', '.pyw'):
        token_tags = {tokenize.STRING: 'string', tokenize.COMMENT: 'comment', tokenize.NUMBER: 'number'}
        try:
            for token in tokenize.generate_tokens(io.StringIO(text).readline):
                tag = token_tags.get(token.type)
                if token.type == tokenize.NAME and keyword.iskeyword(token.string):
                    tag = 'keyword'
                if tag:
                    spans.append((tag, f'{token.start[0]}.{token.start[1]}', f'{token.end[0]}.{token.end[1]}'))
        except (tokenize.TokenError, IndentationError, SyntaxError):
            pass  # Keep useful spans while the user is midway through an edit.
    else:
        for tag, expression in GENERIC_SYNTAX.items():
            spans.extend((tag, f'1.0+{match.start()}c', f'1.0+{match.end()}c')
                         for match in expression.finditer(text))
    return spans


class ScrollMotion:
    """Accumulate wheel input and approach the target without overshooting."""
    def __init__(self):
        self.target: float | None = None

    def add(self, current: float, amount: float, maximum: float) -> None:
        base = current if self.target is None else self.target
        self.target = min(maximum, max(0.0, base + amount))

    def step(self, current: float) -> tuple[float, bool]:
        if self.target is None:
            return current, False
        distance = self.target - current
        if abs(distance) < 0.00001:
            value = self.target
            self.target = None
            return value, False
        return current + distance * 0.35, True

    def reset(self) -> None:
        self.target = None


def directory_entries(path: Path) -> list[tuple[Path, bool, bool]]:
    with os.scandir(path) as entries:
        result = [(Path(entry.path), entry.is_dir(), entry.is_symlink())
                  for entry in entries if entry.name not in {'.git', '__pycache__'}]
    return sorted(result, key=lambda item: (not item[1], item[0].name.lower()))


class DiskMonitor:
    """Hash files only when their disk metadata changes; run on one worker."""
    def __init__(self):
        self._cache: dict[Path, tuple[tuple[int, ...], str]] = {}

    def scan(self, paths: list[Path]) -> dict[Path, str | None]:
        active = set(paths)
        self._cache = {path: value for path, value in self._cache.items() if path in active}
        results = {}
        for path in paths:
            try:
                info = path.stat()
                signature = (info.st_mtime_ns, info.st_ctime_ns, info.st_size, info.st_ino)
                cached = self._cache.get(path)
                if cached and cached[0] == signature:
                    results[path] = cached[1]
                    continue
                digest = hashlib.sha256()
                with path.open('rb') as stream:
                    for chunk in iter(lambda: stream.read(65536), b''):
                        digest.update(chunk)
                value = digest.hexdigest()
                self._cache[path] = (signature, value)
                results[path] = value
            except FileNotFoundError:
                self._cache.pop(path, None)
                results[path] = None
            except OSError:
                continue
        return results
