"""Tk text editor with line numbers, syntax tags, indentation and completion."""
from __future__ import annotations
import ast
import keyword
import re
import sys
import tkinter as tk
from tkinter import font as tkfont
from tkinter import ttk
from .core import Document
from .theme import CODE_FONT, COLORS
from .performance import SYNTAX_TAGS, ScrollMotion, syntax_spans


class Editor(ttk.Frame):
    def __init__(self, parent, doc: Document, app):
        super().__init__(parent)
        self.doc, self.app = doc, app
        self._highlight_job = None
        self._sync_job = None
        self._paint_job = None
        self._gutter_job = None
        self._scroll_job = None
        self._highlight_future = None
        self._version = 0
        self._pending_changes = False
        self._closed = False
        self.motion = ScrollMotion()
        self.gutter = tk.Canvas(self, width=52, bg=COLORS['editor'], highlightthickness=0)
        self.gutter.pack(side='left', fill='y')
        self.text = tk.Text(self, undo=True, maxundo=500, wrap='none', borderwidth=0,
                            padx=12, pady=8, background=COLORS['editor'], foreground=COLORS['text'],
                            insertbackground=COLORS['text'], selectbackground=COLORS['selection'],
                            highlightthickness=0, font=(CODE_FONT, app.settings.get('font_size', 12)))
        vertical = ttk.Scrollbar(self, orient='vertical', command=self.scroll)
        vertical.pack(side='right', fill='y')
        horizontal = ttk.Scrollbar(self, orient='horizontal', command=self.text.xview)
        horizontal.pack(side='bottom', fill='x')
        self.text.pack(fill='both', expand=True)
        self.text.configure(yscrollcommand=lambda a, b: (vertical.set(a, b), self.draw_gutter()),
                            xscrollcommand=horizontal.set)
        self.text.insert('1.0', doc.text)
        self.text.edit_modified(False)
        for name, color in {'keyword':'#569cd6', 'string':'#ce9178', 'comment':'#6a9955',
                            'number':'#b5cea8'}.items():
            self.text.tag_configure(name, foreground=color)
        self.text.tag_configure('found', background='#51412d')
        self.text.bind('<<Modified>>', self.modified)
        self.text.bind('<Configure>', lambda e: self.draw_gutter())
        self.text.bind('<KeyRelease>', lambda e: app.update_status())
        self.text.bind('<ButtonRelease-1>', lambda e: app.update_status())
        self.text.bind('<Tab>', self.indent)
        self.text.bind('<Shift-Tab>', lambda e: self.indent(e, True))
        self.text.bind('<ISO_Left_Tab>', lambda e: self.indent(e, True))
        self.text.bind('<Return>', self.newline)
        self.text.bind('<Control-space>', self.complete)
        self.gutter.bind('<Button-1>', self.breakpoint)
        for widget in (self.text, self.gutter):
            widget.bind('<MouseWheel>', self.wheel)
            widget.bind('<Button-4>', self.wheel)
            widget.bind('<Button-5>', self.wheel)
        self.text.bind('<KeyPress>', lambda event: self.cancel_scroll())
        self.text.bind('<Button-1>', lambda event: self.cancel_scroll())
        self.apply_settings()
        self.highlight()

    def apply_settings(self):
        font = (CODE_FONT, self.app.settings['font_size'])
        metrics = tkfont.Font(font=font)
        self.line_height = metrics.metrics('linespace')
        tab_width = metrics.measure(' ' * self.app.settings['tab_size'])
        self.text.configure(font=font, tabs=(tab_width,),
                            wrap='word' if self.app.settings['word_wrap'] else 'none')
        self.draw_gutter()

    def cancel_scroll(self):
        if self._scroll_job:
            self.after_cancel(self._scroll_job)
            self._scroll_job = None
        self.motion.reset()

    def scroll(self, *args):
        self.cancel_scroll()
        self.text.yview(*args)
        self.draw_gutter()

    def wheel(self, event):
        first, last = self.text.yview()
        if getattr(event, 'num', None) in (4, 5):
            units = -3 if event.num == 4 else 3
        elif sys.platform == 'darwin':
            units = -event.delta
        else:
            units = -event.delta / 120 * 3
        amount = units * self.line_height * (last - first) / max(1, self.text.winfo_height())
        self.motion.add(first, amount, max(0, 1 - (last - first)))
        if self._scroll_job is None:
            self._scroll_job = self.after(16, self.scroll_frame)
        return 'break'

    def scroll_frame(self):
        self._scroll_job = None
        current = self.text.yview()[0]
        value, more = self.motion.step(current)
        self.text.yview_moveto(value)
        if more and self.text.yview()[0] == current:
            # Text view positions round to pixels; finish rather than spin forever.
            self.text.yview_moveto(self.motion.target)
            self.motion.reset()
            more = False
        if more:
            self._scroll_job = self.after(16, self.scroll_frame)

    def draw_gutter(self):
        if not self._closed and self._gutter_job is None:
            self._gutter_job = self.after(16, self.paint_gutter)

    def paint_gutter(self):
        self._gutter_job = None
        self.gutter.delete('all')
        index = self.text.index('@0,0')
        while True:
            info = self.text.dlineinfo(index)
            if info is None:
                break
            line = int(index.split('.')[0])
            y = info[1]
            self.gutter.create_text(44, y + 2, text=str(line), anchor='ne', fill=COLORS['muted'],
                                    font=(CODE_FONT, self.app.settings.get('font_size', 12)))
            if line in self.doc.breakpoints:
                self.gutter.create_oval(5, y + 3, 15, y + 13, fill='#ed6d7c', outline='')
            following = self.text.index(index + '+1line')
            if following == index:
                break
            index = following

    def breakpoint(self, event):
        line = int(self.text.index(f'@0,{event.y}').split('.')[0])
        if line in self.doc.breakpoints:
            self.doc.breakpoints.remove(line)
        else:
            self.doc.breakpoints.add(line)
        self.draw_gutter()
        self.app.status.set('Breakpoint changed. Start a new debug session to apply it.')

    def modified(self, event=None):
        if not self.text.edit_modified():
            return
        self.text.edit_modified(False)
        self._version += 1
        self._pending_changes = True
        if self._sync_job is None:
            self._sync_job = self.after(40, self.flush_changes)
        if self._highlight_job:
            self.after_cancel(self._highlight_job)
        if self._highlight_future:
            self._highlight_future.cancel()
        if self._paint_job:
            self.after_cancel(self._paint_job)
            self._paint_job = None
        self._highlight_job = self.after(160, self.highlight)

    def sync(self):
        """Flush queued edits immediately before saves, closes and snapshots."""
        if self.text.edit_modified():
            self._version += 1
            self._pending_changes = True
            self.text.edit_modified(False)
        if self._pending_changes:
            self.doc.text = self.text.get('1.0', 'end-1c')
            self._pending_changes = False
        if self._sync_job:
            self.after_cancel(self._sync_job)
            self._sync_job = None

    def flush_changes(self):
        self._sync_job = None
        self.sync()
        self.app.update_titles()

    def set_content(self, content):
        self._version += 1
        self.text.delete('1.0', 'end')
        self.text.insert('1.0', content)
        self.doc.text = content
        self._pending_changes = False
        self.text.edit_modified(False)
        self.highlight()
        self.app.update_titles()

    def highlight(self):
        if self._highlight_job:
            self.after_cancel(self._highlight_job)
        self._highlight_job = None
        self.sync()
        version, snapshot = self._version, self.doc.text
        extension = self.doc.path.suffix.lower() if self.doc.path else '.py'
        if self._highlight_future:
            self._highlight_future.cancel()

        def ready(spans):
            if self._closed or version != self._version:
                return
            if self._paint_job:
                self.after_cancel(self._paint_job)
                self._paint_job = None
            for tag in SYNTAX_TAGS:
                self.text.tag_remove(tag, '1.0', 'end')

            def paint_batch(offset=0):
                self._paint_job = None
                if self._closed or version != self._version:
                    return
                grouped = {}
                for tag, start, end in spans[offset:offset + 240]:
                    grouped.setdefault(tag, []).extend((start, end))
                for tag, indices in grouped.items():
                    self.text.tag_add(tag, *indices)
                offset += 240
                if offset < len(spans):
                    self._paint_job = self.after(8, lambda: paint_batch(offset))
            paint_batch()
            self.draw_gutter()

        self._highlight_future = self.app.background(lambda: syntax_spans(snapshot, extension), ready)

    def indent(self, event=None, unindent=False):
        size = self.app.settings.get('tab_size', 4)
        spaces = ' ' * size
        try:
            first = int(self.text.index('sel.first').split('.')[0])
            end = self.text.index('sel.last')
            last, col = map(int, end.split('.'))
            if col == 0 and last > first:
                last -= 1
        except tk.TclError:
            first = last = int(self.text.index('insert').split('.')[0])
            if not unindent:
                self.text.insert('insert', spaces)
                return 'break'
        self.text.edit_separator()
        for line in range(first, last + 1):
            index = f'{line}.0'
            if unindent:
                value = self.text.get(index, index + f'+{size}c')
                count = 1 if value.startswith('\t') else len(value) - len(value.lstrip(' '))
                self.text.delete(index, index + f'+{count}c')
            else:
                self.text.insert(index, spaces)
        self.text.edit_separator()
        return 'break'

    def newline(self, event):
        try:
            self.text.delete('sel.first', 'sel.last')
        except tk.TclError:
            pass
        before = self.text.get('insert linestart', 'insert')
        indent = re.match(r'\s*', before).group()
        if before.rstrip().endswith((':', '{', '[')):
            indent += ' ' * self.app.settings.get('tab_size', 4)
        self.text.insert('insert', '\n' + indent)
        return 'break'

    def complete(self, event=None):
        self.sync()
        prefix = re.search(r'[A-Za-z_]\w*$', self.text.get('insert linestart', 'insert'))
        if not prefix:
            return 'break'
        prefix = prefix.group()
        words = set(keyword.kwlist) | set(re.findall(r'\b[A-Za-z_]\w*\b', self.doc.text))
        choices = sorted(w for w in words if w.startswith(prefix) and w != prefix)[:30]
        if choices:
            menu = tk.Menu(self, tearoff=False)
            for word in choices:
                menu.add_command(label=word, command=lambda w=word: self.text.insert('insert', w[len(prefix):]))
            box = self.text.bbox('insert')
            if box:
                menu.tk_popup(self.text.winfo_rootx() + box[0], self.text.winfo_rooty() + box[1] + box[3])
        return 'break'

    def symbols(self):
        self.sync()
        try:
            tree = ast.parse(self.doc.text)
            return [(node.name, node.lineno) for node in ast.walk(tree)
                    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))]
        except SyntaxError:
            return []

    def destroy(self):
        self._closed = True
        for name in ('_highlight_job', '_sync_job', '_paint_job', '_gutter_job', '_scroll_job'):
            job = getattr(self, name)
            if job:
                self.after_cancel(job)
                setattr(self, name, None)
        if self._highlight_future:
            self._highlight_future.cancel()
        super().destroy()
