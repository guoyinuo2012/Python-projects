"""Code editor: a standard-library Python desktop workbench."""
__version__ = '1.1.1'
