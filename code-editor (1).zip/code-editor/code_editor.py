#!/usr/bin/env python3
"""Launch Code editor and keep startup failures visible when opened from Explorer."""
import os
from pathlib import Path
import sys
import tempfile
import traceback


def report_startup_error(error):
    details = traceback.format_exc()
    log_path = Path(tempfile.gettempdir()) / 'code-editor-startup-error.log'
    try:
        log_path.write_text(details, encoding='utf-8')
        log_note = 'Full error saved to: {}'.format(log_path)
    except OSError:
        log_note = 'The error log could not be saved.'
    message = (
        'Code editor could not start.\n\n{}: {}\n\n'
        'Extract the ENTIRE ZIP before opening the app. Keep code_editor.py\n'
        'beside the editor_app folder. Python 3.10+ with Tcl/Tk is required.\n\n{}'
    ).format(type(error).__name__, error, log_note)
    stream = sys.stderr or sys.stdout
    if stream is not None:
        try:
            stream.write(message + '\n\n' + details)
            stream.flush()
        except (OSError, UnicodeError):
            pass
    if os.name == 'nt' and not os.environ.get('CODE_EDITOR_FROM_BATCH'):
        # Also works with pythonw.exe, missing Tk, or a broken package import.
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, message, 'Code editor startup error', 0x10)
        except (AttributeError, OSError):
            pass
    if (os.name == 'nt' and not os.environ.get('CODE_EDITOR_FROM_BATCH')
            and sys.stdin is not None and sys.stdin.isatty()):
        try:
            input('\nPress Enter to close this window...')
        except (EOFError, OSError):
            pass
    return 1


def main():
    try:
        if sys.version_info < (3, 10):
            raise RuntimeError('Python 3.10 or newer is required. Current version: ' + sys.version.split()[0])
        from editor_app.app import main as run_editor
        return run_editor()
    except Exception as error:
        return report_startup_error(error)


if __name__ == '__main__':
    raise SystemExit(main())
