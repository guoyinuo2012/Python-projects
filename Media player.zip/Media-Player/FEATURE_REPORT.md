# Feature and validation report

Validation date: 14 October 2026 (UTC)

## Implemented and tested in this environment

- Playlist identity, reordering, current-item removal behavior, sequential
  navigation, repeat-one/all, and non-repeating shuffle cycles.
- M3U/M3U8, PLS, and XSPF parsing/writing, relative paths, URLs, spaces, and
  Unicode metadata.
- Settings validation, atomic writes, malformed-file recovery, recent-history
  deduplication/bounds, resume validation, changed-file detection, and near-end
  cleanup.
- Path/URL normalization, file URIs, Unicode paths, supported folder filtering,
  and symlink-loop avoidance.
- Playback state transitions and stale-generation event rejection.
- Conversion destination protection and VLC conversion/stream argument building.
- PySide6 main-window construction, exact top-level menu order, file-to-playback
  orchestration with a mocked engine, seek synchronization, playlist switching,
  fullscreen entry/exit, clean close, and controller release.
- First-run environment path selection, dependency fingerprinting, package
  probing, and source-launcher missing-package diagnostics.
- Persistent playlist restoration and per-media bookmarks with validated bounds.
- Duplicate/missing playlist cleanup, source copying, local-folder opening, and
  subtitle drag-and-drop routing.
- Playback-rate presets, stop-after-current, quit-at-end, and cancelable sleep
  timers.
- Windows VLC DLL discovery retains the required search-directory handle until
  shutdown instead of allowing it to expire before python-vlc loads.
- Python bytecode compilation for every source and test module.

Test command and result:

```text
QT_QPA_PLATFORM=offscreen python -m pytest -q
45 passed, 1 skipped
```

The GUI smoke tests ran with PySide6 6.12.0 on Linux using Qt's offscreen
platform. An 860×560 rendering was inspected for clipping, alignment, control
order, placeholder scaling, and readable contrast.

## Implemented but unverified here

The native libVLC runtime was not installed in the execution environment.
`python-vlc` was installed, but its probe correctly reported that
`libvlc_get_version` was unavailable. Therefore these implementation paths are
present but were not falsely marked as live-tested:

- Real audio/video open, play, pause, stop, seek, rate, end-of-media, and error
  events.
- Windows/macOS/Linux native video-surface embedding.
- Audio, video, and subtitle track selection.
- External subtitle loading and audio/subtitle delay.
- Output device enumeration and stereo channel changes.
- Equalizer preset, preamp, and band application.
- Aspect, crop, zoom, deinterlacing, frame step, and snapshots.
- Disc, capture-device, and real network-stream playback.
- VLC-process conversion and streaming.
- Close during active real playback or an actual conversion process.

The included integration test creates a one-second PCM WAV file and exercises
real open/play/pause/stop/volume/mute when libVLC exists. It was the one skipped
test in this environment.

## Partially implemented

- Video effects: portable menu-level aspect/crop/zoom/deinterlace controls are
  implemented; VLC's complete filter-chain UI is not recreated because filter
  availability differs by runtime.
- Preferences: application-owned settings are implemented. The thousands of
  internal VLC advanced preferences are not duplicated.
- Conversion/streaming: conservative profiles, cancellation, status, and output
  safety are implemented. Accurate percentage progress is unavailable from the
  selected VLC process interface, so the display is intentionally indeterminate.
- Subtitle font preference is persisted; some libVLC subtitle appearance
  changes require reopening media and are reported as such in the dialog.

## Explicitly unavailable through the chosen stack

- Portable in-session VLC record toggle.
- Renderer discovery/control across all target runtimes.
- Video-as-wallpaper.
- VLC VLM administration, electronic program guide, Lua plugins/extensions,
  VLsub, and alternate interfaces.
- Runtime toolbar layout editing and an automatic update service.
- An undocked playlist window; the docked playlist avoids cross-platform video
  ownership/detachment errors.

Every corresponding menu item presents this limitation; none is a silent no-op.

## Visual differences and unverified platforms

- The target is VLC 3.0.21 on Windows 64-bit at 100% scaling. This environment
  could not run Windows or the reference executable, so same-OS screenshot
  overlays and difference images were blocked.
- Windows title-bar metrics, Segoe UI rasterization, native menu shadows, and
  Windows hover/pressed rendering remain unverified.
- macOS and Windows live appearance and video embedding remain unverified.
- System-native widget rendering varies by operating system and Qt version.
- A newly drawn geometric placeholder replaces VLC's trademarked cone artwork,
  so it is intentionally not a pixel copy.
- Initial size and compact control dimensions are documented implementation
  choices because the official reference material did not specify normative
  pixel measurements.

No claim of “100% identical,” universal codec support, or testing on every
operating system is made.

