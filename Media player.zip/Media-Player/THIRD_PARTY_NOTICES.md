# Third-party notices

Media Player's original source is licensed under the MIT License. The
following dependencies are installed separately and are not copied into this
source archive.

## PySide6 and Qt

PySide6 is the Qt for Python binding supplied by The Qt Company. Qt modules are
available under commercial and open-source licenses, commonly LGPLv3/GPLv3 for
the modules used here. Distributors must select an appropriate license and meet
its obligations, including relinking and notice/source obligations where
applicable.

- https://doc.qt.io/qtforpython-6/licenses.html
- https://www.qt.io/licensing/open-source-lgpl-obligations

## python-vlc

python-vlc is the Python binding for libVLC. Consult the package distribution
for its current license text and notices.

- https://pypi.org/project/python-vlc/
- https://github.com/oaubert/python-vlc

## VLC and libVLC

VLC media player and libVLC are produced by VideoLAN. This project controls an
independently installed libVLC runtime and does not bundle VLC binaries. VLC's
application and libVLC components have different GNU license terms; review the
exact runtime and plugins you distribute.

- https://www.videolan.org/legal.html
- https://www.videolan.org/vlc/libvlc.html

VLC and VideoLAN are trademarks of the VideoLAN organization. Media Player is
independent and is not endorsed by or affiliated with VideoLAN.

