# Packaging instructions

Build packages separately on each target operating system. A Windows executable
does not run on macOS or Linux, and PyInstaller is not a cross-compiler.

## Common preparation

```bash
python -m venv .venv
# Activate the environment using the platform command.
python -m pip install -r requirements-dev.txt
pytest -q
```

The source distribution's platform launchers use `bootstrap.py` to create a
private environment and install `requirements.txt` on first use. PyInstaller
builds use the already prepared build environment and do not run that bootstrap
inside the packaged executable.

The packaged application still requires a compatible native VLC/libVLC runtime
unless you deliberately bundle libVLC and all of its plugins under their license
terms. The default commands below do not copy VLC binaries.

## Windows

Use 64-bit Python with 64-bit VLC, or 32-bit Python with 32-bit VLC.

```powershell
.venv\Scripts\python -m PyInstaller `
  --noconfirm --clean --windowed `
  --name "Media Player" `
  --paths src `
  run_player.py
```

Test `dist\Media Player\Media Player.exe` on a clean Windows
machine with matching VLC installed. Check local files, a URL, video embedding,
fullscreen restoration, subtitles, output devices, and shutdown.

For a distributable installer, use an installer builder such as WiX or Inno
Setup around the PyInstaller directory. Show the `THIRD_PARTY_NOTICES.md` file
and do not change file associations without explicit user consent.

## macOS

Run on macOS with VLC installed in `/Applications`:

```bash
.venv/bin/python -m PyInstaller \
  --noconfirm --clean --windowed \
  --name "Media Player" \
  --paths src \
  run_player.py
```

Test the generated `.app` on both intended CPU architectures. Sign and notarize
the final app according to Apple's current process. If shipping universal2,
ensure Python, Qt, and libVLC are all architecture-compatible.

## Linux

Build on the oldest distribution you intend to support:

```bash
.venv/bin/python -m PyInstaller \
  --noconfirm --clean --windowed \
  --name media-player \
  --paths src \
  run_player.py
```

Declare VLC/libVLC as a native package dependency for `.deb`/`.rpm` packaging.
If producing AppImage or Flatpak, include libVLC plugins deliberately and verify
their discovery path, licenses, hardware decoding, X11/Wayland embedding, and
audio portal/device behavior.

## Release checklist

1. Run all unit and GUI smoke tests on the target OS.
2. Run the real libVLC integration test.
3. Manually test audio, video, seeking, tracks, subtitles, fullscreen, snapshots,
   conversion, streaming, missing files, failed URLs, and close during work.
4. Compare the ten states listed in the source specification against the fixed
   VLC 3.0.21 Windows reference at equal size/scale/theme.
5. Include README, LICENSE, THIRD_PARTY_NOTICES, REFERENCE, ACTION_INVENTORY, and
   FEATURE_REPORT in the installer or distribution.
6. Record the exact Python, PySide6, python-vlc, libVLC, OS, CPU architecture,
   and graphics environment used for validation.

