"""Source-tree launcher with readable dependency errors."""

from __future__ import annotations

import os
import sys
from importlib.util import find_spec
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT / "src"))
BOOTSTRAP_ENVIRONMENT_FLAG = "MEDIA_PLAYER_BOOTSTRAPPED"


def show_startup_error(message: str) -> None:
    print(message, file=sys.stderr)
    try:
        import tkinter
        from tkinter import messagebox

        root = tkinter.Tk()
        root.withdraw()
        messagebox.showerror("Media Player", message)
        root.destroy()
    except Exception:
        # Console launchers retain the printed diagnostic when Tk is unavailable.
        return


def missing_python_packages() -> list[str]:
    """Return user-facing names for packages unavailable to this interpreter."""

    missing: list[str] = []
    for module_name, package_name in (("PySide6", "PySide6"), ("vlc", "python-vlc")):
        try:
            available = find_spec(module_name) is not None
        except (ImportError, ValueError):
            available = False
        if not available:
            missing.append(package_name)
    return missing


def should_bootstrap() -> bool:
    """Use the first-run installer for an unpackaged source-tree launch."""

    return (
        not getattr(sys, "frozen", False)
        and os.environ.get(BOOTSTRAP_ENVIRONMENT_FLAG) != "1"
        and (PROJECT_ROOT / "bootstrap.py").is_file()
    )


def main() -> int:
    if should_bootstrap():
        from bootstrap import main as bootstrap_main

        return bootstrap_main(sys.argv[1:])

    missing = missing_python_packages()
    if missing:
        show_startup_error(
            "Media Player cannot start.\n\n"
            "Missing Python packages: "
            + ", ".join(missing)
            + "\n\nStart the app with the platform launcher so it can install them "
            "automatically.\n\nManual command: python -m pip install -r requirements.txt"
        )
        return 2
    from media_player.app import main as app_main

    return app_main(sys.argv[1:])


if __name__ == "__main__":
    raise SystemExit(main())
