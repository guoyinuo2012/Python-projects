# Media Player

Media Player is a real Python desktop media player built with PySide6 and
python-vlc. Its layout, menu order, controls, and core interactions follow the
classic Windows interface of **VLC media player 3.0.21 “Vetinari”**.

This is an independent implementation. It does not launch or wrap VLC's desktop
interface. The application owns its PySide6 interface and controls the installed
libVLC engine directly.

## What is included

- Embedded video and audio playback through libVLC.
- Local files, multiple files, folders, command-line paths, URLs, discs, capture
  inputs, drag and drop, and M3U/M3U8/PLS/XSPF playlists.
- A stable-ID playlist with reordering, multi-selection, searching, sorting,
  repeat one/all, and non-repeating shuffle cycles.
- Automatic restoration of the previous playlist plus persistent per-media
  bookmarks that survive restarts.
- Play, pause, stop, previous, next, seeking, jump-to-time, speed control, volume,
  mute, frame stepping, A–B repeat, and fullscreen controls.
- Speed presets, stop-after-current, quit-at-end, and configurable sleep timers.
- Playlist cleanup for duplicate and missing entries, current-location copying,
  opening a local item's folder, and subtitle drag-and-drop.
- Audio, video, and subtitle track selection; external subtitles; track delays;
  aspect, crop, zoom, deinterlacing, snapshots, and an equalizer.
- Conversion and streaming jobs run in independent VLC processes so the main
  interface remains responsive.
- Recent media, validated preferences, safe atomic settings writes, resume
  positions, bounded logs, and clear-history/reset behavior.
- Windows, macOS, and Linux launchers, tests, packaging instructions, license
  notices, a reference record, and a validation report.

See [FEATURE_REPORT.md](FEATURE_REPORT.md) for the exact verified/unverified split
and [ACTION_INVENTORY.md](ACTION_INVENTORY.md) for every exposed menu action.

## Requirements

- Python 3.10 or newer.
- PySide6 6.6 or newer.
- python-vlc.
- A native VLC/libVLC 3.x installation.

The application-specific source is Python. PySide6/Qt supplies native desktop
widgets and libVLC supplies native decoding and playback. The `python-vlc` package
is only a Python binding; it does **not** include libVLC.

On Windows, Python and VLC must use the same architecture. A 64-bit Python needs
64-bit VLC. The launcher checks normal VLC installation folders and `VLC_HOME`.

## Install and launch

The platform launchers create a private `.venv` and install PySide6 and
python-vlc automatically when they are first run. The first launch therefore
needs an internet connection and can take a few minutes; later launches reuse
the installed environment. VLC/libVLC is a separate native runtime and must be
installed on the computer.

### Windows

1. Install 64-bit Python 3.10 or newer and 64-bit VLC from VideoLAN.
2. Extract the complete project ZIP to a normal folder.
3. Double-click `launch_windows.bat`.

The launcher prepares its private Python environment automatically. If Python
is absent, it opens the official Python download page. If startup fails, its
console stays open so the error remains readable.

Double-clicking `run_player.py` now performs the same automatic setup, although
`launch_windows.bat` is recommended because it keeps setup errors visible.

### macOS

Install Python 3.10 or newer and the VLC application in `/Applications`, then
double-click `launch_macos.command` or run:

```bash
chmod +x launch_macos.command
./launch_macos.command
```

If python-vlc cannot locate the VLC framework, see Troubleshooting below.

### Linux

Install VLC/libVLC with the distribution package manager first. Examples:

```bash
# Debian/Ubuntu
sudo apt install vlc libvlc5

# Fedora
sudo dnf install vlc
```

Then launch (the Python packages are installed automatically):

```bash
chmod +x launch_linux.sh
./launch_linux.sh
```

The exact native package names vary by distribution.

### Installed Python package

From the project folder:

```bash
python -m pip install .
media-player
```

## Opening media

- Use **Media → Open File**, **Open Multiple Files**, **Open Folder**, **Open
  Disc**, **Open Network Stream**, or **Open Capture Device**.
- Drop files or folders on the video area.
- Drop subtitle files on a loaded video to attach them immediately.
- Double-click a playlist row to play it.
- Pass files, folders, playlists, or URLs on the command line:

  ```bash
  python run_player.py "movie with spaces.mkv" "https://example.test/live"
  python run_player.py --no-play album-folder
  ```

Folder scans run in a cancelable background task. Recognized media files are
added in batches, directory symlinks are not followed, and inaccessible folders
are skipped. Format support ultimately depends on the installed libVLC build.

## Keyboard controls

| Action | Key |
|---|---|
| Play / pause | `Space` |
| Stop | `S` |
| Fullscreen | `F` |
| Leave fullscreen | `Esc` |
| Previous / next | `P` / `N` |
| Faster / slower / normal rate | `+` / `-` / `=` |
| Short jump backward / forward | `Shift+Left` / `Shift+Right` |
| Volume up / down | `Ctrl+Up` / `Ctrl+Down` |
| Mute | `M` |
| Frame step | `E` |
| Open file | `Ctrl+O` |
| Open multiple files | `Ctrl+Shift+O` |
| Open folder | `Ctrl+F` |
| Open disc / URL / capture | `Ctrl+D` / `Ctrl+N` / `Ctrl+C` |
| Playlist | `Ctrl+L` |
| Jump to time | `Ctrl+T` |
| Minimal interface | `Ctrl+H` |
| Fullscreen interface | `F11` |

Single-letter playback shortcuts are handled only when focus is not inside a
text, combo, or numeric input, so normal typing is not intercepted.

## Playlist behavior

- Current media is tracked by a UUID, not its row, so reordering is safe.
- Removing the current item selects the item that takes its old row (or the new
  last row) and preserves playing/paused intent.
- Clearing the playlist stops playback.
- A failed item stays selected and reports a useful error; it is not silently
  skipped. Use **Next** to continue.
- At the last item, playback stops unless repeat-all is active.
- Shuffle visits all other available items before repeating. Repeat-all starts a
  new shuffle cycle; repeat-one repeats only after natural end, not after a
  manual **Next**.
- The previous playlist and selected item are restored without autoplay by
  default. Disable this in **Tools → Preferences → Interface** if undesired.
- **Media → Playlist Tools** removes duplicate or missing entries, copies the
  current location, and opens the containing folder for local media.

## Preferences, configuration, and logs

Settings are validated and written atomically to `settings.json` in:

- Windows: `%APPDATA%\Media Player\`
- macOS: `~/Library/Application Support/Media Player/`
- Linux: `$XDG_CONFIG_HOME/Media Player/` or
  `~/.config/Media Player/`

The rotating log is `media-player.log` in the same folder. It is limited
to about 1 MB per file with three backups. **Tools → Messages** shows a bounded
in-memory copy.

Resume positions are accepted only after duration and seekability are known.
Entries under ten seconds, near the end, for changed local files, or for media
whose duration changed materially are ignored.

Custom bookmarks and the last playlist are stored in the same validated settings
file. Playlist restoration is bounded to 1,000 items and bookmarks are bounded
per media source to prevent unbounded configuration growth.

Use **Media → Open Recent Media → Clear** to clear both recent media and resume
history. Start with `--reset-preferences` to reset all settings safely.

## Conversion and streaming

**Convert / Save** validates that the destination exists, is writable, differs
from the source, and is not overwritten without explicit confirmation. It offers
several conservative VLC profiles.

**Stream** accepts HTTP, UDP, or RTP destinations and can optionally transcode to
H.264/AAC. Both operations launch the installed VLC executable with separate
argument tokens (paths with spaces are preserved). VLC 3 does not provide a
portable, accurate conversion percentage here, so the UI deliberately uses an
indeterminate progress display. Cancelling may leave a partial output file; the
dialog says so explicitly.

## Troubleshooting

### Python packages cannot be installed

- Launch with `launch_windows.bat`, `launch_macos.command`,
  `launch_linux.sh`, or `run_player.py`; each source-tree entry point runs the
  same first-use setup.
- Confirm the computer is online for the first launch.
- Confirm Python 3.10 or newer can create virtual environments. Some Linux
  distributions package this separately as `python3-venv`.
- Delete only the project's `.venv` folder and launch again if an interrupted
  installation left it incomplete.

### “VLC Runtime Not Found”

- Confirm VLC desktop is installed, not only `python-vlc`.
- Confirm Python and VLC are both 32-bit or both 64-bit.
- On Windows, set `VLC_HOME` to the folder containing `libvlc.dll`, for example:

  ```powershell
  $env:VLC_HOME = "C:\Program Files\VideoLAN\VLC"
  ```

- On Linux, install the distribution's libVLC runtime package.
- On macOS, install VLC in `/Applications`. Some Python distributions may need
  `DYLD_LIBRARY_PATH=/Applications/VLC.app/Contents/MacOS/lib` before launch.

### Video is blank but audio plays

Update graphics drivers, try VLC's own application with the same media, and
check whether the installed VLC build can use the platform video output. Remote
desktop and virtual-machine graphics can prevent native video embedding.

### A format or network stream fails

Support is supplied by the local libVLC build and its plugins. Test the same
source in the matching VLC desktop installation. Authentication, DRM, server
availability, codec plugins, and network policy can all affect playback.

### Preferences are damaged

Launch once with:

```bash
python run_player.py --reset-preferences
```

## Development and tests

```bash
python -m pip install -r requirements-dev.txt
pytest -q
```

The default suite contains pure logic tests, mocked playback state tests, and an
offscreen Qt GUI smoke test. A real libVLC audio integration test runs when a
native runtime is available and otherwise reports a skip.

Project packaging is documented in [PACKAGING.md](PACKAGING.md). The fixed
reference and visual-fidelity evidence are in [REFERENCE.md](REFERENCE.md).

## Project structure

```text
src/media_player/
  app.py              startup and dependency diagnostics
  engine.py           generation-safe libVLC controller
  models.py           playlist identity and navigation
  playlist_io.py      M3U, PLS, and XSPF support
  persistence.py      validated atomic settings/history
  conversion.py       VLC conversion/stream validation
  workers.py          cancelable folder scans
  ui/main_window.py   menus, controls, fullscreen, orchestration
  ui/dialogs.py       media, preferences, effects, info, jobs
  ui/widgets.py       video surface, playlist, sliders, overlay
tests/                 unit, GUI smoke, and libVLC integration tests
```

## License and trademarks

The original project code is under the MIT License. Dependency licenses are
listed in [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).

VLC and VideoLAN are trademarks of the VideoLAN organization. This project is
not affiliated with or endorsed by VideoLAN and does not bundle the VLC cone
artwork, VLC binaries, or VLC source code.

