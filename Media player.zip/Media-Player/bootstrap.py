"""Create an isolated runtime on first launch, then start the media player.

This module intentionally uses only the Python standard library so it can run
before PySide6 and python-vlc have been installed.
"""

from __future__ import annotations

import hashlib
import os
import subprocess
import sys
from collections.abc import Callable, Sequence
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
VENV_DIRECTORY = PROJECT_ROOT / ".venv"
REQUIREMENTS_FILE = PROJECT_ROOT / "requirements.txt"
STAMP_FILE = VENV_DIRECTORY / ".media-player-requirements"
MINIMUM_PYTHON = (3, 10)
BOOTSTRAP_ENVIRONMENT_FLAG = "MEDIA_PLAYER_BOOTSTRAPPED"


class BootstrapError(RuntimeError):
    """A readable first-run setup failure."""


def virtual_environment_python(
    directory: Path = VENV_DIRECTORY, *, platform_name: str | None = None
) -> Path:
    """Return the interpreter path for a venv on the requested platform."""

    platform_name = platform_name or os.name
    if platform_name == "nt":
        return directory / "Scripts" / "python.exe"
    return directory / "bin" / "python"


def requirements_fingerprint(requirements_file: Path = REQUIREMENTS_FILE) -> str:
    """Identify the dependency set and the Python ABI used to install it."""

    digest = hashlib.sha256()
    digest.update(requirements_file.read_bytes())
    digest.update(f"\npython={sys.version_info.major}.{sys.version_info.minor}\n".encode())
    return digest.hexdigest()


def _dependency_probe_code() -> str:
    # Import PySide6 so a broken native Qt install is repaired. Merely locate
    # python-vlc: importing it can load libVLC, which remains a system runtime.
    return (
        "import importlib.util; import PySide6; "
        "raise SystemExit(0 if importlib.util.find_spec('vlc') else 1)"
    )


def dependencies_available(
    python: Path,
    *,
    runner: Callable[..., subprocess.CompletedProcess[str]] = subprocess.run,
) -> bool:
    """Check the Python packages without requiring native libVLC yet."""

    result = runner(
        [str(python), "-c", _dependency_probe_code()],
        cwd=PROJECT_ROOT,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False,
        text=True,
    )
    return result.returncode == 0


def _run_checked(command: list[str], description: str) -> None:
    try:
        subprocess.run(command, cwd=PROJECT_ROOT, check=True)
    except (OSError, subprocess.CalledProcessError) as exc:
        raise BootstrapError(f"{description} failed: {exc}") from exc


def _write_stamp(value: str, stamp_file: Path = STAMP_FILE) -> None:
    temporary = stamp_file.with_suffix(".tmp")
    temporary.write_text(value + "\n", encoding="utf-8")
    temporary.replace(stamp_file)


def ensure_runtime() -> Path:
    """Create/update the project venv and return its Python interpreter."""

    if sys.version_info < MINIMUM_PYTHON:
        required = ".".join(map(str, MINIMUM_PYTHON))
        current = f"{sys.version_info.major}.{sys.version_info.minor}"
        raise BootstrapError(f"Python {required} or newer is required; found Python {current}.")
    if not REQUIREMENTS_FILE.is_file():
        raise BootstrapError(f"Dependency file not found: {REQUIREMENTS_FILE}")

    python = virtual_environment_python()
    if not python.is_file():
        print("Preparing Media Player for first use...", flush=True)
        _run_checked(
            [sys.executable, "-m", "venv", str(VENV_DIRECTORY)],
            "Creating the private Python environment",
        )
    if not python.is_file():
        raise BootstrapError("The private Python environment was not created correctly.")

    wanted_fingerprint = requirements_fingerprint()
    try:
        installed_fingerprint = STAMP_FILE.read_text(encoding="utf-8").strip()
    except OSError:
        installed_fingerprint = ""

    if installed_fingerprint != wanted_fingerprint or not dependencies_available(python):
        print("Installing required Python packages (first launch can take a few minutes)...", flush=True)
        _run_checked(
            [
                str(python),
                "-m",
                "pip",
                "install",
                "--disable-pip-version-check",
                "--requirement",
                str(REQUIREMENTS_FILE),
            ],
            "Installing PySide6 and python-vlc",
        )
        if not dependencies_available(python):
            raise BootstrapError("The required Python packages did not pass their startup check.")
        _write_stamp(wanted_fingerprint)

    return python


def show_error(message: str) -> None:
    """Report setup errors in both the terminal and a basic native dialog."""

    full_message = f"Media Player could not be prepared.\n\n{message}"
    print(full_message, file=sys.stderr)
    try:
        import tkinter
        from tkinter import messagebox

        root = tkinter.Tk()
        root.withdraw()
        messagebox.showerror("Media Player Setup", full_message)
        root.destroy()
    except Exception:
        pass


def main(arguments: Sequence[str] | None = None) -> int:
    try:
        python = ensure_runtime()
    except BootstrapError as exc:
        show_error(str(exc))
        return 2

    command = [str(python), str(PROJECT_ROOT / "run_player.py"), *(arguments or sys.argv[1:])]
    child_environment = os.environ.copy()
    child_environment[BOOTSTRAP_ENVIRONMENT_FLAG] = "1"
    try:
        return subprocess.call(command, cwd=PROJECT_ROOT, env=child_environment)
    except OSError as exc:
        show_error(f"Starting the application failed: {exc}")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
