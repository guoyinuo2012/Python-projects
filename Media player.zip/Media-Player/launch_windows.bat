@echo off
setlocal EnableExtensions
cd /d "%~dp0"

where py >nul 2>nul
if not errorlevel 1 (
    py -3 bootstrap.py %*
) else (
    where python >nul 2>nul
    if errorlevel 1 (
        echo Python 3.10 or newer is required.
        echo Install Python from https://www.python.org/downloads/windows/
        start "" "https://www.python.org/downloads/windows/"
        set "APP_EXIT=2"
        goto after_run
    )
    python bootstrap.py %*
)
set "APP_EXIT=%ERRORLEVEL%"

:after_run
if not "%APP_EXIT%"=="0" (
    echo.
    echo Media Player stopped with an error. Read the message above.
    pause
)
endlocal
exit /b %APP_EXIT%

