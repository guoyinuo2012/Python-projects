# Menu action inventory

Status meanings: **Working** is implemented in the Python UI; **Runtime-dependent**
is implemented but requires support from the installed libVLC/VLC build;
**Explained unavailable** opens a reason and has no silent no-op.

## Media

| Action | Status | Implementation |
|---|---|---|
| Open File / Multiple Files | Working | Native file pickers → stable-ID queue → libVLC |
| Open Folder | Working | Cancelable non-blocking recursive scan without symlink traversal |
| Open Disc | Runtime-dependent | Builds `dvd://`, `bluray://`, or `cdda://` input |
| Open Network Stream | Runtime-dependent | Passes validated non-empty URL/MRL to libVLC |
| Open Capture Device | Runtime-dependent | `dshow://`, `qtcapture://`, `v4l2://`, or `screen://` input |
| Open Location from clipboard | Working | Adds clipboard path/URL with normal validation |
| Open Recent Media | Working | Validated, bounded recent list with clear-history action |
| Save Playlist | Working | UTF-8 M3U8, PLS, and XSPF writers |
| Playlist Tools | Working | Removes duplicates/missing files, copies location, opens containing folder |
| Convert / Save | Runtime-dependent | Validated destination and independent VLC process |
| Stream | Runtime-dependent | HTTP/UDP/RTP VLC stream-output process |
| Quit | Working | Saves settings/resume state and releases resources |

## Playback

| Action | Status | Implementation |
|---|---|---|
| Title / Chapter | Runtime-dependent | Populated from libVLC counts with checked current item |
| Program | Explained unavailable | Program enumeration is inconsistent in libVLC 3 Python API |
| Custom Bookmarks | Working | Persistent add, clear, and jump by exact media time |
| Renderer | Explained unavailable | Portable renderer discovery is not enabled |
| Play / Pause / Stop | Runtime-dependent | Shared controller actions and state-synchronized icons |
| Previous / Next | Working | Stable-ID queue navigation; restart current after 3 seconds |
| Record | Explained unavailable | Convert/Save is offered instead of a fake record toggle |
| Faster / Slower / Presets | Runtime-dependent | 0.25×–4.00× libVLC playback-rate controls |
| Short forward / backward | Runtime-dependent | Seekable media only |
| Jump to Specific Time | Runtime-dependent | Hours/minutes/seconds dialog with duration bound |
| A–B Loop | Working | Two-marker cycle enforced from position events |
| Frame by Frame | Runtime-dependent | libVLC `next_frame`, with failure message |
| Stop after Current Item | Working | Stops natural queue advancement once, then resets |
| Quit at End of Playlist | Working | Closes cleanly after the final natural end event |
| Sleep Timer | Working | 15–120 minute single-shot playback stop with cancellation |

## Audio

| Action | Status | Implementation |
|---|---|---|
| Audio Track | Runtime-dependent | Live track descriptions and checked selection |
| Stereo Mode | Runtime-dependent | Stereo, reverse, left, right, Dolby channel modes |
| Audio Device | Runtime-dependent | Enumerated devices, released correctly after listing |
| Visualizations | Explained unavailable | Module availability is not portable across VLC builds |
| Volume / Mute | Runtime-dependent | 0–125% range, remembered volume, synchronized controls |

## Video

| Action | Status | Implementation |
|---|---|---|
| Video Track | Runtime-dependent | Live track descriptions and checked selection |
| Fullscreen | Working | Button/key/double-click, overlay, auto-hide, Esc restoration |
| Always Fit Window | Runtime-dependent | libVLC scale 0 (fit) versus original scale |
| Set as Wallpaper | Explained unavailable | No supported portable libVLC API |
| Zoom / Aspect Ratio / Crop | Runtime-dependent | Direct libVLC video transforms |
| Deinterlace / mode | Runtime-dependent | Direct libVLC deinterlace mode selection |
| Post processing | Explained unavailable | No portable runtime control in selected API |
| Take Snapshot | Runtime-dependent | Unique timestamped path; never overwrites silently |

## Subtitle

| Action | Status | Implementation |
|---|---|---|
| Add Subtitle File | Runtime-dependent | Unicode path → libVLC subtitle slave |
| Drop Subtitle File | Runtime-dependent | Attaches dropped SRT/ASS/SSA/SUB/VTT/SMI to loaded media |
| Sub Track / Disable | Runtime-dependent | Live checked track list including libVLC disable entry |

## Tools

| Action | Status | Implementation |
|---|---|---|
| Effects and Filters | Runtime-dependent | Equalizer enable/preset/preamp/bands; video limitation stated |
| Track Synchronization | Runtime-dependent | Audio and subtitle delays in milliseconds |
| Media Information | Runtime-dependent | Metadata, source, duration, state, and statistics |
| Codec Information | Runtime-dependent | Parsed libVLC media-track records |
| VLM Configuration | Explained unavailable | Not exposed by this interface |
| Program Guide | Explained unavailable | No portable EPG data API used |
| Messages | Working | Bounded live log view and refresh |
| Plugins and extensions | Explained unavailable | Does not execute VLC Lua extensions |
| Customize Interface | Explained unavailable | Fixed reference toolbar |
| Preferences | Working | Save/cancel/reset, playlist restore, and validated persistence |

## View and Help

| Action | Status | Implementation |
|---|---|---|
| Playlist | Working | Replaces/restores central view and remains synchronized |
| Docked Playlist | Working/default | Undocking request explains the cross-platform limitation |
| Always on Top | Working | Native Qt window flag |
| Minimal Interface | Working | Hides menu/seek/advanced chrome; shortcut restores it |
| Fullscreen Interface | Working | Same full-window state as video fullscreen |
| Advanced Controls | Working | Record explanation, A–B, and frame-step buttons |
| Status Bar | Working | Toggleable native status bar |
| Add Interface / VLsub | Explained unavailable | Single PySide6 UI; no third-party Lua execution |
| Help | Working | Opens official VLC 3.0 documentation |
| Check for Updates | Explained unavailable | No project update service is claimed |
| About | Working | Version, runtime, reference, license, and trademark details |

