"""Validated, atomic application settings and playback history."""

from __future__ import annotations

import hashlib
import json
import os
import tempfile
from collections.abc import Iterable
from contextlib import suppress
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .media_utils import is_probable_url, normalize_source

DEFAULT_SETTINGS: dict[str, Any] = {
    "volume": 100,
    "muted": False,
    "repeat_mode": "off",
    "shuffle": False,
    "playlist_visible": False,
    "minimal_interface": False,
    "always_on_top": False,
    "remember_position": True,
    "ask_to_resume": True,
    "auto_play": True,
    "restore_playlist": True,
    "snapshot_directory": "",
    "snapshot_format": "png",
    "recent_media": [],
    "resume_positions": {},
    "saved_playlist": [],
    "saved_current_id": "",
    "bookmarks": {},
    "last_open_directory": "",
    "last_subtitle_directory": "",
    "window_geometry": "",
    "window_state": "",
    "subtitle_encoding": "UTF-8",
    "subtitle_font_size": 16,
    "privacy_allow_metadata": False,
}


def standard_config_directory() -> Path:
    if os.name == "nt":
        base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
    elif os.sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    return base / "Media Player"


def validate_settings(raw: object) -> dict[str, Any]:
    result = deepcopy(DEFAULT_SETTINGS)
    if not isinstance(raw, dict):
        return result
    result["volume"] = min(125, max(0, _as_int(raw.get("volume"), 100)))
    for key in (
        "muted",
        "shuffle",
        "playlist_visible",
        "minimal_interface",
        "always_on_top",
        "remember_position",
        "ask_to_resume",
        "auto_play",
        "restore_playlist",
        "privacy_allow_metadata",
    ):
        result[key] = raw.get(key) if isinstance(raw.get(key), bool) else result[key]
    if raw.get("repeat_mode") in {"off", "one", "all"}:
        result["repeat_mode"] = raw["repeat_mode"]
    if raw.get("snapshot_format") in {"png", "jpg"}:
        result["snapshot_format"] = raw["snapshot_format"]
    result["subtitle_font_size"] = min(72, max(6, _as_int(raw.get("subtitle_font_size"), 16)))
    for key in (
        "snapshot_directory",
        "last_open_directory",
        "last_subtitle_directory",
        "window_geometry",
        "window_state",
        "subtitle_encoding",
    ):
        if isinstance(raw.get(key), str):
            result[key] = raw[key][:16384]
    recent = raw.get("recent_media", [])
    if isinstance(recent, list):
        clean_recent: list[dict[str, str]] = []
        for entry in recent[:30]:
            if isinstance(entry, dict) and isinstance(entry.get("source"), str):
                clean_recent.append(
                    {
                        "source": entry["source"],
                        "opened_at": str(entry.get("opened_at", "")),
                    }
                )
        result["recent_media"] = clean_recent[:15]
    positions = raw.get("resume_positions", {})
    if isinstance(positions, dict):
        clean_positions: dict[str, dict[str, Any]] = {}
        for key, value in list(positions.items())[-500:]:
            if not isinstance(key, str) or not isinstance(value, dict):
                continue
            position = _as_int(value.get("position_ms"), -1)
            duration = _as_int(value.get("duration_ms"), -1)
            source = value.get("source")
            if position >= 0 and duration > 0 and isinstance(source, str):
                clean_positions[key] = {
                    "source": source,
                    "position_ms": position,
                    "duration_ms": duration,
                    "updated_at": str(value.get("updated_at", "")),
                }
        result["resume_positions"] = clean_positions
    saved_playlist = raw.get("saved_playlist", [])
    if isinstance(saved_playlist, list):
        clean_playlist: list[dict[str, Any]] = []
        for entry in saved_playlist[:1000]:
            if not isinstance(entry, dict):
                continue
            source = entry.get("source")
            if not isinstance(source, str) or not source.strip():
                continue
            duration = entry.get("duration_ms")
            duration_ms = _as_int(duration, -1) if duration is not None else -1
            clean_playlist.append(
                {
                    "source": source[:32768],
                    "title": str(entry.get("title", ""))[:2048],
                    "duration_ms": duration_ms if duration_ms >= 0 else None,
                    "artist": str(entry.get("artist", ""))[:2048],
                    "album": str(entry.get("album", ""))[:2048],
                    "item_id": str(entry.get("item_id", ""))[:128],
                }
            )
        result["saved_playlist"] = clean_playlist
    if isinstance(raw.get("saved_current_id"), str):
        result["saved_current_id"] = raw["saved_current_id"][:128]
    bookmarks = raw.get("bookmarks", {})
    if isinstance(bookmarks, dict):
        clean_bookmarks: dict[str, list[int]] = {}
        for source, values in list(bookmarks.items())[-200:]:
            if not isinstance(source, str) or not source or not isinstance(values, list):
                continue
            positions = sorted(
                {
                    position
                    for value in values[:200]
                    if (position := _as_int(value, -1)) >= 0
                }
            )
            if positions:
                clean_bookmarks[source[:32768]] = positions
        result["bookmarks"] = clean_bookmarks
    return result


def _as_int(value: object, default: int) -> int:
    try:
        if isinstance(value, bool):
            return default
        return int(value)  # type: ignore[arg-type]
    except (TypeError, ValueError, OverflowError):
        return default


class SettingsRepository:
    def __init__(self, path: str | Path | None = None) -> None:
        self.path = Path(path) if path else standard_config_directory() / "settings.json"
        self.data = deepcopy(DEFAULT_SETTINGS)

    def load(self) -> dict[str, Any]:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            raw = {}
        except (OSError, json.JSONDecodeError):
            raw = {}
        self.data = validate_settings(raw)
        return deepcopy(self.data)

    def save(self) -> None:
        self.data = validate_settings(self.data)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        descriptor, temp_name = tempfile.mkstemp(
            prefix=f".{self.path.name}.", suffix=".tmp", dir=self.path.parent
        )
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
                json.dump(self.data, handle, ensure_ascii=False, indent=2, sort_keys=True)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_name, self.path)
        finally:
            with suppress(OSError):
                Path(temp_name).unlink(missing_ok=True)

    def reset(self) -> None:
        self.data = deepcopy(DEFAULT_SETTINGS)
        self.save()

    def add_recent(self, source: str) -> None:
        normalized = normalize_source(source)
        recent = [
            entry
            for entry in self.data.get("recent_media", [])
            if isinstance(entry, dict) and entry.get("source") != normalized
        ]
        recent.insert(
            0,
            {"source": normalized, "opened_at": datetime.now(timezone.utc).isoformat()},
        )
        self.data["recent_media"] = recent[:15]

    def clear_history(self) -> None:
        self.data["recent_media"] = []
        self.data["resume_positions"] = {}
        self.save()

    def recent_sources(self) -> list[str]:
        return [
            str(entry["source"])
            for entry in self.data.get("recent_media", [])
            if isinstance(entry, dict) and entry.get("source")
        ]

    def set_playlist_session(
        self, items: Iterable[dict[str, object]], current_id: str | None
    ) -> None:
        if not self.data.get("restore_playlist", True):
            self.data["saved_playlist"] = []
            self.data["saved_current_id"] = ""
            return
        self.data["saved_playlist"] = list(items)[:1000]
        self.data["saved_current_id"] = current_id or ""

    def playlist_session(self) -> tuple[list[dict[str, Any]], str]:
        if not self.data.get("restore_playlist", True):
            return [], ""
        items = self.data.get("saved_playlist", [])
        current_id = self.data.get("saved_current_id", "")
        return deepcopy(items) if isinstance(items, list) else [], str(current_id)

    def bookmark_positions(self, source: str) -> list[int]:
        bookmarks = self.data.get("bookmarks", {})
        if not isinstance(bookmarks, dict):
            return []
        values = bookmarks.get(normalize_source(source), [])
        return list(values) if isinstance(values, list) else []

    def add_bookmark(self, source: str, position_ms: int) -> bool:
        if position_ms < 0:
            return False
        bookmarks = self.data.setdefault("bookmarks", {})
        key = normalize_source(source)
        values = bookmarks.setdefault(key, [])
        if position_ms in values:
            return False
        values.append(int(position_ms))
        values.sort()
        del values[200:]
        return True

    def clear_bookmarks(self, source: str) -> None:
        bookmarks = self.data.get("bookmarks", {})
        if isinstance(bookmarks, dict):
            bookmarks.pop(normalize_source(source), None)

    def set_resume_position(self, source: str, position_ms: int, duration_ms: int) -> None:
        if not self.data.get("remember_position", True) or duration_ms <= 0:
            return
        key = media_identity(source)
        positions = self.data.setdefault("resume_positions", {})
        if position_ms < 10_000 or position_ms >= min(
            duration_ms - 30_000, int(duration_ms * 0.95)
        ):
            positions.pop(key, None)
            return
        positions[key] = {
            "source": normalize_source(source),
            "position_ms": int(position_ms),
            "duration_ms": int(duration_ms),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }

    def resume_position(self, source: str, current_duration_ms: int) -> int | None:
        if not self.data.get("remember_position", True) or current_duration_ms <= 0:
            return None
        entry = self.data.get("resume_positions", {}).get(media_identity(source))
        if not isinstance(entry, dict):
            return None
        saved_duration = _as_int(entry.get("duration_ms"), -1)
        position = _as_int(entry.get("position_ms"), -1)
        tolerance = max(5_000, int(current_duration_ms * 0.02))
        if abs(saved_duration - current_duration_ms) > tolerance:
            return None
        if position < 10_000 or position >= min(
            current_duration_ms - 30_000, int(current_duration_ms * 0.95)
        ):
            return None
        return position


def media_identity(source: str) -> str:
    normalized = normalize_source(source)
    material = normalized
    if not is_probable_url(normalized):
        try:
            stat = Path(normalized).stat()
            material = f"{normalized}|{stat.st_size}|{stat.st_mtime_ns}"
        except OSError:
            material = f"{normalized}|missing"
    return hashlib.sha256(material.encode("utf-8", errors="surrogatepass")).hexdigest()
