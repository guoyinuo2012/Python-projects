"""Playlist data structures with stable item identity and deterministic navigation."""

from __future__ import annotations

import random
from collections.abc import Iterable, Iterator
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from urllib.parse import unquote, urlparse
from uuid import uuid4


class RepeatMode(str, Enum):
    OFF = "off"
    ONE = "one"
    ALL = "all"


@dataclass(slots=True)
class PlaylistItem:
    source: str
    title: str = ""
    duration_ms: int | None = None
    artist: str = ""
    album: str = ""
    item_id: str = field(default_factory=lambda: uuid4().hex)

    @property
    def display_title(self) -> str:
        if self.title.strip():
            return self.title.strip()
        parsed = urlparse(self.source)
        if parsed.scheme and parsed.scheme != "file":
            name = Path(unquote(parsed.path)).name
            return name or self.source
        return Path(self.source).name or self.source

    def to_dict(self) -> dict[str, object]:
        return {
            "source": self.source,
            "title": self.title,
            "duration_ms": self.duration_ms,
            "artist": self.artist,
            "album": self.album,
            "item_id": self.item_id,
        }

    @classmethod
    def from_dict(cls, data: dict[str, object]) -> PlaylistItem:
        duration = data.get("duration_ms")
        return cls(
            source=str(data.get("source", "")),
            title=str(data.get("title", "")),
            duration_ms=int(duration) if isinstance(duration, (int, float)) else None,
            artist=str(data.get("artist", "")),
            album=str(data.get("album", "")),
            item_id=str(data.get("item_id") or uuid4().hex),
        )


class PlaylistQueue:
    """Ordered playlist whose active item is tracked by ID, never by row number."""

    def __init__(self, *, random_source: random.Random | None = None) -> None:
        self._items: list[PlaylistItem] = []
        self.current_id: str | None = None
        self.repeat_mode = RepeatMode.OFF
        self.shuffle = False
        self._shuffle_remaining: list[str] = []
        self._shuffle_history: list[str] = []
        self._random = random_source or random.Random()

    def __len__(self) -> int:
        return len(self._items)

    def __iter__(self) -> Iterator[PlaylistItem]:
        return iter(self._items)

    @property
    def items(self) -> tuple[PlaylistItem, ...]:
        return tuple(self._items)

    @property
    def current(self) -> PlaylistItem | None:
        return self.by_id(self.current_id) if self.current_id else None

    def by_id(self, item_id: str | None) -> PlaylistItem | None:
        if not item_id:
            return None
        return next((item for item in self._items if item.item_id == item_id), None)

    def add(self, item: PlaylistItem) -> None:
        if not item.source:
            raise ValueError("A playlist item requires a source")
        if self.by_id(item.item_id):
            item.item_id = uuid4().hex
        self._items.append(item)
        if self.shuffle and item.item_id != self.current_id:
            self._shuffle_remaining.append(item.item_id)

    def extend(self, items: Iterable[PlaylistItem]) -> None:
        for item in items:
            self.add(item)

    def set_current(self, item_id: str | None) -> PlaylistItem | None:
        if item_id is None:
            self.current_id = None
            return None
        item = self.by_id(item_id)
        if item is None:
            raise KeyError(item_id)
        if self.current_id and self.current_id != item_id and self.shuffle:
            self._shuffle_history.append(self.current_id)
        self.current_id = item_id
        if item_id in self._shuffle_remaining:
            self._shuffle_remaining.remove(item_id)
        return item

    def remove_ids(self, item_ids: Iterable[str]) -> PlaylistItem | None:
        """Remove items and select the current item's successor when it is removed."""
        removed = set(item_ids)
        if not removed:
            return self.current
        old_index = self.index_of(self.current_id)
        current_removed = self.current_id in removed
        self._items = [item for item in self._items if item.item_id not in removed]
        self._shuffle_remaining = [
            item_id for item_id in self._shuffle_remaining if item_id not in removed
        ]
        self._shuffle_history = [
            item_id for item_id in self._shuffle_history if item_id not in removed
        ]
        if current_removed:
            if not self._items:
                self.current_id = None
            else:
                replacement_index = min(max(old_index, 0), len(self._items) - 1)
                self.current_id = self._items[replacement_index].item_id
        return self.current

    def clear(self) -> None:
        self._items.clear()
        self.current_id = None
        self._shuffle_remaining.clear()
        self._shuffle_history.clear()

    def index_of(self, item_id: str | None) -> int:
        if not item_id:
            return -1
        return next((i for i, item in enumerate(self._items) if item.item_id == item_id), -1)

    def reorder(self, ordered_ids: Iterable[str]) -> None:
        requested = list(ordered_ids)
        known = {item.item_id: item for item in self._items}
        if len(requested) != len(known) or set(requested) != set(known):
            raise ValueError("The reordered ID list must contain every playlist item exactly once")
        self._items = [known[item_id] for item_id in requested]

    def sort(self, field_name: str, reverse: bool = False) -> None:
        valid_fields = {"title", "artist", "album", "duration_ms", "source"}
        if field_name not in valid_fields:
            raise ValueError(f"Unsupported sort field: {field_name}")
        self._items.sort(
            key=lambda item: (
                getattr(item, field_name) is None,
                str(getattr(item, field_name) or "").casefold(),
            ),
            reverse=reverse,
        )

    def set_shuffle(self, enabled: bool) -> None:
        self.shuffle = bool(enabled)
        self._shuffle_history.clear()
        self._reset_shuffle_pool()

    def _reset_shuffle_pool(self) -> None:
        self._shuffle_remaining = [
            item.item_id for item in self._items if item.item_id != self.current_id
        ]

    def next(self, *, natural_end: bool = False) -> PlaylistItem | None:
        if not self._items:
            self.current_id = None
            return None
        if natural_end and self.repeat_mode == RepeatMode.ONE and self.current:
            return self.current
        if self.shuffle:
            return self._next_shuffled()
        index = self.index_of(self.current_id)
        if index < 0:
            return self.set_current(self._items[0].item_id)
        if index + 1 < len(self._items):
            return self.set_current(self._items[index + 1].item_id)
        if self.repeat_mode == RepeatMode.ALL:
            return self.set_current(self._items[0].item_id)
        return None

    def _next_shuffled(self) -> PlaylistItem | None:
        if self.current_id is None:
            self._reset_shuffle_pool()
            if not self._shuffle_remaining:
                return self.set_current(self._items[0].item_id)
        if not self._shuffle_remaining:
            if self.repeat_mode != RepeatMode.ALL:
                return None
            self._reset_shuffle_pool()
            if not self._shuffle_remaining:
                return self.current
        chosen = self._random.choice(self._shuffle_remaining)
        return self.set_current(chosen)

    def previous(self) -> PlaylistItem | None:
        if not self._items:
            return None
        if self.shuffle and self._shuffle_history:
            previous_id = self._shuffle_history.pop()
            current_id = self.current_id
            self.current_id = previous_id
            if current_id and current_id not in self._shuffle_remaining:
                self._shuffle_remaining.append(current_id)
            return self.current
        index = self.index_of(self.current_id)
        if index < 0:
            return self.set_current(self._items[0].item_id)
        if index > 0:
            return self.set_current(self._items[index - 1].item_id)
        if self.repeat_mode == RepeatMode.ALL:
            return self.set_current(self._items[-1].item_id)
        return self.current
