"""Bounded application logging for disk and the Messages dialog."""

from __future__ import annotations

import logging
from collections import deque
from collections.abc import Iterable
from logging.handlers import RotatingFileHandler
from pathlib import Path


class RingLogHandler(logging.Handler):
    def __init__(self, capacity: int = 1000) -> None:
        super().__init__()
        self.records: deque[str] = deque(maxlen=capacity)

    def emit(self, record: logging.LogRecord) -> None:
        try:
            self.records.append(self.format(record))
        except Exception:
            self.handleError(record)

    def lines(self) -> Iterable[str]:
        return tuple(self.records)


def configure_logging(config_directory: Path) -> RingLogHandler:
    config_directory.mkdir(parents=True, exist_ok=True)
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    ring = RingLogHandler()
    ring.setFormatter(formatter)
    file_handler = RotatingFileHandler(
        config_directory / "media-player.log",
        maxBytes=1_000_000,
        backupCount=3,
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.addHandler(ring)
    root.addHandler(file_handler)
    return ring
