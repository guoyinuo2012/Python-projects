"""Application entry point and startup diagnostics."""

from __future__ import annotations

import argparse
import os
import struct
import sys
import traceback
from pathlib import Path

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication, QMessageBox

from . import APP_NAME, APP_VERSION
from .logging_utils import configure_logging
from .persistence import SettingsRepository, standard_config_directory

_DLL_DIRECTORY_HANDLES: list[object] = []


def _prepare_windows_vlc_search_path() -> None:
    if os.name != "nt" or not hasattr(os, "add_dll_directory"):
        return
    candidates: list[Path] = []
    configured = os.environ.get("VLC_HOME")
    if configured:
        candidates.append(Path(configured))
    for variable in ("PROGRAMFILES", "PROGRAMFILES(X86)"):
        if os.environ.get(variable):
            candidates.append(Path(os.environ[variable]) / "VideoLAN" / "VLC")
    for directory in candidates:
        if (directory / "libvlc.dll").is_file():
            # The returned handle must remain alive while libVLC and its own
            # dependent DLLs are loaded.
            _DLL_DIRECTORY_HANDLES.append(os.add_dll_directory(str(directory)))
            plugin_path = directory / "plugins"
            if plugin_path.is_dir():
                os.environ.setdefault("VLC_PLUGIN_PATH", str(plugin_path))
            return


def _argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="media-player",
        description="Classic PySide6/libVLC media player",
    )
    parser.add_argument(
        "sources", nargs="*", help="Media paths, folders, playlists, or network URLs"
    )
    parser.add_argument(
        "--no-play", action="store_true", help="Add command-line media without starting playback"
    )
    parser.add_argument(
        "--reset-preferences", action="store_true", help="Reset settings before launch"
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {APP_VERSION}")
    return parser


def _install_exception_hook() -> None:
    def handle_exception(exc_type, value, tb) -> None:  # type: ignore[no-untyped-def]
        details = "".join(traceback.format_exception(exc_type, value, tb))
        sys.stderr.write(details)
        QMessageBox.critical(
            None,
            f"{APP_NAME} Error",
            f"An unexpected error occurred:\n\n{value}\n\nSee the application log for details.",
        )

    sys.excepthook = handle_exception


def main(argv: list[str] | None = None) -> int:
    args = _argument_parser().parse_args(argv)
    _prepare_windows_vlc_search_path()
    application = QApplication.instance() or QApplication(sys.argv[:1])
    application.setApplicationName(APP_NAME)
    application.setApplicationVersion(APP_VERSION)
    application.setOrganizationName(APP_NAME)
    application.setQuitOnLastWindowClosed(True)
    _install_exception_hook()

    settings = SettingsRepository()
    settings.load()
    if args.reset_preferences:
        settings.reset()
    log_handler = configure_logging(standard_config_directory())

    from .engine import LibVlcUnavailableError, PlaybackController
    from .ui.main_window import MainWindow

    try:
        controller = PlaybackController()
    except LibVlcUnavailableError as exc:
        bits = struct.calcsize("P") * 8
        QMessageBox.critical(
            None,
            "VLC Runtime Not Found",
            f"{exc}\n\n"
            f"Install the {bits}-bit VLC desktop application that matches this {bits}-bit Python, "
            "then restart. On Windows, the normal VideoLAN installer is recommended.\n\n"
            "PySide6 and python-vlc alone do not contain the native libVLC media engine.",
        )
        return 2

    window = MainWindow(controller, settings, log_handler)
    window.show()
    if args.sources:
        QTimer.singleShot(0, lambda: window.add_sources(args.sources, play_first=not args.no_play))
    return application.exec()


if __name__ == "__main__":
    raise SystemExit(main())
