"""Media Player package."""

from __future__ import annotations

APP_NAME = "Media Player"
APP_VERSION = "1.1.1"
REFERENCE_VERSION = "VLC media player 3.0.21 Vetinari (Windows 64-bit Qt interface)"

__all__ = ["APP_NAME", "APP_VERSION", "REFERENCE_VERSION"]
