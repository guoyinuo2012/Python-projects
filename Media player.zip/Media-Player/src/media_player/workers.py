"""Cancelable background work used by the GUI."""

from __future__ import annotations

from pathlib import Path
from threading import Event

from PySide6.QtCore import QObject, QRunnable, Signal, Slot

from .media_utils import iter_media_files


class FolderScanSignals(QObject):
    found = Signal(list)
    failed = Signal(str)
    finished = Signal(bool)


class FolderScanTask(QRunnable):
    def __init__(self, root: str | Path, *, batch_size: int = 64) -> None:
        super().__init__()
        self.root = Path(root)
        self.batch_size = max(1, batch_size)
        self.signals = FolderScanSignals()
        self._cancel = Event()

    def cancel(self) -> None:
        self._cancel.set()

    @Slot()
    def run(self) -> None:
        batch: list[str] = []
        try:
            for path in iter_media_files(self.root, cancel=self._cancel):
                batch.append(str(path))
                if len(batch) >= self.batch_size:
                    self.signals.found.emit(batch)
                    batch = []
            if batch:
                self.signals.found.emit(batch)
        except Exception as exc:
            self.signals.failed.emit(str(exc))
        finally:
            self.signals.finished.emit(self._cancel.is_set())
