"""Reusable widgets styled after VLC's restrained classic desktop controls."""

from __future__ import annotations

from PySide6.QtCore import QPoint, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QDragEnterEvent, QDropEvent, QMouseEvent, QPainter, QPen
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMenu,
    QSlider,
    QStyle,
    QToolButton,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from ..models import PlaylistItem


def format_time(milliseconds: int, *, include_hours: bool | None = None) -> str:
    seconds = max(0, int(milliseconds) // 1000)
    hours, remainder = divmod(seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    if include_hours or hours:
        return f"{hours:d}:{minutes:02d}:{seconds:02d}"
    return f"{minutes:02d}:{seconds:02d}"


class SeekSlider(QSlider):
    seek_requested = Signal(int)
    drag_started = Signal()
    drag_finished = Signal(int)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(Qt.Orientation.Horizontal, parent)
        self.setRange(0, 1000)
        self.setSingleStep(1)
        self.setPageStep(20)
        self.setAccessibleName("Playback position")
        self.sliderPressed.connect(self.drag_started)
        self.sliderReleased.connect(lambda: self.drag_finished.emit(self.value()))

    def mousePressEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            option_span = max(1, self.width() - 16)
            value = round(
                self.minimum()
                + (self.maximum() - self.minimum()) * event.position().x() / option_span
            )
            self.setValue(max(self.minimum(), min(self.maximum(), value)))
            self.seek_requested.emit(self.value())
        super().mousePressEvent(event)


class VideoSurface(QWidget):
    sources_dropped = Signal(list)
    double_clicked = Signal()
    context_menu_requested = Signal(QPoint)
    pointer_moved = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.placeholder_visible = True
        self.setAcceptDrops(True)
        self.setMouseTracking(True)
        self.setAttribute(Qt.WidgetAttribute.WA_NativeWindow)
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent)
        self.setMinimumSize(320, 180)
        self.setAccessibleName("Video display")

    def set_placeholder_visible(self, visible: bool) -> None:
        self.placeholder_visible = visible
        self.update()

    def paintEvent(self, event) -> None:  # type: ignore[override]
        if not self.placeholder_visible:
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.fillRect(self.rect(), QColor("#1f1f1f"))
        center = self.rect().center()
        scale = max(0.65, min(1.2, min(self.width(), self.height()) / 390))
        painter.save()
        painter.translate(center.x(), center.y() - 15 * scale)
        painter.scale(scale, scale)
        orange = QColor("#e97917")
        white = QColor("#f4f4f4")
        shadow = QColor(0, 0, 0, 90)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(shadow)
        painter.drawEllipse(QRectF(-66, 80, 132, 24))
        painter.setBrush(orange)
        painter.drawPolygon([QPoint(-50, 80), QPoint(-28, -78), QPoint(28, -78), QPoint(50, 80)])
        painter.setBrush(white)
        painter.drawPolygon([QPoint(-34, -32), QPoint(34, -32), QPoint(40, 9), QPoint(-40, 9)])
        painter.setBrush(orange)
        painter.drawRoundedRect(QRectF(-68, 72, 136, 19), 3, 3)
        painter.setPen(QPen(QColor("#b9b9b9"), 1))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawPolygon([QPoint(-50, 80), QPoint(-28, -78), QPoint(28, -78), QPoint(50, 80)])
        painter.restore()
        painter.setPen(QColor("#cfcfcf"))
        font = painter.font()
        font.setPointSize(10)
        painter.setFont(font)
        painter.drawText(
            QRectF(0, center.y() + 110 * scale, self.width(), 28),
            Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop,
            "Media Player",
        )

    def dragEnterEvent(self, event: QDragEnterEvent) -> None:
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event: QDropEvent) -> None:
        sources: list[str] = []
        for url in event.mimeData().urls():
            sources.append(url.toLocalFile() if url.isLocalFile() else url.toString())
        if sources:
            self.sources_dropped.emit(sources)
            event.acceptProposedAction()

    def mouseDoubleClickEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self.double_clicked.emit()
        super().mouseDoubleClickEvent(event)

    def contextMenuEvent(self, event) -> None:  # type: ignore[override]
        self.context_menu_requested.emit(event.globalPos())

    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        self.pointer_moved.emit()
        super().mouseMoveEvent(event)


class PlaylistTree(QTreeWidget):
    play_requested = Signal(str)
    remove_requested = Signal(list)
    order_changed = Signal(list)
    clear_requested = Signal()

    ITEM_ID_ROLE = Qt.ItemDataRole.UserRole

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setColumnCount(5)
        self.setHeaderLabels(["Title", "Duration", "Artist", "Album", "Location"])
        self.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.setDragEnabled(True)
        self.setAcceptDrops(True)
        self.setDropIndicatorShown(True)
        self.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.setSortingEnabled(False)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._show_context_menu)
        self.itemDoubleClicked.connect(
            lambda item, _column: self.play_requested.emit(item.data(0, self.ITEM_ID_ROLE))
        )
        self.setAccessibleName("Playlist")

    def sync_items(self, items: tuple[PlaylistItem, ...], current_id: str | None) -> None:
        selected = {item.data(0, self.ITEM_ID_ROLE) for item in self.selectedItems()}
        self.clear()
        for media in items:
            marker = "▶ " if media.item_id == current_id else ""
            duration = (
                format_time(media.duration_ms, include_hours=True)
                if media.duration_ms is not None
                else ""
            )
            row = QTreeWidgetItem(
                [marker + media.display_title, duration, media.artist, media.album, media.source]
            )
            row.setData(0, self.ITEM_ID_ROLE, media.item_id)
            row.setToolTip(4, media.source)
            self.addTopLevelItem(row)
            row.setSelected(media.item_id in selected)
        self.resizeColumnToContents(0)
        self.resizeColumnToContents(1)

    def ordered_ids(self) -> list[str]:
        return [
            self.topLevelItem(index).data(0, self.ITEM_ID_ROLE)
            for index in range(self.topLevelItemCount())
        ]

    def selected_ids(self) -> list[str]:
        return [item.data(0, self.ITEM_ID_ROLE) for item in self.selectedItems()]

    def dropEvent(self, event: QDropEvent) -> None:
        super().dropEvent(event)
        self.order_changed.emit(self.ordered_ids())

    def apply_filter(self, query: str) -> None:
        needle = query.strip().casefold()
        for index in range(self.topLevelItemCount()):
            item = self.topLevelItem(index)
            haystack = " ".join(
                item.text(column) for column in range(self.columnCount())
            ).casefold()
            item.setHidden(bool(needle and needle not in haystack))

    def _show_context_menu(self, position: QPoint) -> None:
        menu = QMenu(self)
        play = menu.addAction("Play")
        remove = menu.addAction("Remove Selected")
        menu.addSeparator()
        clear = menu.addAction("Clear Playlist")
        play.setEnabled(len(self.selectedItems()) == 1)
        remove.setEnabled(bool(self.selectedItems()))
        chosen = menu.exec(self.viewport().mapToGlobal(position))
        if chosen is play and self.selectedItems():
            self.play_requested.emit(self.selectedItems()[0].data(0, self.ITEM_ID_ROLE))
        elif chosen is remove:
            self.remove_requested.emit(self.selected_ids())
        elif chosen is clear:
            self.clear_requested.emit()


class PlaylistPanel(QWidget):
    sort_requested = Signal(str)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)
        top = QHBoxLayout()
        title = QLabel("Playlist")
        font = title.font()
        font.setPointSize(font.pointSize() + 2)
        font.setBold(True)
        title.setFont(font)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search playlist")
        self.search.setClearButtonEnabled(True)
        self.search.setMaximumWidth(250)
        self.sort = QComboBox()
        self.sort.addItem("Sort playlist…", "")
        self.sort.addItem("Sort by title", "title")
        self.sort.addItem("Sort by artist", "artist")
        self.sort.addItem("Sort by album", "album")
        self.sort.addItem("Sort by duration", "duration_ms")
        top.addWidget(title)
        top.addStretch(1)
        top.addWidget(self.search)
        top.addWidget(self.sort)
        layout.addLayout(top)
        self.tree = PlaylistTree()
        layout.addWidget(self.tree, 1)
        self.search.textChanged.connect(self.tree.apply_filter)
        self.sort.currentIndexChanged.connect(
            lambda: (
                self.sort_requested.emit(str(self.sort.currentData()))
                if self.sort.currentData()
                else None
            )
        )


class FullscreenOverlay(QFrame):
    previous_clicked = Signal()
    play_clicked = Signal()
    stop_clicked = Signal()
    next_clicked = Signal()
    leave_clicked = Signal()
    seek_requested = Signal(int)
    volume_changed = Signal(int)

    def __init__(self, parent: QWidget) -> None:
        super().__init__(parent)
        self.setObjectName("fullscreenControls")
        self.setStyleSheet(
            "#fullscreenControls { background: rgba(25, 25, 25, 220); border: 1px solid #555; border-radius: 3px; }"
            "#fullscreenControls QToolButton { color: white; min-width: 28px; min-height: 28px; }"
            "#fullscreenControls QLabel { color: white; }"
        )
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 7, 10, 7)
        layout.setSpacing(6)
        style = self.style()
        self.previous_button = QToolButton()
        self.previous_button.setIcon(style.standardIcon(QStyle.StandardPixmap.SP_MediaSkipBackward))
        self.previous_button.setAccessibleName("Previous")
        self.play_button = QToolButton()
        self.play_button.setIcon(style.standardIcon(QStyle.StandardPixmap.SP_MediaPlay))
        self.play_button.setAccessibleName("Play or pause")
        self.stop_button = QToolButton()
        self.stop_button.setIcon(style.standardIcon(QStyle.StandardPixmap.SP_MediaStop))
        self.stop_button.setAccessibleName("Stop")
        self.next_button = QToolButton()
        self.next_button.setIcon(style.standardIcon(QStyle.StandardPixmap.SP_MediaSkipForward))
        self.next_button.setAccessibleName("Next")
        self.seek = SeekSlider()
        self.time_label = QLabel("00:00 / 00:00")
        self.volume = QSlider(Qt.Orientation.Horizontal)
        self.volume.setRange(0, 125)
        self.volume.setValue(100)
        self.volume.setFixedWidth(90)
        self.volume.setAccessibleName("Volume")
        self.leave_button = QToolButton()
        self.leave_button.setText("Exit")
        self.leave_button.setAccessibleName("Leave fullscreen")
        for button in (self.previous_button, self.play_button, self.stop_button, self.next_button):
            layout.addWidget(button)
        layout.addWidget(self.seek, 1)
        layout.addWidget(self.time_label)
        layout.addWidget(self.volume)
        layout.addWidget(self.leave_button)
        self.previous_button.clicked.connect(self.previous_clicked)
        self.play_button.clicked.connect(self.play_clicked)
        self.stop_button.clicked.connect(self.stop_clicked)
        self.next_button.clicked.connect(self.next_clicked)
        self.leave_button.clicked.connect(self.leave_clicked)
        self.seek.seek_requested.connect(self.seek_requested)
        self.seek.drag_finished.connect(self.seek_requested)
        self.volume.valueChanged.connect(self.volume_changed)
        self.setFixedHeight(50)
        self.hide()

    def set_playing(self, playing: bool) -> None:
        icon_type = (
            QStyle.StandardPixmap.SP_MediaPause if playing else QStyle.StandardPixmap.SP_MediaPlay
        )
        self.play_button.setIcon(self.style().standardIcon(icon_type))
