"""Main window reproducing the classic VLC 3.x Windows interaction model."""

from __future__ import annotations

import logging
import re
from collections.abc import Iterable
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from PySide6.QtCore import QByteArray, QPoint, Qt, QThreadPool, QTimer, QUrl
from PySide6.QtGui import (
    QAction,
    QActionGroup,
    QCloseEvent,
    QDesktopServices,
    QDragEnterEvent,
    QDropEvent,
    QKeyEvent,
    QKeySequence,
    QResizeEvent,
)
from PySide6.QtWidgets import (
    QAbstractSpinBox,
    QApplication,
    QComboBox,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPlainTextEdit,
    QProgressDialog,
    QSlider,
    QStackedWidget,
    QStatusBar,
    QStyle,
    QTextEdit,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from .. import APP_NAME
from ..constants import (
    DEFAULT_WINDOW_SIZE,
    FULLSCREEN_HIDE_DELAY_MS,
    MINIMUM_WINDOW_SIZE,
    PLAYLIST_EXTENSIONS,
    SUBTITLE_EXTENSIONS,
)
from ..engine import PlaybackState
from ..logging_utils import RingLogHandler
from ..media_utils import is_probable_url, normalize_source, source_comparison_key
from ..models import PlaylistItem, PlaylistQueue, RepeatMode
from ..persistence import SettingsRepository
from ..playlist_io import load_playlist, save_playlist
from ..workers import FolderScanTask
from .dialogs import (
    AboutDialog,
    ConversionDialog,
    EffectsDialog,
    JumpToTimeDialog,
    MediaInformationDialog,
    MessagesDialog,
    OpenMediaDialog,
    PreferencesDialog,
    StreamDialog,
    TrackSynchronizationDialog,
    open_help,
    show_unavailable,
)
from .widgets import FullscreenOverlay, PlaylistPanel, SeekSlider, VideoSurface, format_time

LOGGER = logging.getLogger(__name__)


class MainWindow(QMainWindow):
    def __init__(
        self,
        controller: Any,
        settings: SettingsRepository,
        log_handler: RingLogHandler,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.controller = controller
        self.settings = settings
        self.log_handler = log_handler
        self.queue = PlaylistQueue()
        self._duration_ms = 0
        self._position_ms = 0
        self._slider_dragging = False
        self._resume_checked = True
        self._pending_resume_source = ""
        self._loaded_item_id: str | None = None
        self._normal_geometry = QByteArray()
        self._normal_was_maximized = False
        self._playlist_before_fullscreen = False
        self._a_marker: int | None = None
        self._b_marker: int | None = None
        self._scan_jobs: dict[FolderScanTask, QProgressDialog] = {}
        self._closing = False

        self.setWindowTitle(APP_NAME)
        self.resize(*DEFAULT_WINDOW_SIZE)
        self.setMinimumSize(*MINIMUM_WINDOW_SIZE)
        self.setAcceptDrops(True)
        self._build_ui()
        self._build_actions()
        self._build_menus()
        self._connect_controller()
        self._restore_settings()

        self.sleep_timer = QTimer(self)
        self.sleep_timer.setSingleShot(True)
        self.sleep_timer.timeout.connect(self._sleep_timer_elapsed)
        self.fullscreen_timer = QTimer(self)
        self.fullscreen_timer.setSingleShot(True)
        self.fullscreen_timer.setInterval(FULLSCREEN_HIDE_DELAY_MS)
        self.fullscreen_timer.timeout.connect(self._hide_fullscreen_controls)
        self.resume_save_timer = QTimer(self)
        self.resume_save_timer.setInterval(10_000)
        self.resume_save_timer.timeout.connect(self._save_resume_position)
        self.resume_save_timer.start()
        QTimer.singleShot(0, self._attach_video_surface)

    def _build_ui(self) -> None:
        self.central = QWidget()
        self.setCentralWidget(self.central)
        layout = QVBoxLayout(self.central)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.stack = QStackedWidget()
        self.video_surface = VideoSurface()
        self.playlist_panel = PlaylistPanel()
        self.stack.addWidget(self.video_surface)
        self.stack.addWidget(self.playlist_panel)
        layout.addWidget(self.stack, 1)

        self.seek_row = QWidget()
        seek_layout = QHBoxLayout(self.seek_row)
        seek_layout.setContentsMargins(8, 5, 8, 2)
        seek_layout.setSpacing(8)
        self.seek_slider = SeekSlider()
        self.seek_slider.setEnabled(False)
        self.time_label = QLabel("00:00 / 00:00")
        self.time_label.setMinimumWidth(105)
        self.time_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        seek_layout.addWidget(self.seek_slider, 1)
        seek_layout.addWidget(self.time_label)
        layout.addWidget(self.seek_row)

        self.advanced_bar = QWidget()
        advanced_layout = QHBoxLayout(self.advanced_bar)
        advanced_layout.setContentsMargins(8, 2, 8, 2)
        advanced_layout.setSpacing(4)
        self.record_button = QToolButton()
        self.record_button.setText("●")
        self.record_button.setToolTip("Record")
        self.record_button.setAccessibleName("Record")
        self.ab_button = QToolButton()
        self.ab_button.setText("A↔B")
        self.ab_button.setToolTip("A-B loop")
        self.ab_button.setAccessibleName("A-B loop")
        self.frame_button = QToolButton()
        self.frame_button.setText("E")
        self.frame_button.setToolTip("Frame by frame")
        self.frame_button.setAccessibleName("Frame by frame")
        advanced_layout.addWidget(self.record_button)
        advanced_layout.addWidget(self.ab_button)
        advanced_layout.addWidget(self.frame_button)
        advanced_layout.addStretch(1)
        self.advanced_bar.hide()
        layout.addWidget(self.advanced_bar)

        self.toolbar = QWidget()
        self.toolbar.setObjectName("playbackToolbar")
        toolbar_layout = QHBoxLayout(self.toolbar)
        toolbar_layout.setContentsMargins(7, 3, 8, 7)
        toolbar_layout.setSpacing(3)
        style = self.style()
        self.play_button = self._tool_button(
            "Play or pause", QStyle.StandardPixmap.SP_MediaPlay, 42
        )
        self.previous_button = self._tool_button(
            "Previous", QStyle.StandardPixmap.SP_MediaSkipBackward
        )
        self.stop_button = self._tool_button("Stop", QStyle.StandardPixmap.SP_MediaStop)
        self.next_button = self._tool_button("Next", QStyle.StandardPixmap.SP_MediaSkipForward)
        self.fullscreen_button = self._tool_button(
            "Fullscreen", QStyle.StandardPixmap.SP_TitleBarMaxButton
        )
        self.playlist_button = QToolButton()
        self.playlist_button.setText("☷")
        self.playlist_button.setCheckable(True)
        self.playlist_button.setToolTip("Show or hide playlist")
        self.playlist_button.setAccessibleName("Toggle playlist")
        self.repeat_button = QToolButton()
        self.repeat_button.setText("↻")
        self.repeat_button.setToolTip("Repeat: off")
        self.repeat_button.setAccessibleName("Change repeat mode")
        self.shuffle_button = QToolButton()
        self.shuffle_button.setText("⇄")
        self.shuffle_button.setCheckable(True)
        self.shuffle_button.setToolTip("Shuffle")
        self.shuffle_button.setAccessibleName("Shuffle")
        for button in (
            self.play_button,
            self.previous_button,
            self.stop_button,
            self.next_button,
            self.fullscreen_button,
            self.playlist_button,
            self.repeat_button,
            self.shuffle_button,
        ):
            toolbar_layout.addWidget(button)
        toolbar_layout.addStretch(1)
        self.volume_button = QToolButton()
        self.volume_button.setIcon(style.standardIcon(QStyle.StandardPixmap.SP_MediaVolume))
        self.volume_button.setToolTip("Mute")
        self.volume_button.setAccessibleName("Mute")
        self.volume_slider = QSlider(Qt.Orientation.Horizontal)
        self.volume_slider.setRange(0, 125)
        self.volume_slider.setFixedWidth(115)
        self.volume_slider.setAccessibleName("Volume")
        self.volume_value = QLabel("100%")
        self.volume_value.setMinimumWidth(36)
        toolbar_layout.addWidget(self.volume_button)
        toolbar_layout.addWidget(self.volume_slider)
        toolbar_layout.addWidget(self.volume_value)
        layout.addWidget(self.toolbar)

        self.setStatusBar(QStatusBar())
        self.statusBar().setSizeGripEnabled(True)
        self.statusBar().showMessage("Ready")
        self.statusBar().hide()

        self.fullscreen_overlay = FullscreenOverlay(self.central)
        self.fullscreen_overlay.previous_clicked.connect(self.play_previous)
        self.fullscreen_overlay.play_clicked.connect(self.toggle_play_pause)
        self.fullscreen_overlay.stop_clicked.connect(self.stop_playback)
        self.fullscreen_overlay.next_clicked.connect(self.play_next)
        self.fullscreen_overlay.leave_clicked.connect(self.leave_fullscreen)
        self.fullscreen_overlay.seek_requested.connect(self._seek_from_slider)
        self.fullscreen_overlay.volume_changed.connect(self._set_volume)

        self.play_button.clicked.connect(self.toggle_play_pause)
        self.previous_button.clicked.connect(self.play_previous)
        self.stop_button.clicked.connect(self.stop_playback)
        self.next_button.clicked.connect(self.play_next)
        self.fullscreen_button.clicked.connect(self.toggle_fullscreen)
        self.playlist_button.toggled.connect(self.set_playlist_visible)
        self.repeat_button.clicked.connect(self.cycle_repeat_mode)
        self.shuffle_button.toggled.connect(self.set_shuffle)
        self.volume_button.clicked.connect(self.toggle_mute)
        self.volume_slider.valueChanged.connect(self._set_volume)
        self.seek_slider.drag_started.connect(self._begin_seek)
        self.seek_slider.drag_finished.connect(self._finish_seek)
        self.seek_slider.seek_requested.connect(self._seek_from_slider)
        self.seek_slider.sliderMoved.connect(self._preview_seek)
        self.record_button.clicked.connect(self._record_unavailable)
        self.ab_button.clicked.connect(self.cycle_ab_loop)
        self.frame_button.clicked.connect(self.frame_step)
        self.video_surface.sources_dropped.connect(self._handle_dropped_sources)
        self.video_surface.double_clicked.connect(self.toggle_fullscreen)
        self.video_surface.context_menu_requested.connect(self._show_video_context_menu)
        self.video_surface.pointer_moved.connect(self._show_fullscreen_controls)
        self.playlist_panel.tree.play_requested.connect(self.play_item)
        self.playlist_panel.tree.remove_requested.connect(self.remove_items)
        self.playlist_panel.tree.clear_requested.connect(self.clear_playlist)
        self.playlist_panel.tree.order_changed.connect(self._reorder_playlist)
        self.playlist_panel.sort_requested.connect(self._sort_playlist)

    def _tool_button(
        self, accessible_name: str, icon: QStyle.StandardPixmap, size: int = 30
    ) -> QToolButton:
        button = QToolButton()
        button.setIcon(self.style().standardIcon(icon))
        button.setFixedSize(size, size)
        button.setIconSize(button.size() * 0.62)
        button.setToolTip(accessible_name)
        button.setAccessibleName(accessible_name)
        return button

    def _make_action(
        self,
        text: str,
        callback: Any,
        shortcut: str | QKeySequence | None = None,
        *,
        checkable: bool = False,
        checked: bool = False,
        menu_only_shortcut: str = "",
    ) -> QAction:
        label = f"{text}\t{menu_only_shortcut}" if menu_only_shortcut else text
        action = QAction(label, self)
        if shortcut:
            action.setShortcut(QKeySequence(shortcut) if isinstance(shortcut, str) else shortcut)
            action.setShortcutContext(Qt.ShortcutContext.WindowShortcut)
        action.setCheckable(checkable)
        action.setChecked(checked)
        action.triggered.connect(callback)
        return action

    def _build_actions(self) -> None:
        self.action_open_file = self._make_action("Open File…", self.open_file, "Ctrl+O")
        self.action_open_multiple = self._make_action(
            "Open Multiple Files…", self.open_multiple_files, "Ctrl+Shift+O"
        )
        self.action_open_folder = self._make_action("Open Folder…", self.open_folder, "Ctrl+F")
        self.action_open_disc = self._make_action(
            "Open Disc…", lambda: self.open_media_dialog(OpenMediaDialog.TAB_DISC), "Ctrl+D"
        )
        self.action_open_network = self._make_action(
            "Open Network Stream…",
            lambda: self.open_media_dialog(OpenMediaDialog.TAB_NETWORK),
            "Ctrl+N",
        )
        self.action_open_capture = self._make_action(
            "Open Capture Device…",
            lambda: self.open_media_dialog(OpenMediaDialog.TAB_CAPTURE),
            "Ctrl+C",
        )
        self.action_open_clipboard = self._make_action(
            "Open Location from clipboard", self.open_clipboard, "Ctrl+V"
        )
        self.action_save_playlist = self._make_action(
            "Save Playlist to File…", self.save_playlist_dialog, "Ctrl+Y"
        )
        self.action_remove_duplicates = self._make_action(
            "Remove Duplicate Entries", self.remove_duplicate_entries
        )
        self.action_remove_missing = self._make_action(
            "Remove Missing Files", self.remove_missing_entries
        )
        self.action_copy_location = self._make_action(
            "Copy Current Media Location", self.copy_current_location
        )
        self.action_open_containing_folder = self._make_action(
            "Open Containing Folder", self.open_containing_folder
        )
        self.action_convert = self._make_action("Convert / Save…", self.show_conversion, "Ctrl+R")
        self.action_stream = self._make_action("Stream…", self.show_streaming, "Ctrl+S")
        self.action_quit = self._make_action("Quit", self.close, "Ctrl+Q")

        self.action_play = self._make_action(
            "Play", self.toggle_play_pause, menu_only_shortcut="Space"
        )
        self.action_stop = self._make_action("Stop", self.stop_playback, menu_only_shortcut="S")
        self.action_previous = self._make_action(
            "Previous", self.play_previous, menu_only_shortcut="P"
        )
        self.action_next = self._make_action("Next", self.play_next, menu_only_shortcut="N")
        self.action_record = self._make_action("Record", self._record_unavailable)
        self.action_jump = self._make_action("Jump to Specific Time", self.jump_to_time, "Ctrl+T")
        self.action_ab = self._make_action("A to B Loop", self.cycle_ab_loop)
        self.action_frame = self._make_action(
            "Frame by Frame", self.frame_step, menu_only_shortcut="E"
        )
        self.action_stop_after_current = self._make_action(
            "Stop after Current Item",
            self._set_stop_after_current,
            checkable=True,
        )
        self.action_quit_at_end = self._make_action(
            "Quit at End of Playlist",
            self._set_quit_at_end,
            checkable=True,
        )
        self.action_faster = self._make_action(
            "Faster", lambda: self.change_rate(0.25), menu_only_shortcut="+"
        )
        self.action_slower = self._make_action(
            "Slower", lambda: self.change_rate(-0.25), menu_only_shortcut="-"
        )
        self.action_normal_rate = self._make_action(
            "Normal Speed", lambda: self.set_rate(1.0), menu_only_shortcut="="
        )
        self.action_jump_forward = self._make_action(
            "Short Forward Jump",
            lambda: self.seek_relative(3_000),
            menu_only_shortcut="Shift+Right",
        )
        self.action_jump_backward = self._make_action(
            "Short Backward Jump",
            lambda: self.seek_relative(-3_000),
            menu_only_shortcut="Shift+Left",
        )

        self.action_volume_up = self._make_action(
            "Increase Volume", lambda: self.adjust_volume(5), menu_only_shortcut="Ctrl+Up"
        )
        self.action_volume_down = self._make_action(
            "Decrease Volume", lambda: self.adjust_volume(-5), menu_only_shortcut="Ctrl+Down"
        )
        self.action_mute = self._make_action(
            "Mute", self.toggle_mute, menu_only_shortcut="M", checkable=True
        )
        self.action_fullscreen = self._make_action(
            "Fullscreen", self.toggle_fullscreen, menu_only_shortcut="F", checkable=True
        )
        self.action_fit_window = self._make_action(
            "Always Fit Window",
            lambda checked: self.controller.set_scale(0.0 if checked else 1.0),
            checkable=True,
            checked=True,
        )
        self.action_on_top = self._make_action(
            "Always on Top", self.set_always_on_top, checkable=True
        )
        self.action_snapshot = self._make_action("Take Snapshot", self.take_snapshot)

        self.action_effects = self._make_action("Effects and Filters", self.show_effects, "Ctrl+E")
        self.action_sync = self._make_action("Track Synchronization", self.show_track_sync)
        self.action_media_info = self._make_action(
            "Media Information", self.show_media_info, "Ctrl+I"
        )
        self.action_codec_info = self._make_action(
            "Codec Information", lambda: self.show_media_info(codec_only=True), "Ctrl+J"
        )
        self.action_messages = self._make_action("Messages", self.show_messages, "Ctrl+M")
        self.action_preferences = self._make_action("Preferences", self.show_preferences, "Ctrl+P")

        self.action_playlist = self._make_action(
            "Playlist", self.set_playlist_visible, "Ctrl+L", checkable=True
        )
        self.action_docked_playlist = self._make_action(
            "Docked Playlist", self._toggle_docked_playlist, checkable=True, checked=True
        )
        self.action_minimal = self._make_action(
            "Minimal Interface", self.set_minimal_interface, "Ctrl+H", checkable=True
        )
        self.action_fullscreen_interface = self._make_action(
            "Fullscreen Interface", self.toggle_fullscreen, "F11", checkable=True
        )
        self.action_advanced = self._make_action(
            "Advanced Controls", self.advanced_bar.setVisible, checkable=True
        )
        self.action_status_bar = self._make_action(
            "Status Bar", self.statusBar().setVisible, checkable=True
        )

        self.action_help = self._make_action("Help", lambda: open_help(self), "F1")
        self.action_about = self._make_action("About", self.show_about, "Shift+F1")

    def _build_menus(self) -> None:
        menu_bar = self.menuBar()
        media = menu_bar.addMenu("&Media")
        for action in (
            self.action_open_file,
            self.action_open_multiple,
            self.action_open_folder,
            self.action_open_disc,
            self.action_open_network,
            self.action_open_capture,
        ):
            media.addAction(action)
        media.addSeparator()
        media.addAction(self.action_open_clipboard)
        self.recent_menu = media.addMenu("Open Recent Media")
        self.recent_menu.aboutToShow.connect(self._populate_recent_menu)
        media.addSeparator()
        media.addAction(self.action_save_playlist)
        playlist_tools = media.addMenu("Playlist Tools")
        playlist_tools.addAction(self.action_remove_duplicates)
        playlist_tools.addAction(self.action_remove_missing)
        playlist_tools.addSeparator()
        playlist_tools.addAction(self.action_copy_location)
        playlist_tools.addAction(self.action_open_containing_folder)
        media.addSeparator()
        media.addAction(self.action_convert)
        media.addAction(self.action_stream)
        media.addSeparator()
        media.addAction(self.action_quit)

        playback = menu_bar.addMenu("&Playback")
        self.title_menu = playback.addMenu("Title")
        self.chapter_menu = playback.addMenu("Chapter")
        self.program_menu = playback.addMenu("Program")
        self.program_menu.addAction(
            self._unavailable_action(
                "No program selection exposed by python-vlc",
                "Program selection",
                "The libVLC 3 Python API does not expose program enumeration consistently.",
            )
        )
        self.bookmarks_menu = playback.addMenu("Custom Bookmarks")
        self.renderer_menu = playback.addMenu("Renderer")
        self.renderer_menu.addAction(
            self._unavailable_action(
                "Select renderer…",
                "Renderer discovery",
                "Renderer discovery is not stable across the supported libVLC 3 runtimes.",
            )
        )
        self.title_menu.aboutToShow.connect(self._populate_title_menu)
        self.chapter_menu.aboutToShow.connect(self._populate_chapter_menu)
        self.bookmarks_menu.aboutToShow.connect(self._populate_bookmarks_menu)
        playback.addSeparator()
        for action in (
            self.action_play,
            self.action_stop,
            self.action_previous,
            self.action_next,
            self.action_record,
        ):
            playback.addAction(action)
        playback.addSeparator()
        speed = playback.addMenu("Speed")
        speed.addAction(self.action_faster)
        speed.addAction(self.action_slower)
        speed.addAction(self.action_normal_rate)
        speed.addSeparator()
        for label, rate in (
            ("0.25x", 0.25),
            ("0.50x", 0.5),
            ("0.75x", 0.75),
            ("1.00x", 1.0),
            ("1.25x", 1.25),
            ("1.50x", 1.5),
            ("2.00x", 2.0),
            ("3.00x", 3.0),
            ("4.00x", 4.0),
        ):
            speed.addAction(label).triggered.connect(
                lambda _checked=False, value=rate: self.set_rate(value)
            )
        jumps = playback.addMenu("Jump Forward / Backward")
        jumps.addAction(self.action_jump_forward)
        jumps.addAction(self.action_jump_backward)
        playback.addAction(self.action_jump)
        playback.addSeparator()
        playback.addAction(self.action_ab)
        playback.addAction(self.action_frame)
        playback.addSeparator()
        playback.addAction(self.action_stop_after_current)
        playback.addAction(self.action_quit_at_end)
        self.sleep_menu = playback.addMenu("Sleep Timer")
        for minutes in (15, 30, 45, 60, 90, 120):
            self.sleep_menu.addAction(f"{minutes} minutes").triggered.connect(
                lambda _checked=False, value=minutes: self.set_sleep_timer(value)
            )
        self.sleep_menu.addSeparator()
        self.sleep_menu.addAction("Cancel Sleep Timer", self.cancel_sleep_timer)

        audio = menu_bar.addMenu("&Audio")
        self.audio_track_menu = audio.addMenu("Audio Track")
        self.stereo_menu = audio.addMenu("Stereo Mode")
        channels = (
            ("Stereo", 1),
            ("Reverse stereo", 2),
            ("Left", 3),
            ("Right", 4),
            ("Dolby Surround", 5),
        )
        for label, value in channels:
            action = self.stereo_menu.addAction(label)
            action.setCheckable(True)
            action.triggered.connect(
                lambda _checked=False, mode=value: self.controller.set_audio_channel(mode)
            )
        self.audio_device_menu = audio.addMenu("Audio Device")
        visualizations = audio.addMenu("Visualizations")
        visualizations.addAction(
            self._unavailable_action(
                "Disable / configure visualizations…",
                "Visualizations",
                "libVLC visualizer module availability depends on the installed runtime and is not exposed safely at runtime.",
            )
        )
        audio.addSeparator()
        audio.addAction(self.action_volume_up)
        audio.addAction(self.action_volume_down)
        audio.addAction(self.action_mute)
        self.audio_track_menu.aboutToShow.connect(self._populate_audio_tracks)
        self.audio_device_menu.aboutToShow.connect(self._populate_audio_devices)
        self.stereo_menu.aboutToShow.connect(self._update_stereo_checks)

        video = menu_bar.addMenu("&Video")
        self.video_track_menu = video.addMenu("Video Track")
        video.addAction(self.action_fullscreen)
        video.addAction(self.action_fit_window)
        video.addAction(
            self._unavailable_action(
                "Set as Wallpaper",
                "Video wallpaper",
                "This operating-system-specific VLC interface feature is not available through libVLC's supported API.",
            )
        )
        zoom = video.addMenu("Zoom")
        for label, scale in (
            ("1:4 Quarter", 0.25),
            ("1:2 Half", 0.5),
            ("1:1 Original", 1.0),
            ("2:1 Double", 2.0),
            ("Fit", 0.0),
        ):
            zoom.addAction(label).triggered.connect(
                lambda _checked=False, value=scale: self.controller.set_scale(value)
            )
        aspect = video.addMenu("Aspect Ratio")
        for label, value in (
            ("Default", ""),
            ("16:9", "16:9"),
            ("4:3", "4:3"),
            ("1:1", "1:1"),
            ("21:9", "21:9"),
            ("16:10", "16:10"),
        ):
            aspect.addAction(label).triggered.connect(
                lambda _checked=False, ratio=value: self.controller.set_aspect_ratio(ratio)
            )
        crop = video.addMenu("Crop")
        for label, value in (
            ("Default", ""),
            ("16:9", "16:9"),
            ("4:3", "4:3"),
            ("1:1", "1:1"),
            ("5:4", "5:4"),
        ):
            crop.addAction(label).triggered.connect(
                lambda _checked=False, geometry=value: self.controller.set_crop(geometry)
            )
        deinterlace = video.addMenu("Deinterlace")
        deinterlace.addAction("Off").triggered.connect(lambda: self.controller.set_deinterlace(""))
        deinterlace.addAction("Automatic").triggered.connect(
            lambda: self.controller.set_deinterlace("auto")
        )
        mode = video.addMenu("Deinterlace mode")
        for label, value in (
            ("Blend", "blend"),
            ("Bob", "bob"),
            ("Yadif", "yadif"),
            ("Yadif (2x)", "yadif2x"),
        ):
            mode.addAction(label).triggered.connect(
                lambda _checked=False, selected=value: self.controller.set_deinterlace(selected)
            )
        post = video.addMenu("Post processing")
        post.addAction(
            self._unavailable_action(
                "Configure…",
                "Post processing",
                "The selected libVLC API does not expose portable post-processing controls.",
            )
        )
        video.addAction(self.action_snapshot)
        self.video_track_menu.aboutToShow.connect(self._populate_video_tracks)

        subtitle = menu_bar.addMenu("Subti&tle")
        subtitle.addAction(self._make_action("Add Subtitle File…", self.add_subtitle))
        self.subtitle_track_menu = subtitle.addMenu("Sub Track")
        self.subtitle_track_menu.aboutToShow.connect(self._populate_subtitle_tracks)

        tools = menu_bar.addMenu("&Tools")
        tools.addAction(self.action_effects)
        tools.addAction(self.action_sync)
        tools.addAction(self.action_media_info)
        tools.addAction(self.action_codec_info)
        tools.addAction(
            self._unavailable_action(
                "VLM Configuration",
                "VLM Configuration",
                "VLM management is not exposed by this desktop interface.",
            )
        )
        tools.addAction(
            self._unavailable_action(
                "Program Guide",
                "Program Guide",
                "No electronic program guide is available for the current input through python-vlc.",
            )
        )
        tools.addAction(self.action_messages)
        tools.addAction(
            self._unavailable_action(
                "Plugins and extensions",
                "Plugins and extensions",
                "VLC Lua extensions cannot be embedded safely in this independent Qt interface.",
            )
        )
        tools.addAction(
            self._unavailable_action(
                "Customize Interface…",
                "Toolbar customization",
                "This build uses the fixed VLC 3.0.21-style toolbar documented in REFERENCE.md.",
            )
        )
        tools.addAction(self.action_preferences)

        view = menu_bar.addMenu("&View")
        view.addAction(self.action_playlist)
        view.addAction(self.action_docked_playlist)
        view.addSeparator()
        view.addAction(self.action_on_top)
        view.addSeparator()
        view.addAction(self.action_minimal)
        view.addAction(self.action_fullscreen_interface)
        view.addSeparator()
        view.addAction(self.action_advanced)
        view.addAction(self.action_status_bar)
        add_interface = view.addMenu("Add Interface")
        add_interface.addAction(
            self._unavailable_action(
                "Console",
                "Additional interfaces",
                "This Python application provides only its PySide6 desktop interface.",
            )
        )
        view.addAction(
            self._unavailable_action(
                "VLsub", "VLsub", "Third-party VLC Lua extensions are not bundled or executed."
            )
        )

        help_menu = menu_bar.addMenu("&Help")
        help_menu.addAction(self.action_help)
        help_menu.addAction(
            self._unavailable_action(
                "Check for Updates…",
                "Updates",
                "This independent project has no automatic update service.",
            )
        )
        help_menu.addAction(self.action_about)

    def _unavailable_action(self, label: str, feature: str, explanation: str) -> QAction:
        action = QAction(label, self)
        action.triggered.connect(lambda: show_unavailable(self, feature, explanation))
        return action

    def _connect_controller(self) -> None:
        self.controller.state_changed.connect(self._on_state_changed)
        self.controller.position_changed.connect(self._on_position_changed)
        self.controller.seekable_changed.connect(self._on_seekable_changed)
        self.controller.buffering_changed.connect(self._on_buffering)
        self.controller.error_occurred.connect(self._on_playback_error)
        self.controller.end_reached.connect(self._on_end_reached)
        self.controller.tracks_changed.connect(self._refresh_video_placeholder)

    def _restore_settings(self) -> None:
        data = self.settings.data
        geometry = data.get("window_geometry", "")
        if isinstance(geometry, str) and geometry:
            self.restoreGeometry(QByteArray.fromBase64(geometry.encode("ascii", errors="ignore")))
        self.volume_slider.blockSignals(True)
        self.volume_slider.setValue(int(data.get("volume", 100)))
        self.volume_slider.blockSignals(False)
        self.fullscreen_overlay.volume.setValue(self.volume_slider.value())
        self.controller.set_volume(self.volume_slider.value())
        muted = bool(data.get("muted", False))
        self.controller.set_muted(muted)
        self.action_mute.setChecked(muted)
        self._update_volume_presentation()
        repeat_value = str(data.get("repeat_mode", "off"))
        self.queue.repeat_mode = (
            RepeatMode(repeat_value)
            if repeat_value in {m.value for m in RepeatMode}
            else RepeatMode.OFF
        )
        self._update_repeat_presentation()
        self.queue.set_shuffle(bool(data.get("shuffle", False)))
        self.shuffle_button.setChecked(self.queue.shuffle)
        self.action_playlist.setChecked(bool(data.get("playlist_visible", False)))
        self.playlist_button.setChecked(bool(data.get("playlist_visible", False)))
        self.set_playlist_visible(bool(data.get("playlist_visible", False)))
        self.action_minimal.setChecked(bool(data.get("minimal_interface", False)))
        self.set_minimal_interface(bool(data.get("minimal_interface", False)))
        self.action_on_top.setChecked(bool(data.get("always_on_top", False)))
        if self.action_on_top.isChecked():
            QTimer.singleShot(0, lambda: self.set_always_on_top(True))
        self._restore_playlist_session()

    def _restore_playlist_session(self) -> None:
        entries, current_id = self.settings.playlist_session()
        items: list[PlaylistItem] = []
        for entry in entries:
            try:
                item = PlaylistItem.from_dict(entry)
            except (TypeError, ValueError):
                continue
            if item.source:
                items.append(item)
        self.queue.extend(items)
        if items:
            selected = self.queue.by_id(current_id) or items[0]
            self.queue.set_current(selected.item_id)
            self._refresh_playlist()
            self.statusBar().showMessage(f"Restored {len(items)} playlist items", 3000)

    def _attach_video_surface(self) -> None:
        self.controller.set_video_output(int(self.video_surface.winId()))

    def open_file(self) -> None:
        initial = str(self.settings.data.get("last_open_directory", ""))
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Open File",
            initial,
            "Media and playlists (*.mp4 *.mkv *.avi *.mov *.webm *.mp3 *.flac *.wav *.ogg *.m3u *.m3u8 *.pls *.xspf);;All files (*)",
        )
        if path:
            self.settings.data["last_open_directory"] = str(Path(path).parent)
            self.add_sources([path], play_first=True)

    def open_multiple_files(self) -> None:
        initial = str(self.settings.data.get("last_open_directory", ""))
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Open Multiple Files", initial, "Media files (*);;All files (*)"
        )
        if paths:
            self.settings.data["last_open_directory"] = str(Path(paths[0]).parent)
            self.add_sources(paths, play_first=True)

    def open_folder(self) -> None:
        initial = str(self.settings.data.get("last_open_directory", ""))
        folder = QFileDialog.getExistingDirectory(self, "Open Folder", initial)
        if folder:
            self.settings.data["last_open_directory"] = folder
            self._start_folder_scan(folder, auto_play=self.queue.current is None)

    def open_media_dialog(self, initial_tab: int = 0) -> None:
        dialog = OpenMediaDialog(self, initial_tab=initial_tab)
        if dialog.exec() != QDialogCode.Accepted:
            return
        sources = dialog.selected_sources()
        self.add_sources(sources, play_first=True)
        subtitle = dialog.subtitle_file()
        if subtitle:
            QTimer.singleShot(600, lambda: self._add_subtitle_path(subtitle))

    def open_clipboard(self) -> None:
        value = QApplication.clipboard().text().strip()
        if not value:
            QMessageBox.information(
                self, "Open Location", "The clipboard does not contain a media location."
            )
            return
        self.add_sources([value], play_first=True)

    def add_sources(self, sources: Iterable[str], *, play_first: bool = False) -> int:
        was_empty = self.queue.current is None
        added: list[PlaylistItem] = []
        errors: list[str] = []
        for raw_source in sources:
            try:
                source = normalize_source(raw_source)
            except ValueError as exc:
                errors.append(str(exc))
                continue
            if not is_probable_url(source) and Path(source).is_dir():
                self._start_folder_scan(source, auto_play=play_first and was_empty and not added)
                continue
            if (
                not is_probable_url(source)
                and Path(source).suffix.casefold() in PLAYLIST_EXTENSIONS
            ):
                try:
                    added.extend(load_playlist(source))
                except (OSError, ValueError) as exc:
                    errors.append(f"{source}: {exc}")
                continue
            if not is_probable_url(source) and not Path(source).is_file():
                errors.append(f"File not found: {source}")
                continue
            added.append(PlaylistItem(source=source))
        self.queue.extend(added)
        self._refresh_playlist()
        if added and play_first and was_empty:
            self.play_item(added[0].item_id)
        if errors:
            QMessageBox.warning(self, "Some Media Could Not Be Added", "\n".join(errors[:12]))
        return len(added)

    def _start_folder_scan(self, folder: str, *, auto_play: bool) -> None:
        task = FolderScanTask(folder)
        progress = QProgressDialog(f"Scanning {folder}", "Cancel", 0, 0, self)
        progress.setWindowTitle("Open Folder")
        progress.setWindowModality(Qt.WindowModality.NonModal)
        progress.setMinimumDuration(300)
        first_batch = {"auto": auto_play}

        def found(paths: list[str]) -> None:
            should_play = first_batch["auto"] and self.queue.current is None
            first_batch["auto"] = False
            self.add_sources(paths, play_first=should_play)

        def finished(cancelled: bool) -> None:
            progress.close()
            self._scan_jobs.pop(task, None)
            self.statusBar().showMessage(
                "Folder scan cancelled" if cancelled else "Folder scan finished", 3000
            )

        task.signals.found.connect(found)
        task.signals.failed.connect(
            lambda message: QMessageBox.warning(self, "Folder Scan", message)
        )
        task.signals.finished.connect(finished)
        progress.canceled.connect(task.cancel)
        self._scan_jobs[task] = progress
        QThreadPool.globalInstance().start(task)

    def play_item(self, item_id: str) -> None:
        item = self.queue.by_id(item_id)
        if item is None:
            return
        self._save_resume_position()
        self.queue.set_current(item_id)
        self._loaded_item_id = None
        self._refresh_playlist()
        self._a_marker = None
        self._b_marker = None
        self._update_ab_presentation()
        source, options = self._split_source_options(item.source)
        options.extend(
            (
                f":subsdec-encoding={self.settings.data.get('subtitle_encoding', 'UTF-8')}",
                f":freetype-rel-fontsize={int(self.settings.data.get('subtitle_font_size', 16))}",
            )
        )
        try:
            self.controller.load(
                source,
                options=options,
                allow_network_metadata=bool(
                    self.settings.data.get("privacy_allow_metadata", False)
                ),
            )
            self._loaded_item_id = item_id
            self.controller.set_volume(self.volume_slider.value())
            self.controller.set_muted(self.action_mute.isChecked())
            self.settings.add_recent(item.source)
            self._pending_resume_source = item.source
            self._resume_checked = False
            self.setWindowTitle(f"{item.display_title} - {APP_NAME}")
            if self.settings.data.get("auto_play", True):
                self.controller.play()
            else:
                self.statusBar().showMessage("Media loaded", 2500)
        except Exception as exc:
            LOGGER.exception("Failed to load %s", item.source)
            self._resume_checked = True
            QMessageBox.critical(self, "Playback Error", str(exc))

    @staticmethod
    def _split_source_options(source: str) -> tuple[str, list[str]]:
        pieces = re.split(r"\s+(?=:[A-Za-z0-9_-]+=?)", source)
        return pieces[0], pieces[1:]

    def toggle_play_pause(self) -> None:
        if self.queue.current is None:
            if len(self.queue):
                self.play_item(self.queue.items[0].item_id)
            else:
                self.open_file()
            return
        if self._loaded_item_id != self.queue.current_id:
            self.play_item(self.queue.current_id)
            return
        self.controller.toggle_pause()

    def stop_playback(self) -> None:
        self._save_resume_position()
        self.controller.stop()

    def play_next(self) -> None:
        item = self.queue.next(natural_end=False)
        if item:
            self.play_item(item.item_id)
        else:
            self.statusBar().showMessage("End of playlist", 2000)

    def play_previous(self) -> None:
        if self.controller.time() > 3000 and not self.queue.shuffle:
            self.controller.set_time(0)
            return
        item = self.queue.previous()
        if item:
            self.play_item(item.item_id)

    def remove_items(self, item_ids: list[str]) -> None:
        was_current = self.queue.current_id in set(item_ids)
        was_playing = self.controller.state == PlaybackState.PLAYING
        if was_current:
            self._save_resume_position()
        replacement = self.queue.remove_ids(item_ids)
        if was_current:
            self.controller.stop()
            self._loaded_item_id = None
            if replacement:
                self.play_item(replacement.item_id)
                if not was_playing:
                    self.controller.pause()
            else:
                self.setWindowTitle(APP_NAME)
                self.video_surface.set_placeholder_visible(True)
        self._refresh_playlist()

    def clear_playlist(self) -> None:
        if not len(self.queue):
            return
        self._save_resume_position()
        self.controller.stop()
        self._loaded_item_id = None
        self.queue.clear()
        self._refresh_playlist()
        self.setWindowTitle(APP_NAME)
        self.video_surface.set_placeholder_visible(True)

    def _reorder_playlist(self, item_ids: list[str]) -> None:
        try:
            self.queue.reorder(item_ids)
        except ValueError:
            self._refresh_playlist()

    def _sort_playlist(self, field_name: str) -> None:
        self.queue.sort(field_name)
        self._refresh_playlist()

    def _refresh_playlist(self) -> None:
        self.playlist_panel.tree.sync_items(self.queue.items, self.queue.current_id)

    def save_playlist_dialog(self) -> None:
        if not len(self.queue):
            QMessageBox.information(self, "Save Playlist", "The playlist is empty.")
            return
        path, selected = QFileDialog.getSaveFileName(
            self,
            "Save Playlist",
            "playlist.m3u8",
            "M3U8 playlist (*.m3u8);;XSPF playlist (*.xspf);;PLS playlist (*.pls)",
        )
        del selected
        if not path:
            return
        if not Path(path).suffix:
            path += ".m3u8"
        try:
            save_playlist(path, self.queue.items)
            self.statusBar().showMessage(f"Playlist saved to {path}", 4000)
        except (OSError, ValueError) as exc:
            QMessageBox.critical(self, "Save Playlist", str(exc))

    def remove_duplicate_entries(self) -> int:
        seen: dict[str, str] = {}
        duplicate_ids: list[str] = []
        for item in self.queue.items:
            key = source_comparison_key(item.source)
            previous_id = seen.get(key)
            if previous_id is None:
                seen[key] = item.item_id
            elif item.item_id == self.queue.current_id:
                duplicate_ids.append(previous_id)
                seen[key] = item.item_id
            else:
                duplicate_ids.append(item.item_id)
        self.queue.remove_ids(duplicate_ids)
        self._refresh_playlist()
        self.statusBar().showMessage(
            f"Removed {len(duplicate_ids)} duplicate playlist entries", 3000
        )
        return len(duplicate_ids)

    def remove_missing_entries(self) -> int:
        missing_ids = [
            item.item_id
            for item in self.queue.items
            if not is_probable_url(item.source) and not Path(item.source).is_file()
        ]
        if missing_ids:
            self.remove_items(missing_ids)
        self.statusBar().showMessage(
            f"Removed {len(missing_ids)} missing playlist entries", 3000
        )
        return len(missing_ids)

    def copy_current_location(self) -> None:
        if not self.queue.current:
            self.statusBar().showMessage("No current media location to copy", 2500)
            return
        QApplication.clipboard().setText(self.queue.current.source)
        self.statusBar().showMessage("Media location copied", 2500)

    def open_containing_folder(self) -> None:
        if not self.queue.current or is_probable_url(self.queue.current.source):
            QMessageBox.information(
                self, "Open Containing Folder", "The current item is not a local file."
            )
            return
        folder = Path(self.queue.current.source).parent
        if not folder.is_dir() or not QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder))):
            QMessageBox.warning(
                self, "Open Containing Folder", f"Could not open the folder:\n{folder}"
            )

    def _handle_dropped_sources(self, sources: list[str]) -> None:
        subtitles: list[str] = []
        media: list[str] = []
        for source in sources:
            if not is_probable_url(source) and Path(source).suffix.casefold() in SUBTITLE_EXTENSIONS:
                subtitles.append(source)
            else:
                media.append(source)
        if media:
            self.add_sources(media, play_first=True)
        if subtitles and self._loaded_item_id:
            for subtitle in subtitles:
                self._add_subtitle_path(subtitle)
        elif subtitles:
            QMessageBox.information(
                self, "Subtitle", "Start a media item before dropping a subtitle file."
            )

    def set_playlist_visible(self, visible: bool = True) -> None:
        visible = bool(visible)
        self.stack.setCurrentWidget(self.playlist_panel if visible else self.video_surface)
        self.action_playlist.blockSignals(True)
        self.playlist_button.blockSignals(True)
        self.action_playlist.setChecked(visible)
        self.playlist_button.setChecked(visible)
        self.action_playlist.blockSignals(False)
        self.playlist_button.blockSignals(False)
        self.settings.data["playlist_visible"] = visible

    def cycle_repeat_mode(self) -> None:
        modes = (RepeatMode.OFF, RepeatMode.ONE, RepeatMode.ALL)
        self.queue.repeat_mode = modes[(modes.index(self.queue.repeat_mode) + 1) % len(modes)]
        self.settings.data["repeat_mode"] = self.queue.repeat_mode.value
        self._update_repeat_presentation()

    def _update_repeat_presentation(self) -> None:
        labels = {
            RepeatMode.OFF: "Repeat: off",
            RepeatMode.ONE: "Repeat: one",
            RepeatMode.ALL: "Repeat: all",
        }
        self.repeat_button.setToolTip(labels[self.queue.repeat_mode])
        self.repeat_button.setText("↻¹" if self.queue.repeat_mode == RepeatMode.ONE else "↻")
        self.repeat_button.setDown(self.queue.repeat_mode != RepeatMode.OFF)

    def set_shuffle(self, enabled: bool) -> None:
        self.queue.set_shuffle(bool(enabled))
        self.settings.data["shuffle"] = bool(enabled)

    def _begin_seek(self) -> None:
        self._slider_dragging = True

    def _finish_seek(self, value: int) -> None:
        self._slider_dragging = False
        self._seek_from_slider(value)

    def _seek_from_slider(self, value: int) -> None:
        if self._duration_ms > 0 and self.controller.is_seekable():
            self.controller.set_time(int(value))

    def _preview_seek(self, value: int) -> None:
        self.time_label.setText(
            f"{format_time(value, include_hours=self._duration_ms >= 3_600_000)} / {format_time(self._duration_ms, include_hours=self._duration_ms >= 3_600_000)}"
        )

    def seek_relative(self, amount_ms: int) -> None:
        if self.controller.is_seekable():
            self.controller.set_time(
                min(self._duration_ms, max(0, self.controller.time() + amount_ms))
            )

    def jump_to_time(self) -> None:
        if not self.controller.is_seekable():
            QMessageBox.information(self, "Jump to Time", "The current media is not seekable.")
            return
        dialog = JumpToTimeDialog(self.controller.time(), self)
        if dialog.exec() == QDialogCode.Accepted:
            self.controller.set_time(min(self._duration_ms, dialog.milliseconds()))

    def frame_step(self) -> None:
        if not self.controller.frame_step():
            QMessageBox.information(
                self,
                "Frame by Frame",
                "Frame stepping is not available for this media or libVLC output.",
            )

    def cycle_ab_loop(self) -> None:
        current = self.controller.time()
        if self._a_marker is None:
            self._a_marker = current
            self.statusBar().showMessage(
                f"A marker set at {format_time(current, include_hours=True)}", 2500
            )
        elif self._b_marker is None:
            if current <= self._a_marker:
                QMessageBox.information(
                    self, "A-B Loop", "Move playback after the A marker before setting B."
                )
                return
            self._b_marker = current
            self.statusBar().showMessage("A-B loop active", 2500)
        else:
            self._a_marker = None
            self._b_marker = None
            self.statusBar().showMessage("A-B loop cleared", 2500)
        self._update_ab_presentation()

    def _update_ab_presentation(self) -> None:
        if self._a_marker is None:
            label = "A to B Loop"
            button = "A↔B"
        elif self._b_marker is None:
            label = "Set B marker (A is set)"
            button = "A→B"
        else:
            label = "Clear A to B Loop"
            button = "A↔B●"
        self.action_ab.setText(label)
        self.ab_button.setText(button)

    def change_rate(self, delta: float) -> None:
        self.set_rate(min(4.0, max(0.25, self.controller.rate() + delta)))

    def set_rate(self, rate: float) -> None:
        if not self.controller.set_rate(rate):
            QMessageBox.information(
                self, "Playback Speed", "The requested speed is unavailable for this media."
            )
        else:
            self.statusBar().showMessage(f"Speed: {rate:.2f}x", 2000)

    def _set_stop_after_current(self, enabled: bool) -> None:
        if enabled:
            self.action_quit_at_end.setChecked(False)
        self.statusBar().showMessage(
            "Playback will stop after the current item" if enabled else "Continuous playback",
            2500,
        )

    def _set_quit_at_end(self, enabled: bool) -> None:
        if enabled:
            self.action_stop_after_current.setChecked(False)
        self.statusBar().showMessage(
            "The player will close at the end of the playlist" if enabled else "Auto-quit disabled",
            2500,
        )

    def set_sleep_timer(self, minutes: int) -> None:
        minutes = max(1, min(24 * 60, int(minutes)))
        self.sleep_timer.start(minutes * 60_000)
        deadline = datetime.now() + timedelta(minutes=minutes)
        self.sleep_menu.setTitle(f"Sleep Timer (until {deadline.strftime('%H:%M')})")
        self.statusBar().showMessage(
            f"Sleep timer set for {deadline.strftime('%H:%M')}", 4000
        )

    def cancel_sleep_timer(self) -> None:
        was_active = self.sleep_timer.isActive()
        self.sleep_timer.stop()
        self.sleep_menu.setTitle("Sleep Timer")
        self.statusBar().showMessage(
            "Sleep timer cancelled" if was_active else "No sleep timer is active", 2500
        )

    def _sleep_timer_elapsed(self) -> None:
        self.sleep_menu.setTitle("Sleep Timer")
        self.stop_playback()
        self.statusBar().showMessage("Sleep timer stopped playback", 5000)

    def adjust_volume(self, amount: int) -> None:
        self.volume_slider.setValue(self.volume_slider.value() + amount)

    def _set_volume(self, value: int) -> None:
        value = self.controller.set_volume(value)
        self.volume_slider.blockSignals(True)
        self.fullscreen_overlay.volume.blockSignals(True)
        self.volume_slider.setValue(value)
        self.fullscreen_overlay.volume.setValue(value)
        self.volume_slider.blockSignals(False)
        self.fullscreen_overlay.volume.blockSignals(False)
        self.settings.data["volume"] = value
        if value > 0 and self.action_mute.isChecked():
            self.action_mute.setChecked(False)
            self.controller.set_muted(False)
            self.settings.data["muted"] = False
        self._update_volume_presentation()

    def toggle_mute(self) -> None:
        muted = not self.controller.is_muted()
        self.controller.set_muted(muted)
        self.action_mute.setChecked(muted)
        self.settings.data["muted"] = muted
        self._update_volume_presentation()

    def _update_volume_presentation(self) -> None:
        muted = self.controller.is_muted()
        icon = (
            QStyle.StandardPixmap.SP_MediaVolumeMuted
            if muted
            else QStyle.StandardPixmap.SP_MediaVolume
        )
        self.volume_button.setIcon(self.style().standardIcon(icon))
        self.volume_value.setText("Muted" if muted else f"{self.volume_slider.value()}%")

    def take_snapshot(self) -> None:
        directory_value = str(self.settings.data.get("snapshot_directory", ""))
        directory = (
            Path(directory_value).expanduser() if directory_value else Path.home() / "Pictures"
        )
        try:
            directory.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            QMessageBox.critical(self, "Snapshot", f"Could not create the snapshot folder: {exc}")
            return
        extension = str(self.settings.data.get("snapshot_format", "png"))
        stem = re.sub(
            r"[^A-Za-z0-9._-]+",
            "_",
            self.queue.current.display_title if self.queue.current else "snapshot",
        )[:60]
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        path = directory / f"{stem}-{timestamp}.{extension}"
        index = 2
        while path.exists():
            path = directory / f"{stem}-{timestamp}-{index}.{extension}"
            index += 1
        if self.controller.snapshot(str(path)):
            self.statusBar().showMessage(f"Snapshot saved to {path}", 5000)
        else:
            QMessageBox.warning(
                self, "Snapshot", "libVLC could not capture the current video frame."
            )

    def add_subtitle(self) -> None:
        initial = str(self.settings.data.get("last_subtitle_directory", ""))
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Add Subtitle File",
            initial,
            "Subtitle files (*.srt *.ass *.ssa *.sub *.vtt);;All files (*)",
        )
        if path:
            self.settings.data["last_subtitle_directory"] = str(Path(path).parent)
            self._add_subtitle_path(path)

    def _add_subtitle_path(self, path: str) -> None:
        try:
            if self.controller.add_subtitle(path):
                self.statusBar().showMessage(f"Subtitle loaded: {Path(path).name}", 3000)
            else:
                QMessageBox.warning(self, "Subtitle", "The subtitle could not be loaded by libVLC.")
        except (OSError, ValueError) as exc:
            QMessageBox.warning(self, "Subtitle", str(exc))

    def show_conversion(self) -> None:
        ConversionDialog(self.queue.current.source if self.queue.current else "", self).exec()

    def show_streaming(self) -> None:
        StreamDialog(self.queue.current.source if self.queue.current else "", self).exec()

    def show_effects(self) -> None:
        EffectsDialog(self.controller, self).exec()

    def show_track_sync(self) -> None:
        TrackSynchronizationDialog(self.controller, self).exec()

    def show_media_info(self, *, codec_only: bool = False) -> None:
        MediaInformationDialog(self.controller, self, codec_only=codec_only).exec()

    def show_messages(self) -> None:
        MessagesDialog(self.log_handler, self).exec()

    def show_preferences(self) -> None:
        dialog = PreferencesDialog(self.settings.data, self)
        if dialog.exec() != QDialogCode.Accepted:
            return
        self.settings.data = dialog.values()
        self.settings.save()
        self.set_playlist_visible(bool(self.settings.data["playlist_visible"]))
        self._set_volume(int(self.settings.data["volume"]))
        self.controller.set_muted(bool(self.settings.data["muted"]))
        self.action_mute.setChecked(bool(self.settings.data["muted"]))
        self._update_volume_presentation()

    def show_about(self) -> None:
        AboutDialog(self.controller.version, self).exec()

    def set_always_on_top(self, enabled: bool) -> None:
        was_visible = self.isVisible()
        self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, bool(enabled))
        self.settings.data["always_on_top"] = bool(enabled)
        if was_visible:
            self.show()

    def set_minimal_interface(self, enabled: bool) -> None:
        self.settings.data["minimal_interface"] = bool(enabled)
        self.action_minimal.setChecked(bool(enabled))
        if not self.isFullScreen():
            self.menuBar().setVisible(not enabled)
            self.seek_row.setVisible(not enabled)
            self.advanced_bar.setVisible(not enabled and self.action_advanced.isChecked())

    def _toggle_docked_playlist(self, docked: bool) -> None:
        if not docked:
            show_unavailable(
                self,
                "Undocked playlist",
                "The playlist is intentionally kept inside the main window so video ownership remains stable across platforms.",
            )
            QTimer.singleShot(0, lambda: self.action_docked_playlist.setChecked(True))

    def toggle_fullscreen(self) -> None:
        if self.isFullScreen():
            self.leave_fullscreen()
        else:
            self.enter_fullscreen()

    def enter_fullscreen(self) -> None:
        if self.isFullScreen():
            return
        self._normal_geometry = self.saveGeometry()
        self._normal_was_maximized = self.isMaximized()
        self._playlist_before_fullscreen = self.action_playlist.isChecked()
        self.set_playlist_visible(False)
        self.menuBar().hide()
        self.seek_row.hide()
        self.advanced_bar.hide()
        self.toolbar.hide()
        self.statusBar().hide()
        self.showFullScreen()
        self.action_fullscreen.setChecked(True)
        self.action_fullscreen_interface.setChecked(True)
        self._show_fullscreen_controls()

    def leave_fullscreen(self) -> None:
        if not self.isFullScreen():
            return
        self.fullscreen_timer.stop()
        self.fullscreen_overlay.hide()
        self.unsetCursor()
        self.showNormal()
        if self._normal_was_maximized:
            self.showMaximized()
        elif not self._normal_geometry.isEmpty():
            self.restoreGeometry(self._normal_geometry)
        minimal = self.action_minimal.isChecked()
        self.menuBar().setVisible(not minimal)
        self.seek_row.setVisible(not minimal)
        self.advanced_bar.setVisible(not minimal and self.action_advanced.isChecked())
        self.toolbar.show()
        self.statusBar().setVisible(self.action_status_bar.isChecked())
        self.action_fullscreen.setChecked(False)
        self.action_fullscreen_interface.setChecked(False)
        self.set_playlist_visible(self._playlist_before_fullscreen)
        QTimer.singleShot(0, self._attach_video_surface)

    def _show_fullscreen_controls(self) -> None:
        if not self.isFullScreen():
            return
        self.unsetCursor()
        self._position_fullscreen_overlay()
        self.fullscreen_overlay.show()
        self.fullscreen_overlay.raise_()
        self.fullscreen_timer.start()

    def _hide_fullscreen_controls(self) -> None:
        if not self.isFullScreen():
            return
        if self.fullscreen_overlay.underMouse() or self.fullscreen_overlay.seek.isSliderDown():
            self.fullscreen_timer.start()
            return
        self.fullscreen_overlay.hide()
        self.setCursor(Qt.CursorShape.BlankCursor)

    def _position_fullscreen_overlay(self) -> None:
        width = min(920, max(420, self.central.width() - 60))
        x = (self.central.width() - width) // 2
        y = max(10, self.central.height() - self.fullscreen_overlay.height() - 24)
        self.fullscreen_overlay.setGeometry(x, y, width, self.fullscreen_overlay.height())

    def _show_video_context_menu(self, global_position: QPoint) -> None:
        menu = QMenu(self)
        menu.addAction(self.action_play)
        menu.addAction(self.action_stop)
        menu.addAction(self.action_previous)
        menu.addAction(self.action_next)
        menu.addSeparator()
        menu.addAction(self.action_fullscreen)
        menu.addAction(self.action_snapshot)
        menu.addAction(self.action_playlist)
        menu.exec(global_position)

    def _populate_recent_menu(self) -> None:
        self.recent_menu.clear()
        sources = self.settings.recent_sources()
        if not sources:
            empty = self.recent_menu.addAction("No recent media")
            empty.setEnabled(False)
        for source in sources:
            label = Path(source).name if not is_probable_url(source) else source
            action = self.recent_menu.addAction(label)
            action.setToolTip(source)
            action.triggered.connect(
                lambda _checked=False, value=source: self.add_sources([value], play_first=True)
            )
        if sources:
            self.recent_menu.addSeparator()
        self.recent_menu.addAction("Clear", self._clear_history)

    def _clear_history(self) -> None:
        self.settings.clear_history()
        self.statusBar().showMessage("Recent media and resume history cleared", 3000)

    def _populate_title_menu(self) -> None:
        self.title_menu.clear()
        count = self.controller.title_count()
        if count <= 0:
            action = self.title_menu.addAction("No titles")
            action.setEnabled(False)
            return
        group = QActionGroup(self.title_menu)
        current = self.controller.current_title()
        for index in range(count):
            action = self.title_menu.addAction(f"Title {index + 1}")
            action.setCheckable(True)
            action.setChecked(index == current)
            group.addAction(action)
            action.triggered.connect(
                lambda _checked=False, value=index: self.controller.set_title(value)
            )

    def _populate_chapter_menu(self) -> None:
        self.chapter_menu.clear()
        count = self.controller.chapter_count()
        if count <= 0:
            action = self.chapter_menu.addAction("No chapters")
            action.setEnabled(False)
            return
        group = QActionGroup(self.chapter_menu)
        current = self.controller.current_chapter()
        for index in range(count):
            action = self.chapter_menu.addAction(f"Chapter {index + 1}")
            action.setCheckable(True)
            action.setChecked(index == current)
            group.addAction(action)
            action.triggered.connect(
                lambda _checked=False, value=index: self.controller.set_chapter(value)
            )

    def _populate_bookmarks_menu(self) -> None:
        self.bookmarks_menu.clear()
        add = self.bookmarks_menu.addAction("Add Bookmark")
        add.triggered.connect(self._add_bookmark)
        source = self.queue.current.source if self.queue.current else ""
        values = self.settings.bookmark_positions(source) if source else []
        if values:
            self.bookmarks_menu.addSeparator()
        for index, position in enumerate(values, start=1):
            action = self.bookmarks_menu.addAction(
                f"Bookmark {index} — {format_time(position, include_hours=True)}"
            )
            action.triggered.connect(
                lambda _checked=False, value=position: self.controller.set_time(value)
            )
        if values:
            self.bookmarks_menu.addSeparator()
            self.bookmarks_menu.addAction("Clear Bookmarks", lambda: self._clear_bookmarks(source))

    def _add_bookmark(self) -> None:
        if not self.queue.current:
            QMessageBox.information(self, "Bookmarks", "Open media before adding a bookmark.")
            return
        position = self.controller.time()
        if self.settings.add_bookmark(self.queue.current.source, position):
            self.statusBar().showMessage(
                f"Bookmark added at {format_time(position, include_hours=True)}", 2500
            )
        else:
            self.statusBar().showMessage("A bookmark already exists at this time", 2500)

    def _clear_bookmarks(self, source: str) -> None:
        self.settings.clear_bookmarks(source)
        self.statusBar().showMessage("Bookmarks cleared", 2500)

    def _populate_track_menu(
        self, menu: QMenu, tracks: list[tuple[int, str]], current: int, setter: Any
    ) -> None:
        menu.clear()
        if not tracks:
            action = menu.addAction("No tracks")
            action.setEnabled(False)
            return
        group = QActionGroup(menu)
        for track_id, name in tracks:
            action = menu.addAction(name)
            action.setCheckable(True)
            action.setChecked(track_id == current)
            group.addAction(action)
            action.triggered.connect(lambda _checked=False, value=track_id: setter(value))

    def _populate_audio_tracks(self) -> None:
        self._populate_track_menu(
            self.audio_track_menu,
            self.controller.audio_tracks(),
            self.controller.current_audio_track(),
            self.controller.set_audio_track,
        )

    def _populate_video_tracks(self) -> None:
        self._populate_track_menu(
            self.video_track_menu,
            self.controller.video_tracks(),
            self.controller.current_video_track(),
            self.controller.set_video_track,
        )

    def _populate_subtitle_tracks(self) -> None:
        self._populate_track_menu(
            self.subtitle_track_menu,
            self.controller.subtitle_tracks(),
            self.controller.current_subtitle_track(),
            self.controller.set_subtitle_track,
        )

    def _populate_audio_devices(self) -> None:
        self.audio_device_menu.clear()
        devices = self.controller.audio_devices()
        current = self.controller.current_audio_device()
        if not devices:
            action = self.audio_device_menu.addAction(
                "System default (device enumeration unavailable)"
            )
            action.setEnabled(False)
            return
        group = QActionGroup(self.audio_device_menu)
        for device_id, description in devices:
            action = self.audio_device_menu.addAction(description)
            action.setCheckable(True)
            action.setChecked(device_id == current)
            group.addAction(action)
            action.triggered.connect(
                lambda _checked=False, value=device_id: self.controller.set_audio_device(value)
            )

    def _update_stereo_checks(self) -> None:
        current = self.controller.current_audio_channel()
        for index, action in enumerate(self.stereo_menu.actions(), start=1):
            action.setChecked(index == current)

    def _on_state_changed(self, state: PlaybackState) -> None:
        playing = state == PlaybackState.PLAYING
        icon = (
            QStyle.StandardPixmap.SP_MediaPause if playing else QStyle.StandardPixmap.SP_MediaPlay
        )
        self.play_button.setIcon(self.style().standardIcon(icon))
        self.fullscreen_overlay.set_playing(playing)
        self.action_play.setText("Pause\tSpace" if playing else "Play\tSpace")
        messages = {
            PlaybackState.OPENING: "Opening media…",
            PlaybackState.BUFFERING: "Buffering…",
            PlaybackState.PLAYING: "Playing",
            PlaybackState.PAUSED: "Paused",
            PlaybackState.STOPPED: "Stopped",
            PlaybackState.ENDED: "Playback ended",
            PlaybackState.FAILED: "Playback failed",
            PlaybackState.IDLE: "Ready",
        }
        self.statusBar().showMessage(messages.get(state, state.value))
        if state in {PlaybackState.PLAYING, PlaybackState.PAUSED}:
            QTimer.singleShot(250, self._refresh_video_placeholder)
        elif state in {
            PlaybackState.IDLE,
            PlaybackState.STOPPED,
            PlaybackState.ENDED,
            PlaybackState.FAILED,
        } and (state != PlaybackState.STOPPED or not self.controller.video_tracks()):
            self.video_surface.set_placeholder_visible(True)

    def _refresh_video_placeholder(self) -> None:
        tracks = [
            (track_id, name) for track_id, name in self.controller.video_tracks() if track_id >= 0
        ]
        self.video_surface.set_placeholder_visible(not bool(tracks))

    def _on_position_changed(self, position: int, duration: int) -> None:
        self._position_ms = max(0, position)
        self._duration_ms = max(0, duration)
        seekable = self._duration_ms > 0 and self.controller.is_seekable()
        self.seek_slider.setEnabled(seekable)
        self.fullscreen_overlay.seek.setEnabled(seekable)
        if self._duration_ms > 0:
            for slider in (self.seek_slider, self.fullscreen_overlay.seek):
                slider.setRange(0, self._duration_ms)
                if not (
                    slider.isSliderDown() or (slider is self.seek_slider and self._slider_dragging)
                ):
                    slider.setValue(min(self._position_ms, self._duration_ms))
            include_hours = self._duration_ms >= 3_600_000
            label = f"{format_time(self._position_ms, include_hours=include_hours)} / {format_time(self._duration_ms, include_hours=include_hours)}"
        else:
            label = format_time(self._position_ms, include_hours=self._position_ms >= 3_600_000)
        if not self._slider_dragging:
            self.time_label.setText(label)
        self.fullscreen_overlay.time_label.setText(label)
        if (
            self._a_marker is not None
            and self._b_marker is not None
            and self._position_ms >= self._b_marker
        ):
            self.controller.set_time(self._a_marker)
        self._attempt_resume()

    def _on_seekable_changed(self, seekable: bool) -> None:
        enabled = bool(seekable and self._duration_ms > 0)
        self.seek_slider.setEnabled(enabled)
        self.fullscreen_overlay.seek.setEnabled(enabled)

    def _on_buffering(self, percent: float) -> None:
        self.statusBar().showMessage(f"Buffering {max(0.0, min(100.0, percent)):.0f}%")

    def _attempt_resume(self) -> None:
        if self._resume_checked or not self._pending_resume_source or self._duration_ms <= 0:
            return
        if not self.controller.is_seekable():
            return
        position = self.settings.resume_position(self._pending_resume_source, self._duration_ms)
        self._resume_checked = True
        if position is None:
            return
        should_resume = True
        if self.settings.data.get("ask_to_resume", True):
            answer = QMessageBox.question(
                self,
                "Continue Playback",
                f"Continue from {format_time(position, include_hours=True)}?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.Yes,
            )
            should_resume = answer == QMessageBox.StandardButton.Yes
        if should_resume:
            self.controller.set_time(position)

    def _save_resume_position(self) -> None:
        source = str(getattr(self.controller, "source", ""))
        if not source and self.queue.current:
            source = self.queue.current.source
        if not source:
            return
        self.settings.set_resume_position(
            source, self.controller.time(), self.controller.duration()
        )

    def _on_playback_error(self, message: str) -> None:
        LOGGER.error("Playback error for %s: %s", self.controller.source, message)
        self.statusBar().showMessage(message, 7000)
        QMessageBox.warning(
            self, "Playback Error", message + "\n\nThe item remains selected; use Next to skip it."
        )

    def _on_end_reached(self) -> None:
        self._save_resume_position()
        if self.action_stop_after_current.isChecked():
            self.action_stop_after_current.setChecked(False)
            self.video_surface.set_placeholder_visible(True)
            self.statusBar().showMessage("Stopped after the current item", 4000)
            return
        current_id = self.queue.current_id
        next_item = self.queue.next(natural_end=True)
        if next_item is None:
            self.video_surface.set_placeholder_visible(True)
            if self.action_quit_at_end.isChecked():
                self.action_quit_at_end.setChecked(False)
                QTimer.singleShot(0, self.close)
            return
        if next_item.item_id == current_id:
            self.controller.set_time(0)
            self.controller.play()
        else:
            self.play_item(next_item.item_id)

    def _record_unavailable(self) -> None:
        show_unavailable(
            self,
            "Recording",
            "Portable in-session recording is not exposed by the libVLC 3 Python API. Use Convert / Save for a controlled output job.",
        )

    def keyPressEvent(self, event: QKeyEvent) -> None:
        if self._focus_accepts_text():
            super().keyPressEvent(event)
            return
        key = event.key()
        modifiers = event.modifiers()
        if key == Qt.Key.Key_Escape and self.isFullScreen():
            self.leave_fullscreen()
        elif modifiers == Qt.KeyboardModifier.NoModifier and key == Qt.Key.Key_Space:
            self.toggle_play_pause()
        elif modifiers == Qt.KeyboardModifier.NoModifier and key == Qt.Key.Key_S:
            self.stop_playback()
        elif modifiers == Qt.KeyboardModifier.NoModifier and key == Qt.Key.Key_F:
            self.toggle_fullscreen()
        elif modifiers == Qt.KeyboardModifier.NoModifier and key == Qt.Key.Key_N:
            self.play_next()
        elif modifiers == Qt.KeyboardModifier.NoModifier and key == Qt.Key.Key_P:
            self.play_previous()
        elif modifiers == Qt.KeyboardModifier.NoModifier and key == Qt.Key.Key_M:
            self.toggle_mute()
        elif modifiers == Qt.KeyboardModifier.NoModifier and key in {
            Qt.Key.Key_Plus,
            Qt.Key.Key_Equal,
        }:
            self.change_rate(0.25 if key == Qt.Key.Key_Plus else 1.0 - self.controller.rate())
        elif modifiers == Qt.KeyboardModifier.NoModifier and key == Qt.Key.Key_Minus:
            self.change_rate(-0.25)
        elif modifiers == Qt.KeyboardModifier.NoModifier and key == Qt.Key.Key_E:
            self.frame_step()
        elif modifiers == Qt.KeyboardModifier.ShiftModifier and key == Qt.Key.Key_Left:
            self.seek_relative(-3_000)
        elif modifiers == Qt.KeyboardModifier.ShiftModifier and key == Qt.Key.Key_Right:
            self.seek_relative(3_000)
        elif modifiers == Qt.KeyboardModifier.ControlModifier and key == Qt.Key.Key_Up:
            self.adjust_volume(5)
        elif modifiers == Qt.KeyboardModifier.ControlModifier and key == Qt.Key.Key_Down:
            self.adjust_volume(-5)
        else:
            super().keyPressEvent(event)

    @staticmethod
    def _focus_accepts_text() -> bool:
        widget = QApplication.focusWidget()
        while widget is not None:
            if isinstance(
                widget, (QLineEdit, QTextEdit, QPlainTextEdit, QAbstractSpinBox, QComboBox)
            ):
                return True
            widget = widget.parentWidget()
        return False

    def dragEnterEvent(self, event: QDragEnterEvent) -> None:
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event: QDropEvent) -> None:
        sources = [
            url.toLocalFile() if url.isLocalFile() else url.toString()
            for url in event.mimeData().urls()
        ]
        if sources:
            self._handle_dropped_sources(sources)
            event.acceptProposedAction()

    def resizeEvent(self, event: QResizeEvent) -> None:
        super().resizeEvent(event)
        if self.isFullScreen():
            self._position_fullscreen_overlay()

    def closeEvent(self, event: QCloseEvent) -> None:
        if self._closing:
            event.accept()
            return
        self._closing = True
        for task in tuple(self._scan_jobs):
            task.cancel()
        self._save_resume_position()
        self.settings.data.update(
            {
                "volume": self.volume_slider.value(),
                "muted": self.controller.is_muted(),
                "repeat_mode": self.queue.repeat_mode.value,
                "shuffle": self.queue.shuffle,
                "playlist_visible": self.action_playlist.isChecked(),
                "minimal_interface": self.action_minimal.isChecked(),
                "always_on_top": self.action_on_top.isChecked(),
                "window_geometry": bytes(self.saveGeometry().toBase64()).decode("ascii"),
            }
        )
        self.settings.set_playlist_session(
            (item.to_dict() for item in self.queue.items), self.queue.current_id
        )
        try:
            self.settings.save()
        except OSError:
            LOGGER.exception("Could not save settings")
        self.controller.release()
        event.accept()


class QDialogCode:
    """Avoid importing QDialog solely for its enum across PySide6 minor versions."""

    Accepted = 1
