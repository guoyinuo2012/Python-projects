"""Dialogs corresponding to the classic VLC 3.x menu surface."""

from __future__ import annotations

import logging
import sys
from copy import deepcopy
from pathlib import Path
from typing import Any

from PySide6.QtCore import QProcess, QProcessEnvironment, Qt, QTimer, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QRadioButton,
    QSlider,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QTextBrowser,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .. import APP_NAME, APP_VERSION, REFERENCE_VERSION
from ..conversion import (
    CONVERSION_PROFILES,
    build_conversion_arguments,
    build_stream_arguments,
    locate_vlc_executable,
    validate_output_destination,
)
from ..logging_utils import RingLogHandler

LOGGER = logging.getLogger(__name__)


def show_unavailable(parent: QWidget, feature: str, explanation: str) -> None:
    QMessageBox.information(
        parent,
        feature,
        f"{feature} is unavailable in this build.\n\n{explanation}",
    )


class OpenMediaDialog(QDialog):
    """One dialog for file, disc, network, and capture inputs."""

    TAB_FILE = 0
    TAB_DISC = 1
    TAB_NETWORK = 2
    TAB_CAPTURE = 3

    def __init__(self, parent: QWidget | None = None, *, initial_tab: int = 0) -> None:
        super().__init__(parent)
        self.setWindowTitle("Open Media")
        self.resize(610, 390)
        layout = QVBoxLayout(self)
        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_file_tab(), "File")
        self.tabs.addTab(self._build_disc_tab(), "Disc")
        self.tabs.addTab(self._build_network_tab(), "Network")
        self.tabs.addTab(self._build_capture_tab(), "Capture Device")
        self.tabs.setCurrentIndex(max(0, min(self.tabs.count() - 1, initial_tab)))
        layout.addWidget(self.tabs)
        self.buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Open | QDialogButtonBox.StandardButton.Cancel
        )
        self.buttons.accepted.connect(self._validate_and_accept)
        self.buttons.rejected.connect(self.reject)
        layout.addWidget(self.buttons)

    def _build_file_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        label = QLabel("File Selection")
        font = label.font()
        font.setBold(True)
        label.setFont(font)
        layout.addWidget(label)
        self.file_list = QListWidget()
        self.file_list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        layout.addWidget(self.file_list, 1)
        row = QHBoxLayout()
        add_files = QPushButton("Add…")
        add_folder = QPushButton("Add Folder…")
        remove = QPushButton("Remove")
        add_files.clicked.connect(self._choose_files)
        add_folder.clicked.connect(self._choose_folder)
        remove.clicked.connect(
            lambda: [
                self.file_list.takeItem(self.file_list.row(item))
                for item in self.file_list.selectedItems()
            ]
        )
        row.addWidget(add_files)
        row.addWidget(add_folder)
        row.addWidget(remove)
        row.addStretch(1)
        layout.addLayout(row)
        self.subtitle_check = QCheckBox("Use a subtitle file")
        self.subtitle_path = QLineEdit()
        self.subtitle_path.setEnabled(False)
        subtitle_browse = QPushButton("Browse…")
        subtitle_browse.setEnabled(False)
        self.subtitle_check.toggled.connect(self.subtitle_path.setEnabled)
        self.subtitle_check.toggled.connect(subtitle_browse.setEnabled)
        subtitle_browse.clicked.connect(self._choose_subtitle)
        subtitle_row = QHBoxLayout()
        subtitle_row.addWidget(self.subtitle_path, 1)
        subtitle_row.addWidget(subtitle_browse)
        layout.addWidget(self.subtitle_check)
        layout.addLayout(subtitle_row)
        return widget

    def _build_disc_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        group = QGroupBox("Disc Selection")
        radios = QHBoxLayout(group)
        self.disc_dvd = QRadioButton("DVD")
        self.disc_bluray = QRadioButton("Blu-ray")
        self.disc_audio = QRadioButton("Audio CD")
        self.disc_dvd.setChecked(True)
        for radio in (self.disc_dvd, self.disc_bluray, self.disc_audio):
            radios.addWidget(radio)
        radios.addStretch(1)
        layout.addWidget(group)
        form = QFormLayout()
        device_row = QHBoxLayout()
        self.disc_device = QLineEdit()
        self.disc_device.setPlaceholderText("D:\\ or /dev/dvd")
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._choose_disc_directory)
        device_row.addWidget(self.disc_device, 1)
        device_row.addWidget(browse)
        form.addRow("Disc device", device_row)
        self.disc_title = QSpinBox()
        self.disc_title.setRange(0, 999)
        self.disc_chapter = QSpinBox()
        self.disc_chapter.setRange(0, 999)
        form.addRow("Starting title", self.disc_title)
        form.addRow("Starting chapter", self.disc_chapter)
        layout.addLayout(form)
        layout.addStretch(1)
        return widget

    def _build_network_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.addWidget(QLabel("Please enter a network URL:"))
        self.network_url = QComboBox()
        self.network_url.setEditable(True)
        self.network_url.addItems(["https://", "rtsp://", "udp://@", "rtp://@"])
        self.network_url.setCurrentText("")
        layout.addWidget(self.network_url)
        note = QLabel(
            "Supported protocols depend on the installed libVLC runtime and network access."
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        layout.addStretch(1)
        return widget

    def _build_capture_tab(self) -> QWidget:
        widget = QWidget()
        form = QFormLayout(widget)
        self.capture_mode = QComboBox()
        self.capture_mode.addItems(["Screen", "Camera / capture card"])
        self.capture_device = QLineEdit()
        self.capture_device.setPlaceholderText("Optional device name or path")
        self.capture_fps = QSpinBox()
        self.capture_fps.setRange(1, 120)
        self.capture_fps.setValue(30)
        form.addRow("Capture mode", self.capture_mode)
        form.addRow("Device", self.capture_device)
        form.addRow("Desired frame rate", self.capture_fps)
        return widget

    def _choose_files(self) -> None:
        files, _ = QFileDialog.getOpenFileNames(
            self, "Open Media", "", "Media files (*);;All files (*)"
        )
        existing = {self.file_list.item(i).text() for i in range(self.file_list.count())}
        for path in files:
            if path not in existing:
                self.file_list.addItem(path)

    def _choose_folder(self) -> None:
        path = QFileDialog.getExistingDirectory(self, "Open Folder")
        if path:
            self.file_list.addItem(path)

    def _choose_subtitle(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Subtitle",
            "",
            "Subtitle files (*.srt *.ass *.ssa *.sub *.vtt);;All files (*)",
        )
        if path:
            self.subtitle_path.setText(path)

    def _choose_disc_directory(self) -> None:
        path = QFileDialog.getExistingDirectory(self, "Select Disc or Folder")
        if path:
            self.disc_device.setText(path)

    def _validate_and_accept(self) -> None:
        try:
            if not self.selected_sources():
                raise ValueError("Select or enter a media source.")
        except ValueError as exc:
            QMessageBox.warning(self, "Open Media", str(exc))
            return
        self.accept()

    def selected_sources(self) -> list[str]:
        tab = self.tabs.currentIndex()
        if tab == self.TAB_FILE:
            return [self.file_list.item(i).text() for i in range(self.file_list.count())]
        if tab == self.TAB_NETWORK:
            value = self.network_url.currentText().strip()
            return [value] if value else []
        if tab == self.TAB_DISC:
            device = self.disc_device.text().strip()
            scheme = (
                "bluray"
                if self.disc_bluray.isChecked()
                else "cdda"
                if self.disc_audio.isChecked()
                else "dvd"
            )
            base = f"{scheme}:///{device}" if device else f"{scheme}:///"
            if scheme in {"dvd", "bluray"}:
                base += f"#{self.disc_title.value()}:{self.disc_chapter.value()}"
            return [base]
        if self.capture_mode.currentIndex() == 0:
            return [f"screen:// :screen-fps={self.capture_fps.value()}"]
        device = self.capture_device.text().strip()
        if sys.platform.startswith("win"):
            return [f"dshow:// :dshow-vdev={device}" if device else "dshow://"]
        if sys.platform == "darwin":
            return ["qtcapture://"]
        return [f"v4l2://{device}" if device else "v4l2://"]

    def subtitle_file(self) -> str:
        return self.subtitle_path.text().strip() if self.subtitle_check.isChecked() else ""


class JumpToTimeDialog(QDialog):
    def __init__(self, current_ms: int, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Jump to Time")
        layout = QVBoxLayout(self)
        form = QFormLayout()
        row = QHBoxLayout()
        self.hours = QSpinBox()
        self.hours.setRange(0, 999)
        self.minutes = QSpinBox()
        self.minutes.setRange(0, 59)
        self.seconds = QSpinBox()
        self.seconds.setRange(0, 59)
        total_seconds = max(0, current_ms // 1000)
        hours, remainder = divmod(total_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        self.hours.setValue(hours)
        self.minutes.setValue(minutes)
        self.seconds.setValue(seconds)
        row.addWidget(self.hours)
        row.addWidget(QLabel(":"))
        row.addWidget(self.minutes)
        row.addWidget(QLabel(":"))
        row.addWidget(self.seconds)
        form.addRow("Go to time", row)
        layout.addLayout(form)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def milliseconds(self) -> int:
        return ((self.hours.value() * 60 + self.minutes.value()) * 60 + self.seconds.value()) * 1000


class PreferencesDialog(QDialog):
    def __init__(self, settings: dict[str, Any], parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Simple Preferences")
        self.resize(650, 470)
        self._original = deepcopy(settings)
        layout = QVBoxLayout(self)
        self.tabs = QTabWidget()
        self.tabs.addTab(self._interface_tab(settings), "Interface")
        self.tabs.addTab(self._audio_tab(settings), "Audio")
        self.tabs.addTab(self._video_tab(settings), "Video")
        self.tabs.addTab(self._subtitle_tab(settings), "Subtitles / OSD")
        self.tabs.addTab(self._input_tab(settings), "Input / Codecs")
        self.tabs.addTab(self._hotkeys_tab(), "Hotkeys")
        layout.addWidget(self.tabs, 1)
        self.buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save
            | QDialogButtonBox.StandardButton.Cancel
            | QDialogButtonBox.StandardButton.Reset
        )
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        self.buttons.button(QDialogButtonBox.StandardButton.Reset).clicked.connect(
            self._reset_controls
        )
        layout.addWidget(self.buttons)

    def _interface_tab(self, data: dict[str, Any]) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        self.auto_play = QCheckBox("Start playback automatically after opening media")
        self.auto_play.setChecked(bool(data.get("auto_play", True)))
        self.playlist_visible = QCheckBox("Show playlist when the application starts")
        self.playlist_visible.setChecked(bool(data.get("playlist_visible", False)))
        self.restore_playlist = QCheckBox("Restore the previous playlist on startup")
        self.restore_playlist.setChecked(bool(data.get("restore_playlist", True)))
        self.remember_position = QCheckBox("Continue playback from the last position")
        self.remember_position.setChecked(bool(data.get("remember_position", True)))
        self.ask_resume = QCheckBox("Ask before resuming")
        self.ask_resume.setChecked(bool(data.get("ask_to_resume", True)))
        self.metadata = QCheckBox("Allow network metadata and artwork lookups")
        self.metadata.setChecked(bool(data.get("privacy_allow_metadata", False)))
        for control in (
            self.auto_play,
            self.playlist_visible,
            self.restore_playlist,
            self.remember_position,
            self.ask_resume,
            self.metadata,
        ):
            layout.addWidget(control)
        privacy = QLabel(
            "Network metadata is disabled by default. The player never downloads artwork silently."
        )
        privacy.setWordWrap(True)
        layout.addWidget(privacy)
        layout.addStretch(1)
        return widget

    def _audio_tab(self, data: dict[str, Any]) -> QWidget:
        widget = QWidget()
        form = QFormLayout(widget)
        self.default_volume = QSpinBox()
        self.default_volume.setRange(0, 125)
        self.default_volume.setSuffix(" %")
        self.default_volume.setValue(int(data.get("volume", 100)))
        self.start_muted = QCheckBox("Start muted")
        self.start_muted.setChecked(bool(data.get("muted", False)))
        form.addRow("Default volume", self.default_volume)
        form.addRow("", self.start_muted)
        return widget

    def _video_tab(self, data: dict[str, Any]) -> QWidget:
        widget = QWidget()
        form = QFormLayout(widget)
        snapshot_row = QHBoxLayout()
        self.snapshot_directory = QLineEdit(str(data.get("snapshot_directory", "")))
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse_snapshot)
        snapshot_row.addWidget(self.snapshot_directory, 1)
        snapshot_row.addWidget(browse)
        self.snapshot_format = QComboBox()
        self.snapshot_format.addItems(["png", "jpg"])
        self.snapshot_format.setCurrentText(str(data.get("snapshot_format", "png")))
        form.addRow("Video snapshot directory", snapshot_row)
        form.addRow("Snapshot format", self.snapshot_format)
        return widget

    def _subtitle_tab(self, data: dict[str, Any]) -> QWidget:
        widget = QWidget()
        form = QFormLayout(widget)
        self.subtitle_encoding = QComboBox()
        self.subtitle_encoding.addItems(
            ["UTF-8", "UTF-16", "Windows-1252", "ISO-8859-1", "Shift_JIS"]
        )
        self.subtitle_encoding.setCurrentText(str(data.get("subtitle_encoding", "UTF-8")))
        self.subtitle_size = QSpinBox()
        self.subtitle_size.setRange(6, 72)
        self.subtitle_size.setValue(int(data.get("subtitle_font_size", 16)))
        form.addRow("Default text encoding", self.subtitle_encoding)
        form.addRow("Relative font size", self.subtitle_size)
        notice = QLabel(
            "Font rendering options are passed to libVLC when supported; some changes apply to newly opened media only."
        )
        notice.setWordWrap(True)
        form.addRow(notice)
        return widget

    def _input_tab(self, _data: dict[str, Any]) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        label = QLabel(
            "Hardware decoding, caching, and codec availability are controlled by the installed libVLC runtime."
        )
        label.setWordWrap(True)
        layout.addWidget(label)
        layout.addStretch(1)
        return widget

    def _hotkeys_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        table = QTableWidget(0, 2)
        table.setHorizontalHeaderLabels(["Action", "Shortcut"])
        hotkeys = [
            ("Play / Pause", "Space"),
            ("Stop", "S"),
            ("Fullscreen", "F"),
            ("Leave fullscreen", "Esc"),
            ("Next", "N"),
            ("Previous", "P"),
            ("Faster", "+"),
            ("Slower", "-"),
            ("Normal speed", "="),
            ("Volume up", "Ctrl+Up"),
            ("Volume down", "Ctrl+Down"),
            ("Mute", "M"),
            ("Short jump backward", "Shift+Left"),
            ("Short jump forward", "Shift+Right"),
        ]
        table.setRowCount(len(hotkeys))
        for row, values in enumerate(hotkeys):
            for column, value in enumerate(values):
                table.setItem(row, column, QTableWidgetItem(value))
        table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(table)
        return widget

    def _browse_snapshot(self) -> None:
        path = QFileDialog.getExistingDirectory(
            self, "Snapshot Folder", self.snapshot_directory.text()
        )
        if path:
            self.snapshot_directory.setText(path)

    def _reset_controls(self) -> None:
        self.auto_play.setChecked(True)
        self.playlist_visible.setChecked(False)
        self.restore_playlist.setChecked(True)
        self.remember_position.setChecked(True)
        self.ask_resume.setChecked(True)
        self.metadata.setChecked(False)
        self.default_volume.setValue(100)
        self.start_muted.setChecked(False)
        self.snapshot_directory.clear()
        self.snapshot_format.setCurrentText("png")
        self.subtitle_encoding.setCurrentText("UTF-8")
        self.subtitle_size.setValue(16)

    def values(self) -> dict[str, Any]:
        result = deepcopy(self._original)
        result.update(
            {
                "auto_play": self.auto_play.isChecked(),
                "playlist_visible": self.playlist_visible.isChecked(),
                "restore_playlist": self.restore_playlist.isChecked(),
                "remember_position": self.remember_position.isChecked(),
                "ask_to_resume": self.ask_resume.isChecked(),
                "privacy_allow_metadata": self.metadata.isChecked(),
                "volume": self.default_volume.value(),
                "muted": self.start_muted.isChecked(),
                "snapshot_directory": self.snapshot_directory.text().strip(),
                "snapshot_format": self.snapshot_format.currentText(),
                "subtitle_encoding": self.subtitle_encoding.currentText(),
                "subtitle_font_size": self.subtitle_size.value(),
            }
        )
        return result


class EffectsDialog(QDialog):
    def __init__(self, controller: Any, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.controller = controller
        self.setWindowTitle("Adjustments and Effects")
        self.resize(690, 480)
        layout = QVBoxLayout(self)
        tabs = QTabWidget()
        tabs.addTab(self._audio_tab(), "Audio Effects")
        tabs.addTab(self._video_tab(), "Video Effects")
        layout.addWidget(tabs, 1)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Apply | QDialogButtonBox.StandardButton.Close
        )
        buttons.button(QDialogButtonBox.StandardButton.Apply).clicked.connect(self.apply_values)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _audio_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        self.eq_enabled = QCheckBox("Enable")
        self.eq_preset = QComboBox()
        presets = self.controller.equalizer_presets()
        self.eq_preset.addItems(presets or ["Flat"])
        top = QHBoxLayout()
        top.addWidget(self.eq_enabled)
        top.addWidget(QLabel("Preset"))
        top.addWidget(self.eq_preset, 1)
        layout.addLayout(top)
        sliders = QHBoxLayout()
        self.preamp = self._vertical_slider("Preamp")
        sliders.addLayout(self.preamp[0])
        self.band_sliders: list[tuple[QVBoxLayout, QSlider]] = []
        frequencies = self.controller.equalizer_frequencies() or [
            60,
            170,
            310,
            600,
            1000,
            3000,
            6000,
            12000,
            14000,
            16000,
        ]
        for frequency in frequencies:
            label = f"{frequency / 1000:g}k" if frequency >= 1000 else f"{frequency:g}"
            band = self._vertical_slider(label)
            self.band_sliders.append(band)
            sliders.addLayout(band[0])
        layout.addLayout(sliders, 1)
        return widget

    def _vertical_slider(self, label_text: str) -> tuple[QVBoxLayout, QSlider]:
        layout = QVBoxLayout()
        value = QLabel("0.0 dB")
        value.setAlignment(Qt.AlignmentFlag.AlignCenter)
        slider = QSlider(Qt.Orientation.Vertical)
        slider.setRange(-200, 200)
        slider.setValue(0)
        slider.valueChanged.connect(
            lambda amount, label=value: label.setText(f"{amount / 10:.1f} dB")
        )
        caption = QLabel(label_text)
        caption.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(value)
        layout.addWidget(slider, 1, Qt.AlignmentFlag.AlignHCenter)
        layout.addWidget(caption)
        return layout, slider

    def _video_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        note = QLabel(
            "Video filter chains vary between libVLC builds. Aspect ratio, crop, zoom, "
            "deinterlacing, and snapshots are available from the Video menu."
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        layout.addStretch(1)
        return widget

    def apply_values(self) -> None:
        enabled = self.eq_enabled.isChecked()
        if not self.controller.enable_equalizer(enabled, self.eq_preset.currentIndex()):
            QMessageBox.warning(
                self, "Audio Effects", "The installed libVLC runtime could not apply the equalizer."
            )
            return
        if enabled:
            self.controller.set_equalizer_preamp(self.preamp[1].value() / 10)
            for index, (_layout, slider) in enumerate(self.band_sliders):
                self.controller.set_equalizer_band(index, slider.value() / 10)


class TrackSynchronizationDialog(QDialog):
    def __init__(self, controller: Any, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.controller = controller
        self.setWindowTitle("Track Synchronization")
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.audio_delay = QSpinBox()
        self.audio_delay.setRange(-60_000, 60_000)
        self.audio_delay.setSuffix(" ms")
        self.audio_delay.setValue(controller.audio_delay())
        self.subtitle_delay = QSpinBox()
        self.subtitle_delay.setRange(-60_000, 60_000)
        self.subtitle_delay.setSuffix(" ms")
        self.subtitle_delay.setValue(controller.subtitle_delay())
        form.addRow("Audio track synchronization", self.audio_delay)
        form.addRow("Subtitle track synchronization", self.subtitle_delay)
        layout.addLayout(form)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Apply | QDialogButtonBox.StandardButton.Close
        )
        buttons.button(QDialogButtonBox.StandardButton.Apply).clicked.connect(self.apply_values)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def apply_values(self) -> None:
        audio_ok = self.controller.set_audio_delay(self.audio_delay.value())
        subtitle_ok = self.controller.set_subtitle_delay(self.subtitle_delay.value())
        if not audio_ok or not subtitle_ok:
            QMessageBox.warning(
                self,
                "Track Synchronization",
                "One or more delays could not be applied to the current media.",
            )


class MediaInformationDialog(QDialog):
    def __init__(
        self, controller: Any, parent: QWidget | None = None, *, codec_only: bool = False
    ) -> None:
        super().__init__(parent)
        self.controller = controller
        self.setWindowTitle("Current Media Information")
        self.resize(650, 450)
        layout = QVBoxLayout(self)
        self.tabs = QTabWidget()
        self.general = QTableWidget(0, 2)
        self.general.setHorizontalHeaderLabels(["Property", "Value"])
        self.general.horizontalHeader().setStretchLastSection(True)
        self.general.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.codec = QTreeWidget()
        self.codec.setHeaderLabels(["Codec detail", "Value"])
        self.codec.header().setStretchLastSection(True)
        self.statistics = QPlainTextEdit()
        self.statistics.setReadOnly(True)
        self.tabs.addTab(self.general, "General")
        self.tabs.addTab(self.codec, "Codec Details")
        self.tabs.addTab(self.statistics, "Statistics")
        if codec_only:
            self.tabs.setCurrentWidget(self.codec)
        layout.addWidget(self.tabs)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        refresh = buttons.addButton("Refresh", QDialogButtonBox.ButtonRole.ActionRole)
        refresh.clicked.connect(self.refresh)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self.refresh()

    def refresh(self) -> None:
        metadata = self.controller.metadata()
        metadata.setdefault("Location", self.controller.source or "No media")
        metadata.setdefault("Duration", f"{self.controller.duration() / 1000:.3f} s")
        self.general.setRowCount(len(metadata))
        for row, (key, value) in enumerate(metadata.items()):
            self.general.setItem(row, 0, QTableWidgetItem(key))
            self.general.setItem(row, 1, QTableWidgetItem(value))
        self.codec.clear()
        for track in self.controller.media_tracks():
            parent = QTreeWidgetItem([f"Track {track.get('Track', '')}", track.get("Type", "")])
            for key, value in track.items():
                if key not in {"Track", "Type"}:
                    parent.addChild(QTreeWidgetItem([key, value]))
            self.codec.addTopLevelItem(parent)
            parent.setExpanded(True)
        self.statistics.setPlainText(
            f"State: {getattr(self.controller.state, 'value', self.controller.state)}\n"
            f"Position: {self.controller.time()} ms\n"
            f"Duration: {self.controller.duration()} ms\n"
            f"Seekable: {'yes' if self.controller.is_seekable() else 'no'}\n"
            f"Rate: {self.controller.rate():.2f}x\n"
            f"Volume: {self.controller.volume()}%"
        )


class MessagesDialog(QDialog):
    def __init__(self, handler: RingLogHandler, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.handler = handler
        self.setWindowTitle("Messages")
        self.resize(760, 440)
        layout = QVBoxLayout(self)
        self.text = QPlainTextEdit()
        self.text.setReadOnly(True)
        layout.addWidget(self.text, 1)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        refresh = buttons.addButton("Refresh", QDialogButtonBox.ButtonRole.ActionRole)
        clear = buttons.addButton("Clear View", QDialogButtonBox.ButtonRole.ActionRole)
        refresh.clicked.connect(self.refresh)
        clear.clicked.connect(self.text.clear)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self.refresh()

    def refresh(self) -> None:
        self.text.setPlainText("\n".join(self.handler.lines()))
        self.text.verticalScrollBar().setValue(self.text.verticalScrollBar().maximum())


class AboutDialog(QDialog):
    def __init__(self, libvlc_version: str, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle(f"About {APP_NAME}")
        self.resize(520, 360)
        layout = QVBoxLayout(self)
        heading = QLabel(APP_NAME)
        heading.setAlignment(Qt.AlignmentFlag.AlignCenter)
        font = heading.font()
        font.setPointSize(18)
        font.setBold(True)
        heading.setFont(font)
        layout.addWidget(heading)
        text = QTextBrowser()
        text.setOpenExternalLinks(True)
        text.setHtml(
            f"<p style='text-align:center'><b>Version {APP_VERSION}</b></p>"
            "<p>An independent Python desktop media player using PySide6 and libVLC.</p>"
            f"<p><b>Visual reference:</b> {REFERENCE_VERSION}</p>"
            f"<p><b>Detected libVLC:</b> {libvlc_version}</p>"
            "<p>This application is not VLC, is not produced by VideoLAN, and does not bundle VLC artwork. "
            "VLC and VideoLAN are trademarks of the VideoLAN organization.</p>"
            "<p>See LICENSE and THIRD_PARTY_NOTICES.md in the project folder.</p>"
        )
        layout.addWidget(text, 1)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)


class _VlcProcessDialog(QDialog):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.process = QProcess(self)
        self.process.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
        self.process.readyReadStandardOutput.connect(self._capture_output)
        self.process.finished.connect(self._finished)
        self.process.errorOccurred.connect(self._process_error)
        self._output: list[str] = []
        self._cancelled = False

    def _start_process(self, arguments: list[str]) -> bool:
        executable = locate_vlc_executable()
        if not executable:
            QMessageBox.critical(
                self,
                self.windowTitle(),
                "The VLC command-line executable was not found. Set VLC_PATH or install VLC.",
            )
            return False
        self._output.clear()
        self._cancelled = False
        environment = QProcessEnvironment.systemEnvironment()
        self.process.setProcessEnvironment(environment)
        self.process.start(executable, arguments)
        if not self.process.waitForStarted(1500):
            QMessageBox.critical(self, self.windowTitle(), self.process.errorString())
            return False
        return True

    def _capture_output(self) -> None:
        output = bytes(self.process.readAllStandardOutput()).decode("utf-8", errors="replace")
        self._output.extend(output.splitlines())
        self._output = self._output[-300:]

    def cancel_job(self) -> None:
        if self.process.state() == QProcess.ProcessState.NotRunning:
            return
        self._cancelled = True
        self.process.terminate()
        QTimer.singleShot(1800, self._kill_if_running)

    def reject(self) -> None:
        if self.process.state() != QProcess.ProcessState.NotRunning:
            answer = QMessageBox.question(
                self,
                self.windowTitle(),
                "A VLC job is still running. Stop it and close this dialog?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if answer != QMessageBox.StandardButton.Yes:
                return
            self.cancel_job()
        super().reject()

    def _kill_if_running(self) -> None:
        if self.process.state() != QProcess.ProcessState.NotRunning:
            self.process.kill()

    def _finished(self, exit_code: int, _status: QProcess.ExitStatus) -> None:
        del exit_code

    def _process_error(self, _error: QProcess.ProcessError) -> None:
        LOGGER.error("VLC background process error: %s", self.process.errorString())


class ConversionDialog(_VlcProcessDialog):
    def __init__(self, source: str = "", parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Convert / Save")
        self.resize(620, 330)
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.source = QLineEdit(source)
        source_row = QHBoxLayout()
        source_row.addWidget(self.source, 1)
        source_browse = QPushButton("Browse…")
        source_browse.clicked.connect(self._browse_source)
        source_row.addWidget(source_browse)
        self.destination = QLineEdit()
        destination_row = QHBoxLayout()
        destination_row.addWidget(self.destination, 1)
        destination_browse = QPushButton("Browse…")
        destination_browse.clicked.connect(self._browse_destination)
        destination_row.addWidget(destination_browse)
        self.profile = QComboBox()
        self.profile.addItems([profile.name for profile in CONVERSION_PROFILES])
        self.overwrite = QCheckBox("Overwrite an existing output after confirmation")
        form.addRow("Source", source_row)
        form.addRow("Destination file", destination_row)
        form.addRow("Profile", self.profile)
        form.addRow("", self.overwrite)
        layout.addLayout(form)
        self.progress = QProgressBar()
        self.progress.setRange(0, 1)
        self.progress.setValue(0)
        self.status = QLabel("Ready")
        layout.addWidget(self.progress)
        layout.addWidget(self.status)
        self.buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        self.start_button = self.buttons.addButton("Start", QDialogButtonBox.ButtonRole.AcceptRole)
        self.cancel_button = self.buttons.addButton(
            "Cancel Job", QDialogButtonBox.ButtonRole.ActionRole
        )
        self.cancel_button.setEnabled(False)
        self.start_button.clicked.connect(self.start_job)
        self.cancel_button.clicked.connect(self.cancel_job)
        self.buttons.rejected.connect(self.reject)
        layout.addWidget(self.buttons)

    def _browse_source(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Choose Input")
        if path:
            self.source.setText(path)

    def _browse_destination(self) -> None:
        profile = CONVERSION_PROFILES[self.profile.currentIndex()]
        path, _ = QFileDialog.getSaveFileName(
            self, "Choose Output", "", f"{profile.name} (*{profile.extension});;All files (*)"
        )
        if path:
            if not Path(path).suffix:
                path += profile.extension
            self.destination.setText(path)

    def start_job(self) -> None:
        source = self.source.text().strip()
        destination = self.destination.text().strip()
        overwrite = self.overwrite.isChecked()
        if Path(destination).exists():
            if not overwrite:
                QMessageBox.warning(
                    self,
                    "Convert / Save",
                    "The output already exists. Enable overwrite and start again.",
                )
                return
            answer = QMessageBox.question(
                self, "Confirm Overwrite", f"Replace this file?\n{destination}"
            )
            if answer != QMessageBox.StandardButton.Yes:
                return
        try:
            output = validate_output_destination(source, destination, overwrite=overwrite)
            arguments = build_conversion_arguments(
                source, str(output), CONVERSION_PROFILES[self.profile.currentIndex()]
            )
        except (ValueError, OSError) as exc:
            QMessageBox.warning(self, "Convert / Save", str(exc))
            return
        if self._start_process(arguments):
            self.progress.setRange(0, 0)
            self.status.setText(
                "Conversion is running. Accurate progress is not exposed by this VLC command."
            )
            self.start_button.setEnabled(False)
            self.cancel_button.setEnabled(True)

    def _finished(self, exit_code: int, status: QProcess.ExitStatus) -> None:
        self.progress.setRange(0, 1)
        self.progress.setValue(1 if exit_code == 0 and not self._cancelled else 0)
        self.start_button.setEnabled(True)
        self.cancel_button.setEnabled(False)
        if self._cancelled:
            self.status.setText(
                "Cancelled. A partial output file may remain and can be deleted safely."
            )
        elif status == QProcess.ExitStatus.NormalExit and exit_code == 0:
            self.status.setText("Conversion completed.")
        else:
            detail = "\n".join(self._output[-8:]) or self.process.errorString()
            self.status.setText("Conversion failed.")
            QMessageBox.warning(self, "Conversion Failed", detail)


class StreamDialog(_VlcProcessDialog):
    def __init__(self, source: str = "", parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Stream Output")
        self.resize(600, 280)
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.source = QLineEdit(source)
        self.destination = QLineEdit("http://0.0.0.0:8080/stream")
        self.transcode = QCheckBox("Transcode to H.264/AAC before streaming")
        form.addRow("Source", self.source)
        form.addRow("Destination", self.destination)
        form.addRow("", self.transcode)
        layout.addLayout(form)
        note = QLabel(
            "HTTP starts a local server; UDP/RTP sends to the specified host. Check firewall permissions before sharing."
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        self.status = QLabel("Ready")
        layout.addWidget(self.status)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        self.start_button = buttons.addButton("Stream", QDialogButtonBox.ButtonRole.AcceptRole)
        self.cancel_button = buttons.addButton("Stop", QDialogButtonBox.ButtonRole.ActionRole)
        self.cancel_button.setEnabled(False)
        self.start_button.clicked.connect(self.start_job)
        self.cancel_button.clicked.connect(self.cancel_job)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def start_job(self) -> None:
        try:
            arguments = build_stream_arguments(
                self.source.text().strip(),
                self.destination.text().strip(),
                transcode=self.transcode.isChecked(),
            )
        except ValueError as exc:
            QMessageBox.warning(self, "Stream Output", str(exc))
            return
        if self._start_process(arguments):
            self.status.setText("Streaming…")
            self.start_button.setEnabled(False)
            self.cancel_button.setEnabled(True)

    def _finished(self, exit_code: int, status: QProcess.ExitStatus) -> None:
        self.start_button.setEnabled(True)
        self.cancel_button.setEnabled(False)
        if self._cancelled:
            self.status.setText("Stream stopped.")
        elif status == QProcess.ExitStatus.NormalExit and exit_code == 0:
            self.status.setText("Stream ended.")
        else:
            self.status.setText("Streaming failed.")
            detail = "\n".join(self._output[-8:]) or self.process.errorString()
            QMessageBox.warning(self, "Streaming Failed", detail)


def open_help(parent: QWidget) -> None:
    if not QDesktopServices.openUrl(QUrl("https://docs.videolan.me/vlc-user/desktop/3.0/en/")):
        QMessageBox.warning(
            parent, "Help", "Could not open the VLC 3.0 user documentation in your browser."
        )
