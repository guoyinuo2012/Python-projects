"""Qt widgets and windows for Media Player."""
