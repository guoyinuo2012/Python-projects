"""Path, URL, and folder-scanning helpers."""

from __future__ import annotations

import os
import re
from collections.abc import Iterable, Iterator
from pathlib import Path
from threading import Event
from urllib.parse import unquote, urlparse
from urllib.request import url2pathname

from .constants import MEDIA_EXTENSIONS, NETWORK_SCHEMES, PLAYLIST_EXTENSIONS

_WINDOWS_DRIVE = re.compile(r"^[A-Za-z]:[\\/]")


def is_network_url(value: str) -> bool:
    parsed = urlparse(value.strip())
    return parsed.scheme.casefold() in NETWORK_SCHEMES


def is_probable_url(value: str) -> bool:
    parsed = urlparse(value.strip())
    return bool(parsed.scheme and not _WINDOWS_DRIVE.match(value.strip()))


def normalize_source(value: str, *, base_dir: Path | None = None) -> str:
    value = value.strip().strip('"')
    if not value:
        raise ValueError("Media source is empty")
    parsed = urlparse(value)
    if parsed.scheme.casefold() == "file":
        path_text = url2pathname(unquote(parsed.path))
        if parsed.netloc and parsed.netloc not in {"", "localhost"}:
            path_text = f"//{parsed.netloc}{path_text}"
        if os.name == "nt" and re.match(r"^/[A-Za-z]:", path_text):
            path_text = path_text[1:]
        return str(Path(path_text).expanduser().resolve(strict=False))
    if is_probable_url(value):
        return value
    path = Path(value).expanduser()
    if not path.is_absolute() and base_dir is not None:
        path = base_dir / path
    return str(path.resolve(strict=False))


def source_kind(source: str) -> str:
    if is_network_url(source):
        return "network"
    suffix = Path(source).suffix.casefold()
    if suffix in PLAYLIST_EXTENSIONS:
        return "playlist"
    if Path(source).is_dir():
        return "folder"
    return "file"


def source_comparison_key(value: str) -> str:
    """Return a stable duplicate-detection key without altering URL case."""

    normalized = normalize_source(value)
    if os.name == "nt" and not is_probable_url(normalized):
        return normalized.casefold()
    return normalized


def is_supported_media_path(path: Path) -> bool:
    return path.suffix.casefold() in MEDIA_EXTENSIONS


def deduplicate_sources(values: Iterable[str]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        normalized = normalize_source(value)
        key = source_comparison_key(normalized)
        if key not in seen:
            seen.add(key)
            result.append(normalized)
    return result


def iter_media_files(
    root: Path,
    *,
    cancel: Event | None = None,
    recursive: bool = True,
) -> Iterator[Path]:
    """Yield recognized media files without following directory symlink loops."""
    root = root.expanduser().resolve(strict=True)
    if not root.is_dir():
        raise NotADirectoryError(str(root))
    pending = [root]
    visited: set[tuple[int, int] | str] = set()
    while pending:
        if cancel and cancel.is_set():
            return
        directory = pending.pop()
        try:
            stat = directory.stat()
            identity: tuple[int, int] | str = (stat.st_dev, stat.st_ino)
            if not stat.st_ino:
                identity = str(directory.resolve())
            if identity in visited:
                continue
            visited.add(identity)
            entries = sorted(os.scandir(directory), key=lambda entry: entry.name.casefold())
        except (OSError, PermissionError):
            continue
        for entry in entries:
            if cancel and cancel.is_set():
                return
            try:
                if entry.is_file(follow_symlinks=False):
                    path = Path(entry.path)
                    if is_supported_media_path(path):
                        yield path
                elif recursive and entry.is_dir(follow_symlinks=False):
                    pending.append(Path(entry.path))
            except OSError:
                continue
