"""Shared constants for the player."""

from __future__ import annotations

MEDIA_EXTENSIONS = frozenset(
    {
        ".3g2",
        ".3gp",
        ".aac",
        ".ac3",
        ".aiff",
        ".alac",
        ".amr",
        ".ape",
        ".asf",
        ".avi",
        ".dts",
        ".dv",
        ".f4v",
        ".flac",
        ".flv",
        ".m2t",
        ".m2ts",
        ".m4a",
        ".m4v",
        ".mka",
        ".mkv",
        ".mov",
        ".mp2",
        ".mp3",
        ".mp4",
        ".mpeg",
        ".mpg",
        ".mts",
        ".oga",
        ".ogg",
        ".ogm",
        ".ogv",
        ".opus",
        ".rm",
        ".rmvb",
        ".spx",
        ".ts",
        ".tta",
        ".vob",
        ".wav",
        ".webm",
        ".wma",
        ".wmv",
        ".wv",
    }
)

PLAYLIST_EXTENSIONS = frozenset({".m3u", ".m3u8", ".pls", ".xspf"})
SUBTITLE_EXTENSIONS = frozenset({".ass", ".smi", ".srt", ".ssa", ".sub", ".vtt"})

NETWORK_SCHEMES = frozenset(
    {"http", "https", "ftp", "ftps", "sftp", "rtsp", "rtmp", "rtp", "udp", "mms", "smb"}
)

DEFAULT_WINDOW_SIZE = (860, 560)
MINIMUM_WINDOW_SIZE = (620, 390)
FULLSCREEN_HIDE_DELAY_MS = 2600
