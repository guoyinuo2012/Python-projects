"""Validation and VLC command construction for conversion and streaming jobs."""

from __future__ import annotations

import os
import shutil
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class ConversionProfile:
    name: str
    transcode: str
    mux: str
    extension: str


CONVERSION_PROFILES = (
    ConversionProfile(
        "Video - H.264 + MP3 (MP4)",
        "vcodec=h264,vb=1600,acodec=mp3,ab=128,channels=2",
        "mp4",
        ".mp4",
    ),
    ConversionProfile(
        "Video - H.264 + AAC (TS)", "vcodec=h264,vb=1600,acodec=mp4a,ab=128,channels=2", "ts", ".ts"
    ),
    ConversionProfile(
        "Video - VP8 + Vorbis (WebM)",
        "vcodec=VP80,vb=1200,acodec=vorb,ab=128,channels=2",
        "webm",
        ".webm",
    ),
    ConversionProfile("Audio - MP3", "acodec=mp3,ab=192,channels=2", "raw", ".mp3"),
    ConversionProfile("Audio - FLAC", "acodec=flac", "raw", ".flac"),
    ConversionProfile("Audio - Vorbis (OGG)", "acodec=vorb,ab=192,channels=2", "ogg", ".ogg"),
)


def locate_vlc_executable() -> str | None:
    configured = os.environ.get("VLC_PATH")
    if configured and Path(configured).is_file():
        return configured
    command = shutil.which("vlc") or shutil.which("cvlc")
    if command:
        return command
    candidates: list[Path] = []
    if os.name == "nt":
        for variable in ("PROGRAMFILES", "PROGRAMFILES(X86)"):
            if os.environ.get(variable):
                candidates.append(Path(os.environ[variable]) / "VideoLAN" / "VLC" / "vlc.exe")
    elif os.sys.platform == "darwin":
        candidates.append(Path("/Applications/VLC.app/Contents/MacOS/VLC"))
    return next((str(path) for path in candidates if path.is_file()), None)


def validate_output_destination(source: str, destination: str, *, overwrite: bool = False) -> Path:
    if not source.strip():
        raise ValueError("Choose an input source")
    if not destination.strip():
        raise ValueError("Choose an output destination")
    output = Path(destination).expanduser().resolve(strict=False)
    if Path(source).expanduser().resolve(strict=False) == output:
        raise ValueError("The output must be different from the input")
    if not output.parent.exists():
        raise ValueError("The output folder does not exist")
    if not output.parent.is_dir():
        raise ValueError("The output parent is not a folder")
    if not os.access(output.parent, os.W_OK):
        raise PermissionError("The output folder is not writable")
    if output.exists() and not overwrite:
        raise FileExistsError(str(output))
    if output.exists() and output.is_dir():
        raise IsADirectoryError(str(output))
    return output


def build_conversion_arguments(
    source: str,
    destination: str,
    profile: ConversionProfile,
) -> list[str]:
    output = Path(destination).expanduser().resolve(strict=False)
    escaped = str(output).replace("'", "\\'")
    sout = f"#transcode{{{profile.transcode}}}:standard{{access=file,mux={profile.mux},dst='{escaped}'}}"
    return ["-I", "dummy", source, "--sout", sout, "vlc://quit"]


def build_stream_arguments(source: str, destination: str, *, transcode: bool = False) -> list[str]:
    if not source.strip():
        raise ValueError("Choose an input source")
    if not destination.strip():
        raise ValueError("Enter a stream destination")
    if not destination.startswith(("http://", "udp://", "rtp://")):
        raise ValueError("The stream destination must begin with http://, udp://, or rtp://")
    if destination.startswith("http://"):
        host_path = destination.removeprefix("http://")
        host_port, _, path = host_path.partition("/")
        host, separator, port = host_port.rpartition(":")
        host = host if separator else host_port
        port = port if separator else "8080"
        chain = f"standard{{access=http,mux=ts,dst={host}:{port}/{path}}}"
    else:
        access = destination.split(":", 1)[0]
        target = destination.split("//", 1)[-1]
        chain = f"standard{{access={access},mux=ts,dst={target}}}"
    if transcode:
        chain = "transcode{vcodec=h264,vb=1200,acodec=mp4a,ab=128}:" + chain
    return ["-I", "dummy", source, "--sout", f"#{chain}", "--sout-keep"]
