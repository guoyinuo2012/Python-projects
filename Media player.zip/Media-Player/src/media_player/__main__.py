"""Run Media Player with ``python -m media_player``."""

from .app import main

if __name__ == "__main__":
    raise SystemExit(main())
