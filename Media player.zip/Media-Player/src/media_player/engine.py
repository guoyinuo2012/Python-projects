"""Thread-safe Qt wrapper around python-vlc/libVLC."""

from __future__ import annotations

import logging
import re
import sys
from collections.abc import Callable
from contextlib import suppress
from enum import Enum
from pathlib import Path
from typing import Any, ClassVar

from PySide6.QtCore import QObject, Qt, Signal, Slot

from .media_utils import is_probable_url

try:
    import vlc as _vlc
except (ImportError, OSError):  # The launcher turns this into a user-facing message.
    _vlc = None


LOGGER = logging.getLogger(__name__)


class PlaybackState(str, Enum):
    IDLE = "idle"
    OPENING = "opening"
    BUFFERING = "buffering"
    PLAYING = "playing"
    PAUSED = "paused"
    STOPPED = "stopped"
    ENDED = "ended"
    FAILED = "failed"


class PlaybackStateMachine:
    """Small state authority used by both libVLC callbacks and tests."""

    EVENT_STATES: ClassVar[dict[str, PlaybackState]] = {
        "opening": PlaybackState.OPENING,
        "buffering": PlaybackState.BUFFERING,
        "playing": PlaybackState.PLAYING,
        "paused": PlaybackState.PAUSED,
        "stopped": PlaybackState.STOPPED,
        "ended": PlaybackState.ENDED,
        "error": PlaybackState.FAILED,
    }

    def __init__(self) -> None:
        self.state = PlaybackState.IDLE
        self.generation = 0

    def begin_load(self) -> int:
        self.generation += 1
        self.state = PlaybackState.OPENING
        return self.generation

    def accept(self, event_name: str, generation: int) -> PlaybackState | None:
        if generation != self.generation:
            return None
        state = self.EVENT_STATES.get(event_name)
        if state is not None:
            self.state = state
        return state

    def reset(self) -> None:
        self.generation += 1
        self.state = PlaybackState.IDLE


class LibVlcUnavailableError(RuntimeError):
    pass


def probe_libvlc(vlc_module: Any = None) -> tuple[bool, str]:
    module = vlc_module or _vlc
    if module is None:
        return False, "The python-vlc package is not installed."
    try:
        version = module.libvlc_get_version()
        if isinstance(version, bytes):
            version = version.decode("utf-8", errors="replace")
        version_text = str(version)
        match = re.match(r"\s*(\d+)", version_text)
        if match and int(match.group(1)) != 3:
            return False, f"Incompatible libVLC {version_text}; a libVLC 3.x runtime is required."
        return True, version_text
    except Exception as exc:  # python-vlc raises several ctypes-specific types.
        return False, f"The native libVLC runtime could not be loaded: {exc}"


class PlaybackController(QObject):
    """Owns one libVLC instance and replaces the media player for each load.

    Each media player gets callbacks that capture its generation. Qt queues the
    private signal onto the GUI thread; callbacks never touch widgets directly.
    """

    state_changed = Signal(object)
    media_changed = Signal(str)
    position_changed = Signal(int, int)
    seekable_changed = Signal(bool)
    buffering_changed = Signal(float)
    tracks_changed = Signal()
    metadata_changed = Signal(dict)
    error_occurred = Signal(str)
    end_reached = Signal()
    _raw_event = Signal(str, object, int)

    def __init__(self, parent: QObject | None = None, *, vlc_module: Any = None) -> None:
        super().__init__(parent)
        self._vlc = vlc_module or _vlc
        available, detail = probe_libvlc(self._vlc)
        if not available:
            raise LibVlcUnavailableError(detail)
        try:
            self._instance = self._vlc.Instance(
                "--no-video-title-show",
                "--no-snapshot-preview",
                "--quiet",
            )
        except Exception as exc:
            raise LibVlcUnavailableError(f"libVLC initialization failed: {exc}") from exc
        if self._instance is None:
            raise LibVlcUnavailableError("libVLC returned no playable instance")
        self.machine = PlaybackStateMachine()
        self._player: Any = None
        self._media: Any = None
        self._source = ""
        self._video_window_id: int | None = None
        self._callbacks: list[Callable[..., None]] = []
        self._volume = 100
        self._muted = False
        self._equalizer: Any = None
        self._raw_event.connect(self._handle_raw_event, Qt.ConnectionType.QueuedConnection)
        self._new_player(self.machine.generation)

    @property
    def state(self) -> PlaybackState:
        return self.machine.state

    @property
    def source(self) -> str:
        return self._source

    @property
    def version(self) -> str:
        ok, detail = probe_libvlc(self._vlc)
        return detail if ok else "Unavailable"

    def _new_player(self, generation: int) -> None:
        self._release_player()
        self._player = self._instance.media_player_new()
        self._callbacks = []
        event_manager = self._player.event_manager()
        event_types = {
            self._vlc.EventType.MediaPlayerOpening: "opening",
            self._vlc.EventType.MediaPlayerBuffering: "buffering",
            self._vlc.EventType.MediaPlayerPlaying: "playing",
            self._vlc.EventType.MediaPlayerPaused: "paused",
            self._vlc.EventType.MediaPlayerStopped: "stopped",
            self._vlc.EventType.MediaPlayerEndReached: "ended",
            self._vlc.EventType.MediaPlayerEncounteredError: "error",
            self._vlc.EventType.MediaPlayerTimeChanged: "time",
            self._vlc.EventType.MediaPlayerLengthChanged: "length",
            self._vlc.EventType.MediaPlayerSeekableChanged: "seekable",
            self._vlc.EventType.MediaPlayerVout: "tracks",
        }
        for event_type, event_name in event_types.items():

            def callback(event: Any, name: str = event_name, gen: int = generation) -> None:
                payload: object = None
                try:
                    if name in {"time", "length"}:
                        payload = (
                            max(0, int(self._player.get_time())),
                            max(0, int(self._player.get_length())),
                        )
                    elif name == "buffering":
                        payload = float(event.u.new_cache)
                    elif name == "seekable":
                        payload = bool(event.u.new_seekable)
                except Exception:
                    payload = None
                self._raw_event.emit(name, payload, gen)

            self._callbacks.append(callback)
            event_manager.event_attach(event_type, callback)
        self._apply_video_output()
        self._player.audio_set_volume(self._volume)
        self._player.audio_set_mute(self._muted)

    @Slot(str, object, int)
    def _handle_raw_event(self, event_name: str, payload: object, generation: int) -> None:
        state = self.machine.accept(event_name, generation)
        if generation != self.machine.generation:
            return
        if state is not None:
            self.state_changed.emit(state)
        if event_name in {"time", "length"} and isinstance(payload, tuple):
            position, duration = payload
            self.position_changed.emit(int(position), int(duration))
        elif event_name == "seekable":
            self.seekable_changed.emit(bool(payload))
        elif event_name == "buffering":
            percent = float(payload) if isinstance(payload, (int, float)) else 0.0
            self.buffering_changed.emit(percent)
        elif event_name == "tracks":
            self.tracks_changed.emit()
        elif event_name == "ended":
            self.end_reached.emit()
        elif event_name == "error":
            message = (
                "libVLC could not play this media. It may be unavailable, unsupported, or damaged."
            )
            self.error_occurred.emit(message)

    def load(
        self,
        source: str,
        *,
        options: list[str] | None = None,
        allow_network_metadata: bool = False,
    ) -> None:
        if not source:
            raise ValueError("Media source is empty")
        generation = self.machine.begin_load()
        self.state_changed.emit(self.machine.state)
        self._new_player(generation)
        self._source = source
        try:
            if is_probable_url(source):
                self._media = self._instance.media_new(source)
            else:
                self._media = self._instance.media_new_path(str(Path(source)))
            for option in options or []:
                self._media.add_option(option)
            self._player.set_media(self._media)
            parse_flags = self._vlc.MediaParseFlag.local
            if allow_network_metadata:
                parse_flags |= self._vlc.MediaParseFlag.network
            self._media.parse_with_options(parse_flags, 2_000)
            self.media_changed.emit(source)
        except Exception as exc:
            self.machine.accept("error", generation)
            raise RuntimeError(f"Could not load media: {exc}") from exc

    def play(self) -> None:
        if not self._media:
            return
        if self._player.play() == -1:
            self.error_occurred.emit("libVLC rejected the playback request.")

    def pause(self) -> None:
        if self._player:
            self._player.set_pause(1)

    def resume(self) -> None:
        if self._player:
            self._player.set_pause(0)

    def toggle_pause(self) -> None:
        if self.state == PlaybackState.PLAYING:
            self.pause()
        elif self._media:
            self.play()

    def stop(self) -> None:
        if self._player:
            self._player.stop()

    def set_video_output(self, window_id: int) -> None:
        self._video_window_id = int(window_id)
        self._apply_video_output()

    def _apply_video_output(self) -> None:
        if not self._player or self._video_window_id is None:
            return
        try:
            if sys.platform.startswith("win"):
                self._player.set_hwnd(self._video_window_id)
            elif sys.platform == "darwin":
                self._player.set_nsobject(self._video_window_id)
            else:
                self._player.set_xwindow(self._video_window_id)
        except Exception:
            LOGGER.exception("Failed to attach the libVLC video surface")

    def time(self) -> int:
        return max(0, int(self._player.get_time())) if self._player else 0

    def duration(self) -> int:
        return max(0, int(self._player.get_length())) if self._player else 0

    def is_seekable(self) -> bool:
        try:
            return bool(self._player and self._player.is_seekable())
        except Exception:
            return False

    def set_time(self, milliseconds: int) -> bool:
        if not self._player or not self.is_seekable():
            return False
        return self._player.set_time(max(0, int(milliseconds))) != -1

    def set_position(self, position: float) -> bool:
        if not self._player or not self.is_seekable():
            return False
        return self._player.set_position(min(1.0, max(0.0, float(position)))) != -1

    def frame_step(self) -> bool:
        try:
            return self._player.next_frame() == 0
        except Exception:
            return False

    def set_rate(self, rate: float) -> bool:
        try:
            return self._player.set_rate(float(rate)) == 0
        except Exception:
            return False

    def rate(self) -> float:
        try:
            value = float(self._player.get_rate())
            return value if value > 0 else 1.0
        except Exception:
            return 1.0

    def set_volume(self, volume: int) -> int:
        self._volume = min(125, max(0, int(volume)))
        if self._player:
            self._player.audio_set_volume(self._volume)
        return self._volume

    def volume(self) -> int:
        try:
            value = int(self._player.audio_get_volume())
            return value if value >= 0 else self._volume
        except Exception:
            return self._volume

    def set_muted(self, muted: bool) -> None:
        self._muted = bool(muted)
        if self._player:
            self._player.audio_set_mute(self._muted)

    def is_muted(self) -> bool:
        try:
            return bool(self._player.audio_get_mute())
        except Exception:
            return self._muted

    def audio_tracks(self) -> list[tuple[int, str]]:
        return self._descriptions("audio_get_track_description")

    def subtitle_tracks(self) -> list[tuple[int, str]]:
        return self._descriptions("video_get_spu_description")

    def video_tracks(self) -> list[tuple[int, str]]:
        return self._descriptions("video_get_track_description")

    def _descriptions(self, method_name: str) -> list[tuple[int, str]]:
        if not self._player:
            return []
        try:
            values = getattr(self._player, method_name)() or []
            return [(int(track_id), _decode(name)) for track_id, name in values]
        except Exception:
            return []

    def set_audio_track(self, track_id: int) -> bool:
        return bool(self._player and self._player.audio_set_track(int(track_id)) == 0)

    def current_audio_track(self) -> int:
        try:
            return int(self._player.audio_get_track())
        except Exception:
            return -1

    def set_subtitle_track(self, track_id: int) -> bool:
        return bool(self._player and self._player.video_set_spu(int(track_id)) == 0)

    def current_subtitle_track(self) -> int:
        try:
            return int(self._player.video_get_spu())
        except Exception:
            return -1

    def set_video_track(self, track_id: int) -> bool:
        return bool(self._player and self._player.video_set_track(int(track_id)) == 0)

    def current_video_track(self) -> int:
        try:
            return int(self._player.video_get_track())
        except Exception:
            return -1

    def title_count(self) -> int:
        try:
            return max(0, int(self._player.get_title_count()))
        except Exception:
            return 0

    def current_title(self) -> int:
        try:
            return int(self._player.get_title())
        except Exception:
            return -1

    def set_title(self, title: int) -> None:
        if self._player:
            self._player.set_title(int(title))

    def chapter_count(self) -> int:
        try:
            return max(0, int(self._player.get_chapter_count()))
        except Exception:
            return 0

    def current_chapter(self) -> int:
        try:
            return int(self._player.get_chapter())
        except Exception:
            return -1

    def set_chapter(self, chapter: int) -> None:
        if self._player:
            self._player.set_chapter(int(chapter))

    def set_audio_channel(self, channel: int) -> bool:
        try:
            return bool(self._player and self._player.audio_set_channel(int(channel)) == 0)
        except Exception:
            return False

    def current_audio_channel(self) -> int:
        try:
            return int(self._player.audio_get_channel())
        except Exception:
            return -1

    def audio_devices(self) -> list[tuple[str, str]]:
        if not self._player:
            return []
        head = None
        result: list[tuple[str, str]] = []
        try:
            head = self._player.audio_output_device_enum()
            current = head
            while current:
                node = current.contents
                result.append((_decode(node.device), _decode(node.description)))
                current = node.next
        except Exception:
            return []
        finally:
            if head:
                with suppress(Exception):
                    self._vlc.libvlc_audio_output_device_list_release(head)
        return result

    def current_audio_device(self) -> str:
        try:
            return _decode(self._player.audio_output_device_get())
        except Exception:
            return ""

    def set_audio_device(self, device_id: str) -> None:
        if self._player:
            self._player.audio_output_device_set(None, device_id.encode())

    def add_subtitle(self, subtitle_path: str) -> bool:
        if not self._player:
            return False
        uri = Path(subtitle_path).expanduser().resolve(strict=True).as_uri()
        try:
            return self._player.add_slave(self._vlc.MediaSlaveType.subtitle, uri, True) == 0
        except Exception:
            try:
                return bool(self._player.video_set_subtitle_file(subtitle_path))
            except Exception:
                return False

    def set_audio_delay(self, milliseconds: int) -> bool:
        return bool(self._player and self._player.audio_set_delay(int(milliseconds) * 1000) == 0)

    def audio_delay(self) -> int:
        try:
            return int(self._player.audio_get_delay() / 1000)
        except Exception:
            return 0

    def set_subtitle_delay(self, milliseconds: int) -> bool:
        return bool(
            self._player and self._player.video_set_spu_delay(int(milliseconds) * 1000) == 0
        )

    def subtitle_delay(self) -> int:
        try:
            return int(self._player.video_get_spu_delay() / 1000)
        except Exception:
            return 0

    def set_aspect_ratio(self, value: str) -> None:
        if self._player:
            self._player.video_set_aspect_ratio(value.encode() if value else None)

    def set_crop(self, value: str) -> None:
        if self._player:
            self._player.video_set_crop_geometry(value.encode() if value else None)

    def set_scale(self, scale: float) -> None:
        if self._player:
            self._player.video_set_scale(float(scale))

    def set_deinterlace(self, mode: str) -> None:
        if self._player:
            self._player.video_set_deinterlace(mode.encode() if mode else None)

    def snapshot(self, path: str, width: int = 0, height: int = 0) -> bool:
        try:
            return bool(
                self._player and self._player.video_take_snapshot(0, path, width, height) == 0
            )
        except Exception:
            return False

    def metadata(self) -> dict[str, str]:
        if not self._media:
            return {}
        fields = {
            "Title": self._vlc.Meta.Title,
            "Artist": self._vlc.Meta.Artist,
            "Album": self._vlc.Meta.Album,
            "Genre": self._vlc.Meta.Genre,
            "Date": self._vlc.Meta.Date,
            "Track number": self._vlc.Meta.TrackNumber,
            "Description": self._vlc.Meta.Description,
            "Publisher": self._vlc.Meta.Publisher,
        }
        result: dict[str, str] = {}
        for label, meta_type in fields.items():
            try:
                value = self._media.get_meta(meta_type)
                if value:
                    result[label] = _decode(value)
            except Exception:
                continue
        return result

    def media_tracks(self) -> list[dict[str, str]]:
        if not self._media:
            return []
        result: list[dict[str, str]] = []
        try:
            tracks = self._media.tracks_get() or []
        except Exception:
            return result
        for index, track in enumerate(tracks):
            result.append(
                {
                    "Track": str(index + 1),
                    "Type": str(getattr(track, "type", "Unknown")),
                    "Codec": _fourcc(getattr(track, "codec", 0)),
                    "Original codec": _fourcc(getattr(track, "original_fourcc", 0)),
                    "ID": str(getattr(track, "id", "")),
                    "Profile": str(getattr(track, "profile", "")),
                    "Level": str(getattr(track, "level", "")),
                }
            )
        return result

    def equalizer_presets(self) -> list[str]:
        try:
            count = int(self._vlc.libvlc_audio_equalizer_get_preset_count())
            return [
                _decode(self._vlc.libvlc_audio_equalizer_get_preset_name(i)) for i in range(count)
            ]
        except Exception:
            return []

    def equalizer_frequencies(self) -> list[float]:
        try:
            count = int(self._vlc.libvlc_audio_equalizer_get_band_count())
            return [
                float(self._vlc.libvlc_audio_equalizer_get_band_frequency(i)) for i in range(count)
            ]
        except Exception:
            return []

    def enable_equalizer(self, enabled: bool, preset_index: int = 0) -> bool:
        try:
            if self._equalizer is not None:
                self._equalizer.release()
                self._equalizer = None
            if enabled:
                self._equalizer = self._vlc.libvlc_audio_equalizer_new_from_preset(
                    max(0, preset_index)
                )
                return self._player.set_equalizer(self._equalizer) == 0
            return self._player.set_equalizer(None) == 0
        except Exception:
            return False

    def set_equalizer_preamp(self, value: float) -> bool:
        try:
            if self._equalizer is None:
                return False
            return (
                self._equalizer.set_preamp(float(value)) == 0
                and self._player.set_equalizer(self._equalizer) == 0
            )
        except Exception:
            return False

    def set_equalizer_band(self, index: int, value: float) -> bool:
        try:
            if self._equalizer is None:
                return False
            return (
                self._equalizer.set_amp_at_index(float(value), int(index)) == 0
                and self._player.set_equalizer(self._equalizer) == 0
            )
        except Exception:
            return False

    def release(self) -> None:
        self.machine.reset()
        self._release_player()
        if self._equalizer is not None:
            with suppress(Exception):
                self._equalizer.release()
            self._equalizer = None
        with suppress(Exception):
            self._instance.release()

    def _release_player(self) -> None:
        player, self._player = self._player, None
        media, self._media = self._media, None
        if player is not None:
            with suppress(Exception):
                player.stop()
            with suppress(Exception):
                player.release()
        if media is not None:
            with suppress(Exception):
                media.release()


def _decode(value: object) -> str:
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return str(value)


def _fourcc(value: int) -> str:
    try:
        return (
            int(value)
            .to_bytes(4, byteorder="little")
            .decode("ascii", errors="replace")
            .rstrip("\x00")
        )
    except Exception:
        return str(value)
