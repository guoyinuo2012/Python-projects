"""Read and write M3U, PLS, and XSPF playlists."""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from pathlib import Path

from .media_utils import is_probable_url, normalize_source
from .models import PlaylistItem


def _resolve_entry(entry: str, playlist_path: Path) -> str:
    if is_probable_url(entry):
        return normalize_source(entry)
    return normalize_source(entry, base_dir=playlist_path.parent)


def load_playlist(path: str | Path) -> list[PlaylistItem]:
    playlist_path = Path(path).expanduser().resolve(strict=True)
    suffix = playlist_path.suffix.casefold()
    if suffix in {".m3u", ".m3u8"}:
        return _load_m3u(playlist_path)
    if suffix == ".pls":
        return _load_pls(playlist_path)
    if suffix == ".xspf":
        return _load_xspf(playlist_path)
    raise ValueError(f"Unsupported playlist format: {suffix or '(none)'}")


def _read_text(path: Path) -> str:
    data = path.read_bytes()
    for encoding in ("utf-8-sig", "utf-8", "cp1252"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def _load_m3u(path: Path) -> list[PlaylistItem]:
    items: list[PlaylistItem] = []
    pending_title = ""
    pending_duration: int | None = None
    for raw_line in _read_text(path).splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line.upper().startswith("#EXTINF:"):
            match = re.match(r"#EXTINF:([+-]?\d+),(.*)", line, flags=re.IGNORECASE)
            if match:
                seconds = int(match.group(1))
                pending_duration = seconds * 1000 if seconds >= 0 else None
                pending_title = match.group(2).strip()
            continue
        if line.startswith("#"):
            continue
        items.append(
            PlaylistItem(
                source=_resolve_entry(line, path),
                title=pending_title,
                duration_ms=pending_duration,
            )
        )
        pending_title = ""
        pending_duration = None
    return items


def _load_pls(path: Path) -> list[PlaylistItem]:
    values: dict[int, dict[str, str]] = {}
    for raw_line in _read_text(path).splitlines():
        line = raw_line.strip()
        match = re.match(r"(File|Title|Length)(\d+)=(.*)", line, flags=re.IGNORECASE)
        if not match:
            continue
        key, index, value = match.group(1).casefold(), int(match.group(2)), match.group(3).strip()
        values.setdefault(index, {})[key] = value
    items: list[PlaylistItem] = []
    for index in sorted(values):
        data = values[index]
        if not data.get("file"):
            continue
        length = data.get("length", "-1")
        seconds = int(length) if re.fullmatch(r"-?\d+", length) else -1
        items.append(
            PlaylistItem(
                source=_resolve_entry(data["file"], path),
                title=data.get("title", ""),
                duration_ms=seconds * 1000 if seconds >= 0 else None,
            )
        )
    return items


def _load_xspf(path: Path) -> list[PlaylistItem]:
    try:
        root = ET.fromstring(_read_text(path))
    except ET.ParseError as exc:
        raise ValueError(f"Invalid XSPF playlist: {exc}") from exc
    items: list[PlaylistItem] = []
    for track in root.findall(".//{*}track"):
        location = track.findtext("{*}location", default="").strip()
        if not location:
            continue
        duration_text = track.findtext("{*}duration", default="").strip()
        duration = int(duration_text) if duration_text.isdigit() else None
        items.append(
            PlaylistItem(
                source=_resolve_entry(location, path),
                title=track.findtext("{*}title", default=""),
                artist=track.findtext("{*}creator", default=""),
                album=track.findtext("{*}album", default=""),
                duration_ms=duration,
            )
        )
    return items


def save_playlist(path: str | Path, items: list[PlaylistItem] | tuple[PlaylistItem, ...]) -> Path:
    playlist_path = Path(path).expanduser().resolve(strict=False)
    playlist_path.parent.mkdir(parents=True, exist_ok=True)
    suffix = playlist_path.suffix.casefold()
    if suffix in {".m3u", ".m3u8"}:
        _save_m3u(playlist_path, items)
    elif suffix == ".pls":
        _save_pls(playlist_path, items)
    elif suffix == ".xspf":
        _save_xspf(playlist_path, items)
    else:
        raise ValueError(f"Unsupported playlist format: {suffix or '(none)'}")
    return playlist_path


def _save_m3u(path: Path, items: list[PlaylistItem] | tuple[PlaylistItem, ...]) -> None:
    lines = ["#EXTM3U"]
    for item in items:
        duration = -1 if item.duration_ms is None else item.duration_ms // 1000
        lines.extend((f"#EXTINF:{duration},{item.display_title}", item.source))
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _save_pls(path: Path, items: list[PlaylistItem] | tuple[PlaylistItem, ...]) -> None:
    lines = ["[playlist]"]
    for index, item in enumerate(items, start=1):
        seconds = -1 if item.duration_ms is None else item.duration_ms // 1000
        lines.extend(
            (
                f"File{index}={item.source}",
                f"Title{index}={item.display_title}",
                f"Length{index}={seconds}",
            )
        )
    lines.extend((f"NumberOfEntries={len(items)}", "Version=2"))
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _save_xspf(path: Path, items: list[PlaylistItem] | tuple[PlaylistItem, ...]) -> None:
    namespace = "http://xspf.org/ns/0/"
    ET.register_namespace("", namespace)
    root = ET.Element(f"{{{namespace}}}playlist", {"version": "1"})
    track_list = ET.SubElement(root, f"{{{namespace}}}trackList")
    for item in items:
        track = ET.SubElement(track_list, f"{{{namespace}}}track")
        ET.SubElement(track, f"{{{namespace}}}location").text = item.source
        ET.SubElement(track, f"{{{namespace}}}title").text = item.display_title
        if item.artist:
            ET.SubElement(track, f"{{{namespace}}}creator").text = item.artist
        if item.album:
            ET.SubElement(track, f"{{{namespace}}}album").text = item.album
        if item.duration_ms is not None:
            ET.SubElement(track, f"{{{namespace}}}duration").text = str(item.duration_ms)
    tree = ET.ElementTree(root)
    ET.indent(tree, space="  ")
    tree.write(path, encoding="utf-8", xml_declaration=True)
