# Reference and fidelity record

## Fixed target

- **Application:** VLC media player
- **Version:** 3.0.21 “Vetinari”
- **Build target:** Windows 64-bit, default Qt interface
- **Comparison environment:** Windows 11, default light application theme,
  100% display scaling
- **Reference release date:** 10 June 2024

The implementation does not intentionally mix VLC 4 previews, macOS-native VLC,
skins, mobile interfaces, or unrelated media-player designs.

## Authoritative material consulted

1. [Official VLC 3.0.21 release page](https://www.videolan.org/vlc/releases/3.0.21.html)
2. [Official VLC 3.0 desktop overview](https://docs.videolan.me/vlc-user/desktop/3.0/en/gettingstarted/desktopoverview/index.html)
3. [Official Windows/Linux menu-bar guide](https://docs.videolan.me/vlc-user/desktop/3.0/en/gettingstarted/desktopoverview/windows_and_linux/menu_bar.html)
4. [Official playback-controls image](https://docs.videolan.me/vlc-user/desktop/3.0/en/_images/playback_controls_windows.png)
5. [Official VLC 3.0 hotkeys](https://docs.videolan.me/vlc-user/desktop/3.0/en/basic/hotkeys.html)
6. [Official VLC 3.0 source branch mirror](https://github.com/videolan/vlc-3.0)
7. [Official VLC 3.0.21 archive](https://download.videolan.org/pub/videolan/vlc/3.0.21/win64/)

## Interface inventory used for reconstruction

The documented Windows interface has three primary regions: the menu bar, the
media/video area above the track slider, and playback/volume controls below the
slider. The toolbar reference places a large play control first, then previous,
stop, next, fullscreen, auxiliary controls, playlist/repeat/shuffle, and volume
at the right. The menu bar contains Media, Playback, Audio, Video, Subtitle,
Tools, View, and Help in that order.

Media Player follows that structure with native Qt widgets, restrained
spacing, standard desktop menus, a dark playback surface, a compact slider row,
and a bottom playback toolbar. Its placeholder is newly drawn at runtime and is
not copied VLC artwork.

## Measurements and evidence limits

Official documentation provided the control arrangement and menu screenshots,
but not a normative pixel specification for every Windows theme and DPI. The
project therefore uses an 860×560 initial client size, a 620×390 minimum, 30 px
small toolbar buttons, a 42 px play button, and DPI-aware Qt layouts. These are
implementation measurements, not claimed measurements of the reference.

The build environment did not contain Windows, a native VLC 3.0.21 executable,
or libVLC. An offscreen Linux/Qt rendering was inspected at 860×560, and widget
layout plus menu order were exercised in tests. Equivalent-condition reference
captures, overlays, and Windows font/theme comparison remain unverified. See
`FEATURE_REPORT.md` for the exact validation status.

## Deliberate identity differences

- The title is **Media Player**, not VLC media player.
- No VLC cone bitmap, VLC icon files, or VideoLAN brand assets are bundled.
- The about dialog states that this is an independent implementation.
- Unavailable libVLC/API functions present a reason instead of silently doing
  nothing.

