from __future__ import annotations

from pathlib import Path

import pytest

from media_player.conversion import (
    CONVERSION_PROFILES,
    build_conversion_arguments,
    build_stream_arguments,
    validate_output_destination,
)


def test_destination_validation_prevents_overwrite_and_input_replacement(tmp_path: Path) -> None:
    source = tmp_path / "input.mp4"
    source.write_bytes(b"source")
    with pytest.raises(ValueError, match="different"):
        validate_output_destination(str(source), str(source))
    output = tmp_path / "output.mp4"
    output.write_bytes(b"existing")
    with pytest.raises(FileExistsError):
        validate_output_destination(str(source), str(output))
    assert validate_output_destination(str(source), str(output), overwrite=True) == output


def test_destination_requires_existing_parent(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="does not exist"):
        validate_output_destination("source.mp4", str(tmp_path / "missing" / "out.mp4"))


def test_conversion_arguments_are_separate_tokens(tmp_path: Path) -> None:
    output = tmp_path / "a file.mp4"
    arguments = build_conversion_arguments("input file.mp4", str(output), CONVERSION_PROFILES[0])
    assert arguments[2] == "input file.mp4"
    assert str(output) in arguments[4]
    assert arguments[-1] == "vlc://quit"


def test_stream_destination_validation() -> None:
    with pytest.raises(ValueError, match="must begin"):
        build_stream_arguments("input.mp4", "example.test:8080")
    args = build_stream_arguments("input.mp4", "http://0.0.0.0:8080/live", transcode=True)
    assert "transcode" in args[4]
