from __future__ import annotations

from pathlib import Path
from typing import Any

from PySide6.QtCore import QObject, Signal
from PySide6.QtWidgets import QApplication

from media_player.engine import PlaybackState
from media_player.logging_utils import RingLogHandler
from media_player.models import PlaylistItem
from media_player.persistence import SettingsRepository
from media_player.ui.main_window import MainWindow


class FakeController(QObject):
    state_changed = Signal(object)
    media_changed = Signal(str)
    position_changed = Signal(int, int)
    seekable_changed = Signal(bool)
    buffering_changed = Signal(float)
    tracks_changed = Signal()
    metadata_changed = Signal(dict)
    error_occurred = Signal(str)
    end_reached = Signal()

    def __init__(self) -> None:
        super().__init__()
        self.state = PlaybackState.IDLE
        self.source = ""
        self.version = "fake-libVLC"
        self.loaded: list[tuple[str, list[str]]] = []
        self._time = 0
        self._duration = 120_000
        self._volume = 100
        self._muted = False
        self.released = False
        self.subtitles: list[str] = []

    def __getattr__(self, name: str) -> Any:
        if name.startswith("set_"):
            return lambda *args, **kwargs: True
        raise AttributeError(name)

    def set_video_output(self, _value: int) -> None:
        pass

    def set_volume(self, value: int) -> int:
        self._volume = value
        return value

    def volume(self) -> int:
        return self._volume

    def set_muted(self, value: bool) -> None:
        self._muted = value

    def is_muted(self) -> bool:
        return self._muted

    def load(
        self,
        source: str,
        *,
        options: list[str] | None = None,
        allow_network_metadata: bool = False,
    ) -> None:
        del allow_network_metadata
        self.source = source
        self.loaded.append((source, options or []))
        self.state = PlaybackState.OPENING
        self.state_changed.emit(self.state)

    def play(self) -> None:
        self.state = PlaybackState.PLAYING
        self.state_changed.emit(self.state)

    def pause(self) -> None:
        self.state = PlaybackState.PAUSED
        self.state_changed.emit(self.state)

    def toggle_pause(self) -> None:
        self.pause() if self.state == PlaybackState.PLAYING else self.play()

    def stop(self) -> None:
        self.state = PlaybackState.STOPPED
        self.state_changed.emit(self.state)

    def time(self) -> int:
        return self._time

    def duration(self) -> int:
        return self._duration

    def is_seekable(self) -> bool:
        return True

    def set_time(self, value: int) -> bool:
        self._time = value
        return True

    def frame_step(self) -> bool:
        return True

    def set_rate(self, _value: float) -> bool:
        return True

    def rate(self) -> float:
        return 1.0

    def audio_tracks(self):
        return []

    def video_tracks(self):
        return []

    def subtitle_tracks(self):
        return []

    def current_audio_track(self):
        return -1

    def current_video_track(self):
        return -1

    def current_subtitle_track(self):
        return -1

    def title_count(self):
        return 0

    def current_title(self):
        return -1

    def chapter_count(self):
        return 0

    def current_chapter(self):
        return -1

    def audio_devices(self):
        return []

    def current_audio_device(self):
        return ""

    def current_audio_channel(self):
        return 1

    def equalizer_presets(self):
        return []

    def equalizer_frequencies(self):
        return []

    def audio_delay(self):
        return 0

    def subtitle_delay(self):
        return 0

    def metadata(self):
        return {}

    def media_tracks(self):
        return []

    def snapshot(self, *_args):
        return False

    def add_subtitle(self, path: str) -> bool:
        self.subtitles.append(path)
        return True

    def release(self) -> None:
        self.released = True


def application() -> QApplication:
    return QApplication.instance() or QApplication([])


def test_main_window_builds_and_opens_media(tmp_path: Path) -> None:
    app = application()
    media = tmp_path / "sample.mp3"
    media.write_bytes(b"not decoded by fake engine")
    settings = SettingsRepository(tmp_path / "settings.json")
    settings.load()
    controller = FakeController()
    window = MainWindow(controller, settings, RingLogHandler())
    window.show()
    app.processEvents()
    assert [action.text().replace("&", "") for action in window.menuBar().actions()] == [
        "Media",
        "Playback",
        "Audio",
        "Video",
        "Subtitle",
        "Tools",
        "View",
        "Help",
    ]
    assert window.add_sources([str(media)], play_first=True) == 1
    app.processEvents()
    assert controller.loaded[0][0] == str(media.resolve())
    assert controller.state == PlaybackState.PLAYING
    controller.position_changed.emit(30_000, 120_000)
    app.processEvents()
    assert window.seek_slider.value() == 30_000
    window.set_playlist_visible(True)
    assert window.playlist_panel.isVisible()
    window.close()
    app.processEvents()
    assert controller.released


def test_fullscreen_overlay_state_can_round_trip(tmp_path: Path) -> None:
    app = application()
    settings = SettingsRepository(tmp_path / "settings.json")
    settings.load()
    controller = FakeController()
    window = MainWindow(controller, settings, RingLogHandler())
    window.show()
    app.processEvents()
    window.enter_fullscreen()
    app.processEvents()
    assert window.isFullScreen()
    assert window.fullscreen_overlay.isVisible()
    window.leave_fullscreen()
    app.processEvents()
    assert not window.isFullScreen()
    window.close()


def test_saved_playlist_restores_without_autoplay_and_starts_on_play(tmp_path: Path) -> None:
    app = application()
    media = tmp_path / "restored.mp3"
    media.write_bytes(b"audio")
    settings = SettingsRepository(tmp_path / "settings.json")
    settings.load()
    item = PlaylistItem(str(media), title="Restored", item_id="restored-id")
    settings.set_playlist_session([item.to_dict()], item.item_id)
    controller = FakeController()
    window = MainWindow(controller, settings, RingLogHandler())
    assert len(window.queue) == 1
    assert window.queue.current_id == item.item_id
    assert controller.loaded == []
    window.toggle_play_pause()
    app.processEvents()
    assert controller.loaded[0][0] == str(media)
    assert controller.state == PlaybackState.PLAYING
    window.close()


def test_bookmarks_and_playlist_maintenance(tmp_path: Path) -> None:
    app = application()
    media = tmp_path / "song.mp3"
    media.write_bytes(b"audio")
    missing = tmp_path / "missing.mp3"
    settings = SettingsRepository(tmp_path / "settings.json")
    settings.load()
    controller = FakeController()
    window = MainWindow(controller, settings, RingLogHandler())
    window.add_sources([str(media)], play_first=True)
    controller._time = 25_000
    window._add_bookmark()
    assert settings.bookmark_positions(str(media)) == [25_000]
    window.queue.extend(
        [PlaylistItem(str(media)), PlaylistItem(str(missing))]
    )
    assert window.remove_duplicate_entries() == 1
    assert window.remove_missing_entries() == 1
    assert len(window.queue) == 1
    window.close()
    app.processEvents()
    restored = SettingsRepository(settings.path)
    restored.load()
    assert restored.bookmark_positions(str(media)) == [25_000]


def test_sleep_timer_stop_after_current_and_quit_at_end(tmp_path: Path) -> None:
    app = application()
    first = tmp_path / "first.mp3"
    second = tmp_path / "second.mp3"
    first.write_bytes(b"one")
    second.write_bytes(b"two")
    settings = SettingsRepository(tmp_path / "settings.json")
    settings.load()
    controller = FakeController()
    window = MainWindow(controller, settings, RingLogHandler())
    window.add_sources([str(first), str(second)], play_first=True)
    window.set_sleep_timer(15)
    assert window.sleep_timer.isActive()
    assert "until" in window.sleep_menu.title()
    window.cancel_sleep_timer()
    assert not window.sleep_timer.isActive()
    assert window.sleep_menu.title() == "Sleep Timer"
    first_id = window.queue.current_id
    window.action_stop_after_current.setChecked(True)
    window._on_end_reached()
    assert not window.action_stop_after_current.isChecked()
    assert window.queue.current_id == first_id
    window.queue.set_current(window.queue.items[-1].item_id)
    window.action_quit_at_end.setChecked(True)
    window._on_end_reached()
    app.processEvents()
    assert controller.released


def test_dropped_subtitle_attaches_to_loaded_media(tmp_path: Path) -> None:
    app = application()
    media = tmp_path / "video.mp4"
    subtitle = tmp_path / "captions.srt"
    media.write_bytes(b"video")
    subtitle.write_text("1\n00:00:00,000 --> 00:00:01,000\nHello\n", encoding="utf-8")
    settings = SettingsRepository(tmp_path / "settings.json")
    settings.load()
    controller = FakeController()
    window = MainWindow(controller, settings, RingLogHandler())
    window.add_sources([str(media)], play_first=True)
    window._handle_dropped_sources([str(subtitle)])
    assert controller.subtitles == [str(subtitle)]
    window.close()
    app.processEvents()
