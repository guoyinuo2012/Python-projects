from __future__ import annotations

import sys

import bootstrap
import run_player


def test_missing_python_packages_reports_distribution_names(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    monkeypatch.setattr(
        run_player,
        "find_spec",
        lambda module_name: object() if module_name == "PySide6" else None,
    )
    assert run_player.missing_python_packages() == ["python-vlc"]


def test_source_launcher_bootstraps_only_once(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    monkeypatch.delenv(run_player.BOOTSTRAP_ENVIRONMENT_FLAG, raising=False)
    assert run_player.should_bootstrap()
    monkeypatch.setenv(run_player.BOOTSTRAP_ENVIRONMENT_FLAG, "1")
    assert not run_player.should_bootstrap()


def test_direct_source_launch_delegates_to_bootstrap(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    received: list[str] = []
    monkeypatch.setattr(run_player, "should_bootstrap", lambda: True)
    monkeypatch.setattr(sys, "argv", ["run_player.py", "--version"])
    monkeypatch.setattr(bootstrap, "main", lambda arguments: received.extend(arguments) or 17)
    assert run_player.main() == 17
    assert received == ["--version"]
