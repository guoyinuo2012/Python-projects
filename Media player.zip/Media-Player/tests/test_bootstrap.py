from __future__ import annotations

import subprocess
from pathlib import Path

import bootstrap


def test_virtual_environment_python_uses_platform_layout(tmp_path: Path) -> None:
    assert bootstrap.virtual_environment_python(tmp_path, platform_name="nt") == (
        tmp_path / "Scripts" / "python.exe"
    )
    assert bootstrap.virtual_environment_python(tmp_path, platform_name="posix") == (
        tmp_path / "bin" / "python"
    )


def test_requirements_fingerprint_changes_with_contents(tmp_path: Path) -> None:
    requirements = tmp_path / "requirements.txt"
    requirements.write_text("one==1\n", encoding="utf-8")
    first = bootstrap.requirements_fingerprint(requirements)
    requirements.write_text("two==2\n", encoding="utf-8")
    assert bootstrap.requirements_fingerprint(requirements) != first


def test_dependency_probe_uses_requested_interpreter(tmp_path: Path) -> None:
    requested = tmp_path / "python"
    observed: list[object] = []

    def fake_runner(command, **kwargs):  # type: ignore[no-untyped-def]
        observed.extend((command, kwargs))
        return subprocess.CompletedProcess(command, 0, "", "")

    assert bootstrap.dependencies_available(requested, runner=fake_runner)
    assert observed[0][0] == str(requested)  # type: ignore[index]
    assert observed[1]["check"] is False  # type: ignore[index]


def test_dependency_probe_failure_is_false(tmp_path: Path) -> None:
    def fake_runner(command, **_kwargs):  # type: ignore[no-untyped-def]
        return subprocess.CompletedProcess(command, 1, "", "")

    assert not bootstrap.dependencies_available(tmp_path / "python", runner=fake_runner)


def test_bootstrap_marks_child_to_prevent_recursive_setup(monkeypatch, tmp_path: Path) -> None:  # type: ignore[no-untyped-def]
    python = tmp_path / "python"
    observed: dict[str, object] = {}

    def fake_call(command, **kwargs):  # type: ignore[no-untyped-def]
        observed.update(command=command, **kwargs)
        return 0

    monkeypatch.setattr(bootstrap, "ensure_runtime", lambda: python)
    monkeypatch.setattr(bootstrap.subprocess, "call", fake_call)
    assert bootstrap.main(["--version"]) == 0
    assert observed["command"][0] == str(python)  # type: ignore[index]
    assert observed["env"][bootstrap.BOOTSTRAP_ENVIRONMENT_FLAG] == "1"  # type: ignore[index]
