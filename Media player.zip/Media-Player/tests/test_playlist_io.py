from __future__ import annotations

from pathlib import Path

import pytest

from media_player.models import PlaylistItem
from media_player.playlist_io import load_playlist, save_playlist


@pytest.mark.parametrize("suffix", [".m3u8", ".pls", ".xspf"])
def test_playlist_round_trip_preserves_sources_and_titles(tmp_path: Path, suffix: str) -> None:
    local = tmp_path / "音楽 track.mp3"
    local.write_bytes(b"test")
    items = [
        PlaylistItem(str(local), title="Unicode 音楽", duration_ms=123_000, artist="Artist"),
        PlaylistItem("https://example.test/live stream", title="Network stream"),
    ]
    target = tmp_path / f"list{suffix}"
    save_playlist(target, items)
    restored = load_playlist(target)
    assert [item.source for item in restored] == [item.source for item in items]
    assert [item.title for item in restored] == [item.title for item in items]
    assert restored[0].duration_ms == 123_000


def test_m3u_resolves_relative_paths(tmp_path: Path) -> None:
    media = tmp_path / "media" / "song.mp3"
    media.parent.mkdir()
    media.write_bytes(b"data")
    playlist = tmp_path / "list.m3u"
    playlist.write_text("#EXTM3U\n#EXTINF:10,Song\nmedia/song.mp3\n", encoding="utf-8")
    item = load_playlist(playlist)[0]
    assert item.source == str(media.resolve())
    assert item.title == "Song"
    assert item.duration_ms == 10_000


def test_invalid_xspf_has_useful_error(tmp_path: Path) -> None:
    playlist = tmp_path / "broken.xspf"
    playlist.write_text("<playlist><broken>", encoding="utf-8")
    with pytest.raises(ValueError, match="Invalid XSPF"):
        load_playlist(playlist)
