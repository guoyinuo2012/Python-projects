from __future__ import annotations

import random

from media_player.models import PlaylistItem, PlaylistQueue, RepeatMode


def make_queue(count: int = 4) -> PlaylistQueue:
    queue = PlaylistQueue(random_source=random.Random(7))
    queue.extend(PlaylistItem(f"/tmp/{index}.mp3", title=f"Item {index}") for index in range(count))
    return queue


def test_reorder_keeps_current_identity() -> None:
    queue = make_queue()
    current = queue.items[1]
    queue.set_current(current.item_id)
    queue.reorder([item.item_id for item in reversed(queue.items)])
    assert queue.current is current
    assert queue.index_of(current.item_id) == 2


def test_removing_current_selects_successor_at_same_row() -> None:
    queue = make_queue()
    removed = queue.items[1]
    expected = queue.items[2]
    queue.set_current(removed.item_id)
    replacement = queue.remove_ids([removed.item_id])
    assert replacement is expected
    assert queue.current_id == expected.item_id


def test_repeat_one_applies_only_to_natural_end() -> None:
    queue = make_queue(2)
    first = queue.set_current(queue.items[0].item_id)
    queue.repeat_mode = RepeatMode.ONE
    assert queue.next(natural_end=True) is first
    assert queue.next(natural_end=False) is queue.items[1]


def test_repeat_all_wraps_in_both_directions() -> None:
    queue = make_queue(3)
    queue.repeat_mode = RepeatMode.ALL
    queue.set_current(queue.items[-1].item_id)
    assert queue.next() is queue.items[0]
    assert queue.previous() is queue.items[-1]


def test_shuffle_visits_every_other_item_before_repeat() -> None:
    queue = make_queue(5)
    first = queue.items[0]
    queue.set_current(first.item_id)
    queue.set_shuffle(True)
    visited = [first.item_id]
    for _ in range(4):
        item = queue.next()
        assert item is not None
        visited.append(item.item_id)
    assert len(set(visited)) == 5
    assert queue.next() is None
    queue.repeat_mode = RepeatMode.ALL
    assert queue.next() is not None


def test_invalid_reorder_is_rejected() -> None:
    queue = make_queue(2)
    try:
        queue.reorder([queue.items[0].item_id])
    except ValueError as exc:
        assert "every playlist item" in str(exc)
    else:
        raise AssertionError("Invalid reorder was accepted")
