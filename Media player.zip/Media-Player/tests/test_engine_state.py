from __future__ import annotations

from media_player.engine import PlaybackState, PlaybackStateMachine, probe_libvlc


class VersionProbe:
    def __init__(self, version: bytes) -> None:
        self.version = version

    def libvlc_get_version(self) -> bytes:
        return self.version


def test_state_machine_rejects_stale_media_events() -> None:
    machine = PlaybackStateMachine()
    first = machine.begin_load()
    second = machine.begin_load()
    assert second > first
    assert machine.accept("playing", first) is None
    assert machine.state == PlaybackState.OPENING
    assert machine.accept("buffering", second) == PlaybackState.BUFFERING
    assert machine.accept("playing", second) == PlaybackState.PLAYING


def test_state_machine_covers_terminal_states() -> None:
    machine = PlaybackStateMachine()
    generation = machine.begin_load()
    assert machine.accept("paused", generation) == PlaybackState.PAUSED
    assert machine.accept("stopped", generation) == PlaybackState.STOPPED
    assert machine.accept("ended", generation) == PlaybackState.ENDED
    assert machine.accept("error", generation) == PlaybackState.FAILED
    machine.reset()
    assert machine.state == PlaybackState.IDLE


def test_libvlc_version_probe_accepts_three_and_rejects_other_majors() -> None:
    assert probe_libvlc(VersionProbe(b"3.0.21 Vetinari")) == (True, "3.0.21 Vetinari")
    available, detail = probe_libvlc(VersionProbe(b"4.0.0"))
    assert not available
    assert "3.x" in detail
