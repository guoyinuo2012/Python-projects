from __future__ import annotations

import os
from pathlib import Path

import pytest

from media_player.media_utils import (
    deduplicate_sources,
    is_network_url,
    iter_media_files,
    normalize_source,
    source_comparison_key,
    source_kind,
)


def test_paths_urls_spaces_and_unicode(tmp_path: Path) -> None:
    media = tmp_path / "space 音楽.mp3"
    media.write_bytes(b"x")
    assert normalize_source(str(media)) == str(media.resolve())
    assert normalize_source(media.as_uri()) == str(media.resolve())
    assert normalize_source("https://example.test/a b") == "https://example.test/a b"
    assert is_network_url("RTSP://example.test/live")


def test_deduplicate_sources_preserves_order(tmp_path: Path) -> None:
    media = tmp_path / "track.mp3"
    media.write_bytes(b"x")
    values = deduplicate_sources([str(media), str(media), "https://example.test/live"])
    assert values == [str(media.resolve()), "https://example.test/live"]


def test_source_comparison_key_preserves_url_case() -> None:
    assert source_comparison_key("https://example.test/VideoA") != source_comparison_key(
        "https://example.test/videoa"
    )


def test_folder_scan_filters_extensions_and_does_not_follow_symlink_loops(tmp_path: Path) -> None:
    root = tmp_path / "root"
    child = root / "child"
    child.mkdir(parents=True)
    (root / "a.mp3").write_bytes(b"a")
    (child / "b.mkv").write_bytes(b"b")
    (child / "note.txt").write_text("no", encoding="utf-8")
    if os.name != "nt":
        (child / "loop").symlink_to(root, target_is_directory=True)
    found = {path.name for path in iter_media_files(root)}
    assert found == {"a.mp3", "b.mkv"}


def test_source_kind(tmp_path: Path) -> None:
    folder = tmp_path / "folder"
    folder.mkdir()
    assert source_kind("https://example.test/live") == "network"
    assert source_kind(str(folder)) == "folder"
    assert source_kind(str(tmp_path / "list.m3u8")) == "playlist"


def test_empty_source_rejected() -> None:
    with pytest.raises(ValueError, match="empty"):
        normalize_source("   ")
