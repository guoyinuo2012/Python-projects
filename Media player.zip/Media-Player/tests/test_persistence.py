from __future__ import annotations

import json
from pathlib import Path

from media_player.persistence import SettingsRepository, validate_settings


def test_validation_clamps_and_recovers_types() -> None:
    result = validate_settings(
        {
            "volume": 999,
            "muted": "yes",
            "repeat_mode": "forever",
            "subtitle_font_size": -10,
            "recent_media": ["bad", {"source": "https://example.test/a"}],
        }
    )
    assert result["volume"] == 125
    assert result["muted"] is False
    assert result["repeat_mode"] == "off"
    assert result["subtitle_font_size"] == 6
    assert result["recent_media"] == [{"source": "https://example.test/a", "opened_at": ""}]


def test_atomic_save_and_malformed_file_recovery(tmp_path: Path) -> None:
    path = tmp_path / "settings.json"
    repository = SettingsRepository(path)
    repository.load()
    repository.data["volume"] = 73
    repository.save()
    assert json.loads(path.read_text(encoding="utf-8"))["volume"] == 73
    path.write_text("{not valid", encoding="utf-8")
    assert SettingsRepository(path).load()["volume"] == 100


def test_recent_media_is_deduplicated_and_bounded(tmp_path: Path) -> None:
    repository = SettingsRepository(tmp_path / "settings.json")
    repository.load()
    for index in range(20):
        repository.add_recent(f"https://example.test/{index}")
    repository.add_recent("https://example.test/18")
    sources = repository.recent_sources()
    assert len(sources) == 15
    assert sources[0] == "https://example.test/18"
    assert sources.count("https://example.test/18") == 1


def test_resume_position_requires_matching_media_and_ignores_near_end(tmp_path: Path) -> None:
    media = tmp_path / "clip.mp4"
    media.write_bytes(b"media")
    repository = SettingsRepository(tmp_path / "settings.json")
    repository.load()
    repository.set_resume_position(str(media), 45_000, 120_000)
    assert repository.resume_position(str(media), 120_000) == 45_000
    assert repository.resume_position(str(media), 180_000) is None
    repository.set_resume_position(str(media), 118_000, 120_000)
    assert repository.resume_position(str(media), 120_000) is None


def test_changed_local_file_gets_new_resume_identity(tmp_path: Path) -> None:
    media = tmp_path / "clip.mp4"
    media.write_bytes(b"first")
    repository = SettingsRepository(tmp_path / "settings.json")
    repository.load()
    repository.set_resume_position(str(media), 30_000, 100_000)
    media.write_bytes(b"changed and longer")
    assert repository.resume_position(str(media), 100_000) is None


def test_playlist_session_and_bookmarks_are_validated(tmp_path: Path) -> None:
    media = tmp_path / "song.mp3"
    media.write_bytes(b"audio")
    repository = SettingsRepository(tmp_path / "settings.json")
    repository.load()
    repository.set_playlist_session(
        [
            {
                "source": str(media),
                "title": "Song",
                "duration_ms": 90_000,
                "item_id": "stable-id",
            }
        ],
        "stable-id",
    )
    assert repository.add_bookmark(str(media), 40_000)
    assert not repository.add_bookmark(str(media), 40_000)
    repository.save()

    restored = SettingsRepository(repository.path)
    restored.load()
    items, current_id = restored.playlist_session()
    assert items[0]["source"] == str(media)
    assert current_id == "stable-id"
    assert restored.bookmark_positions(str(media)) == [40_000]
    restored.clear_bookmarks(str(media))
    assert restored.bookmark_positions(str(media)) == []


def test_disabling_playlist_restore_clears_saved_session(tmp_path: Path) -> None:
    repository = SettingsRepository(tmp_path / "settings.json")
    repository.load()
    repository.data["restore_playlist"] = False
    repository.set_playlist_session([{"source": "https://example.test/live"}], "id")
    assert repository.playlist_session() == ([], "")
