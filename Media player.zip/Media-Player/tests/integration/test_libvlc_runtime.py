from __future__ import annotations

import math
import struct
import time
import wave
from pathlib import Path

import pytest
from PySide6.QtCore import QCoreApplication

from media_player.engine import PlaybackController, PlaybackState, probe_libvlc

pytestmark = pytest.mark.integration


def _write_tone(path: Path) -> None:
    sample_rate = 22_050
    with wave.open(str(path), "wb") as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(sample_rate)
        frames = bytearray()
        for index in range(sample_rate):
            sample = int(6000 * math.sin(2 * math.pi * 440 * index / sample_rate))
            frames.extend(struct.pack("<h", sample))
        output.writeframes(frames)


@pytest.mark.skipif(not probe_libvlc()[0], reason="native libVLC runtime is not installed")
def test_real_libvlc_audio_play_pause_stop_and_volume(tmp_path: Path) -> None:
    app = QCoreApplication.instance() or QCoreApplication([])
    media = tmp_path / "tone.wav"
    _write_tone(media)
    controller = PlaybackController()
    try:
        controller.load(str(media))
        controller.set_volume(35)
        controller.set_muted(False)
        controller.play()
        deadline = time.monotonic() + 3
        while (
            controller.state not in {PlaybackState.PLAYING, PlaybackState.ENDED}
            and time.monotonic() < deadline
        ):
            app.processEvents()
            time.sleep(0.01)
        assert controller.state in {PlaybackState.PLAYING, PlaybackState.ENDED}
        assert controller.volume() >= 0
        if controller.state == PlaybackState.PLAYING:
            controller.pause()
            app.processEvents()
        controller.stop()
    finally:
        controller.release()
