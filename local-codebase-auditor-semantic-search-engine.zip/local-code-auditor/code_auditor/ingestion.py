"""Bounded asynchronous ingestion with hierarchical .gitignore rules."""

import asyncio
import hashlib
import io
import os
import tokenize
from pathlib import Path

from pathspec import GitIgnoreSpec

from .filesystem import read_bytes
from .models import AuditorError, ScanResult, SourceFile

DEFAULT_EXTENSIONS = frozenset(
    {
        ".py",
        ".js",
        ".jsx",
        ".ts",
        ".tsx",
        ".json",
        ".toml",
        ".yaml",
        ".yml",
        ".md",
        ".html",
        ".css",
        ".sql",
        ".sh",
    }
)
EXCLUDED_DIRS = frozenset(
    {
        ".git",
        ".venv",
        "venv",
        "node_modules",
        "__pycache__",
        ".code-auditor",
        ".pytest_cache",
        ".ruff_cache",
    }
)


class Scanner:
    """Never follow symlinks; unreadable directory discovery aborts the scan.

    Read failures are reported by relative path. Every eligible file enters
    `seen`, including unreadable, binary and oversized files, so callers can
    distinguish read failures from deletions. Worker count bounds open files.
    """

    def __init__(
        self,
        root: Path,
        extensions: frozenset[str] = DEFAULT_EXTENSIONS,
        workers: int = 8,
        max_bytes: int = 2_000_000,
        max_files: int = 10_000,
        max_total_bytes: int = 32_000_000,
    ):
        self.root = root.expanduser().resolve()
        self.extensions = extensions
        self.workers = workers
        self.max_bytes = max_bytes
        self.max_files = max_files
        self.max_total_bytes = max_total_bytes
        if not 1 <= workers <= 64 or min(max_bytes, max_files, max_total_bytes) < 1:
            raise AuditorError("workers must be in [1,64]; all size/count limits must be positive")
        if not self.root.is_dir():
            raise AuditorError(f"Not a directory: {self.root}")

    def discover(self) -> list[Path]:
        files: list[Path] = []
        enumerated = 0

        def visit(directory: Path, inherited: list[tuple[Path, GitIgnoreSpec]]) -> None:
            nonlocal enumerated
            if len(directory.relative_to(self.root).parts) > 128:
                raise AuditorError("Directory nesting exceeds 128 levels")
            rules = list(inherited)
            ignore = directory / ".gitignore"
            try:
                if ignore.is_file() and not ignore.is_symlink():
                    rules.append(
                        (
                            directory,
                            GitIgnoreSpec.from_lines(
                                read_bytes(
                                    self.root,
                                    ignore.relative_to(self.root).as_posix(),
                                    self.max_bytes,
                                )
                                .decode("utf-8-sig")
                                .splitlines()
                            ),
                        )
                    )
                with os.scandir(directory) as entries:
                    ordered = []
                    for entry in entries:
                        enumerated += 1
                        if enumerated > self.max_files * 10:
                            raise AuditorError(
                                "Directory entry budget exceeded; increase --max-files"
                            )
                        ordered.append(entry)
                    ordered.sort(key=lambda entry: entry.name)
            except (OSError, UnicodeError, ValueError) as exc:
                raise AuditorError(f"Cannot enumerate {directory}: {exc}") from exc
            for entry in ordered:
                try:
                    if entry.is_symlink():
                        continue
                    path = Path(entry.path)
                    is_dir = entry.is_dir(follow_symlinks=False)
                    if is_dir and entry.name in EXCLUDED_DIRS:
                        continue
                    ignored = False
                    for base, spec in rules:
                        relative = path.relative_to(base).as_posix() + ("/" if is_dir else "")
                        decision = spec.check_file(relative).include
                        if decision is not None:
                            ignored = bool(decision)
                    if ignored:
                        continue
                    if is_dir:
                        visit(path, rules)
                    elif (
                        entry.is_file(follow_symlinks=False)
                        and path.suffix.lower() in self.extensions
                    ):
                        if len(files) >= self.max_files:
                            raise AuditorError("File count budget exceeded; increase --max-files")
                        files.append(path)
                except OSError as exc:
                    raise AuditorError(f"Cannot inspect {entry.path}: {exc}") from exc

        visit(self.root, [])
        return files

    def read(self, path: Path) -> SourceFile:
        relative = path.relative_to(self.root).as_posix()
        raw = read_bytes(self.root, relative, self.max_bytes)
        if b"\x00" in raw:
            raise AuditorError("Binary file (NUL byte)")
        encoding = (
            tokenize.detect_encoding(io.BytesIO(raw).readline)[0]
            if path.suffix.lower() == ".py"
            else "utf-8-sig"
        )
        content = raw.decode(encoding)
        return SourceFile(relative, content, hashlib.sha256(raw).hexdigest(), encoding)

    async def scan(self) -> ScanResult:
        paths = await asyncio.to_thread(self.discover)
        result = ScanResult(seen={p.relative_to(self.root).as_posix() for p in paths})
        total_bytes = 0
        queue: asyncio.Queue[Path] = asyncio.Queue()
        for path in paths:
            queue.put_nowait(path)

        async def worker() -> None:
            nonlocal total_bytes
            while True:
                try:
                    path = queue.get_nowait()
                except asyncio.QueueEmpty:
                    return
                try:
                    source = await asyncio.to_thread(self.read, path)
                except (OSError, UnicodeError, SyntaxError, AuditorError) as exc:
                    result.errors[path.relative_to(self.root).as_posix()] = str(exc)
                else:
                    total_bytes += len(source.content.encode("utf-8"))
                    if total_bytes > self.max_total_bytes:
                        raise AuditorError(
                            "Workspace content budget exceeded; increase --max-total-bytes"
                        )
                    result.files.append(source)
                finally:
                    queue.task_done()

        await asyncio.gather(*(worker() for _ in range(self.workers)))
        result.files.sort(key=lambda source: source.path)
        return result
