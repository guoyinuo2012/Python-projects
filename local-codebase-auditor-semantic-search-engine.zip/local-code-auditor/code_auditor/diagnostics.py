"""Executable local embedding/index round-trip diagnostics."""

import tempfile
from pathlib import Path

import numpy as np

from .audit import Auditor
from .chunking import Chunker
from .embeddings import Embedder
from .models import AuditorError, SourceFile
from .search import HybridSearch
from .storage import Store


def diagnose(root: Path, embedder: Embedder) -> dict:
    sources = [
        SourceFile(
            "inventory.py", "def reserve_stock(quantity):\n    return quantity\n", "inventory"
        ),
        SourceFile("billing.py", "def invoice_customer(amount):\n    return amount\n", "billing"),
    ]
    chunker = Chunker()
    groups = [chunker.chunk(source)[0] for source in sources]
    chunks = [chunk for group in groups for chunk in group]
    vectors = embedder.encode([chunk.searchable() for chunk in chunks])
    query = embedder.encode(["reserve stock quantity"], query=True)
    if vectors.shape[1] != query.shape[1] or not vectors.any() or not query.any():
        raise AuditorError(
            "Model diagnostic failed: zero vectors or document/query dimension mismatch"
        )
    if not np.isfinite(vectors).all() or not np.isfinite(query).all():
        raise AuditorError("Model diagnostic failed: non-finite vectors")
    with tempfile.TemporaryDirectory(prefix="code-auditor-doctor-") as temporary:
        database = Path(temporary) / "probe.sqlite3"
        store = Store(database, root, embedder.signature)
        try:
            with store.transaction():
                for source, group, vector in zip(sources, groups, vectors, strict=True):
                    store.put_file(
                        source.path,
                        source.digest,
                        Auditor().audit(source).to_dict(),
                        None,
                        "utf-8",
                        group,
                        vector.reshape(1, -1),
                    )
            store.integrity_check()
        finally:
            store.close()
        reopened = Store(database, root, embedder.signature)
        try:
            loaded, persisted, _ = reopened.snapshot()
            if len(loaded) != 2 or not np.array_equal(
                persisted,
                vectors[
                    [next(i for i, c in enumerate(chunks) if c.id == item.id) for item in loaded]
                ],
            ):
                raise AuditorError("Persistence round-trip changed vectors or chunks")
            search = HybridSearch(reopened, embedder)
            keyword_hits = search.query("reserve_stock", semantic_weight=0)
            semantic_hits = search.query("reserve stock quantity", semantic_weight=1)
            hybrid_hits = search.query("reserve stock quantity")
            if not keyword_hits or keyword_hits[0].chunk.path != "inventory.py":
                raise AuditorError("BM25 diagnostic failed")
            if not semantic_hits or not hybrid_hits:
                raise AuditorError("Semantic/hybrid diagnostic returned no positive matches")
            return {
                "status": "passed",
                "backend": embedder.signature,
                "dimensions": int(vectors.shape[1]),
                "sqlite_round_trip": True,
                "faiss": True,
                "bm25": True,
                "hybrid": True,
                "semantic_top_path": semantic_hits[0].chunk.path,
                "note": "Operational smoke test only; semantic quality requires repository-specific relevance checks.",
            }
        finally:
            reopened.close()
