"""Typed values shared by ingestion, indexing, auditing and presentation."""

from dataclasses import asdict, dataclass, field
from typing import Any


class AuditorError(Exception):
    """An operational error suitable for display without a traceback."""


@dataclass(frozen=True)
class SourceFile:
    path: str
    content: str
    digest: str
    encoding: str = "utf-8"


@dataclass(frozen=True)
class Chunk:
    id: str
    path: str
    name: str
    kind: str
    start_line: int
    end_line: int
    content: str
    parent: str | None = None
    docstring: str | None = None
    imports: tuple[str, ...] = ()

    def searchable(self) -> str:
        return f"{self.path}\n{self.name}\n{self.docstring or ''}\n{self.content}"


@dataclass(frozen=True)
class Finding:
    path: str
    line: int
    rule: str
    severity: str
    message: str


@dataclass
class FileHealth:
    path: str
    code_lines: int = 0
    comment_lines: int = 0
    blank_lines: int = 0
    complexity: dict[str, int] = field(default_factory=dict)
    findings: list[Finding] = field(default_factory=list)

    @property
    def code_to_comment_ratio(self) -> float | None:
        return self.code_lines / self.comment_lines if self.comment_lines else None

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["code_to_comment_ratio"] = self.code_to_comment_ratio
        return result


@dataclass
class ScanResult:
    files: list[SourceFile] = field(default_factory=list)
    seen: set[str] = field(default_factory=set)
    errors: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class SearchHit:
    chunk: Chunk
    score: float
    keyword_score: float
    semantic_score: float
