"""Bounded regular-file reads without following symlink path components."""

import os
import stat
from contextlib import contextmanager
from pathlib import Path, PurePosixPath

from .models import AuditorError


def relative_parts(relative: str) -> tuple[str, ...]:
    path = PurePosixPath(relative)
    if (
        not path.parts
        or path.is_absolute()
        or ".." in path.parts
        or "\\" in relative
        or "\x00" in relative
    ):
        raise AuditorError("Expected a relative path inside the workspace")
    return path.parts


@contextmanager
def open_regular(root: Path, relative: str):
    """POSIX directory descriptors pin ancestry while each component is opened.

    On platforms lacking dir_fd/O_NOFOLLOW, lstat ancestry checks plus inode
    comparisons detect ordinary changes, but cannot exclude every hostile
    concurrent rename. The caller must own and trust the workspace.
    """
    parts = relative_parts(relative)
    descriptors = []
    try:
        flags = os.O_RDONLY | getattr(os, "O_NONBLOCK", 0)
        if os.open in os.supports_dir_fd and hasattr(os, "O_NOFOLLOW"):
            directory_flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
            descriptor = os.open(root, directory_flags)
            descriptors.append(descriptor)
            for part in parts[:-1]:
                descriptor = os.open(part, directory_flags, dir_fd=descriptor)
                descriptors.append(descriptor)
            file_descriptor = os.open(parts[-1], flags | os.O_NOFOLLOW, dir_fd=descriptor)
        else:
            current = root
            for part in parts:
                current = current / part
                if stat.S_ISLNK(current.lstat().st_mode):
                    raise AuditorError("Symlink source paths are disabled")
            file_descriptor = os.open(current, flags)
        with os.fdopen(file_descriptor, "rb") as stream:
            info = os.fstat(stream.fileno())
            if not stat.S_ISREG(info.st_mode):
                raise AuditorError("Source is not a regular file")
            yield stream
    finally:
        for descriptor in reversed(descriptors):
            os.close(descriptor)


def read_bytes(root: Path, relative: str, max_bytes: int) -> bytes:
    if max_bytes < 1:
        raise AuditorError("Read limit must be positive")
    with open_regular(root, relative) as stream:
        before = os.fstat(stream.fileno())
        if before.st_size > max_bytes:
            raise AuditorError(f"File exceeds {max_bytes} bytes")
        raw = stream.read(max_bytes + 1)
        after = os.fstat(stream.fileno())
    if len(raw) > max_bytes:
        raise AuditorError("File grew beyond size limit")
    if (before.st_mtime_ns, before.st_ctime_ns, before.st_size) != (
        after.st_mtime_ns,
        after.st_ctime_ns,
        after.st_size,
    ):
        raise AuditorError("File changed while being read; retry the operation")
    path_info = (root / relative).lstat()
    if stat.S_ISLNK(path_info.st_mode) or (path_info.st_dev, path_info.st_ino) != (
        before.st_dev,
        before.st_ino,
    ):
        raise AuditorError("Source path was replaced while being read")
    return raw
