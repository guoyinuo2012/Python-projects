"""Incremental orchestration; failed embedding batches never partially commit."""

import asyncio
import json
from dataclasses import asdict, dataclass

import numpy as np

from .audit import Auditor
from .chunking import Chunker
from .embeddings import Embedder
from .ingestion import Scanner
from .models import AuditorError
from .storage import Store

PIPELINE_VERSION = "ast-v1:audit-v2"


@dataclass(frozen=True)
class UpdateSummary:
    changed: int
    unchanged: int
    deleted: int
    chunks: int
    errors: dict[str, str]


class Pipeline:
    def __init__(self, scanner: Scanner, store: Store, embedder: Embedder, batch_size: int = 16):
        if batch_size < 1:
            raise AuditorError("batch_size must be positive")
        self.scanner = scanner
        self.store = store
        self.embedder = embedder
        self.batch_size = batch_size
        self.chunker = Chunker()
        self.auditor = Auditor()

    async def update(self) -> UpdateSummary:
        scan = await self.scanner.scan()
        old = self.store.versions()
        pending = []
        unchanged = 0
        errors = dict(scan.errors)
        chunk_count = 0
        payload_bytes = 0
        for source in scan.files:
            digest = f"{source.digest}:{PIPELINE_VERSION}"
            if old.get(source.path) == digest:
                unchanged += 1
                continue
            chunks, syntax_error = self.chunker.chunk(source)
            health = self.auditor.audit(source).to_dict()
            chunk_count += len(chunks)
            payload_bytes += sum(len(json.dumps(asdict(chunk)).encode()) for chunk in chunks)
            if chunk_count > self.store.max_chunks or payload_bytes > self.store.max_index_bytes:
                raise AuditorError(
                    "Changed chunks exceed index budget; increase --max-chunks/--max-index-bytes"
                )
            matrices = []
            for start in range(0, len(chunks), self.batch_size):
                batch = chunks[start : start + self.batch_size]
                matrices.append(
                    await asyncio.to_thread(
                        self.embedder.encode, [chunk.searchable() for chunk in batch]
                    )
                )
            vectors = np.concatenate(matrices, axis=0) if matrices else None
            if vectors is not None:
                payload_bytes += vectors.nbytes
                if payload_bytes > self.store.max_index_bytes:
                    raise AuditorError("Embedding budget exceeded; increase --max-index-bytes")
            pending.append(
                (source.path, digest, health, syntax_error, source.encoding, chunks, vectors)
            )
            if syntax_error:
                errors[source.path] = syntax_error
        deleted = set(old) - scan.seen
        # Discovery/embedding errors abort before the write transaction. Read
        # errors invalidate old chunks, so search cannot return obsolete code.
        # Detect edits during slow embedding work before committing old code.
        for source in scan.files:
            current = await asyncio.to_thread(self.scanner.read, self.scanner.root / source.path)
            if current.digest != source.digest:
                raise AuditorError(f"{source.path} changed during indexing; retry")
        with self.store.transaction():
            # Reject overlapping writers instead of overwriting a newer scan.
            if self.store.versions() != old:
                raise AuditorError("Index changed during scanning; retry the update")
            for path in deleted:
                self.store.delete_file(path)
            for item in pending:
                self.store.put_file(*item)
            for path, error in scan.errors.items():
                health = {
                    "path": path,
                    "code_lines": 0,
                    "comment_lines": 0,
                    "blank_lines": 0,
                    "complexity": {},
                    "findings": [],
                    "code_to_comment_ratio": None,
                }
                self.store.put_file(path, "read-error", health, error, "unknown", [], None)
            self.store.check_budget()
        errors.update(self.store.errors())
        return UpdateSummary(
            len(pending) + len(scan.errors),
            unchanged,
            len(deleted),
            self.store.stats()["chunks"],
            errors,
        )
