"""Support python -m code_auditor."""

from .cli import main

raise SystemExit(main())
