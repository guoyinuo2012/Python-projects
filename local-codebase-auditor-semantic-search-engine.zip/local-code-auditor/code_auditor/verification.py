"""Run explicit project checks in temporary baseline and candidate workspaces.

This is isolation of files, not a security sandbox: trusted test commands can
access the host, network and inherited environment just like ordinary tests.
"""

import os
import signal
import subprocess
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

from .audit import redact
from .filesystem import read_bytes, relative_parts
from .ingestion import EXCLUDED_DIRS
from .models import AuditorError


@dataclass(frozen=True)
class CheckResult:
    command: tuple[str, ...]
    baseline_output: str
    candidate_output: str


def copy_workspace(
    root: Path, target: Path, max_files: int = 10_000, max_bytes: int = 64_000_000
) -> None:
    """Bounded copy of regular files only; generated environments are excluded."""
    count = 0
    total = 0
    entries_seen = 0
    for directory, directories, files in os.walk(root, followlinks=False, onerror=_walk_error):
        base = Path(directory)
        if len(base.relative_to(root).parts) > 128:
            raise AuditorError("Verification workspace nesting exceeds 128 levels")
        directories[:] = [
            name
            for name in directories
            if name not in EXCLUDED_DIRS
            and name not in {"build", "dist"}
            and not (base / name).is_symlink()
        ]
        entries_seen += len(directories) + len(files)
        if entries_seen > max_files * 10:
            raise AuditorError("Verification directory-entry budget exceeded")
        for name in files:
            path = base / name
            if path.is_symlink() or not path.is_file():
                continue
            count += 1
            if count > max_files:
                raise AuditorError("Verification file budget exceeded")
            relative = path.relative_to(root).as_posix()
            raw = read_bytes(root, relative, max_bytes)
            total += len(raw)
            if total > max_bytes:
                raise AuditorError(
                    f"Verification workspace exceeds {max_bytes} bytes; increase --max-total-bytes"
                )
            destination = target / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(raw)
            destination.chmod(path.stat().st_mode & 0o777)


def _walk_error(error: OSError) -> None:
    raise AuditorError(f"Cannot copy verification workspace: {error}") from error


def _kill(process: subprocess.Popen) -> None:
    if os.name == "posix":
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    elif process.poll() is None:
        process.kill()


def run_check(
    command: list[str], directory: Path, timeout: float, max_output: int = 1_000_000
) -> str:
    if not command or any(not isinstance(value, str) or not value for value in command):
        raise AuditorError("An explicit nonempty --test-command is required")
    if not 0 < timeout <= 3600:
        raise AuditorError("Test timeout must be in (0,3600] seconds")
    environment = dict(os.environ)
    environment["PYTHONPATH"] = os.pathsep.join((str(directory), str(directory / "src")))
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    process = None
    try:
        with tempfile.TemporaryFile() as output:
            process = subprocess.Popen(
                command,
                cwd=directory,
                env=environment,
                stdin=subprocess.DEVNULL,
                stdout=output,
                stderr=subprocess.STDOUT,
                shell=False,
                start_new_session=os.name == "posix",
            )
            start = time.monotonic()
            reason = None
            while process.poll() is None:
                if time.monotonic() - start > timeout:
                    reason = "Project test command timed out"
                    break
                if os.fstat(output.fileno()).st_size > max_output:
                    reason = "Project test output budget exceeded"
                    break
                time.sleep(0.02)
            if reason:
                _kill(process)
            process.wait(timeout=5)
            _kill(process)  # Remove background children in our POSIX process group.
            size = os.fstat(output.fileno()).st_size
            output.seek(max(0, size - 64_000))
            text = redact(output.read(64_000).decode("utf-8", errors="replace"))
            if reason or size > max_output or process.returncode:
                reason = reason or (
                    "Project test output budget exceeded"
                    if size > max_output
                    else f"Project test command failed (exit {process.returncode})"
                )
                raise AuditorError(f"{reason}\n{text}")
            return text
    except (OSError, subprocess.SubprocessError) as exc:
        raise AuditorError(f"Cannot run project test command: {exc}") from exc
    finally:
        if process is not None:
            _kill(process)
            if process.poll() is None:
                process.wait(timeout=5)


def verify_proposal(
    root: Path,
    relative: str,
    original: bytes,
    replacement: bytes,
    command: list[str],
    timeout: float = 120,
    *,
    max_files: int = 10_000,
    max_bytes: int = 64_000_000,
) -> CheckResult:
    relative_parts(relative)
    root = root.resolve()
    if not command:
        raise AuditorError("Applying refactors requires --test-command; preview remains available")
    with tempfile.TemporaryDirectory(prefix="code-auditor-check-") as temporary:
        baseline = Path(temporary) / "baseline"
        candidate = Path(temporary) / "candidate"
        baseline.mkdir()
        candidate.mkdir()
        copy_workspace(root, baseline, max_files, max_bytes)
        target = baseline / relative
        if not target.is_file() or target.read_bytes() != original:
            raise AuditorError("Source changed while staging verification; generate a new proposal")
        copy_workspace(baseline, candidate, max_files, max_bytes)
        (candidate / relative).write_bytes(replacement)
        try:
            baseline_output = run_check(command, baseline, timeout)
        except AuditorError as exc:
            raise AuditorError(
                f"Baseline verification failed; working file untouched.\n{exc}"
            ) from exc
        try:
            candidate_output = run_check(command, candidate, timeout)
        except AuditorError as exc:
            raise AuditorError(
                f"Candidate verification failed; working file untouched.\n{exc}"
            ) from exc
        if target.read_bytes() != original or (candidate / relative).read_bytes() != replacement:
            raise AuditorError(
                "Test command modified the staged target; no refactor will be applied"
            )
        return CheckResult(tuple(command), baseline_output, candidate_output)
