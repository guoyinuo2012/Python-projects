"""Rich terminal commands and an interactive natural-language query loop."""

import argparse
import asyncio
import json
import logging
import shlex
import sqlite3
import sys
from dataclasses import asdict
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text

from . import __version__
from .audit import redact
from .diagnostics import diagnose
from .embeddings import (
    HashEmbedder,
    KeywordOnlyEmbedder,
    OllamaEmbedder,
    SentenceTransformerEmbedder,
)
from .ingestion import DEFAULT_EXTENSIONS, Scanner
from .models import AuditorError
from .pipeline import Pipeline
from .refactor import RefactorAgent
from .search import HybridSearch
from .storage import Store, read_identity

console = Console(highlight=False)


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(
        description="Self-hosted code health auditor and hybrid search"
    )
    result.add_argument("--version", action="version", version=__version__)
    result.add_argument("--root", type=Path, default=Path.cwd(), help="Workspace directory")
    result.add_argument(
        "--db", type=Path, help="SQLite index (default ROOT/.code-auditor/index.sqlite3)"
    )
    result.add_argument("--backend", choices=("ollama", "transformers", "hash"), default="ollama")
    result.add_argument(
        "--model",
        default="nomic-embed-text",
        help="Ollama embedding model or local Transformers directory",
    )
    result.add_argument("--ollama-url", default="http://127.0.0.1:11434")
    result.add_argument("--timeout", type=float, default=120)
    result.add_argument("--workers", type=int, default=8)
    result.add_argument("--max-bytes", type=int, default=2_000_000)
    result.add_argument("--max-files", type=int, default=10_000)
    result.add_argument("--max-total-bytes", type=int, default=32_000_000)
    result.add_argument("--max-chunks", type=int, default=10_000)
    result.add_argument("--max-index-bytes", type=int, default=64_000_000)
    result.add_argument(
        "--test-command",
        help="Trusted project tests, e.g. 'python -m pytest -q'; required for apply",
    )
    result.add_argument("--test-timeout", type=float, default=120)
    result.add_argument("--extensions", help="Comma-separated extensions, e.g. .py,.js,.json")
    result.add_argument("--verbose", action="store_true")
    commands = result.add_subparsers(dest="command", required=True)
    commands.add_parser("doctor", help="Probe the configured local model and index round trip")
    commands.add_parser("index", help="Incrementally scan, audit and embed")
    audit = commands.add_parser("audit", help="Audit current files without an embedding model")
    audit.add_argument("--json", action="store_true")
    audit.add_argument("--fail-on", choices=("never", "warning", "high", "error"), default="never")
    search = commands.add_parser("search", help="Query the persisted index")
    search.add_argument("query")
    search.add_argument("--limit", type=int, default=5)
    search.add_argument("--semantic-weight", type=float, default=0.5)
    search.add_argument("--json", action="store_true")
    commands.add_parser("shell", help="Index current files, then start the interactive loop")
    refactor = commands.add_parser("refactor", help="Preview a Python refactoring proposal")
    refactor.add_argument("path")
    refactor.add_argument("--refactor-model", help="Optional local Ollama generation model")
    refactor.add_argument(
        "--apply", action="store_true", help="Prompt to apply after displaying the diff"
    )
    return result


def show_health(reports: list[dict], errors: dict[str, str]) -> None:
    table = Table(title="Workspace health", show_lines=True)
    for column in ("File", "Code", "Comments/docs", "Code/comment", "Max complexity", "Findings"):
        table.add_column(column)
    for report in reports:
        ratio = report["code_to_comment_ratio"]
        table.add_row(
            Text(redact(report["path"])),
            str(report["code_lines"]),
            str(report["comment_lines"]),
            f"{ratio:.2f}" if ratio is not None else "n/a",
            str(max(report["complexity"].values(), default=0)),
            str(len(report["findings"])),
        )
    console.print(table)
    for report in reports:
        for finding in report["findings"]:
            console.print(
                Text(
                    redact(
                        f"{finding['severity'].upper()} {finding['path']}:{finding['line']} [{finding['rule']}] {finding['message']}"
                    )
                )
            )
    for path, error in errors.items():
        console.print(Text(redact(f"SKIPPED/UNPARSED {path}: {error}"), style="yellow"))


def show_hits(hits) -> None:
    if not hits:
        console.print("No matching snippets.")
    for number, hit in enumerate(hits, 1):
        chunk = hit.chunk
        header = Text(
            f"{number}. {chunk.path}:{chunk.start_line}-{chunk.end_line} · {chunk.name}\n"
            f"RRF={hit.score:.5f} BM25={hit.keyword_score:.3f} cosine={hit.semantic_score:.3f} · parent={chunk.parent or 'module'}"
        )
        language = "python" if chunk.path.endswith(".py") else "text"
        code = Syntax(
            redact(chunk.content).removesuffix("\n").removesuffix("\r"),
            language,
            line_numbers=True,
            start_line=chunk.start_line,
            word_wrap=True,
        )
        console.print(Text(redact(header.plain)))
        console.print(Panel(code, title=Text(redact(chunk.kind)), border_style="cyan"))


def refactor(agent: RefactorAgent, path: str, args, model=None, apply=False) -> None:
    proposal = agent.propose(path, model=model, base_url=args.ollama_url, timeout=args.timeout)
    console.print(Text(proposal.explanation))
    console.print(Syntax(redact(proposal.diff), "diff", word_wrap=True))
    if not proposal.diff:
        console.print("No changes proposed.")
        return
    if apply:
        if not sys.stdin.isatty():
            raise AuditorError(
                "Applying refactors requires an interactive terminal; run without --apply to preview"
            )
        if not args.test_command:
            raise AuditorError(
                "Applying refactors requires --test-command; preview remains available"
            )
        if Confirm.ask(
            "Apply this exact diff, run project tests, and create a backup?", default=False
        ):
            command = shlex.split(args.test_command) if args.test_command else None
            console.print("Checking baseline and candidate in temporary workspaces...")
            backup = agent.apply(proposal, test_command=command, test_timeout=args.test_timeout)
            console.print(
                Text(
                    redact(
                        f"Updated {path}. Backup: {backup}. Baseline and candidate tests passed. Re-run index to refresh search."
                    )
                )
            )


def shell(pipeline: Pipeline, search: HybridSearch, agent: RefactorAgent, args) -> None:
    summary = asyncio.run(pipeline.update())
    console.print(Text(json.dumps(asdict(summary), indent=2)))
    console.print(
        Panel(
            "Type a natural-language query. Commands: :index, :audit, :refactor PATH [MODEL], :help, :quit",
            title="Local Codebase Auditor",
            border_style="cyan",
        )
    )
    while True:
        try:
            query = console.input("[bold cyan]auditor> [/]").strip()
            if query in {":quit", ":exit"}:
                return
            if not query:
                continue
            if query == ":help":
                console.print(
                    "Query any text. :index rescans. :audit shows persisted health (use :index to refresh). :refactor PATH [MODEL] previews and prompts; quotes support paths with spaces. :quit exits."
                )
            elif query == ":index":
                console.print(Text(json.dumps(asdict(asyncio.run(pipeline.update())), indent=2)))
            elif query == ":audit":
                show_health(pipeline.store.health(), pipeline.store.errors())
            elif query.startswith(":refactor"):
                tokens = shlex.split(query)
                if len(tokens) not in (2, 3):
                    raise AuditorError("Usage: :refactor PATH [LOCAL_OLLAMA_MODEL]")
                refactor(
                    agent,
                    tokens[1],
                    args,
                    model=tokens[2] if len(tokens) == 3 else None,
                    apply=True,
                )
            elif query.startswith(":"):
                console.print("Unknown command. Type :help.")
            else:
                show_hits(search.query(query))
        except (AuditorError, OSError, sqlite3.Error, ValueError) as exc:
            console.print(Text(redact(str(exc)), style="red"))
            if args.verbose:
                logging.exception("Interactive command failed")
        except (EOFError, KeyboardInterrupt):
            console.print("\nSession ended.")
            return


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.WARNING)
    store = None
    try:
        extensions = DEFAULT_EXTENSIONS
        if args.extensions:
            extensions = frozenset(
                ext.strip().lower() for ext in args.extensions.split(",") if ext.strip()
            )
            if not extensions or any(not ext.startswith(".") for ext in extensions):
                raise AuditorError("Extensions must be a nonempty list beginning with dots")
        scanner = Scanner(
            args.root,
            extensions,
            args.workers,
            args.max_bytes,
            args.max_files,
            args.max_total_bytes,
        )
        if min(args.max_chunks, args.max_index_bytes) < 1:
            raise AuditorError("Index size/count limits must be positive")
        if args.command == "audit":
            from .audit import Auditor

            scan = asyncio.run(scanner.scan())
            reports = [Auditor().audit(source).to_dict() for source in scan.files]
            if args.json:
                print(json.dumps({"files": reports, "errors": scan.errors}, indent=2))
            else:
                show_health(reports, scan.errors)
            levels = {"warning": 1, "high": 2, "error": 3}
            threshold = levels.get(args.fail_on, 4)
            failed = any(
                levels.get(f["severity"], 0) >= threshold for r in reports for f in r["findings"]
            )
            return 2 if scan.errors or failed else 0
        agent = RefactorAgent(
            scanner.root,
            verification_max_files=args.max_files,
            verification_max_bytes=args.max_total_bytes * 2,
        )
        if args.command == "refactor":
            refactor(agent, args.path, args, args.refactor_model, args.apply)
            return 0
        db = args.db or scanner.root / ".code-auditor" / "index.sqlite3"
        if args.command == "search" and args.semantic_weight == 0:
            embedder = KeywordOnlyEmbedder(read_identity(db, scanner.root))
        elif args.backend == "hash":
            embedder = HashEmbedder()
            print(
                "Hash mode: offline lexical baseline, not learned semantic search.", file=sys.stderr
            )
        elif args.backend == "transformers":
            embedder = SentenceTransformerEmbedder(args.model)
        else:
            embedder = OllamaEmbedder(args.model, args.ollama_url, args.timeout)
        if args.command == "doctor":
            print(json.dumps(diagnose(scanner.root, embedder), indent=2))
            return 0
        store = Store(
            db,
            scanner.root,
            embedder.signature,
            max_chunks=args.max_chunks,
            max_index_bytes=args.max_index_bytes,
        )
        pipeline = Pipeline(scanner, store, embedder)
        search = HybridSearch(store, embedder)
        if args.command == "index":
            summary = asyncio.run(pipeline.update())
            print(json.dumps(asdict(summary), indent=2))
            return 2 if summary.errors else 0
        if args.command == "search":
            hits = search.query(args.query, args.limit, args.semantic_weight)
            if args.json:
                # The local index stores exact source; exported JSON uses masking.
                documents = []
                for hit in hits:
                    document = asdict(hit)
                    for field in ("content", "docstring"):
                        value = document["chunk"][field]
                        if value is not None:
                            document["chunk"][field] = redact(value)
                    document["chunk"]["imports"] = [
                        redact(value) for value in document["chunk"]["imports"]
                    ]
                    documents.append(document)
                print(json.dumps(documents, indent=2))
            else:
                show_hits(hits)
            return 0
        shell(pipeline, search, agent, args)
        return 0
    except (AuditorError, OSError, sqlite3.Error, ValueError, RuntimeError) as exc:
        console.print(Text(redact(str(exc)), style="red"))
        if args.verbose:
            logging.exception("Command failed")
        return 1
    except KeyboardInterrupt:
        return 130
    finally:
        if store is not None:
            store.close()
