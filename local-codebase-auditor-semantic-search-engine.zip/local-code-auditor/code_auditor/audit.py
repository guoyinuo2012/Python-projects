"""Heuristic static health checks. Scanned code is never imported or run."""

import ast
import io
import re
import tokenize

from .models import FileHealth, Finding, SourceFile

SECRET_NAME = re.compile(
    r"(?:api_?key|secret|password|passwd|access_?token|auth_?token|private_?key)", re.I
)
SECRET_VALUE = re.compile(
    r"(?:AKIA[0-9A-Z]{16}|sk-[a-zA-Z0-9_-]{20,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)"
)
SECRET_ASSIGNMENT = re.compile(
    r"""(?i)(?:api[_-]?key|secret|password|passwd|access[_-]?token|auth[_-]?token|private[_-]?key)["']?\s*[=:]\s*["']([^"'\n]{8,})["']"""
)


def redact(text: str) -> str:
    """Best-effort masking for terminal output; the local index retains source."""
    text = re.sub(
        r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----.*?-----END (?:RSA |EC |OPENSSH )?PRIVATE KEY-----",
        "[REDACTED PRIVATE KEY]",
        text,
        flags=re.DOTALL,
    )
    text = SECRET_VALUE.sub("[REDACTED]", text)
    text = SECRET_ASSIGNMENT.sub(
        lambda match: match.group(0).replace(match.group(1), "[REDACTED]"), text
    )
    text = text.replace("\r\n", "\n")
    return re.sub(
        r"[\x00-\x08\x0b-\x1f\x7f\u202a-\u202e\u2066-\u2069]",
        lambda match: (
            f"\\x{ord(match.group()):02x}"
            if ord(match.group()) < 128
            else f"\\u{ord(match.group()):04x}"
        ),
        text,
    )


def complexity(function: ast.AST) -> int:
    """McCabe-style count with boolean operands, comprehensions and match cases.

    Nested scopes are counted independently. Each if/loop/except/conditional
    expression contributes one; each boolean operator contributes n-1.
    Pattern alternatives contribute n-1; a wildcard match default contributes
    zero. This is a documented static approximation, not a control-flow proof.
    """
    total = 1

    stack = [(function, True)]
    while stack:
        node, root = stack.pop()
        if not root and isinstance(
            node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)
        ):
            continue
        if isinstance(
            node, (ast.If, ast.For, ast.AsyncFor, ast.While, ast.ExceptHandler, ast.IfExp)
        ):
            total += 1
        elif isinstance(node, ast.BoolOp):
            total += len(node.values) - 1
        elif isinstance(node, ast.comprehension):
            total += 1 + len(node.ifs)
        elif isinstance(node, ast.Match):
            total += sum(
                not (isinstance(case.pattern, ast.MatchAs) and case.pattern.pattern is None)
                for case in node.cases
            )
            total += sum(case.guard is not None for case in node.cases)
        elif isinstance(node, ast.MatchOr):
            total += len(node.patterns) - 1
        stack.extend((child, False) for child in ast.iter_child_nodes(node))
    return total


class Auditor:
    def __init__(self, complexity_threshold: int = 10):
        self.threshold = complexity_threshold

    def audit(self, source: SourceFile) -> FileHealth:
        health = FileHealth(source.path)
        lines = source.content.splitlines()
        blank = {i for i, line in enumerate(lines, 1) if not line.strip()}
        comment_lines: set[int] = set()

        def finding(line: int, rule: str, severity: str, message: str) -> None:
            health.findings.append(Finding(source.path, line, rule, severity, message))

        tree = None
        if source.path.lower().endswith(".py"):
            try:
                tree = ast.parse(source.content, filename=source.path)
            except (SyntaxError, ValueError, RecursionError) as exc:
                finding(
                    getattr(exc, "lineno", None) or 1,
                    "syntax-error",
                    "error",
                    "Malformed Python syntax; structural analysis unavailable",
                )
            try:
                for token in tokenize.generate_tokens(io.StringIO(source.content).readline):
                    if token.type == tokenize.COMMENT:
                        comment_lines.add(token.start[0])
            except (tokenize.TokenError, IndentationError, SyntaxError):
                # Preserve partial token counts and syntax finding for malformed input.
                comment_lines.update(
                    i for i, line in enumerate(lines, 1) if line.lstrip().startswith("#")
                )
        else:
            comment_lines = {
                i
                for i, line in enumerate(lines, 1)
                if line.lstrip().startswith(("#", "//", "/*", "*", "--", "<!--"))
            }
        # Inline comments count as documentation AND code. Standalone comments
        # and Python docstrings are excluded from the code count.
        standalone = {
            i
            for i in comment_lines
            if lines[i - 1].lstrip().startswith(("#", "//", "/*", "*", "--", "<!--"))
        }
        doc_lines: set[int] = set()
        if tree is not None:
            aliases: dict[str, str] = {}
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for item in node.names:
                        aliases[item.asname or item.name.split(".")[0]] = (
                            item.name if item.asname else item.name.split(".")[0]
                        )
                elif isinstance(node, ast.ImportFrom):
                    for item in node.names:
                        aliases[item.asname or item.name] = f"{node.module or ''}.{item.name}"
                if isinstance(
                    node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)
                ):
                    if (
                        node.body
                        and isinstance(node.body[0], ast.Expr)
                        and isinstance(node.body[0].value, ast.Constant)
                        and isinstance(node.body[0].value.value, str)
                    ):
                        doc = node.body[0]
                        doc_lines.update(range(doc.lineno, (doc.end_lineno or doc.lineno) + 1))

            def call_name(node: ast.AST) -> str:
                if isinstance(node, ast.Name):
                    return aliases.get(node.id, node.id)
                if isinstance(node, ast.Attribute):
                    return f"{call_name(node.value)}.{node.attr}"
                return ""

            # Resolve simple local aliases of dangerous imported/builtin calls.
            for _ in range(4):
                for assignment in ast.walk(tree):
                    if isinstance(assignment, ast.Assign) and isinstance(
                        assignment.value, (ast.Name, ast.Attribute)
                    ):
                        resolved = call_name(assignment.value)
                        for target in assignment.targets:
                            if isinstance(target, ast.Name) and resolved:
                                aliases[target.id] = resolved
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    positional = [*node.args.posonlyargs, *node.args.args]
                    defaults = (
                        list(
                            zip(
                                positional[-len(node.args.defaults) :],
                                node.args.defaults,
                                strict=True,
                            )
                        )
                        if node.args.defaults
                        else []
                    )
                    defaults.extend(zip(node.args.kwonlyargs, node.args.kw_defaults, strict=True))
                    for argument, value in defaults:
                        if (
                            SECRET_NAME.search(argument.arg)
                            and isinstance(value, ast.Constant)
                            and isinstance(value.value, str)
                            and len(value.value) >= 8
                        ):
                            finding(
                                value.lineno,
                                "hardcoded-secret",
                                "high",
                                "Potential credential in a function default",
                            )
                    value = complexity(node)
                    health.complexity[f"{node.name}@{node.lineno}"] = value
                    if value > self.threshold:
                        finding(
                            node.lineno,
                            "complexity",
                            "warning",
                            f"Cyclomatic complexity {value} exceeds {self.threshold}",
                        )
                if isinstance(node, (ast.Assign, ast.AnnAssign)):
                    value = node.value
                    targets = node.targets if isinstance(node, ast.Assign) else [node.target]
                    if (
                        isinstance(value, ast.Constant)
                        and isinstance(value.value, str)
                        and len(value.value) >= 8
                    ):
                        if any(SECRET_NAME.search(ast.unparse(target)) for target in targets):
                            finding(
                                node.lineno,
                                "hardcoded-secret",
                                "high",
                                "Potential hardcoded credential; move to environment or local secret store",
                            )
                if isinstance(node, ast.Dict):
                    for key, value in zip(node.keys, node.values, strict=True):
                        if (
                            isinstance(key, ast.Constant)
                            and isinstance(key.value, str)
                            and SECRET_NAME.search(key.value)
                            and isinstance(value, ast.Constant)
                            and isinstance(value.value, str)
                            and len(value.value) >= 8
                        ):
                            finding(
                                value.lineno,
                                "hardcoded-secret",
                                "high",
                                "Potential hardcoded credential in mapping",
                            )
                if not isinstance(node, ast.Call):
                    continue
                for keyword in node.keywords:
                    if (
                        keyword.arg
                        and SECRET_NAME.search(keyword.arg)
                        and isinstance(keyword.value, ast.Constant)
                        and isinstance(keyword.value.value, str)
                        and len(keyword.value.value) >= 8
                    ):
                        finding(
                            keyword.value.lineno,
                            "hardcoded-secret",
                            "high",
                            "Potential credential passed as a literal argument",
                        )
                name = call_name(node.func)
                if name in {"eval", "builtins.eval", "exec", "builtins.exec"}:
                    finding(
                        node.lineno,
                        "dynamic-execution",
                        "high",
                        f"{name} can execute arbitrary code; review input trust",
                    )
                elif name in {
                    "pickle.load",
                    "pickle.loads",
                    "dill.load",
                    "dill.loads",
                    "marshal.loads",
                }:
                    finding(
                        node.lineno,
                        "unsafe-deserialization",
                        "high",
                        "Deserialization may execute attacker-controlled code",
                    )
                elif name == "yaml.load":
                    safe = any(
                        kw.arg == "Loader"
                        and call_name(kw.value) in {"yaml.SafeLoader", "yaml.CSafeLoader"}
                        for kw in node.keywords
                    )
                    if not safe:
                        finding(
                            node.lineno,
                            "unsafe-yaml",
                            "high",
                            "Use yaml.safe_load or an explicit SafeLoader",
                        )
                elif name in {"os.system", "os.popen"} or (
                    name.startswith("subprocess.")
                    and any(
                        kw.arg == "shell"
                        and isinstance(kw.value, ast.Constant)
                        and kw.value.value is True
                        for kw in node.keywords
                    )
                ):
                    finding(
                        node.lineno,
                        "shell-execution",
                        "high",
                        "Shell invocation requires careful input validation",
                    )
        for i, line in enumerate(lines, 1):
            if SECRET_VALUE.search(line) or (tree is None and SECRET_ASSIGNMENT.search(line)):
                if not any(f.line == i and f.rule == "hardcoded-secret" for f in health.findings):
                    finding(
                        i,
                        "hardcoded-secret",
                        "high",
                        "Potential embedded credential or private key",
                    )
        health.blank_lines = len(blank)
        health.comment_lines = len(comment_lines | doc_lines)
        health.code_lines = len(set(range(1, len(lines) + 1)) - blank - standalone - doc_lines)
        health.findings.sort(key=lambda item: (item.line, item.rule))
        return health
