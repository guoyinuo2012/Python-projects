"""BM25 and semantic retrieval merged using reciprocal rank fusion."""

import math
from collections import Counter

from .embeddings import Embedder, terms
from .models import AuditorError, SearchHit
from .storage import Store, faiss_index


class HybridSearch:
    def __init__(self, store: Store, embedder: Embedder):
        self.store = store
        self.embedder = embedder
        self.key = None
        self.chunks = []
        self.index = None
        self.documents = []
        self.df: Counter = Counter()
        self.average_length = 1.0
        self.lengths = []

    def refresh(self) -> None:
        if self.key == self.store.cache_key():
            return
        self.chunks, vectors, self.key = self.store.snapshot()
        self.index = faiss_index(vectors) if len(vectors) else None
        self.documents = [Counter(terms(chunk.searchable())) for chunk in self.chunks]
        self.df = Counter(token for document in self.documents for token in document)
        self.lengths = [sum(document.values()) for document in self.documents]
        self.average_length = sum(self.lengths) / max(1, len(self.documents)) or 1.0

    def query(self, query: str, limit: int = 5, semantic_weight: float = 0.5) -> list[SearchHit]:
        if limit < 1 or not 0 <= semantic_weight <= 1:
            raise AuditorError("limit must be positive; semantic weight must be in [0,1]")
        if not query.strip():
            return []
        self.refresh()
        if not self.chunks:
            return []
        n = len(self.chunks)
        candidates = min(n, max(50, limit * 5))
        lexical = []
        query_terms = set(terms(query))
        documents = enumerate(self.documents) if semantic_weight < 1 else ()
        for i, document in documents:
            score = 0.0
            length = self.lengths[i]
            for token in query_terms:
                frequency = document[token]
                if not frequency:
                    continue
                idf = math.log(1 + (n - self.df[token] + 0.5) / (self.df[token] + 0.5))
                denominator = frequency + 1.5 * (1 - 0.75 + 0.75 * length / self.average_length)
                score += idf * frequency * 2.5 / denominator
            if score > 0:
                lexical.append((i, score))
        lexical.sort(key=lambda pair: (-pair[1], self.chunks[pair[0]].id))
        lexical = lexical[:candidates]
        semantic = []
        if semantic_weight:
            vector = self.embedder.encode([query], query=True)
            if vector.shape[1] != self.index.d:
                raise AuditorError("Query embedding dimension does not match the index")
            distances, indices = self.index.search(vector, candidates)
            semantic = [
                (int(i), float(score))
                for i, score in zip(indices[0], distances[0], strict=True)
                if i >= 0 and score > 0
            ]
        fused: dict[int, float] = {}
        for weight, ranking in ((1 - semantic_weight, lexical), (semantic_weight, semantic)):
            if not weight:
                continue
            for rank, (i, _) in enumerate(ranking, 1):
                fused[i] = fused.get(i, 0) + weight / (60 + rank)
        keyword_scores = dict(lexical)
        semantic_scores = dict(semantic)
        ranking = sorted(fused, key=lambda i: (-fused[i], self.chunks[i].id))[:limit]
        return [
            SearchHit(self.chunks[i], fused[i], keyword_scores.get(i, 0), semantic_scores.get(i, 0))
            for i in ranking
        ]
