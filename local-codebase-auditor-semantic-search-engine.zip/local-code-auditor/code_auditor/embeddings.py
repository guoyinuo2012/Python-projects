"""Local embedding adapters with explicit identities and strict validation."""

import hashlib
import ipaddress
import json
import math
import re
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Protocol

import numpy as np

from .models import AuditorError


def terms(text: str) -> list[str]:
    """Split identifiers, including snake_case and camelCase, for lexical recall."""
    text = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", text)
    return re.findall(r"[a-z0-9]+", text.lower())


def normalize(values: object, count: int) -> np.ndarray:
    try:
        matrix = np.asarray(values, dtype=np.float32)
    except (ValueError, TypeError, OverflowError) as exc:
        raise AuditorError("Embedding response is not a numeric matrix") from exc
    if matrix.ndim != 2 or matrix.shape[0] != count or matrix.shape[1] < 1:
        raise AuditorError("Embedding response has invalid dimensions")
    if not np.isfinite(matrix).all():
        raise AuditorError("Embedding response contains non-finite values")
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    if not np.isfinite(norms).all():
        raise AuditorError("Embedding norms overflow")
    return np.ascontiguousarray(matrix / np.where(norms == 0, 1, norms), dtype=np.float32)


class Embedder(Protocol):
    @property
    def signature(self) -> str: ...

    def encode(self, texts: list[str], *, query: bool = False) -> np.ndarray: ...


class KeywordOnlyEmbedder:
    """Identity adapter for explicit BM25-only queries; no model is contacted."""

    def __init__(self, identity: str):
        self.signature = identity

    def encode(self, texts: list[str], *, query: bool = False) -> np.ndarray:
        raise AuditorError("BM25-only mode cannot generate semantic embeddings")


class HashEmbedder:
    """Deterministic offline test baseline, NOT a learned semantic model."""

    def __init__(self, dimensions: int = 512):
        if dimensions < 1:
            raise AuditorError("Embedding dimensions must be positive")
        self.dimensions = dimensions

    @property
    def signature(self) -> str:
        return f"hash-v1:{self.dimensions}"

    def encode(self, texts: list[str], *, query: bool = False) -> np.ndarray:
        matrix = np.zeros((len(texts), self.dimensions), dtype=np.float32)
        for row, text in enumerate(texts):
            for token in terms(text):
                digest = hashlib.blake2b(token.encode(), digest_size=8).digest()
                index = int.from_bytes(digest, "little") % self.dimensions
                matrix[row, index] += 1 if digest[0] & 1 else -1
        return normalize(matrix, len(texts))


class LocalHTTP:
    """Loopback-only HTTP, without proxies or redirects, bounded responses."""

    def __init__(self, base_url: str, timeout: float = 120):
        parsed = urllib.parse.urlsplit(base_url)
        try:
            local = (
                parsed.hostname == "localhost"
                or ipaddress.ip_address(parsed.hostname or "").is_loopback
            )
        except ValueError:
            local = False
        if (
            parsed.scheme != "http"
            or not local
            or parsed.username
            or parsed.password
            or parsed.query
            or parsed.fragment
            or parsed.path not in ("", "/")
        ):
            raise AuditorError("Ollama URL must be http://localhost:PORT or a loopback IP")
        if not math.isfinite(timeout) or timeout <= 0:
            raise AuditorError("HTTP timeout must be finite and positive")
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())

    def post(self, endpoint: str, data: dict) -> dict:
        request = urllib.request.Request(
            self.base_url + endpoint,
            data=json.dumps(data).encode(),
            headers={"Content-Type": "application/json"},
        )
        try:
            with self.opener.open(request, timeout=self.timeout) as response:
                raw = response.read(32_000_001)
            if len(raw) > 32_000_000:
                raise AuditorError("Ollama response exceeds 32 MB")
            result = json.loads(raw)
            if not isinstance(result, dict) or result.get("error"):
                raise AuditorError("Ollama returned an error or invalid object")
            return result
        except (OSError, urllib.error.URLError, ValueError) as exc:
            raise AuditorError(f"Local Ollama request failed: {exc}") from exc


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise AuditorError("Ollama redirects are disabled")


class OllamaEmbedder:
    def __init__(self, model: str, base_url: str = "http://127.0.0.1:11434", timeout: float = 120):
        self.model = model
        self.http = LocalHTTP(base_url, timeout)
        self.digest = self._model_digest()

    def _model_digest(self) -> str:
        # Model digest prevents mixing vectors after a tag is repointed.
        request = urllib.request.Request(self.http.base_url + "/api/tags")
        try:
            with self.http.opener.open(request, timeout=self.http.timeout) as response:
                raw = response.read(2_000_001)
            if len(raw) > 2_000_000:
                raise AuditorError("Ollama model listing exceeds 2 MB")
            tags = json.loads(raw)
            if not isinstance(tags, dict) or not isinstance(tags.get("models"), list):
                raise AuditorError("Invalid Ollama model listing")
            if any(not isinstance(item, dict) for item in tags["models"]):
                raise AuditorError("Invalid Ollama model entry")
            matches = [
                item
                for item in tags["models"]
                if item.get("name") in {self.model, self.model + ":latest"}
                or item.get("model") == self.model
            ]
            if (
                not matches
                or not isinstance(matches[0].get("digest"), str)
                or not matches[0]["digest"]
            ):
                raise AuditorError(
                    f"Local model {self.model!r} is not installed; run ollama pull first"
                )
            return matches[0]["digest"]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            raise AuditorError(f"Cannot inspect local Ollama model: {exc}") from exc

    @property
    def signature(self) -> str:
        return f"ollama:{self.model}:{self.digest}"

    def encode(self, texts: list[str], *, query: bool = False) -> np.ndarray:
        if self._model_digest() != self.digest:
            raise AuditorError(
                "Ollama model changed during this session; use a new index/model identity"
            )
        result = self.http.post(
            "/api/embed", {"model": self.model, "input": texts, "truncate": False}
        )
        if self._model_digest() != self.digest:
            raise AuditorError("Ollama model changed during inference; vectors discarded")
        return normalize(result.get("embeddings"), len(texts))


class SentenceTransformerEmbedder:
    def __init__(self, model_path: str):
        path = Path(model_path).expanduser().resolve()
        if not path.is_dir():
            raise AuditorError("Sentence Transformers requires an existing local model directory")
        try:
            from sentence_transformers import SentenceTransformer

            # No downloads, no remote code execution, CPU for predictable portability.
            self.model = SentenceTransformer(
                str(path), device="cpu", local_files_only=True, trust_remote_code=False
            )
            digest = hashlib.sha256()
            for file in sorted(p for p in path.rglob("*") if p.is_file()):
                digest.update(file.relative_to(path).as_posix().encode())
                with file.open("rb") as stream:
                    for block in iter(lambda: stream.read(1024 * 1024), b""):
                        digest.update(block)
            self.identity = digest.hexdigest()
        except ImportError as exc:
            raise AuditorError(
                "Install the transformers extra: pip install '.[transformers]'"
            ) from exc
        except (OSError, ValueError, RuntimeError, TypeError, AttributeError) as exc:
            raise AuditorError(f"Cannot load local model: {exc}") from exc

    @property
    def signature(self) -> str:
        return f"sentence-transformers:{self.identity}"

    def encode(self, texts: list[str], *, query: bool = False) -> np.ndarray:
        try:
            for text in texts:
                length = len(self.model.tokenizer.encode(text, add_special_tokens=True))
                if length > self.model.max_seq_length:
                    raise AuditorError(
                        f"Logical chunk has {length} tokens; model limit is {self.model.max_seq_length}. Choose a longer-context model; chunks are never silently truncated."
                    )
            values = self.model.encode(
                texts, normalize_embeddings=True, show_progress_bar=False, convert_to_numpy=True
            )
            return normalize(values, len(texts))
        except (ValueError, RuntimeError, TypeError, AttributeError) as exc:
            raise AuditorError(f"Local embedding inference failed: {exc}") from exc
