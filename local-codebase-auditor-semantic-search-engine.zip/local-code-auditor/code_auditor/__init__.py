"""Local code analysis; importing this package never executes scanned code."""

__version__ = "1.1.1"
