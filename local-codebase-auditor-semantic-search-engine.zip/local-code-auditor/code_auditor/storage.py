"""Transactional SQLite metadata/vector persistence and a rebuildable FAISS view."""

import json
import os
import sqlite3
from contextlib import contextmanager
from dataclasses import asdict, fields
from pathlib import Path

import faiss
import numpy as np

from .filesystem import relative_parts
from .models import AuditorError, Chunk

SCHEMA_VERSION = "1"


class Store:
    """One database per workspace and embedding identity.

    Embeddings are persisted as float32 blobs in SQLite. FAISS is an in-memory
    exact inner-product index rebuilt from a transactionally consistent
    snapshot; there is no separate index file that can drift out of sync.
    A generation counter and SQLite data_version invalidate search caches.
    """

    def __init__(
        self,
        path: Path,
        root: Path,
        signature: str,
        *,
        max_chunks: int = 10_000,
        max_index_bytes: int = 64_000_000,
    ):
        if min(max_chunks, max_index_bytes) < 1:
            raise AuditorError("Index limits must be positive")
        if path.expanduser().is_symlink():
            raise AuditorError("Symlink index files are disabled")
        if (
            root.resolve() / ".code-auditor"
        ).is_symlink() and path.expanduser().absolute().parent == root.resolve() / ".code-auditor":
            raise AuditorError("Symlink default state directories are disabled")
        self.path = path.expanduser().resolve()
        self.max_chunks = max_chunks
        self.max_index_bytes = max_index_bytes
        self.connection = None
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            # SQLite derives WAL permissions from the database at creation.
            # Precreate new files privately before opening a connection.
            try:
                descriptor = os.open(
                    self.path,
                    os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
                    0o600,
                )
            except FileExistsError:
                pass
            else:
                os.close(descriptor)
            self.connection = sqlite3.connect(self.path, timeout=30)
            self.connection.row_factory = sqlite3.Row
            tables = {
                row[0]
                for row in self.connection.execute(
                    "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
                )
            }
            if tables and tables != {"metadata", "files", "chunks"}:
                raise AuditorError(
                    "Database is not a complete code-auditor index; use another --db"
                )
            if tables:
                expected = {
                    "schema": SCHEMA_VERSION,
                    "root": str(root.resolve()),
                    "embedder": signature,
                }
                current = dict(self.connection.execute("SELECT key,value FROM metadata"))
                for key, value in expected.items():
                    if current.get(key) != value:
                        raise AuditorError(f"Index {key} mismatch. Use another --db.")
            self.path.chmod(0o600)
            self.connection.execute("PRAGMA foreign_keys=ON")
            self.connection.execute("PRAGMA journal_mode=WAL")
            self.connection.execute("PRAGMA synchronous=FULL")
            self.connection.executescript("""
                CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS files (
                    path TEXT PRIMARY KEY, digest TEXT NOT NULL, health TEXT NOT NULL,
                    error TEXT, encoding TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS chunks (
                    id TEXT PRIMARY KEY, path TEXT NOT NULL REFERENCES files(path) ON DELETE CASCADE,
                    payload TEXT NOT NULL, vector BLOB NOT NULL, dimension INTEGER NOT NULL CHECK(dimension>0));
                CREATE INDEX IF NOT EXISTS chunks_path ON chunks(path);
            """)
            with self.connection:
                expected = {
                    "schema": SCHEMA_VERSION,
                    "root": str(root.resolve()),
                    "embedder": signature,
                }
                for key, value in expected.items():
                    row = self.connection.execute(
                        "SELECT value FROM metadata WHERE key=?", (key,)
                    ).fetchone()
                    if row is not None and row[0] != value:
                        raise AuditorError(
                            f"Index {key} mismatch. Use a separate --db or remove the old index explicitly."
                        )
                    self.connection.execute(
                        "INSERT OR IGNORE INTO metadata VALUES (?,?)", (key, value)
                    )
                self.connection.execute("INSERT OR IGNORE INTO metadata VALUES ('generation','0')")
            self.path.chmod(0o600)
            for suffix in ("-wal", "-shm"):
                sidecar = Path(str(self.path) + suffix)
                if sidecar.exists() and not sidecar.is_symlink():
                    sidecar.chmod(0o600)
            self.check_budget()
            self.integrity_check()
        except (OSError, sqlite3.Error, AuditorError) as exc:
            if self.connection is not None:
                self.connection.close()
            if isinstance(exc, AuditorError):
                raise
            raise AuditorError(f"Cannot open index: {exc}") from exc

    def close(self) -> None:
        self.connection.close()

    def integrity_check(self) -> None:
        rows = self.connection.execute("PRAGMA quick_check").fetchall()
        if len(rows) != 1 or rows[0][0] != "ok":
            raise AuditorError(
                "SQLite integrity check failed; preserve the file and rebuild in a new --db"
            )
        if self.connection.execute("PRAGMA foreign_key_check").fetchone() is not None:
            raise AuditorError("Index contains orphaned chunks; rebuild in a new --db")
        self.cache_key()
        self.snapshot()
        self.health()

    def check_budget(self) -> None:
        row = self.connection.execute(
            "SELECT COUNT(*), COALESCE(SUM(length(CAST(payload AS BLOB))+length(vector)),0) FROM chunks"
        ).fetchone()
        if row[0] > self.max_chunks or row[1] > self.max_index_bytes:
            raise AuditorError(
                "Index budget exceeded; increase --max-chunks/--max-index-bytes or use a smaller workspace"
            )

    def versions(self) -> dict[str, str]:
        return {
            row["path"]: row["digest"]
            for row in self.connection.execute("SELECT path,digest FROM files")
        }

    @contextmanager
    def transaction(self):
        try:
            self.connection.execute("BEGIN IMMEDIATE")
            yield
            self.connection.execute(
                "UPDATE metadata SET value=CAST(value AS INTEGER)+1 WHERE key='generation'"
            )
            self.connection.commit()
        except BaseException:
            self.connection.rollback()
            raise

    def put_file(
        self,
        path: str,
        digest: str,
        health: dict,
        error: str | None,
        encoding: str,
        chunks: list[Chunk],
        vectors: np.ndarray | None,
    ) -> None:
        """Called only within a transaction; atomic at the workspace level."""
        if not self.connection.in_transaction:
            raise AuditorError("put_file requires a transaction")
        if chunks and (vectors is None or vectors.ndim != 2 or vectors.shape[0] != len(chunks)):
            raise AuditorError("Chunk/vector count mismatch")
        relative_parts(path)
        if chunks and (vectors.shape[1] < 1 or not np.isfinite(vectors).all()):
            raise AuditorError("Invalid or non-finite embedding matrix")
        if chunks:
            norms = np.linalg.norm(vectors, axis=1)
            if not np.all(np.isclose(norms, 1, atol=1e-4) | (norms == 0)):
                raise AuditorError("Stored embeddings must be normalized")
            if any(chunk.path != path for chunk in chunks):
                raise AuditorError("Chunk path does not match its source file")
        self.connection.execute("DELETE FROM files WHERE path=?", (path,))
        self.connection.execute(
            "INSERT INTO files VALUES (?,?,?,?,?)",
            (path, digest, json.dumps(health), error, encoding),
        )
        if chunks:
            dimension = vectors.shape[1]
            row = self.connection.execute(
                "SELECT value FROM metadata WHERE key='dimension'"
            ).fetchone()
            if row and int(row[0]) != dimension:
                raise AuditorError("Embedding dimension changed; use a new index")
            self.connection.execute(
                "INSERT OR IGNORE INTO metadata VALUES ('dimension',?)", (str(dimension),)
            )
            self.connection.executemany(
                "INSERT INTO chunks VALUES (?,?,?,?,?)",
                [
                    (
                        chunk.id,
                        path,
                        json.dumps(asdict(chunk)),
                        np.ascontiguousarray(vector, dtype=np.float32).tobytes(),
                        dimension,
                    )
                    for chunk, vector in zip(chunks, vectors, strict=True)
                ],
            )

    def delete_file(self, path: str) -> None:
        if not self.connection.in_transaction:
            raise AuditorError("delete_file requires a transaction")
        self.connection.execute("DELETE FROM files WHERE path=?", (path,))

    def cache_key(self) -> tuple[int, int]:
        row = self.connection.execute(
            "SELECT value FROM metadata WHERE key='generation'"
        ).fetchone()
        try:
            if row is None or not str(row[0]).isdigit():
                raise ValueError("Missing or invalid generation counter")
            return int(row[0]), int(self.connection.execute("PRAGMA data_version").fetchone()[0])
        except (ValueError, TypeError, IndexError) as exc:
            raise AuditorError("Corrupt index generation metadata; rebuild in a new --db") from exc

    def snapshot(self) -> tuple[list[Chunk], np.ndarray, tuple[int, int]]:
        with self.connection:
            self.connection.execute("BEGIN")
            key = self.cache_key()
            self.check_budget()
            rows = self.connection.execute(
                "SELECT id,path,payload,vector,dimension FROM chunks ORDER BY id"
            ).fetchall()
        if not rows:
            return [], np.empty((0, 0), dtype=np.float32), key
        chunks = []
        vectors = []
        for row in rows:
            try:
                payload = json.loads(row["payload"])
                if not isinstance(payload, dict) or set(payload) != {
                    field.name for field in fields(Chunk)
                }:
                    raise ValueError("Invalid chunk fields")
                if payload["id"] != row["id"] or payload["path"] != row["path"]:
                    raise ValueError("Chunk identity mismatch")
                relative_parts(payload["path"])
                if any(
                    not isinstance(payload[key], str)
                    for key in ("id", "path", "name", "kind", "content")
                ):
                    raise ValueError("Invalid chunk text")
                if (
                    any(type(payload[key]) is not int for key in ("start_line", "end_line"))
                    or not 1 <= payload["start_line"] <= payload["end_line"]
                ):
                    raise ValueError("Invalid chunk line range")
                if any(
                    payload[key] is not None and not isinstance(payload[key], str)
                    for key in ("parent", "docstring")
                ):
                    raise ValueError("Invalid structural metadata")
                if not isinstance(payload["imports"], list) or any(
                    not isinstance(value, str) for value in payload["imports"]
                ):
                    raise ValueError("Invalid import metadata")
                payload["imports"] = tuple(payload["imports"])
                vector = np.frombuffer(row["vector"], dtype=np.float32)
                norm = float(np.linalg.norm(vector))
                if (
                    vector.size != row["dimension"]
                    or not np.isfinite(vector).all()
                    or not (norm == 0 or np.isclose(norm, 1, atol=1e-4))
                ):
                    raise ValueError("Invalid vector payload")
                chunks.append(Chunk(**payload))
                vectors.append(vector)
            except (ValueError, TypeError, KeyError, AuditorError) as exc:
                raise AuditorError(
                    "Corrupt chunk/vector in local index; preserve it and rebuild using a new --db"
                ) from exc
        try:
            return chunks, np.ascontiguousarray(np.stack(vectors)), key
        except ValueError as exc:
            raise AuditorError("Inconsistent vector dimensions in index") from exc

    def health(self) -> list[dict]:
        reports = []
        for row in self.connection.execute("SELECT path,health FROM files ORDER BY path"):
            try:
                report = json.loads(row["health"])
                if not isinstance(report, dict) or report.get("path") != row["path"]:
                    raise ValueError("Invalid report identity")
                for field in ("code_lines", "comment_lines", "blank_lines"):
                    if type(report[field]) is not int or report[field] < 0:
                        raise ValueError("Invalid metric")
                if not isinstance(report["complexity"], dict) or any(
                    type(value) is not int or value < 1 for value in report["complexity"].values()
                ):
                    raise ValueError("Invalid complexity metadata")
                if not isinstance(report["findings"], list):
                    raise ValueError("Invalid findings")
                for finding in report["findings"]:
                    if (
                        not isinstance(finding, dict)
                        or finding.get("path") != row["path"]
                        or type(finding.get("line")) is not int
                        or finding["line"] < 1
                    ):
                        raise ValueError("Invalid finding location")
                    if any(
                        not isinstance(finding.get(key), str)
                        for key in ("rule", "severity", "message")
                    ):
                        raise ValueError("Invalid finding text")
                ratio = report["code_to_comment_ratio"]
                if ratio is not None and (
                    type(ratio) not in (int, float) or not np.isfinite(ratio) or ratio < 0
                ):
                    raise ValueError("Invalid documentation ratio")
                reports.append(report)
            except (ValueError, TypeError, KeyError) as exc:
                raise AuditorError("Corrupt health metadata; rebuild in a new --db") from exc
        return reports

    def errors(self) -> dict[str, str]:
        return {
            row[0]: row[1]
            for row in self.connection.execute(
                "SELECT path,error FROM files WHERE error IS NOT NULL"
            )
        }

    def stats(self) -> dict[str, int]:
        return {
            table: self.connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
            for table in ("files", "chunks")
        }


def read_identity(path: Path, root: Path) -> str:
    """Read existing metadata without loading or contacting an embedding model."""
    if not path.is_file() or path.is_symlink():
        raise AuditorError("Index not found; run index first")
    connection = None
    try:
        connection = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True)
        values = dict(connection.execute("SELECT key,value FROM metadata"))
        if values.get("schema") != SCHEMA_VERSION or values.get("root") != str(root.resolve()):
            raise AuditorError("Index root/schema mismatch")
        identity = values.get("embedder")
        if not isinstance(identity, str) or not identity:
            raise AuditorError("Corrupt embedding identity")
        return identity
    except sqlite3.Error as exc:
        raise AuditorError(f"Cannot inspect index identity: {exc}") from exc
    finally:
        if connection is not None:
            connection.close()


def faiss_index(vectors: np.ndarray):
    if vectors.ndim != 2 or not len(vectors):
        raise AuditorError("Cannot build FAISS index from empty vectors")
    index = faiss.IndexFlatIP(vectors.shape[1])
    index.add(np.ascontiguousarray(vectors, dtype=np.float32))
    return index
