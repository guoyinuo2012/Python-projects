"""Python chunks preserve complete definitions, decorators and metadata."""

import ast
import hashlib

from .models import Chunk, SourceFile


class Chunker:
    """Definitions are indivisible; nested definitions get their own chunks.

    Class chunks include full bodies, so class and method hits can overlap.
    Module-level gaps retain imports and executable statements. Non-Python
    files use blank-line paragraph boundaries; no parser claims are made for
    JavaScript or other languages.
    """

    def chunk(self, source: SourceFile) -> tuple[list[Chunk], str | None]:
        lines = source.content.splitlines(keepends=True)
        if not source.content.strip():
            return [], None
        chunks: list[Chunk] = []

        def add(
            start: int,
            end: int,
            name: str,
            kind: str,
            parent: str | None = None,
            docstring: str | None = None,
            imports: tuple[str, ...] = (),
        ) -> None:
            content = "".join(lines[start - 1 : end])
            if not content.strip():
                return
            identity = f"{source.path}:{start}:{end}:{kind}:{name}:{source.digest}"
            chunks.append(
                Chunk(
                    hashlib.sha256(identity.encode()).hexdigest(),
                    source.path,
                    name,
                    kind,
                    start,
                    end,
                    content,
                    parent,
                    docstring,
                    imports,
                )
            )

        if source.path.lower().endswith(".py"):
            try:
                tree = ast.parse(source.content, filename=source.path)
            except (SyntaxError, ValueError, RecursionError) as exc:
                add(1, len(lines), "unparsed module", "syntax-error")
                return chunks, str(exc)
            imports = tuple(
                ast.unparse(node)
                for node in ast.walk(tree)
                if isinstance(node, (ast.Import, ast.ImportFrom))
            )
            definitions = (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)

            stack = [(tree, ())]
            while stack:
                node, parents = stack.pop()
                if isinstance(node, definitions):
                    start = min([node.lineno] + [d.lineno for d in node.decorator_list])
                    qualified = ".".join((*parents, node.name))
                    kind = "class" if isinstance(node, ast.ClassDef) else "function"
                    add(
                        start,
                        node.end_lineno or node.lineno,
                        qualified,
                        kind,
                        ".".join(parents) or None,
                        ast.get_docstring(node),
                        imports,
                    )
                    parents = (*parents, node.name)
                stack.extend(
                    (child, parents) for child in reversed(list(ast.iter_child_nodes(node)))
                )

            occupied = set()
            for chunk in chunks:
                occupied.update(range(chunk.start_line, chunk.end_line + 1))
            start = None
            for line in range(1, len(lines) + 2):
                uncovered = line <= len(lines) and line not in occupied
                if uncovered and start is None:
                    start = line
                elif not uncovered and start is not None:
                    add(
                        start,
                        line - 1,
                        "module",
                        "module",
                        docstring=ast.get_docstring(tree),
                        imports=imports,
                    )
                    start = None
            return sorted(chunks, key=lambda chunk: (chunk.start_line, chunk.end_line)), None
        start = 1
        for number, line in enumerate(lines, 1):
            if not line.strip():
                add(start, number, f"section {start}", "text")
                start = number + 1
        add(start, len(lines), f"section {start}", "text")
        return chunks, None
