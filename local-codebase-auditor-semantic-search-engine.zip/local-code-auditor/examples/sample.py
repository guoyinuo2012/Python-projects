"""Small deliberately imperfect fixture for the auditor demonstration."""

import json


def load_config(text: str) -> dict:
    """Parse a JSON configuration without executing code."""
    return json.loads(text)


class Inventory:
    """Track product quantities in memory."""

    def __init__(self):
        self.stock = {}

    def reserve(self, product: str, quantity: int) -> bool:
        """Reserve available stock; reject nonpositive quantities."""
        if quantity <= 0 or self.stock.get(product, 0) < quantity:
            return False
        self.stock[product] -= quantity
        return True


def parse_literal():
    """Deliberately unsafe syntax that deterministic refactoring can fix."""
    return eval("{'count': 3}")
