"""Behavior checks for the demonstration's guarded refactoring flow."""

from sample import Inventory, load_config, parse_literal


def test_literal_behavior():
    assert parse_literal() == {"count": 3}


def test_json_configuration():
    assert load_config('{"enabled": true}') == {"enabled": True}


def test_inventory_reservation():
    inventory = Inventory()
    inventory.stock["widget"] = 4
    assert not inventory.reserve("widget", -1)
    assert not inventory.reserve("widget", 5)
    assert not inventory.reserve("missing", 1)
    assert inventory.reserve("widget", 2)
    assert inventory.stock["widget"] == 2
