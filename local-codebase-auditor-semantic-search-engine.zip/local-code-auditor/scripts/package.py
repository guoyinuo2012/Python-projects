"""Build a lean archive and compare every entry with its source bytes."""

import zipfile
from pathlib import Path

EXCLUDED = {
    ".code-auditor",
    "__pycache__",
    ".pytest_cache",
    ".ruff_cache",
    ".git",
    "build",
    "dist",
    ".venv",
}


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    files = sorted(
        path
        for path in root.rglob("*")
        if path.is_file()
        and not path.is_symlink()
        and not any(
            part in EXCLUDED or part.endswith(".egg-info") for part in path.relative_to(root).parts
        )
        and path.suffix not in {".pyc", ".log", ".sqlite3"}
        and path.name not in {"FULL_SOURCE.md", "MANIFEST.json", "test-results.xml"}
    )
    archive = root.parent / "local-code-auditor.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as output:
        for path in files:
            output.write(path, "local-code-auditor/" + path.relative_to(root).as_posix())
    with zipfile.ZipFile(archive) as output:
        if output.testzip() is not None:
            raise RuntimeError("Archive integrity check failed")
        for path in files:
            name = "local-code-auditor/" + path.relative_to(root).as_posix()
            if output.read(name) != path.read_bytes():
                raise RuntimeError(f"Archive content mismatch: {name}")
    print(f"Validated archive: {len(files)} files, {archive.stat().st_size} bytes")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
