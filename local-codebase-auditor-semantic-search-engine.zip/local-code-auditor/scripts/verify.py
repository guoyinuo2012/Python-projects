"""Run lint, formatting, compilation and automated tests."""

import subprocess
import sys
from pathlib import Path


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    commands = [
        [sys.executable, "-m", "ruff", "check", "."],
        [sys.executable, "-m", "ruff", "format", "--check", "."],
        [sys.executable, "-m", "compileall", "-q", "code_auditor"],
        [sys.executable, "-m", "pytest", "-q"],
    ]
    for command in commands:
        print("Running: " + " ".join(command), flush=True)
        try:
            result = subprocess.run(command, cwd=root, check=False)
        except OSError as exc:
            print(f"Cannot start check: {exc}", file=sys.stderr)
            return 1
        if result.returncode:
            return result.returncode
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
