# Local Codebase Auditor & Semantic Search Engine

Self-hosted Python terminal tool for code scanning, Python AST chunking, health
checks, and hybrid BM25/vector search. Rich provides the UI, SQLite stores chunks
and metadata, and FAISS searches vectors. Scanning never executes source code.

## Install

Requires Python 3.11 or newer. From this extracted directory:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e .
```

Windows PowerShell: activate with `.venv\Scripts\Activate.ps1`.
For tests/development, install `python -m pip install -e '.[dev]'`.
For verified Linux package pins, install `requirements.lock`, then install the
project with `python -m pip install -e . --no-deps`.
Dependencies/models may need internet for installation; runtime resources are local.

## Quick start without a model

```bash
python -m code_auditor --root examples --backend hash index
python -m code_auditor --root examples --backend hash search "reserve product stock"
python -m code_auditor --root examples audit
python -m code_auditor --root examples --backend hash doctor
python -m code_auditor --root examples --backend hash --test-command "python -m pytest -q" shell
```

The hash backend is a lexical baseline, **not learned semantic search**.
The demo contains a literal `eval` call and three behavior tests.

## Local semantic search

Install Ollama locally. Start `ollama serve`, then in another terminal:

```bash
ollama pull nomic-embed-text
python -m code_auditor --root /path/to/repository doctor
python -m code_auditor --root /path/to/repository index
python -m code_auditor --root /path/to/repository search "where are requests validated?"
python -m code_auditor --root /path/to/repository shell
```

Defaults: Ollama, `nomic-embed-text`, `http://127.0.0.1:11434`.
Override with global `--model MODEL` and `--ollama-url URL`. Only loopback HTTP
is accepted; proxies/redirects are disabled. Models are never pulled automatically.
Model identity changes require a new index. Oversized chunks fail without truncation.

Alternatively use a cached Sentence Transformers directory:

```bash
python -m pip install -e '.[transformers]'
python -m code_auditor --root /path/to/repository --backend transformers --model /path/to/local/model index
```

This adapter uses CPU, local files only, and disables remote model code.

## Commands

Global options go **before** the command. Use `--help` for all options.

| Command | Purpose |
| --- | --- |
| `index` | Incrementally update changed, removed and ignored files |
| `audit` | Fresh health scan without an embedding model |
| `audit --json --fail-on high` | JSON findings with a CI threshold |
| `search "query"` | Search the persisted snapshot |
| `search "query" --semantic-weight 0` | BM25 only; no model contact |
| `search "query" --semantic-weight 1` | Vector search only |
| `search "query" --json` | JSON results |
| `shell` | Index and start the interactive query loop |
| `doctor` | Check model operation, persistence and retrieval |
| `refactor file.py` | Preview a deterministic fix |
| `refactor file.py --apply` | Review, test, back up and apply |

Shell controls: `:index`, `:audit`, `:refactor file.py`,
`:refactor file.py LOCAL_GENERATION_MODEL`, `:help`, `:quit`.
Quote paths containing spaces. Shell audit uses persisted findings; run `:index`
after edits. Standalone audit always scans afresh.

Default database: `ROOT/.code-auditor/index.sqlite3`; override with `--db PATH`.
Each root/embedding identity needs its own database. Reindex after source/ignore edits.
Exit codes: 0 success, 1 operational failure, 2 incomplete scan/audit threshold or
argument error, 130 interrupted noninteractive work.

## Guarded refactoring

Edits require an explicit trusted test command and interactive approval:

```bash
python -m code_auditor --root /path/to/repository --test-command "python -m pytest -q" refactor file.py --apply
```

The built-in fix handles unshadowed single-argument `eval` calls with literal-only
constant strings. Dynamic expressions are refused. Broader proposals require
`--refactor-model MODEL` and an installed local Ollama generation model.

Syntax, preserved interfaces and high-severity finding regressions are checked.
Baseline and candidate tests must pass in separate temporary copies before editing.
Timeouts, excessive output, stale source and candidate mutations block the edit.
Workspace locks, byte checks, backups and atomic replacement protect writes.
Backups live in `ROOT/.code-auditor/backups/`; review and copy one over the original
to restore it, then rerun tests and indexing.

**Temporary copies are not a security sandbox.** Tests/candidates execute with your
privileges and environment. Use trusted code/tests; isolate untrusted repositories
in an OS/container sandbox. Tests must exercise the staged checkout, not absolute
paths or an externally installed copy. Passing tests cannot prove all behavior.
Avoid concurrent external edits; locks only coordinate this tool. Confirm a crashed
process stopped before removing its stale lock. Atomic replacement preserves mode
bits, but not ownership, ACLs or extended attributes.

## Scope and limits

- Python AST chunks retain complete definitions, decorators, docstrings, imports,
  parent names and lines. Class/method chunks deliberately overlap.
- Malformed Python remains searchable as text with a syntax finding. Empty files
  have no chunks. Encoding, binary, permissions and size errors are handled.
  Deep expression traversal is iterative; ignore-file reads also obey file limits.
- Nested `.gitignore` files are respected; symlinks/generated directories are skipped.
  Git global excludes and `.git/info/exclude` are outside scanner scope.
- Other languages use paragraph chunks and heuristic comments, without Python AST
  structures or complexity metrics.
- Health metrics approximate McCabe complexity and code/comment ratios. Heuristics
  flag likely secrets, `eval`/`exec`, unsafe deserialization and shell calls.
  False positives and missed issues remain possible.
- Failed embedding updates preserve the old index; corrupt/incompatible databases
  are rejected without destructive repair.
- FAISS holds all vectors in memory; BM25 scores all chunks. Defaults cap scans at
  10,000 selected files/32 MB source and indexes at 10,000 chunks/64 MB serialized
  data. These bound workload, not exact RAM. Refactor staging defaults to
  10,000 files/64 MB. Adjust global CLI budgets for larger trusted workloads.
- Indexes/backups contain original source, potentially including secrets. Masking
  is best effort. Protect files with OS access controls. Private POSIX permissions
  are used where supported. No telemetry is implemented.

## Tests and files

```bash
python scripts/verify.py
python -m pytest -q examples
python scripts/package.py
```

`code_auditor/` holds the runtime modules; `tests/` holds regression tests;
`examples/` holds a demo; `scripts/` holds verification and lean packaging;
`.github/workflows/ci.yml` provides CI. No duplicate source dumps or old reports
are included.

The regression suite was exercised on Python 3.12/Linux. Adapter tests use a
loopback HTTP fixture and a controlled model loader. Pretrained model inference
and other platforms still require validation on your machine. `doctor` checks
operation, not semantic quality or complete safety.
