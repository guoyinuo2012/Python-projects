"""Safety regression tests for staging, budgets, corruption and diagnostics."""

import asyncio
import json
import os
import sys
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pytest

from code_auditor.audit import Auditor
from code_auditor.cli import main
from code_auditor.diagnostics import diagnose
from code_auditor.embeddings import HashEmbedder, OllamaEmbedder
from code_auditor.filesystem import read_bytes
from code_auditor.ingestion import Scanner
from code_auditor.models import AuditorError, SourceFile
from code_auditor.refactor import RefactorAgent, validate_change
from code_auditor.search import HybridSearch
from code_auditor.storage import Store, read_identity
from code_auditor.verification import run_check, verify_proposal


def command(code):
    return [sys.executable, "-c", code]


def test_apply_requires_project_tests_and_leaves_source(workspace, write):
    path = write("file.py", 'x = eval("1")\n')
    agent = RefactorAgent(workspace)
    proposal = agent.propose("file.py")
    with pytest.raises(AuditorError, match="test-command"):
        agent.apply(proposal)
    assert path.read_bytes() == proposal.original
    assert not (workspace / ".code-auditor/refactor.lock").exists()
    assert not list(workspace.glob(".code-auditor/backups/*"))


def test_baseline_failure_prevents_apply(workspace, write):
    path = write("file.py", 'x = eval("1")\n')
    agent = RefactorAgent(workspace)
    proposal = agent.propose("file.py")
    with pytest.raises(AuditorError, match="Baseline verification failed"):
        agent.apply(proposal, test_command=command("raise AssertionError('broken baseline')"))
    assert path.read_bytes() == proposal.original
    assert not list(workspace.glob(".code-auditor/backups/*"))


def test_candidate_behavior_failure_prevents_apply(workspace, write):
    path = write("file.py", "x = 1\n")
    original = path.read_bytes()
    with pytest.raises(AuditorError, match="Candidate verification failed"):
        verify_proposal(
            workspace, "file.py", original, b"x = 2\n", command("import file; assert file.x == 1")
        )
    assert path.read_bytes() == original


def test_successful_tests_do_not_write_working_files(workspace, write):
    path = write("file.py", 'x = eval("1")\n')
    agent = RefactorAgent(workspace)
    proposal = agent.propose("file.py")
    result = verify_proposal(
        workspace,
        "file.py",
        proposal.original,
        proposal.replacement,
        command("import file; assert file.x == 1; open('generated.txt','w').write('stage only')"),
    )
    assert result.command
    assert not (workspace / "generated.txt").exists()
    assert path.read_bytes() == proposal.original


def test_staged_target_mutation_prevents_apply(workspace, write):
    path = write("file.py", "x = 1\n")
    with pytest.raises(AuditorError, match="modified the staged target"):
        verify_proposal(
            workspace,
            "file.py",
            path.read_bytes(),
            b"x = 2\n",
            command("open('file.py','w').write('x = 3\\n')"),
        )
    assert path.read_text() == "x = 1\n"


def test_timeout_output_budget_and_missing_executable(workspace):
    with pytest.raises(AuditorError, match="timed out"):
        run_check(command("import time; time.sleep(5)"), workspace, 0.1)
    with pytest.raises(AuditorError, match="output budget"):
        run_check(command("print('x' * 10000)"), workspace, 2, max_output=100)
    with pytest.raises(AuditorError, match="Cannot run"):
        run_check(["nonexistent-code-auditor-command"], workspace, 2)


def test_existing_refactor_lock_blocks_second_writer(workspace, write):
    write("file.py", 'x = eval("1")\n')
    agent = RefactorAgent(workspace)
    proposal = agent.propose("file.py")
    write(".code-auditor/refactor.lock", "another process")
    with pytest.raises(AuditorError, match="workspace lock"):
        agent.apply(proposal, test_command=command("import file; assert file.x == 1"))
    assert (workspace / ".code-auditor/refactor.lock").read_text() == "another process"


def test_source_changed_during_tests_is_not_overwritten(workspace, write):
    path = write("file.py", 'x = eval("1")\n')
    agent = RefactorAgent(workspace)
    proposal = agent.propose("file.py")
    original_verify = verify_proposal

    def editing_verify(*args, **kwargs):
        result = original_verify(*args, **kwargs)
        path.write_text("x = 99\n")
        return result

    with patch("code_auditor.refactor.verify_proposal", side_effect=editing_verify):
        with pytest.raises(AuditorError, match="changed during verification"):
            agent.apply(proposal, test_command=command("import file; assert file.x == 1"))
    assert path.read_text() == "x = 99\n"


def test_interface_and_security_regressions_are_rejected():
    for replacement in (
        "x=1\n",
        "def fn(other): return other\n",
        "async def fn(value): return value\n",
    ):
        with pytest.raises(AuditorError, match="interface"):
            validate_change("def fn(value): return value\n", replacement, "file.py")
    with pytest.raises(AuditorError, match="high-severity"):
        validate_change("x = 1\n", "x = eval(user_input)\n", "file.py")


def test_forged_proposal_cannot_bypass_static_change_checks(workspace, write):
    write("file.py", 'def fn(): return eval("1")\n')
    agent = RefactorAgent(workspace)
    proposal = agent.propose("file.py")
    with pytest.raises(AuditorError, match="interface"):
        agent.apply(replace(proposal, replacement=b"x = 1\n"), test_command=command("pass"))


def test_source_and_count_budgets_abort_scan(workspace, write):
    write("a.py", "x = 1\n")
    write("b.py", "x = 2\n")
    with pytest.raises(AuditorError, match="File count budget"):
        asyncio.run(Scanner(workspace, max_files=1).scan())
    with pytest.raises(AuditorError, match="content budget"):
        asyncio.run(Scanner(workspace, max_total_bytes=5).scan())


def test_chunk_budget_rolls_back(engine, write):
    pipeline, store, _ = engine
    write("file.py", "def a(): return 1\n")
    asyncio.run(pipeline.update())
    old = store.versions()
    store.max_chunks = 1
    write("file.py", "def a(): return 2\ndef b(): return 3\n")
    with pytest.raises(AuditorError, match="index budget"):
        asyncio.run(pipeline.update())
    assert store.versions() == old


def test_unchanged_plus_new_chunks_budget_rolls_back(engine, write):
    pipeline, store, _ = engine
    write("a.py", "def a(): return 1\n")
    asyncio.run(pipeline.update())
    store.max_chunks = 1
    old = store.versions()
    write("b.py", "def b(): return 2\n")
    with pytest.raises(AuditorError, match="Index budget"):
        asyncio.run(pipeline.update())
    assert store.versions() == old


def test_source_changed_during_embedding_aborts_update(engine, write):
    pipeline, store, embedder = engine
    path = write("file.py", "def first(): return 1\n")
    real_encode = embedder.encode

    def changing_encode(texts, **kwargs):
        vectors = real_encode(texts, **kwargs)
        path.write_text("def second(): return 2\n")
        return vectors

    with patch.object(embedder, "encode", side_effect=changing_encode):
        with pytest.raises(AuditorError, match="changed during indexing"):
            asyncio.run(pipeline.update())
    assert store.stats()["files"] == 0


@pytest.mark.parametrize(
    "corruption", ["invalid-json", "missing-field", "invalid-line", "invalid-import", "bad-vector"]
)
def test_corrupt_chunk_metadata_has_controlled_error(engine, write, corruption):
    pipeline, store, embedder = engine
    write("file.py", "def fn(): return 1\n")
    asyncio.run(pipeline.update())
    row = store.connection.execute("SELECT id,payload FROM chunks").fetchone()
    payload = json.loads(row["payload"])
    if corruption == "invalid-json":
        encoded = "{not-json"
    elif corruption == "missing-field":
        del payload["imports"]
        encoded = json.dumps(payload)
    elif corruption == "invalid-line":
        payload["start_line"] = -1
        encoded = json.dumps(payload)
    elif corruption == "invalid-import":
        payload["imports"] = [42]
        encoded = json.dumps(payload)
    else:
        encoded = json.dumps(payload)
    with store.connection:
        store.connection.execute("UPDATE chunks SET payload=? WHERE id=?", (encoded, row["id"]))
        if corruption == "bad-vector":
            store.connection.execute("UPDATE chunks SET vector=?", (b"bad",))
    with pytest.raises(AuditorError, match="Corrupt chunk/vector"):
        HybridSearch(store, embedder).query("fn")


def test_corrupt_health_and_generation_report_controlled_errors(engine, write):
    pipeline, store, _ = engine
    write("file.py", "pass\n")
    asyncio.run(pipeline.update())
    with store.connection:
        store.connection.execute("UPDATE files SET health='{}'")
    with pytest.raises(AuditorError, match="Corrupt health"):
        store.health()
    with store.connection:
        store.connection.execute("UPDATE metadata SET value='oops' WHERE key='generation'")
    with pytest.raises(AuditorError, match="generation metadata"):
        store.cache_key()


def test_unknown_database_not_modified(workspace, tmp_path):
    import sqlite3

    database = tmp_path / "unrelated.sqlite3"
    with sqlite3.connect(database) as connection:
        connection.execute("CREATE TABLE unrelated (value TEXT)")
    with pytest.raises(AuditorError, match="not a complete"):
        Store(database, workspace, "hash-v1:512")
    with sqlite3.connect(database) as connection:
        assert connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall() == [("unrelated",)]


def test_directory_symlink_replacement_never_reads_external_source(workspace, tmp_path, write):
    write("inside/file.py", "safe = 1\n")
    outside = tmp_path / "outside"
    outside.mkdir()
    (outside / "file.py").write_text("external = 1\n")
    (workspace / "inside/file.py").unlink()
    (workspace / "inside").rmdir()
    (workspace / "inside").symlink_to(outside, target_is_directory=True)
    with pytest.raises((AuditorError, OSError)):
        read_bytes(workspace, "inside/file.py", 100)


def test_uppercase_python_encoding_and_structure(workspace, write):
    write("FILE.PY", b'# coding: latin-1\ndef caf\xe9(): return eval("1")\n')
    scan = asyncio.run(Scanner(workspace).scan())
    assert not scan.errors
    assert "café" in scan.files[0].content
    assert b"literal_eval" in RefactorAgent(workspace).propose("FILE.PY").replacement


def test_security_aliases_and_credential_defaults_and_arguments():
    text = "danger = eval\nnext_call = danger\nnext_call(user_input)\ndef fn(api_key='fakepass99'): pass\nclient(password='fakepass99')\n"
    report = Auditor().audit(SourceFile("file.py", text, "fixture"))
    assert sum(f.rule == "dynamic-execution" for f in report.findings) == 1
    assert sum(f.rule == "hardcoded-secret" for f in report.findings) == 2


def test_doctor_real_faiss_sqlite_round_trip(workspace):
    report = diagnose(workspace, HashEmbedder(128))
    assert report["status"] == "passed" and report["dimensions"] == 128
    assert report["sqlite_round_trip"] and report["faiss"] and report["bm25"]


def test_ollama_model_change_before_or_after_inference_is_rejected(local_server):
    embedder = OllamaEmbedder("test", local_server)
    with patch.object(embedder, "_model_digest", return_value="new-digest"):
        with pytest.raises(AuditorError, match="changed during this session"):
            embedder.encode(["input"])
    with patch.object(embedder, "_model_digest", side_effect=[embedder.digest, "new-digest"]):
        with pytest.raises(AuditorError, match="changed during inference"):
            embedder.encode(["input"])


def test_bm25_cli_does_not_contact_model(engine, workspace, write, capsys):
    pipeline, store, _ = engine
    write("file.py", "def reserve_stock(): return 1\n")
    asyncio.run(pipeline.update())
    assert read_identity(store.path, workspace).startswith("hash-v1")
    with patch("code_auditor.cli.OllamaEmbedder", side_effect=AssertionError("Contacted model")):
        assert (
            main(
                [
                    "--root",
                    str(workspace),
                    "--db",
                    str(store.path),
                    "search",
                    "reserve",
                    "--semantic-weight",
                    "0",
                    "--json",
                ]
            )
            == 0
        )
    assert "reserve_stock" in capsys.readouterr().out


def test_budget_failure_preserves_preexisting_index(engine, write):
    pipeline, store, _ = engine
    write("file.py", "def fn(): return 1\n")
    asyncio.run(pipeline.update())
    before = store.versions()
    pipeline.scanner.max_total_bytes = 1
    with pytest.raises(AuditorError, match="content budget"):
        asyncio.run(pipeline.update())
    assert store.versions() == before


def test_zero_embedding_model_fails_doctor(workspace):
    embedder = HashEmbedder(128)
    with patch.object(embedder, "encode", return_value=np.zeros((2, 128), dtype=np.float32)):
        with pytest.raises(AuditorError, match="zero vectors"):
            diagnose(workspace, embedder)


def test_symlink_state_and_backup_paths_refused(workspace, tmp_path, write):
    write("file.py", 'x = eval("1")\n')
    external = tmp_path / "external-state"
    external.mkdir()
    agent = RefactorAgent(workspace)
    proposal = agent.propose("file.py")
    (workspace / ".code-auditor").symlink_to(external, target_is_directory=True)
    with pytest.raises(AuditorError, match="Symlink state"):
        agent.apply(proposal, test_command=command("import file; assert file.x == 1"))
    assert not list(external.iterdir())


def test_durability_error_reports_that_write_already_happened(workspace, write):
    path = write("file.py", 'x = eval("1")\n')
    agent = RefactorAgent(workspace)
    proposal = agent.propose("file.py")
    fsync = os.fsync
    count = 0

    def failing_fsync(descriptor):
        nonlocal count
        count += 1
        if count == 4:
            raise OSError("simulated directory sync failure")
        return fsync(descriptor)

    with patch("code_auditor.refactor.os.fsync", side_effect=failing_fsync):
        with pytest.raises(AuditorError, match="Replacement was written"):
            agent.apply(proposal, test_command=command("import file; assert file.x == 1"))
    assert path.read_bytes() == proposal.replacement
    backups = list(workspace.glob(".code-auditor/backups/*"))
    assert len(backups) == 1 and backups[0].read_bytes() == proposal.original


@pytest.mark.skipif(os.name != "posix", reason="POSIX FIFO safety")
def test_fifo_read_fails_without_blocking(workspace):
    os.mkfifo(workspace / "pipe.py")
    with pytest.raises(AuditorError, match="not a regular"):
        read_bytes(workspace, "pipe.py", 100)


def test_terminal_control_sequences_are_neutralized():
    from code_auditor.audit import redact

    source = "safe\x1b]52;c;payload\x07\rhidden\u202e.txt\r\nline"
    output = redact(source)
    assert "\x1b" not in output and "\x07" not in output and "\u202e" not in output
    assert "\\x1b" in output and "\\u202e" in output
    assert output.endswith("\nline")


@pytest.mark.skipif(os.name != "posix", reason="POSIX file permissions")
def test_database_and_sidecars_are_private(engine, write):
    pipeline, store, _ = engine
    write("file.py", "pass\n")
    asyncio.run(pipeline.update())
    for path in [store.path, Path(str(store.path) + "-wal"), Path(str(store.path) + "-shm")]:
        if path.exists():
            assert path.stat().st_mode & 0o077 == 0


def test_default_index_state_symlink_does_not_write_external_directory(workspace, tmp_path):
    external = tmp_path / "external"
    external.mkdir()
    (workspace / ".code-auditor").symlink_to(external, target_is_directory=True)
    with pytest.raises(AuditorError, match="state directories"):
        Store(workspace / ".code-auditor/index.sqlite3", workspace, "hash-v1:512")
    assert not list(external.iterdir())


def test_staging_api_rejects_path_traversal(workspace, tmp_path):
    outside = tmp_path / "outside.py"
    outside.write_text("x = 1\n")
    for relative in ("../outside.py", str(outside)):
        with pytest.raises(AuditorError, match="relative path"):
            verify_proposal(workspace, relative, b"x = 1\n", b"x = 2\n", command("pass"))
    assert outside.read_text() == "x = 1\n"


def test_health_report_filename_controls_are_escaped():
    import io

    from rich.console import Console

    from code_auditor.cli import show_health

    output = io.StringIO()
    path = "hostile\x1b]52;c;payload\x07.py"
    report = Auditor().audit(SourceFile(path, "eval(user_input)\n", "fixture")).to_dict()
    with patch("code_auditor.cli.console", Console(file=output, force_terminal=False)):
        show_health([report], {})
    assert "\x1b" not in output.getvalue() and "\x07" not in output.getvalue()
    assert "\\x1b" in output.getvalue()


def test_reopening_corrupt_index_fails_before_successful_use(engine, workspace, write):
    pipeline, store, embedder = engine
    write("file.py", "def fn(): return 1\n")
    asyncio.run(pipeline.update())
    with store.connection:
        store.connection.execute("UPDATE chunks SET payload='{broken-json'")
    with pytest.raises(AuditorError, match="Corrupt chunk/vector"):
        Store(store.path, workspace, embedder.signature)
    assert store.connection.execute("SELECT payload FROM chunks").fetchone()[0] == "{broken-json"


@pytest.mark.parametrize("relative", ["", ".", "./", "bad\x00.py"])
def test_invalid_regular_file_paths_fail_cleanly(workspace, relative):
    with pytest.raises(AuditorError, match="relative path"):
        read_bytes(workspace, relative, 100)


@pytest.mark.parametrize("timeout", [float("nan"), float("inf"), -float("inf"), 0, -1])
def test_http_timeout_rejects_nonfinite_and_nonpositive_values(timeout):
    from code_auditor.embeddings import LocalHTTP

    with pytest.raises(AuditorError, match="finite and positive"):
        LocalHTTP("http://127.0.0.1:11434", timeout)


def test_oversized_ignore_file_aborts_without_changing_index(engine, write):
    write("file.py", "x = 1\n")
    asyncio.run(engine[0].update())
    versions = engine[1].versions()
    write(".gitignore", "#" * (engine[0].scanner.max_bytes + 1))
    with pytest.raises(AuditorError, match="exceeds"):
        asyncio.run(engine[0].update())
    assert engine[1].versions() == versions


def test_utf8_bom_ignore_rules_are_respected(workspace, write):
    write(".gitignore", "\ufeffignored.py\n")
    write("ignored.py", "x = 1\n")
    write("included.py", "x = 2\n")
    assert [p.name for p in Scanner(workspace).discover()] == ["included.py"]


@pytest.mark.parametrize(
    "original,replacement",
    [
        ("class Example(metaclass=type):\n    pass\n", "class Example:\n    pass\n"),
        (
            "def outer():\n    def inner(x):\n        return x\n    return inner\n",
            "def outer():\n    def inner(x, y):\n        return x\n    return inner\n",
        ),
        (
            "def outer():\n    def inner(x):\n        return x\n    return inner\n",
            "def outer():\n    return None\n",
        ),
    ],
)
def test_refactor_preserves_class_options_and_nested_interfaces(original, replacement):
    with pytest.raises(AuditorError, match="interface"):
        validate_change(original, replacement, "file.py")


def test_deep_valid_expression_indexes_without_recursive_walker_crash(engine, write):
    write("deep.py", "def calculate():\n    return " + "-" * 1800 + "1\n")
    result = asyncio.run(engine[0].update())
    assert not result.errors
    assert result.chunks == 1
    assert engine[1].health()[0]["complexity"] == {"calculate@1": 1}
    assert HybridSearch(engine[1], engine[2]).query("calculate", semantic_weight=0)
