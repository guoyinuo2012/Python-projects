"""Transactional updates, persistent vectors, search and cache invalidation."""

import asyncio
from unittest.mock import patch

import numpy as np
import pytest

from code_auditor.embeddings import HashEmbedder
from code_auditor.models import AuditorError
from code_auditor.search import HybridSearch
from code_auditor.storage import Store


def update(engine):
    return asyncio.run(engine[0].update())


def test_incremental_change_delete_empty_and_recovery(engine, write):
    first = write("inventory.py", "def reserve_stock(product):\n    return product\n")
    write("billing.py", "def charge_customer(total):\n    return total\n")
    summary = update(engine)
    assert summary.changed == 2 and summary.chunks == 2
    with patch.object(engine[2], "encode", side_effect=AssertionError("Unchanged file embedded")):
        assert update(engine).unchanged == 2
    first.write_text("def reserve_stock(product):\n    return product.upper()\n")
    assert update(engine).changed == 1
    first.unlink()
    assert update(engine).deleted == 1
    write("empty.py", "")
    assert update(engine).changed == 1
    assert engine[1].stats() == {"files": 2, "chunks": 1}


def test_malformed_file_is_audited_and_searchable(engine, write):
    write("broken.py", "def special_broken(:\n")
    summary = update(engine)
    assert "broken.py" in summary.errors
    assert engine[1].health()[0]["findings"][0]["rule"] == "syntax-error"
    hits = HybridSearch(engine[1], engine[2]).query("special broken")
    assert hits[0].chunk.kind == "syntax-error"
    assert "broken.py" in update(engine).errors


def test_embedding_failure_rolls_back_entire_update(engine, write):
    path = write("original.py", "def old():\n    return 1\n")
    update(engine)
    versions = engine[1].versions()
    path.write_text("def new():\n    return 2\n")
    write("another.py", "def more():\n    return 3\n")
    with patch.object(engine[2], "encode", side_effect=AuditorError("inference failed")):
        with pytest.raises(AuditorError, match="inference failed"):
            update(engine)
    assert engine[1].versions() == versions
    assert engine[1].stats() == {"files": 1, "chunks": 1}


def test_read_failure_invalidates_stale_chunks_and_recovers(engine, write):
    write("file.py", "def visible():\n    return 1\n")
    update(engine)
    with patch.object(engine[0].scanner, "read", side_effect=PermissionError("denied")):
        summary = update(engine)
    assert summary.errors == {"file.py": "denied"}
    assert engine[1].stats()["chunks"] == 0
    assert update(engine).changed == 1
    assert engine[1].stats()["chunks"] == 1


def test_keyword_semantic_and_hybrid_ranking(engine, write):
    write("inventory.py", "def reserve_stock(product, quantity):\n    return quantity\n")
    write("billing.py", "def invoice_customer(amount):\n    return amount\n")
    update(engine)
    search = HybridSearch(engine[1], engine[2])
    for weight in (0, 0.5, 1):
        hits = search.query("reserve stock quantity", semantic_weight=weight)
        assert hits and hits[0].chunk.path == "inventory.py"
    assert search.query(" ") == []
    assert search.query("zzzxxyyqqq", semantic_weight=0) == []
    with pytest.raises(AuditorError):
        search.query("x", limit=0)
    with pytest.raises(AuditorError):
        search.query("x", semantic_weight=1.5)


def test_persistence_and_cross_connection_cache_refresh(engine, workspace, write):
    path = write("file.py", "def first_version():\n    return 1\n")
    update(engine)
    observer = Store(engine[1].path, workspace, engine[2].signature)
    try:
        search = HybridSearch(observer, engine[2])
        assert search.query("first version", semantic_weight=0)
        path.write_text("def second_version():\n    return 2\n")
        update(engine)
        assert search.query("second version", semantic_weight=0)[0].chunk.name == "second_version"
        assert not search.query("first", semantic_weight=0)
    finally:
        observer.close()


def test_index_root_model_identity_guard(engine, workspace, tmp_path):
    with pytest.raises(AuditorError, match="embedder mismatch"):
        Store(engine[1].path, workspace, HashEmbedder(64).signature)
    with pytest.raises(AuditorError, match="root mismatch"):
        Store(engine[1].path, tmp_path, engine[2].signature)


def test_dimension_change_rolls_back(engine, write):
    path = write("file.py", "def old(): return 1\n")
    update(engine)
    versions = engine[1].versions()
    path.write_text("def new(): return 2\n")
    with patch.object(engine[2], "encode", return_value=np.ones((1, 64), dtype=np.float32) / 8):
        with pytest.raises(AuditorError, match="dimension changed"):
            update(engine)
    assert engine[1].versions() == versions


def test_empty_workspace_is_valid(engine):
    assert update(engine).chunks == 0
    assert HybridSearch(engine[1], engine[2]).query("anything") == []


def test_discovery_failure_keeps_existing_index(engine, write):
    write("file.py", "pass")
    update(engine)
    before = engine[1].versions()
    with patch.object(
        engine[0].scanner, "discover", side_effect=AuditorError("directory unreadable")
    ):
        with pytest.raises(AuditorError):
            update(engine)
    assert engine[1].versions() == before


def test_query_tokenization_happens_once_per_search(engine, write):
    from code_auditor.embeddings import terms

    for number in range(4):
        write(f"file{number}.py", f"def stock_{number}(): return {number}\n")
    update(engine)
    search = HybridSearch(engine[1], engine[2])
    search.refresh()
    with patch("code_auditor.search.terms", wraps=terms) as tokenize_query:
        assert search.query("stock", semantic_weight=0)
        tokenize_query.assert_called_once_with("stock")


def test_vector_only_search_skips_bm25_document_scoring(engine, write):
    write("file.py", "def reserve_stock(): return 1\n")
    update(engine)
    search = HybridSearch(engine[1], engine[2])
    search.refresh()

    class NoLexicalIteration(list):
        def __iter__(self):
            raise AssertionError("Vector-only search scanned BM25 documents")

    search.documents = NoLexicalIteration(search.documents)
    assert search.query("reserve stock", semantic_weight=1)
