"""Local HTTP adapter contracts and executable CLI integration."""

import json
import subprocess
import sys
from unittest.mock import patch

import numpy as np
import pytest

from code_auditor.embeddings import (
    HashEmbedder,
    LocalHTTP,
    OllamaEmbedder,
    SentenceTransformerEmbedder,
    normalize,
)
from code_auditor.models import AuditorError
from code_auditor.refactor import RefactorAgent


def test_ollama_contract_and_model_identity(local_server):
    embedder = OllamaEmbedder("test", local_server)
    assert embedder.signature == "ollama:test:sha256:test-identity"
    vectors = embedder.encode(["one", "two"])
    assert vectors.shape == (2, 3)
    assert np.allclose(np.linalg.norm(vectors, axis=1), 1)
    with pytest.raises(AuditorError, match="not installed"):
        OllamaEmbedder("missing", local_server)


def test_local_model_refactor_contract(local_server, workspace, write):
    path = write("file.py", "x = 1\n")
    proposal = RefactorAgent(workspace).propose(
        "file.py", model="local-generator", base_url=local_server
    )
    assert proposal.replacement == b"x = 2\n"
    assert path.read_text() == "x = 1\n"


@pytest.mark.parametrize(
    "url",
    [
        "https://localhost:11434",
        "http://example.com",
        "http://localhost@evil.com",
        "http://127.0.0.1/path",
        "http://127.0.0.1?x=1",
    ],
)
def test_remote_endpoints_are_rejected(url):
    with pytest.raises(AuditorError):
        LocalHTTP(url)


def test_provider_error_and_unavailable_service(local_server):
    with pytest.raises(AuditorError):
        LocalHTTP(local_server).post("/invalid", {})
    with patch("urllib.request.OpenerDirector.open", side_effect=OSError("connection refused")):
        with pytest.raises(AuditorError):
            LocalHTTP("http://127.0.0.1:1").post("/api/embed", {})


@pytest.mark.parametrize(
    "values,count", [([[float("nan")]], 1), ([[1, 2]], 2), ([1, 2], 1), ([["bad"]], 1)]
)
def test_invalid_embedding_matrices(values, count):
    with pytest.raises(AuditorError):
        normalize(values, count)


def test_hash_is_deterministic_and_normalized():
    first = HashEmbedder(64).encode(["reserveStock product_quantity", ""])
    second = HashEmbedder(64).encode(["reserveStock product_quantity", ""])
    assert np.array_equal(first, second)
    assert np.allclose(np.linalg.norm(first[0]), 1)
    assert not first[1].any()


def test_transformers_requires_existing_local_directory(tmp_path):
    with pytest.raises(AuditorError, match="existing local"):
        SentenceTransformerEmbedder(str(tmp_path / "missing"))


def cli(root, *arguments, stdin=None):
    return subprocess.run(
        [
            sys.executable,
            "-m",
            "code_auditor",
            "--root",
            str(root),
            "--backend",
            "hash",
            *arguments,
        ],
        input=stdin,
        text=True,
        capture_output=True,
        timeout=30,
    )


def test_cli_index_search_audit_shell_and_refactor(workspace, write):
    path = write("sample.py", 'def reserve_stock():\n    return eval("[1, 2]")\n')
    index = cli(workspace, "index")
    assert index.returncode == 0, index.stderr + index.stdout
    assert json.loads(index.stdout)["changed"] == 1
    search = cli(workspace, "search", "reserve stock", "--json")
    assert search.returncode == 0
    hits = json.loads(search.stdout)
    assert hits[0]["chunk"]["path"] == "sample.py"
    audit = cli(workspace, "audit", "--json", "--fail-on", "high")
    assert audit.returncode == 2
    assert json.loads(audit.stdout)["files"][0]["findings"][0]["rule"] == "dynamic-execution"
    session = cli(workspace, "shell", stdin="reserve stock\n:audit\n:help\n:quit\n")
    assert session.returncode == 0, session.stderr + session.stdout
    assert "reserve_stock" in session.stdout and "Workspace health" in session.stdout
    proposal = cli(workspace, "refactor", "sample.py")
    assert proposal.returncode == 0 and "literal_eval" in proposal.stdout
    refused = cli(workspace, "refactor", "sample.py", "--apply")
    assert refused.returncode == 1 and "interactive terminal" in refused.stdout
    assert "eval(" in path.read_text()


def test_cli_no_models_required_for_audit_and_failure_exit_codes(workspace, write):
    write("bad.py", "def broken(:")
    result = cli(workspace, "audit", "--json", "--fail-on", "error")
    assert result.returncode == 2
    missing = cli(workspace / "missing", "index")
    assert missing.returncode == 1 and "Not a directory" in missing.stdout


def test_transformers_local_loader_identity_limits_and_normalization(tmp_path):
    import types

    model_dir = tmp_path / "model"
    model_dir.mkdir()
    weights = model_dir / "weights.bin"
    weights.write_bytes(b"fixture-not-real-weights")

    class Tokenizer:
        def encode(self, text, add_special_tokens=True):
            return text.split()

    class Model:
        max_seq_length = 4
        tokenizer = Tokenizer()

        def __init__(self, path, **kwargs):
            assert path == str(model_dir.resolve())
            assert kwargs["local_files_only"] is True
            assert kwargs["trust_remote_code"] is False

        def encode(self, texts, **kwargs):
            return [[3, 4] for text in texts]

    module = types.ModuleType("sentence_transformers")
    module.SentenceTransformer = Model
    with patch.dict(sys.modules, {"sentence_transformers": module}):
        embedder = SentenceTransformerEmbedder(str(model_dir))
        assert np.allclose(embedder.encode(["short input"]), [[0.6, 0.8]])
        with pytest.raises(AuditorError, match="never silently truncated"):
            embedder.encode(["one two three four five"])
        weights.write_bytes(b"different-fixture-weights")
        assert embedder.signature != SentenceTransformerEmbedder(str(model_dir)).signature


def test_search_json_masks_short_credentials(workspace, write):
    secret = "fakepass99"
    write("secret.py", f'api_key = "{secret}"\n')
    assert cli(workspace, "index").returncode == 0
    result = cli(workspace, "search", "api key", "--json")
    assert result.returncode == 0
    assert secret not in result.stdout
    assert "[REDACTED]" in json.loads(result.stdout)[0]["chunk"]["content"]


@pytest.mark.parametrize(
    "payload",
    [{"models": [42]}, {"models": "wrong"}, [], {"models": [{"name": "test", "digest": 42}]}],
)
def test_malformed_ollama_model_listing_is_operational_error(payload):
    import io

    with patch(
        "urllib.request.OpenerDirector.open", return_value=io.BytesIO(json.dumps(payload).encode())
    ):
        with pytest.raises(AuditorError):
            OllamaEmbedder("test", "http://127.0.0.1:11434")
