"""Exact-byte preservation, stale edits, syntax validation and path safety."""

import sys
from unittest.mock import patch

import pytest

from code_auditor.models import AuditorError
from code_auditor.refactor import RefactorAgent, validate


def test_literal_refactor_diff_apply_backup_and_behavior(workspace, write):
    original = b'"""Demo."""\nfrom __future__ import annotations\n\ndef parse():\n    return eval("{\'count\': 3}")\n'
    path = write("sample.py", original)
    agent = RefactorAgent(workspace)
    proposal = agent.propose("sample.py")
    assert path.read_bytes() == original
    assert "literal_eval" in proposal.diff
    assert proposal.replacement.index(b"from __future__") < proposal.replacement.index(
        b"import ast"
    )
    backup = agent.apply(
        proposal,
        test_command=[sys.executable, "-c", 'import sample; assert sample.parse() == {"count": 3}'],
    )
    assert backup.read_bytes() == original
    assert path.read_bytes() == proposal.replacement
    # Execute only this known test fixture, never user/workspace source.
    namespace = {}
    exec(compile(proposal.replacement, "trusted_fixture.py", "exec"), namespace)
    assert namespace["parse"]() == {"count": 3}


def test_stale_proposal_never_overwrites_user_edit(workspace, write):
    path = write("file.py", 'x = eval("[1,2]")\n')
    agent = RefactorAgent(workspace)
    proposal = agent.propose("file.py")
    path.write_text("x = 99\n")
    with pytest.raises(AuditorError, match="changed since"):
        agent.apply(proposal)
    assert path.read_text() == "x = 99\n"


def test_encoding_unicode_crlf_preserved(workspace, write):
    raw = b"# coding: latin-1\r\nname = 'caf\xe9'; x = eval('[1, 2]')\r\n"
    path = write("file.py", raw)
    proposal = RefactorAgent(workspace).propose("file.py")
    assert b"caf\xe9" in proposal.replacement
    assert proposal.replacement.count(b"\n") == proposal.replacement.count(b"\r\n")
    validate(proposal.replacement.decode("latin-1"), "file.py")
    assert path.read_bytes() == raw


@pytest.mark.parametrize(
    "content",
    [
        "x = eval(user_input)\n",
        'x = eval("1+2")\n',
        'def eval(x): return x\nx = eval("1")\n',
        'def fn(eval): return eval("1")\n',
    ],
)
def test_unsafe_or_dynamic_changes_refused(workspace, write, content):
    write("file.py", content)
    with pytest.raises(AuditorError):
        RefactorAgent(workspace).propose("file.py")


def test_invalid_original_source_refused(workspace, write):
    write("file.py", "def bad(:")
    with pytest.raises(AuditorError, match="invalid Python syntax"):
        RefactorAgent(workspace).propose("file.py")


def test_symlink_and_path_escape_refused(workspace, tmp_path, write):
    outside = tmp_path / "outside.py"
    outside.write_text('x = eval("1")')
    (workspace / "link.py").symlink_to(outside)
    agent = RefactorAgent(workspace)
    for path in ("../outside.py", str(outside), "link.py"):
        with pytest.raises(AuditorError):
            agent.propose(path)


def test_alias_collision_is_avoided(workspace, write):
    write("file.py", '_code_auditor_ast = 1\nx = eval("1")\n')
    proposal = RefactorAgent(workspace).propose("file.py")
    assert b"import ast as _code_auditor_ast_\n" in proposal.replacement


def test_write_failure_leaves_original(workspace, write):
    path = write("file.py", 'x = eval("1")\n')
    agent = RefactorAgent(workspace)
    proposal = agent.propose("file.py")
    with patch("code_auditor.refactor.os.replace", side_effect=PermissionError("denied")):
        with pytest.raises(AuditorError, match="write failed"):
            agent.apply(
                proposal, test_command=[sys.executable, "-c", "import file; assert file.x == 1"]
            )
    assert path.read_bytes() == proposal.original
    assert not list(workspace.glob(".file.py.*"))


def test_local_model_bad_json_and_invalid_syntax(workspace, write):
    write("file.py", "x = 1\n")
    agent = RefactorAgent(workspace)
    for response in (
        {"response": "invalid json"},
        {"response": '{"code":"def invalid(:"}'},
        {"response": '{"code":""}'},
        {"response": "{}"},
    ):
        with patch("code_auditor.refactor.LocalHTTP.post", return_value=response):
            with pytest.raises(AuditorError):
                agent.propose("file.py", model="test-model")


def test_module_header_semicolon_refused(workspace, write):
    write("file.py", '"""Docs."""; x = eval("1")\n')
    with pytest.raises(AuditorError, match="shares a line"):
        RefactorAgent(workspace).propose("file.py")


def test_shadowed_set_literal_call_refused(workspace, write):
    write("file.py", 'set = lambda: 99\nx = eval("set()")\n')
    with pytest.raises(AuditorError, match="No deterministic fix"):
        RefactorAgent(workspace).propose("file.py")


def test_exception_binding_alias_collision_avoided(workspace, write):
    write(
        "file.py",
        'def parse():\n    try:\n        return eval("1")\n    except ValueError as _code_auditor_ast:\n        return 0\n',
    )
    proposal = RefactorAgent(workspace).propose("file.py")
    assert b"import ast as _code_auditor_ast_\n" in proposal.replacement
    namespace = {}
    exec(compile(proposal.replacement, "trusted_fixture.py", "exec"), namespace)
    assert namespace["parse"]() == 1


@pytest.mark.parametrize(
    "content",
    [
        'async def eval(x): return x\nx = eval("1")\n',
        'try:\n    x = 1\nexcept ValueError as eval:\n    x = eval("1")\n',
        'match x:\n    case {"value": eval}:\n        y = eval("1")\n',
    ],
)
def test_additional_eval_bindings_refused(workspace, write, content):
    write("file.py", content)
    with pytest.raises(AuditorError, match="shadowed"):
        RefactorAgent(workspace).propose("file.py")
