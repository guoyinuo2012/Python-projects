"""Isolated workspaces and persistent indexes for integration tests."""

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest

from code_auditor.embeddings import HashEmbedder
from code_auditor.ingestion import Scanner
from code_auditor.pipeline import Pipeline
from code_auditor.storage import Store


@pytest.fixture
def workspace(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()
    return root


@pytest.fixture
def engine(workspace, tmp_path):
    embedder = HashEmbedder(128)
    store = Store(tmp_path / "index.sqlite3", workspace, embedder.signature)
    pipeline = Pipeline(Scanner(workspace), store, embedder, batch_size=2)
    yield pipeline, store, embedder
    store.close()


@pytest.fixture
def write(workspace):
    def create(relative: str, content: str | bytes) -> Path:
        path = workspace / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(content, bytes):
            path.write_bytes(content)
        else:
            path.write_text(content, encoding="utf-8")
        return path

    return create


@pytest.fixture
def local_server():
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format, *args):
            return

        def send(self, payload):
            raw = json.dumps(payload).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def do_GET(self):
            self.send({"models": [{"name": "test:latest", "digest": "sha256:test-identity"}]})

        def do_POST(self):
            payload = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            if self.path == "/api/embed":
                assert payload["truncate"] is False
                self.send({"embeddings": [[3, 4, 0] for _ in payload["input"]]})
            elif self.path == "/api/generate":
                self.send({"response": json.dumps({"code": "x = 2\n"})})
            else:
                self.send({"error": "unknown route"})

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{server.server_port}"
    server.shutdown()
    server.server_close()
    thread.join(timeout=2)
