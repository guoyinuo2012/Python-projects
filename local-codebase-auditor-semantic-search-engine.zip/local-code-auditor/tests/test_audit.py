"""Metric semantics and security patterns, including import aliases."""

import ast

from code_auditor.audit import Auditor, complexity, redact
from code_auditor.models import SourceFile


def audit(text, path="file.py"):
    return Auditor().audit(SourceFile(path, text, "digest"))


def test_metrics_docstrings_and_inline_comments():
    report = audit('"""Module docs."""\n# comment\nx = 1  # inline\n\n')
    assert report.code_lines == 1
    assert report.comment_lines == 3
    assert report.blank_lines == 1
    assert report.code_to_comment_ratio == 1 / 3


def test_zero_comment_ratio_is_json_safe_null():
    assert audit("x = 1\n").to_dict()["code_to_comment_ratio"] is None


def test_complexity_excludes_nested_function_and_counts_decisions():
    tree = ast.parse(
        "def outer(a,b):\n    def inner():\n        if a:\n            pass\n    if a and b:\n        return [x for x in a if x]\n    return 0\n"
    )
    assert complexity(tree.body[0]) == 5
    assert complexity(tree.body[0].body[0]) == 2


def test_high_complexity_flag():
    report = audit("def fn(x):\n" + "    if x: pass\n" * 11)
    assert report.complexity == {"fn@1": 12}
    assert any(f.rule == "complexity" for f in report.findings)


def test_security_aliases_and_safe_yaml():
    report = audit(
        "import pickle as p\nfrom subprocess import run as r\nimport yaml\n"
        "api_key = 'fictional-secret-value'\n"
        "eval(user_text)\nexec(user_text)\np.loads(data)\n"
        "r(cmd, shell=True)\nyaml.load(text)\n"
        "yaml.load(text, Loader=yaml.SafeLoader)\n"
    )
    rules = [f.rule for f in report.findings]
    assert rules.count("dynamic-execution") == 2
    assert rules.count("unsafe-deserialization") == 1
    assert rules.count("shell-execution") == 1
    assert rules.count("unsafe-yaml") == 1
    assert rules.count("hardcoded-secret") == 1
    assert all("fictional-secret-value" not in f.message for f in report.findings)


def test_mapping_secrets_and_malformed_syntax():
    assert any(
        f.rule == "hardcoded-secret" for f in audit("x = {'password': 'fictional123'}").findings
    )
    assert any(f.rule == "syntax-error" for f in audit("def x(:").findings)


def test_non_python_security_and_comment_counts():
    report = audit('// comment\nconst api_key = "fictional-secret-value";\n', "file.js")
    assert report.comment_lines == 1 and report.code_lines == 1
    assert len(report.findings) == 1


def test_redaction_masks_assignment_and_provider_pattern():
    result = redact('api_key = "fictional-secret-value"\nx = "sk-' + "x" * 24 + '"')
    assert "fictional-secret-value" not in result
    assert "sk-" not in result
    assert "[REDACTED]" in result


def test_mapping_secret_and_complete_private_key_redaction():
    text = "config = {'password': 'fakepass99'}\n-----BEGIN PRIVATE KEY-----\nPRIVATE_PAYLOAD\n-----END PRIVATE KEY-----"
    result = redact(text)
    assert "fakepass99" not in result
    assert "PRIVATE_PAYLOAD" not in result
