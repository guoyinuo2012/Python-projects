"""Gitignore hierarchy, bounded reads, encodings and structural extraction."""

import asyncio
import hashlib
from unittest.mock import patch

import pytest

from code_auditor.chunking import Chunker
from code_auditor.ingestion import Scanner
from code_auditor.models import AuditorError, SourceFile


def source(content: str, path="sample.py"):
    return SourceFile(path, content, hashlib.sha256(content.encode()).hexdigest())


def test_hierarchical_ignore_and_negation(workspace, write):
    write(".gitignore", "*.json\n!keep.json\nignored/\n*.tmp\n")
    write("keep.json", "{}")
    write("drop.json", "{}")
    write("root.py", "pass\n")
    write("nested/.gitignore", "!local.json\nhidden.py\n")
    write("nested/local.json", "{}")
    write("nested/hidden.py", "pass\n")
    write("nested/ok.py", "pass\n")
    write("ignored/.gitignore", "!child.py\n")
    write("ignored/child.py", "pass\n")
    write(".venv/package.py", "pass\n")
    write("file.bin", b"data")
    result = asyncio.run(Scanner(workspace).scan())
    assert result.seen == {"keep.json", "root.py", "nested/local.json", "nested/ok.py"}
    assert not result.errors


def test_anchored_rules_are_relative_to_ignore_directory(workspace, write):
    write("sub/.gitignore", "/only.py\n")
    write("sub/only.py", "pass")
    write("sub/deeper/only.py", "pass")
    write("only.py", "pass")
    result = asyncio.run(Scanner(workspace).scan())
    assert result.seen == {"only.py", "sub/deeper/only.py"}


def test_empty_binary_size_encoding_and_syntax(workspace, write):
    write("empty.py", "")
    write("binary.py", b"abc\x00xyz")
    write("big.py", "x" * 101)
    write("encoded.py", b"# coding: latin-1\nname = 'caf\xe9'\n")
    write("bad.json", b"\xff")
    result = asyncio.run(Scanner(workspace, max_bytes=100).scan())
    assert result.seen == {"empty.py", "binary.py", "big.py", "encoded.py", "bad.json"}
    assert set(result.errors) == {"binary.py", "big.py", "bad.json"}
    encoded = next(item for item in result.files if item.path == "encoded.py")
    assert "café" in encoded.content
    assert Chunker().chunk(next(item for item in result.files if item.path == "empty.py")) == (
        [],
        None,
    )


def test_symlink_never_followed(workspace, tmp_path, write):
    outside = tmp_path / "outside.py"
    outside.write_text("pass")
    (workspace / "link.py").symlink_to(outside)
    (workspace / "linked-dir").symlink_to(tmp_path, target_is_directory=True)
    write("regular.py", "pass")
    result = asyncio.run(Scanner(workspace).scan())
    assert result.seen == {"regular.py"}


def test_read_permission_failure_is_reported(workspace, write):
    write("denied.py", "pass")
    with patch.object(Scanner, "read", side_effect=PermissionError("denied")):
        result = asyncio.run(Scanner(workspace).scan())
    assert result.seen == {"denied.py"}
    assert result.errors == {"denied.py": "denied"}


def test_directory_permission_failure_aborts(workspace):
    with patch("code_auditor.ingestion.os.scandir", side_effect=PermissionError("denied")):
        with pytest.raises(AuditorError, match="Cannot enumerate"):
            asyncio.run(Scanner(workspace).scan())


@pytest.mark.parametrize("workers,max_bytes", [(0, 100), (1, 0)])
def test_invalid_scanner_limits(workspace, workers, max_bytes):
    with pytest.raises(AuditorError):
        Scanner(workspace, workers=workers, max_bytes=max_bytes)


def test_python_definitions_decorators_docstrings_imports_and_parents():
    text = (
        '"""Module docs."""\nimport os\nfrom pathlib import Path\n\n'
        '@decorator\nclass Worker:\n    """Class docs."""\n'
        '    async def run(self):\n        """Run docs."""\n'
        "        def nested():\n            return 1\n        return nested()\n\n"
        "if True:\n    def conditional():\n        return 2\n"
    )
    chunks, error = Chunker().chunk(source(text))
    assert error is None
    cls = next(chunk for chunk in chunks if chunk.name == "Worker")
    method = next(chunk for chunk in chunks if chunk.name == "Worker.run")
    nested = next(chunk for chunk in chunks if chunk.name == "Worker.run.nested")
    assert cls.start_line == 5 and cls.docstring == "Class docs."
    assert method.parent == "Worker" and method.docstring == "Run docs."
    assert nested.parent == "Worker.run"
    assert "import os" in method.imports and "from pathlib import Path" in method.imports
    assert any(chunk.name == "conditional" for chunk in chunks)
    covered = {line for chunk in chunks for line in range(chunk.start_line, chunk.end_line + 1)}
    assert covered == set(range(1, len(text.splitlines()) + 1))


def test_malformed_python_remains_searchable():
    chunks, error = Chunker().chunk(source("def broken(:\n"))
    assert error and len(chunks) == 1 and chunks[0].kind == "syntax-error"


def test_non_python_uses_paragraph_boundaries():
    chunks, error = Chunker().chunk(source("first\n\nsecond\nline\n", "file.md"))
    assert error is None
    assert [(chunk.start_line, chunk.end_line) for chunk in chunks] == [(1, 2), (3, 4)]
