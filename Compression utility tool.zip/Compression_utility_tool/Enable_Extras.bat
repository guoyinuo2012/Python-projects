@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 goto python_fallback
py -3 -m venv .app-env
if errorlevel 1 goto failure
goto install
:python_fallback
python -m venv .app-env
if errorlevel 1 goto failure
:install
.app-env\Scripts\python -m pip install -r requirements-optional.txt
if errorlevel 1 goto failure
echo Extras installed. Double-click Start.bat to launch.
pause
exit /b 0
:failure
echo Setup failed. Read the error above. Python 3.10+ and internet access are required.
pause
exit /b 1
