"""Multi-input ZIP building, member selection and streaming SHA-256 tools."""

from __future__ import annotations

from contextlib import suppress
from dataclasses import dataclass
import fnmatch
import hashlib
import hmac
import os
from pathlib import Path
import stat
import tempfile
import time
import zipfile

from archive_engine import (
    ARCHIVE_FORMATS,
    BUFFER_SIZE,
    DEFAULT_LIMIT,
    TAR_FORMATS,
    Stats,
    check_cancel,
    copy_stream,
    detect_format,
    process_file,
    publish_file,
    safe_member_path,
    walk_tar,
    zip_member_path,
)


@dataclass(frozen=True)
class Member:
    name: str
    size: int
    directory: bool


def excluded(name: str, patterns) -> bool:
    relative = name.split("/", 1)[-1]
    basename = name.rstrip("/").rsplit("/", 1)[-1]
    return any(
        fnmatch.fnmatchcase(candidate, pattern)
        for pattern in patterns
        for candidate in (name.rstrip("/"), relative.rstrip("/"), basename)
    )


def create_zip(
    inputs,
    output,
    level=6,
    excludes=(),
    stored=False,
    cancel=None,
    progress=None,
    password=None,
) -> Stats:
    """Combine unrelated roots in one ZIP, renaming conflicting root names."""
    started = time.perf_counter()
    output = Path(output)
    if os.path.lexists(output):
        raise FileExistsError("Choose a new ZIP filename.")
    if not inputs or type(level) is not int or not 0 <= level <= 9:
        raise ValueError("Choose input items and a compression level from 0 to 9.")
    entries, roots, visited = [], set(), set()
    for value in inputs:
        check_cancel(cancel)
        source = Path(os.path.abspath(value))
        if str(source) in visited:
            continue
        visited.add(str(source))
        if source.is_symlink() or not (source.is_dir() or source.is_file()):
            raise OSError("Inputs must be ordinary files or folders, not links.")
        if source.is_dir() and output.resolve().is_relative_to(source.resolve()):
            raise OSError("Save the ZIP outside every selected input folder.")
        root_name, counter = source.name, 2
        while root_name.casefold() in roots:
            name = Path(source.name)
            root_name = f"{name.stem} ({counter}){name.suffix}"
            counter += 1
        roots.add(root_name.casefold())
        safe_member_path(root_name)

        def append(path, source=source, root_name=root_name):
            relative = path.relative_to(source).as_posix() if source.is_dir() else "."
            name = root_name if relative == "." else root_name + "/" + relative
            if excluded(name, excludes):
                return False
            if path.is_symlink() or not (path.is_dir() or path.is_file()):
                raise OSError("ZIP inputs cannot contain links or special files.")
            safe_member_path(name)
            entries.append((path, name))
            if len(entries) > 100_000:
                raise OSError("ZIP exceeds the 100,000-entry limit.")
            return True

        if not append(source):
            continue
        if source.is_dir():

            def walk_error(error):
                raise error

            for directory, folders, files in os.walk(
                source, followlinks=False, onerror=walk_error
            ):
                check_cancel(cancel)
                folders[:] = [
                    name for name in sorted(folders) if append(Path(directory) / name)
                ]
                for name in sorted(files):
                    append(Path(directory) / name)
    if not entries:
        raise ValueError("All inputs were excluded; no archive was created.")
    total = sum(path.stat().st_size for path, _ in entries if path.is_file())
    completed, count, temporary = 0, 0, None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w+b",
            buffering=BUFFER_SIZE,
            delete=False,
            dir=output.parent,
            prefix=".file-compressor-",
            suffix=".tmp",
        ) as destination:
            temporary = Path(destination.name)
            method = zipfile.ZIP_STORED if stored else zipfile.ZIP_DEFLATED
            archive_class = zipfile.ZipFile
            if password is not None:
                from runtime_tools import aes_zip_class

                archive_class = aes_zip_class()
            with archive_class(
                destination, "w", method, compresslevel=None if stored else level
            ) as archive:
                if password is not None:
                    import pyzipper

                    archive.setpassword(password.encode("utf-8"))
                    archive.setencryption(pyzipper.WZ_AES, nbits=256)
                for path, name in entries:
                    check_cancel(cancel)
                    if path.is_dir():
                        archive.writestr(name + "/", b"")
                        continue
                    base = completed

                    def update(amount, base=base):
                        if progress:
                            progress(min(99.0, (base + amount) / max(total, 1) * 100))

                    with (
                        path.open("rb", buffering=BUFFER_SIZE) as reader,
                        archive.open(
                            name,
                            "w",
                            force_zip64=path.stat().st_size * 1.05
                            >= zipfile.ZIP64_LIMIT,
                        ) as writer,
                    ):
                        completed += copy_stream(reader, writer, cancel, update)
                    count += 1
            destination.flush()
            os.fsync(destination.fileno())
            size = destination.tell()
        check_cancel(cancel)
        publish_file(temporary, output, cancel)
        if progress:
            progress(100.0)
        return Stats(total, size, time.perf_counter() - started, False, "zip", count)
    finally:
        if temporary is not None:
            with suppress(OSError):
                temporary.unlink()


def list_members(path, cancel=None, max_output=DEFAULT_LIMIT) -> list[Member]:
    selected = detect_format(path)
    members = []
    if selected == "zip":
        with zipfile.ZipFile(path) as archive:
            for info in archive.infolist():
                check_cancel(cancel)
                zip_member_path(info)
                members.append(Member(info.filename, info.file_size, info.is_dir()))
                if len(members) > 100_000:
                    raise OSError("Archive exceeds the member limit.")
    elif selected in TAR_FORMATS:

        def collect(info, _reader, _position):
            name = info.name
            while name.startswith("./"):
                name = name[2:]
            if info.isdir() and name in ("", "."):
                return
            if not (info.isfile() or info.isdir()) or info.sparse is not None:
                raise OSError("TAR links and special files are unsupported.")
            relative = safe_member_path(name).as_posix()
            members.append(
                Member(
                    relative + ("/" if info.isdir() else ""), info.size, info.isdir()
                )
            )

        walk_tar(path, selected, cancel, max_output, collect)
    else:
        raise ValueError("Member selection requires ZIP or TAR.")
    return members


def extract_selected(
    path, output, names, cancel=None, progress=None, max_output=DEFAULT_LIMIT
):
    if detect_format(path) not in ARCHIVE_FORMATS:
        raise ValueError("Member selection requires ZIP or TAR.")
    return process_file(
        path,
        output,
        True,
        members=names,
        cancel=cancel,
        progress=progress,
        max_output=max_output,
    )


def sha256_file(path, expected=None, cancel=None, progress=None):
    """Return a SHA-256 digest and optional match result, without modifying input."""
    if expected is not None:
        expected = expected.strip().lower()
        if len(expected) != 64 or any(c not in "0123456789abcdef" for c in expected):
            raise ValueError(
                "Expected SHA-256 must contain exactly 64 hexadecimal characters."
            )
    path = Path(path)
    if not stat.S_ISREG(path.stat().st_mode):
        raise OSError("Choose a regular file to hash.")
    digest, copied, total = hashlib.sha256(), 0, path.stat().st_size
    with path.open("rb", buffering=BUFFER_SIZE) as reader:
        while True:
            check_cancel(cancel)
            chunk = reader.read(BUFFER_SIZE)
            if not chunk:
                break
            digest.update(chunk)
            copied += len(chunk)
            if progress:
                progress(min(99.0, copied / max(total, 1) * 100))
    check_cancel(cancel)
    value = digest.hexdigest()
    if progress:
        progress(100.0)
    return value, hmac.compare_digest(value, expected) if expected is not None else None


def cli(arguments) -> int:
    """Advanced CLI commands, sharing the same engines as the GUI."""
    import argparse
    from dataclasses import asdict
    import json
    import sys
    from archive_engine import EXTENSIONS, build_jobs, run_jobs

    parser = argparse.ArgumentParser(description="Advanced local archive tools")
    commands = parser.add_subparsers(dest="command", required=True)
    combine = commands.add_parser("combine", help="Combine inputs in one ZIP")
    combine.add_argument("inputs", nargs="+", type=Path)
    combine.add_argument("-o", "--output", required=True, type=Path)
    combine.add_argument("-l", "--level", choices=range(10), type=int, default=6)
    combine.add_argument("--exclude", action="append", default=[])
    combine.add_argument(
        "--store", action="store_true", help="Store without compression"
    )
    extract = commands.add_parser("extract", help="Extract selected ZIP/TAR members")
    extract.add_argument("archive", type=Path)
    extract.add_argument("-o", "--output", required=True, type=Path)
    extract.add_argument("--member", action="append", required=True)
    extract.add_argument("--max-output-gib", type=float, default=20)
    checksum = commands.add_parser("hash", help="Calculate/compare SHA-256")
    checksum.add_argument("file", type=Path)
    checksum.add_argument("--expect")
    batch = commands.add_parser("batch", help="Run multiple jobs sequentially")
    batch.add_argument("inputs", nargs="+", type=Path)
    batch.add_argument("--output-dir", type=Path, required=True)
    batch.add_argument("-d", "--decompress", action="store_true")
    batch.add_argument("-f", "--format", choices=("auto", *EXTENSIONS), default="auto")
    batch.add_argument("-l", "--level", type=int, choices=range(10), default=6)
    batch.add_argument("--max-output-gib", type=float, default=20)
    batch.add_argument("--report", type=Path, help="Write a NEW JSON result report")
    args = parser.parse_args(arguments)
    try:
        limit = getattr(args, "max_output_gib", 20)
        if not 0 <= limit < float("inf"):
            parser.error("Output limit must be finite and nonnegative.")
        limit = int(limit * 1024**3)
        if args.command == "combine":
            print(
                create_zip(
                    args.inputs, args.output, args.level, args.exclude, args.store
                ).report()
            )
        elif args.command == "extract":
            print(
                extract_selected(
                    args.archive, args.output, args.member, max_output=limit
                ).report()
            )
        elif args.command == "hash":
            digest, match = sha256_file(args.file, args.expect)
            print(f"{digest}  {args.file}")
            if match is not None:
                print("MATCH" if match else "MISMATCH")
            return 1 if match is False else 0
        else:
            format = (
                "gzip" if not args.decompress and args.format == "auto" else args.format
            )
            jobs = build_jobs(
                args.inputs, args.output_dir, args.decompress, format, args.level
            )
            results = run_jobs(jobs, max_output=limit)
            for result in results:
                print(f"{result.job.source}: {result.status} -> {result.job.output}")
                if result.error:
                    print(result.error, file=sys.stderr)
            if args.report:
                data = [
                    {
                        "input": str(result.job.source),
                        "output": str(result.job.output),
                        "status": result.status,
                        "error": result.error,
                        "metrics": asdict(result.stats) if result.stats else None,
                    }
                    for result in results
                ]
                with args.report.open("x", encoding="utf-8") as file:
                    json.dump(data, file, indent=2)
                    file.write("\n")
            return 1 if any(result.status != "Completed" for result in results) else 0
        return 0
    except KeyboardInterrupt:
        print("Interrupted. Completed outputs are kept.", file=sys.stderr)
        return 130
    except Exception as error:
        print(f"Error: {error}", file=sys.stderr)
        return 1
