#!/bin/sh
exec sh "$(dirname "$0")/Start.sh" "$@"
