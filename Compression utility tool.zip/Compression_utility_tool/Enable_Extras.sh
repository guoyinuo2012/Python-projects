#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 -m venv .app-env
.app-env/bin/python -m pip install -r requirements-optional.txt
printf 'Extras installed. Run the Start launcher.\n'
