# Compression utility tool

Local Python GUI and CLI for ZIP, TAR, Gzip, Bzip2 and XZ. File contents stream
in 128 KiB chunks; inputs are never deleted. No uploads or telemetry.

## Start

Extract the ZIP into a **new folder**, keeping its files together.
Python 3.10+ is required; the GUI also needs Tkinter/Tcl-Tk and a desktop session.
Core compression has no third-party dependencies.

| OS | Launch | Optional extras |
| --- | --- | --- |
| Windows | `Start.bat` | `Enable_Extras.bat` |
| macOS | `Start.command` | `Enable_Extras.command` |
| Linux | `./Start.sh` | `./Enable_Extras.sh` | `./Build.sh` |

Launchers prefer `.app-env` if present, then system Python. Windows uses `py -3`
then `python`; Unix uses `python3` then `python`. Startup errors remain visible.
If Unix permissions were lost during extraction, run `chmod +x *.sh *.command`.
You can also launch with `python compression_utility_tool.py` or `python3 compression_utility_tool.py`.
Check Tk availability with `python -m tkinter`.

An old `compression.py` from an earlier version conflicts with Python 3.14.
Do not merge this release into an old folder. Keep `archive_engine.py` beside
`compression_utility_tool.py`. Mobile OSes and systems without compatible Python/Tk
are outside the desktop GUI's supported scope.

## GUI

1. Add files or a folder. Folders default to ZIP; TAR variants are also available.
2. Choose Compress/Decompress, format, preset/level and an existing output folder.
3. Start. Each queued item gets its own output; ZIP/TAR outputs preserve the
   input's top-level folder. Other formats handle one file per stream.

Existing outputs are refused or automatically numbered in batch mode. Failed
jobs are logged and the queue continues. Retry unfinished restarts failed,
cancelled or unrun jobs using current settings, retaining successful outputs.
Planning errors must be fixed before starting. Running a finished queue again
creates additional outputs.

Pause/resume works at streaming checkpoints while the app stays open; it does
not survive closing or rebooting. A current codec/filesystem call may delay a
checkpoint. Cancel also works while paused and keeps completed outputs. Closing
is blocked while a worker is active. Keep inputs unchanged during operations.

Preview lists up to 500 archive entries. Verify integrity streams all contents
without extracting files; it checks integrity rather than extraction-path safety.
Plain TAR has no payload checksums. Open output opens the selected completed
item's folder, the latest tool output, or the configured directory. Export results
saves the session log. Queues/logs last for the session; settings persist locally.

The modern interface includes light/dark themes, status colors with text labels,
an empty-queue Browse button and separate file/operation panels. Minimum window
size is 1020 × 760 pixels. Ctrl+O adds files, Delete removes selected items,
and Escape cancels.

### More Tools

- **ZIP builder:** combine queued files/folders, optionally only selected rows.
  Root-name collisions get suffixes. Comma-separated glob exclusions such as
  `*.tmp, .git, __pycache__` prune matching items; these exclusions apply only to
  this builder. Store-only mode disables compression. Save outside all input
  folders and use a new ZIP filename.
- **Extract:** select one ZIP/TAR, load its entries, search and select
  members. A selected directory includes descendants, even those hidden by the
  search. Up to 1,000 matching rows are shown; narrow the search for other entries.
  Changing the search clears selection. Extraction keeps internal paths and
  requires a new folder. ZIP limits apply to selected data; TAR must scan the
  whole archive, so its limit applies to all scanned contents.
- **SHA-256:** calculate a file digest or compare a 64-character hexadecimal
  expected digest. Results report MATCH/MISMATCH. A digest detects changes but
  does not establish authorship.

### Optional extras

Run the matching Enable_Extras launcher once, then restart using Start.
Setup requires internet access and Python with pip/venv, creates a private
`.app-env`, and installs pinned `pyzipper` and `tkinterdnd2`. Alternatively:

```sh
python -m pip install -r requirements-optional.txt
```

If setup fails, delete only this app's `.app-env` to restore system-Python launch.
Drag files/folders onto the file queue; drops while busy are ignored. Compatible
TkDND binaries are required; Add Files/Add Folder still work if unavailable.

For **AES-256 ZIPs**, enable password protection in ZIP builder. Enter and
confirm a nonempty password. To restore, select the ZIP in the main queue and
choose **Unlock selected encrypted ZIP** in that same tool panel. Supply the
password and a new folder. Wrong-password errors remove partial extraction.
Passwords are held for the operation and never saved; filenames remain visible.
Forgotten passwords cannot be recovered by this app. Use an AES-compatible
extractor; built-in OS support varies. Ordinary batch extraction, preview,
verification and selective extraction do not unlock encrypted ZIPs.

## CLI

Replace `python` with `python3` or `py -3` as appropriate.

```sh
python compression_utility_tool.py -i notes.txt -o notes.gz
python compression_utility_tool.py -i notes.txt -o notes.xz -f xz -l 7
python compression_utility_tool.py -i photos -o photos.tar.gz -f tar-gzip
python compression_utility_tool.py -d -i bundle.zip -o restored --max-output-gib 50
python compression_utility_tool.py combine notes.txt photos -o bundle.zip --exclude '*.tmp'
python compression_utility_tool.py combine video.mp4 photo.jpg -o media.zip --store
python compression_utility_tool.py extract bundle.zip -o selected --member notes.txt --member 'photos/'
python compression_utility_tool.py hash notes.txt
python compression_utility_tool.py batch first.txt second.txt --output-dir backups -f xz --report results.json
python compression_utility_tool.py batch first.gz second.zip --output-dir restored -d
python compression_utility_tool.py --compatibility
python compression_utility_tool.py --help
python compression_utility_tool.py combine --help
```

`-f/--format`: auto, gzip, bzip2, xz, zip, tar, tar-gzip, tar-bzip2, tar-xz.
Auto defaults to Gzip on compression and detects content on decompression.
Levels are 0–9 (default 6); Bzip2 maps 0 to 1. Plain TAR does not compress.
High XZ levels require more RAM. Quote patterns to avoid shell expansion.
`hash --expect DIGEST` compares a real 64-character hex digest. Batch JSON reports
require new filenames; report failure does not undo completed jobs. Failed jobs
and hash mismatches exit 1; interruption exits 130 and keeps completed outputs.

## Limits and output protection

The default extraction/verification limit is **20 GiB per job**; change it in the
GUI or with `--max-output-gib`. Zero disables it. This is not a RAM cap. ZIP/TAR
metadata/file lists use memory proportional to entry count, capped at 100,000.
TAR padding after its end marker is capped at 16 MiB.

Extraction rejects traversal, reserved/unsafe Windows names, links, special files
and duplicate/case-colliding paths. TAR sparse files are unsupported. Existing
extraction folders are never merged. Metadata/permissions are not preserved.
RAR, 7z and automatic input deletion are not supported.

Single-file outputs are staged beside their destination, flushed/fsynced and
published without overwrite. Filesystems lacking hard links use exclusive output
creation with a streaming copy. That fallback and directory extraction expose
partial output while running; normal errors/cancellation remove it. Abrupt
termination, power loss or cleanup failures can leave temporary/partial output.
Directory entries are not fsynced; full crash durability is not guaranteed.
A late cancellation may retain an output that has already finished publication.

Metrics include time, streamed bytes, average MiB/s excluding pauses and estimated
remaining time. Queue progress gives each job equal weight; ETA can vary with job
size and scanning. Codec finalization/publication may take time near 99%.
Publication fallback copies contribute to streamed bytes; final elapsed time
includes pauses. Compression ratio is compressed/original bytes; above 100% means
expansion. Empty inputs and selective extraction report no applicable ratio.

## Verification and package contents

All **60 development tests passed on Linux with Python 3.12 and 3.14**, with
optional encryption installed. Live Linux GUI checks covered the compressor
features, themes, pause/resume, retry and minimum sizing. Windows/macOS GUI
appearance is not natively verified here.

This lean download contains only the running app, OS launchers, optional-feature
setup and instructions. Development tests, build scripts, CI configuration,
compiled output and caches are excluded. Python is required; this is not a
prebuilt standalone executable. Developer-only `--self-test` was removed.

Keep the six Python modules together: `compression_utility_tool.py`, `archive_engine.py`,
`advanced_tools.py`, `preferences.py`, `runtime_tools.py` and `file_tools.py`. The remaining files
are the README, three Start launchers and optional setup files.


## New file and queue utilities

Open More Tools to find these tabs:

- **Split / join:** choose one regular file in the main queue and a part size
  (default 100 MiB). Save to a NEW folder. Numbered binary parts and `manifest.json`
  contain per-part and whole-file SHA-256 checksums. Choose that manifest to rejoin
  into a NEW file; every part and the final checksum must match before publication.
  Missing, changed, linked or incorrectly sized parts are refused. An empty input
  produces a manifest without parts. The maximum is 100,000 parts, with part sizes
  from 1 MiB to 1 TiB in the GUI. These are the app's binary parts, not multipart
  ZIP/RAR volumes. Keep all parts with the manifest; file names in the manifest
  are informational, and rejoin uses the destination you explicitly choose.
- **Compare:** benchmark Gzip, Bzip2, XZ and ZIP on the selected regular file using
  the current level. Results list bytes, elapsed time, savings, smallest output
  and fastest codec. Compression runs on the entire input in the configured output
  folder, so allow time/free space. Temporary outputs are removed. This comparison
  does not automatically change your selected format. Use Export results to save it.
- **Convert:** convert ordinary unencrypted ZIP/TAR archives to ZIP, TAR, TAR.GZ,
  TAR.BZ2 or TAR.XZ, using the selected level. Member paths and empty directories
  remain intact. Temporary extraction is staged beside the output; allow disk
  space for both uncompressed contents and the new archive. The main extraction
  limit applies, and temporary files are removed on normal success/error/cancel.
  Metadata/permissions are normalized. Output metrics use uncompressed member
  bytes as the original size. Conversion does not unlock encrypted archives.
- **Queue:** save/reload paths and validated settings as a NEW JSON session file;
  paths are absolute, so sessions are intended for the same machine. Loading
  replaces the queue. Missing paths stay visible and must be corrected before
  starting. Passwords and file contents are never saved. Sessions do not preserve
  partially completed jobs, completed-row mappings or logs. Sort by name resets
  row status just like other queue edits.
- **Queue → Plan batch:** inspect input file/folder counts, total bytes, available
  output-volume space and planned names without creating output. Names are not
  reserved and final compressed/extracted sizes are not predicted. Queue inventory
  avoids counting overlapping paths twice and refuses links/special files. Its
  100,000-entry limit includes directories. Analyze provides just the inventory.

Splitting, joining, comparisons, conversions, inventory and planning use the same
background worker and Pause/Resume/Cancel controls as compression. Session JSON
is bounded at 16 MiB and 100,000 paths; missing inputs are allowed on load.
The main extraction limit also applies when joining; use 0 only when you intend
unlimited output. Split/join checksums detect accidental changes, not sender
identity: a malicious sender can replace both data and manifest.

Additional CLI examples:

```sh
python compression_utility_tool.py split video.mp4 -o video.parts --part-mib 100
python compression_utility_tool.py join video.parts/manifest.json -o restored.mp4
python compression_utility_tool.py join video.parts/manifest.json -o big.mp4 --max-output-gib 100
python compression_utility_tool.py compare notes.txt --work-dir scratch --report comparison.json
python compression_utility_tool.py convert source.zip -o converted.tar.xz -f tar-xz
python compression_utility_tool.py inventory notes.txt photos
python compression_utility_tool.py plan notes.txt photos --output-dir backups -f zip
python compression_utility_tool.py split --help
```

The CLI permits split sizes down to 1 MiB via `--part-mib`. Comparison reports
require new filenames. CLI errors exit 1; interrupted operations exit 130.
The runtime folder now has 14 files: one additional module contains these tools;
no development tests/build outputs were added to the download. The 60 development
tests and Linux GUI checks cover the new utilities. Windows/macOS native GUI
appearance remains unverified.


The app, entry script and download are now named **Compression utility tool**.
Existing settings from the earlier File Compressor version are loaded if the new
settings file does not yet exist; settings are saved under the new app name on close.
Only copy your own data/session files forward, and extract this release into a new
folder. Conversion progress updates while large files are encoded. Backend options
reject non-integer levels/byte limits, including booleans and non-finite values.
