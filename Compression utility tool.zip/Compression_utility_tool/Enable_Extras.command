#!/bin/sh
exec sh "$(dirname "$0")/Enable_Extras.sh" "$@"
