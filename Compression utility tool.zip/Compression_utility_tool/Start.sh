#!/bin/sh
# Portable desktop/CLI launcher for macOS and Linux.
cd "$(dirname "$0")" || exit 1
if [ "$#" -eq 0 ]; then
    set -- --gui
fi
for interpreter in ./.app-env/bin/python python3 python; do
    if command -v "$interpreter" >/dev/null 2>&1 && "$interpreter" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)' >/dev/null 2>&1; then
        "$interpreter" compression_utility_tool.py "$@"
        result=$?
        if [ "$result" -ne 0 ]; then
            printf '\nCompression utility tool could not finish. Read the error above.\n'
            if [ -t 0 ]; then
                printf 'Press Enter to close… '
                read answer
            fi
        fi
        exit "$result"
    fi
done
printf 'Install Python 3.10+ with Tkinter/Tcl-Tk, then try again.\n' >&2
exit 1
