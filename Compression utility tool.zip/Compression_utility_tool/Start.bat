@echo off
setlocal
cd /d "%~dp0"
if not exist ".app-env\Scripts\python.exe" goto system_python
.app-env\Scripts\python "compression_utility_tool.py" --gui
goto finished
:system_python
where py >nul 2>&1
if errorlevel 1 goto try_python
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>&1
if errorlevel 1 goto try_python
py -3 "compression_utility_tool.py" --gui
goto finished
:try_python
where python >nul 2>&1
if errorlevel 1 goto missing
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>&1
if errorlevel 1 goto missing
python "compression_utility_tool.py" --gui
:finished
if not errorlevel 1 exit /b 0
echo.
echo Compression utility tool could not start. Read the error above.
pause
exit /b 1
:missing
echo Install Python 3.10 or newer with Tcl/Tk support, then try again.
echo The Python launcher or Python must be available on PATH.
pause
exit /b 1
