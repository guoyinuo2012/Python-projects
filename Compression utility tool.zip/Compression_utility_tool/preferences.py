"""Validated local preferences and read-only compatibility diagnostics."""

from __future__ import annotations

from contextlib import suppress
import importlib
import json
import math
import os
from pathlib import Path
import platform
import shutil
import sys
import tempfile


def settings_path() -> Path:
    home = Path.home()
    if sys.platform == "win32":
        base = Path(os.environ.get("LOCALAPPDATA", home / "AppData" / "Local"))
    elif sys.platform == "darwin":
        base = home / "Library" / "Application Support"
    else:
        candidate = Path(os.environ.get("XDG_CONFIG_HOME", home / ".config"))
        base = candidate if candidate.is_absolute() else home / ".config"
    return base / "CompressionUtilityTool" / "settings.json"


def validated_settings(data: object) -> dict:
    if not isinstance(data, dict):
        return {}
    clean = {}
    if type(data.get("dark")) is bool:
        clean["dark"] = data["dark"]
    if data.get("mode") in ("compress", "decompress"):
        clean["mode"] = data["mode"]
    formats = {
        "auto",
        "gzip",
        "bzip2",
        "xz",
        "zip",
        "tar",
        "tar-gzip",
        "tar-bzip2",
        "tar-xz",
    }
    if isinstance(data.get("format"), str) and data["format"] in formats:
        clean["format"] = data["format"]
    if type(data.get("level")) is int and 0 <= data["level"] <= 9:
        clean["level"] = data["level"]
    if data.get("preset") in ("Fast", "Balanced", "Smallest", "Custom"):
        clean["preset"] = data["preset"]
    limit = data.get("limit")
    if type(limit) in (int, float) and 0 <= limit <= 10000 and math.isfinite(limit):
        clean["limit"] = limit
    output = data.get("output_directory")
    if isinstance(output, str) and len(output) <= 32768:
        try:
            if Path(output).is_dir():
                clean["output_directory"] = output
        except (OSError, ValueError):
            pass
    return clean


def load_settings(path: Path | None = None) -> dict:
    try:
        selected = Path(path) if path is not None else settings_path()
        if path is None and not selected.exists():
            legacy = selected.parent.parent / "FileCompressor" / "settings.json"
            if legacy.is_file():
                selected = legacy
        with Path(selected).open("r", encoding="utf-8") as file:
            # Preferences should be small; reject unexpectedly large files.
            if Path(selected).stat().st_size > 128 * 1024:
                return {}
            return validated_settings(json.load(file))
    except (OSError, ValueError, UnicodeError, RecursionError):
        return {}


def save_settings(data: dict, path: Path | None = None) -> None:
    selected = Path(path if path is not None else settings_path())
    selected.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=selected.parent,
            prefix=".settings-",
            suffix=".tmp",
            delete=False,
        ) as file:
            temporary = Path(file.name)
            json.dump(validated_settings(data), file, indent=2, allow_nan=False)
            file.write("\n")
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary, selected)
    finally:
        if temporary is not None:
            with suppress(OSError):
                temporary.unlink(missing_ok=True)


def compatibility_report(output_directory: Path | None = None) -> str:
    lines = [
        "Compression utility tool compatibility report",
        "",
        f"System: {platform.system()} {platform.release()}",
        f"Architecture: {platform.machine()}",
        f"Python: {platform.python_version()}",
        f"Python requirement: {'OK' if sys.version_info >= (3, 10) else '3.10+ required'}",
    ]
    for name in ("zlib", "gzip", "bz2", "lzma", "zipfile", "tarfile", "tkinter"):
        try:
            module = importlib.import_module(name)
            detail = f" (Tk {module.TkVersion})" if name == "tkinter" else ""
            lines.append(f"{name}: available{detail}")
        except (ImportError, OSError) as error:
            lines.append(f"{name}: unavailable ({error})")
    if sys.platform.startswith("linux"):
        display = bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))
        lines.append(
            f"Graphical session environment: {'detected' if display else 'not detected; CLI still works'}"
        )
    else:
        lines.append("Native GUI display: not checked by this report")
    lines.append(
        "GUI requires an accessible desktop display; importing Tkinter alone does not prove it."
    )
    if output_directory is not None:
        folder = Path(output_directory)
        lines.append(f"Output directory: {folder}")
        lines.append(f"Directory exists: {folder.is_dir()}")
        lines.append(f"Write permission check: {os.access(folder, os.W_OK)}")
        try:
            lines.append(
                f"Free space: {shutil.disk_usage(folder).free / 1024**3:.2f} GiB"
            )
        except OSError:
            lines.append("Free space: unavailable")
    lines.extend(
        [
            "",
            "No packages were installed or files changed by this check.",
            "Designed for Windows/macOS/Linux; native execution was verified on Linux only.",
        ]
    )
    return "\n".join(lines)


if __name__ == "__main__":
    print(compatibility_report())
