"""Streaming file utilities and explicit queue-session persistence."""

from __future__ import annotations

from contextlib import suppress
from dataclasses import asdict
import hashlib
import hmac
import json
import os
from pathlib import Path
import shutil
import stat
import tarfile
import tempfile
import time

from archive_engine import (
    ARCHIVE_FORMATS,
    BUFFER_SIZE,
    DEFAULT_LIMIT,
    EXTENSIONS,
    Stats,
    CheckedReader,
    check_cancel,
    codec_stream,
    detect_format,
    process_file,
    publish_file,
    safe_member_path,
    validate_options,
)
from advanced_tools import create_zip
from preferences import validated_settings

MAX_PARTS = 100_000
JSON_LIMIT = 16 * 1024**2


def regular_file(path):
    path = Path(path)
    if not stat.S_ISREG(path.lstat().st_mode):
        raise OSError("Choose an ordinary file, not a link or special file.")
    return path


def read_json(path):
    with regular_file(path).open("rb") as reader:
        data = reader.read(JSON_LIMIT + 1)
    if len(data) > JSON_LIMIT:
        raise ValueError("JSON file exceeds the 16 MiB limit.")
    return json.loads(data)


def write_json(path, data):
    """Publish a new JSON file without overwriting existing data."""
    path = Path(path)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=path.parent, delete=False
        ) as writer:
            temporary = Path(writer.name)
            json.dump(data, writer, indent=2, allow_nan=False)
            writer.write("\n")
            writer.flush()
            os.fsync(writer.fileno())
        publish_file(temporary, path)
    finally:
        if temporary is not None:
            with suppress(OSError):
                temporary.unlink()


def split_file(source, output, part_size, cancel=None, progress=None):
    """Create numbered binary parts plus SHA-256 manifest in a NEW directory."""
    source, output = regular_file(source), Path(output)
    if type(part_size) is not int or not 1 <= part_size <= 1024**4:
        raise ValueError("Part size must be 1 byte–1 TiB.")
    size = source.stat().st_size
    if (size + part_size - 1) // part_size > MAX_PARTS:
        raise ValueError("Too many parts; increase the part size.")
    check_cancel(cancel)
    output.mkdir()
    entries, digest, copied = [], hashlib.sha256(), 0
    try:
        with source.open("rb", buffering=BUFFER_SIZE) as reader:
            initial = os.fstat(reader.fileno())
            while copied < size:
                check_cancel(cancel)
                name = f"part-{len(entries) + 1:06d}.bin"
                part_hash, amount = hashlib.sha256(), 0
                target_size = min(part_size, size - copied)
                with (output / name).open("xb", buffering=BUFFER_SIZE) as writer:
                    while amount < target_size:
                        check_cancel(cancel)
                        chunk = reader.read(
                            min(BUFFER_SIZE, part_size - amount, size - copied)
                        )
                        if not chunk:
                            raise OSError("Input changed or ended unexpectedly.")
                        writer.write(chunk)
                        digest.update(chunk)
                        part_hash.update(chunk)
                        amount += len(chunk)
                        copied += len(chunk)
                        if cancel is not None and hasattr(cancel, "record_bytes"):
                            cancel.record_bytes(len(chunk))
                        if progress:
                            progress(min(99, copied / max(size, 1) * 100))
                    writer.flush()
                    os.fsync(writer.fileno())
                entries.append(
                    {"name": name, "size": amount, "sha256": part_hash.hexdigest()}
                )
            final = os.fstat(reader.fileno())
            if reader.read(1) or (initial.st_size, initial.st_mtime_ns) != (
                final.st_size,
                final.st_mtime_ns,
            ):
                raise OSError("Input changed during splitting.")
        check_cancel(cancel)
        manifest = {
            "version": 1,
            "name": source.name,
            "size": size,
            "part_size": part_size,
            "sha256": digest.hexdigest(),
            "parts": entries,
        }
        write_json(output / "manifest.json", manifest)
        if progress:
            progress(100)
        return manifest
    except BaseException:
        shutil.rmtree(output)
        raise


def digest_valid(value):
    return (
        isinstance(value, str)
        and len(value) == 64
        and all(c in "0123456789abcdef" for c in value)
    )


def join_parts(
    manifest_path, output, cancel=None, progress=None, max_output=DEFAULT_LIMIT
):
    """Validate every part and the complete digest before publishing a NEW file."""
    started = time.perf_counter()
    manifest_path, output = Path(manifest_path), Path(output)
    data = read_json(manifest_path)
    if (
        not isinstance(data, dict)
        or type(data.get("version")) is not int
        or data["version"] != 1
    ):
        raise ValueError("Unsupported split-file manifest.")
    size, part_size, parts = data.get("size"), data.get("part_size"), data.get("parts")
    if (
        type(size) is not int
        or size < 0
        or type(part_size) is not int
        or not 1 <= part_size <= 1024**4
        or not isinstance(parts, list)
        or len(parts) > MAX_PARTS
        or not digest_valid(data.get("sha256"))
    ):
        raise ValueError("Invalid split-file manifest.")
    validate_options(6, max_output)
    if max_output and size > max_output:
        raise ValueError("Joined file exceeds the configured output limit.")
    if len(parts) != (size + part_size - 1) // part_size:
        raise ValueError("Missing or extra parts in manifest.")
    for index, part in enumerate(parts):
        check_cancel(cancel)
        if (
            not isinstance(part, dict)
            or part.get("name") != f"part-{index + 1:06d}.bin"
            or type(part.get("size")) is not int
            or part["size"] != min(part_size, size - index * part_size)
            or not digest_valid(part.get("sha256"))
        ):
            raise ValueError("Invalid part entry.")
        if (
            regular_file(manifest_path.parent / part["name"]).stat().st_size
            != part["size"]
        ):
            raise OSError("Part size mismatch.")
    if os.path.lexists(output):
        raise FileExistsError("Choose a new joined filename.")
    temporary, copied, digest = None, 0, hashlib.sha256()
    try:
        with tempfile.NamedTemporaryFile(
            mode="w+b", buffering=BUFFER_SIZE, dir=output.parent, delete=False
        ) as writer:
            temporary = Path(writer.name)
            for part in parts:
                part_hash, amount = hashlib.sha256(), 0
                with regular_file(manifest_path.parent / part["name"]).open(
                    "rb", buffering=BUFFER_SIZE
                ) as reader:
                    while amount < part["size"]:
                        check_cancel(cancel)
                        chunk = reader.read(min(BUFFER_SIZE, part["size"] - amount))
                        if not chunk:
                            raise OSError("Part ended unexpectedly.")
                        writer.write(chunk)
                        digest.update(chunk)
                        part_hash.update(chunk)
                        amount += len(chunk)
                        copied += len(chunk)
                        if cancel is not None and hasattr(cancel, "record_bytes"):
                            cancel.record_bytes(len(chunk))
                        if progress:
                            progress(min(99, copied / max(size, 1) * 100))
                    if reader.read(1) or not hmac.compare_digest(
                        part_hash.hexdigest(), part["sha256"]
                    ):
                        raise OSError(
                            "Part checksum mismatch; output was not published."
                        )
            if not hmac.compare_digest(digest.hexdigest(), data["sha256"]):
                raise OSError("Whole-file checksum mismatch.")
            writer.flush()
            os.fsync(writer.fileno())
        check_cancel(cancel)
        publish_file(temporary, output, cancel)
        if progress:
            progress(100)
        return Stats(size, size, time.perf_counter() - started, False, "joined")
    finally:
        if temporary is not None:
            with suppress(OSError):
                temporary.unlink()


def inventory(inputs, cancel=None):
    """Count regular files and empty folders without following links."""
    count, folders, size, seen = 0, 0, 0, set()
    for value in inputs:
        source = Path(value)
        candidates = [source]
        while candidates:
            check_cancel(cancel)
            path = candidates.pop()
            key = os.path.normcase(str(path.absolute()))
            if key in seen:
                continue
            seen.add(key)
            mode = path.lstat().st_mode
            if stat.S_ISDIR(mode):
                folders += 1
                with os.scandir(path) as entries:
                    for entry in entries:
                        candidates.append(Path(entry.path))
                        if len(seen) + len(candidates) > 100_000:
                            raise ValueError("Inventory exceeds 100,000 entries.")
            elif stat.S_ISREG(mode):
                count += 1
                size += path.stat().st_size
            else:
                raise OSError("Inputs contain links or special files.")
            if len(seen) > 100_000:
                raise ValueError("Inventory exceeds 100,000 entries.")
    return {"files": count, "folders": folders, "bytes": size}


def benchmark(source, directory, level=6, cancel=None, progress=None):
    """Compare real full-file compression; all temporary results are removed."""
    source, directory = regular_file(source), Path(directory)
    results = []
    with tempfile.TemporaryDirectory(prefix=".codec-compare-", dir=directory) as work:
        for index, format in enumerate(("gzip", "bzip2", "xz", "zip")):
            check_cancel(cancel)

            def update(value, index=index):
                if progress:
                    progress((index + value / 100) / 4 * 100)

            stats = process_file(
                source,
                Path(work) / (format + EXTENSIONS[format]),
                format=format,
                level=level,
                cancel=cancel,
                progress=update,
            )
            results.append(asdict(stats))
    return results


def convert_archive(
    source,
    output,
    format,
    level=6,
    cancel=None,
    progress=None,
    max_output=DEFAULT_LIMIT,
):
    """Convert ordinary ZIP/TAR archives through a bounded temporary extraction."""
    started = time.perf_counter()
    validate_options(level, max_output)
    source, output = regular_file(source), Path(output)
    if detect_format(source) not in ARCHIVE_FORMATS or format not in ARCHIVE_FORMATS:
        raise ValueError("Conversion supports unencrypted ZIP and TAR variants.")
    if os.path.lexists(output):
        raise FileExistsError("Choose a new archive filename.")

    def extracted(value):
        if progress:
            progress(value / 2)

    def encoded(value):
        if progress:
            progress(50 + value / 2)

    with tempfile.TemporaryDirectory(
        prefix=".archive-convert-", dir=output.parent
    ) as work:
        root = Path(work) / "contents"
        decoded = process_file(
            source, root, True, cancel=cancel, progress=extracted, max_output=max_output
        )
        entries = []
        for path in root.rglob("*"):
            check_cancel(cancel)
            entries.append(path)
            if len(entries) > 100_000:
                raise ValueError("Converted archive exceeds the entry limit.")
        entries.sort()
        if format == "zip" and entries:
            stats = create_zip(
                sorted(root.iterdir()), output, level, cancel=cancel, progress=encoded
            )
        else:
            temporary = None
            try:
                with tempfile.NamedTemporaryFile(
                    mode="w+b", buffering=BUFFER_SIZE, dir=output.parent, delete=False
                ) as destination:
                    temporary = Path(destination.name)
                    if format == "zip":
                        import zipfile

                        with zipfile.ZipFile(destination, "w"):
                            pass
                    else:
                        with codec_stream(destination, format, level=level) as codec:
                            with tarfile.open(
                                fileobj=codec, mode="w|", format=tarfile.PAX_FORMAT
                            ) as archive:
                                copied = 0
                                for path in entries:
                                    check_cancel(cancel)
                                    info = tarfile.TarInfo(
                                        path.relative_to(root).as_posix()
                                    )
                                    safe_member_path(info.name)
                                    info.mode = 0o755 if path.is_dir() else 0o644
                                    if path.is_dir():
                                        info.type = tarfile.DIRTYPE
                                        archive.addfile(info)
                                    else:
                                        info.size = path.stat().st_size
                                        with path.open(
                                            "rb", buffering=BUFFER_SIZE
                                        ) as reader:
                                            archive.addfile(
                                                info,
                                                CheckedReader(
                                                    reader,
                                                    cancel,
                                                    lambda amount, base=copied: encoded(
                                                        min(
                                                            99,
                                                            (base + amount)
                                                            / max(
                                                                decoded.output_size, 1
                                                            )
                                                            * 100,
                                                        )
                                                    ),
                                                ),
                                            )
                                        copied += info.size
                                        encoded(
                                            min(
                                                99,
                                                copied
                                                / max(decoded.output_size, 1)
                                                * 100,
                                            )
                                        )
                    destination.flush()
                    os.fsync(destination.fileno())
                    size = destination.tell()
                check_cancel(cancel)
                publish_file(temporary, output, cancel)
                stats = Stats(
                    decoded.output_size,
                    size,
                    time.perf_counter() - started,
                    False,
                    format,
                    decoded.files,
                )
            finally:
                if temporary is not None:
                    with suppress(OSError):
                        temporary.unlink()
    if progress:
        progress(100)
    return Stats(
        stats.input_size,
        stats.output_size,
        time.perf_counter() - started,
        False,
        format,
        stats.files,
    )


def save_queue(path, inputs, settings):
    values = [str(Path(item).absolute()) for item in inputs]
    if len(values) > 100_000:
        raise ValueError("Queue exceeds 100,000 items.")
    data = {"version": 1, "inputs": values, "settings": validated_settings(settings)}
    if len(json.dumps(data).encode("utf-8")) > JSON_LIMIT:
        raise ValueError("Queue file exceeds 16 MiB.")
    write_json(path, data)


def load_queue(path):
    data = read_json(path)
    if (
        not isinstance(data, dict)
        or type(data.get("version")) is not int
        or data["version"] != 1
    ):
        raise ValueError("Unsupported queue session.")
    values = data.get("inputs")
    if (
        not isinstance(values, list)
        or len(values) > 100_000
        or any(
            not isinstance(p, str)
            or not p
            or len(p) > 32768
            or "\0" in p
            or not Path(p).is_absolute()
            for p in values
        )
    ):
        raise ValueError("Invalid queue paths.")
    return [Path(p) for p in dict.fromkeys(values)], validated_settings(
        data.get("settings")
    )


def plan_batch(
    inputs, directory, decompress=False, format="auto", level=6, cancel=None
):
    from archive_engine import build_jobs

    format = "gzip" if format == "auto" and not decompress else format
    jobs = build_jobs(inputs, directory, decompress, format, level)
    totals = inventory(inputs, cancel)
    return {
        "inventory": totals,
        "output_free_bytes": shutil.disk_usage(directory).free,
        "jobs": [
            {**asdict(job), "source": str(job.source), "output": str(job.output)}
            for job in jobs
        ],
    }


def cli(arguments):
    import argparse
    import sys

    parser = argparse.ArgumentParser(description="Streaming file utilities")
    commands = parser.add_subparsers(dest="command", required=True)
    split = commands.add_parser("split", help="Split a file with SHA-256 manifest")
    split.add_argument("source", type=Path)
    split.add_argument("-o", "--output", type=Path, required=True)
    split.add_argument("--part-mib", type=int, default=100)
    join = commands.add_parser("join", help="Rejoin and verify manifest parts")
    join.add_argument("manifest", type=Path)
    join.add_argument("-o", "--output", type=Path, required=True)
    join.add_argument("--max-output-gib", type=int, default=20)
    compare = commands.add_parser("compare", help="Benchmark Gzip/Bzip2/XZ/ZIP")
    compare.add_argument("source", type=Path)
    compare.add_argument("--work-dir", type=Path, default=Path.cwd())
    compare.add_argument("-l", "--level", type=int, choices=range(10), default=6)
    compare.add_argument("--report", type=Path)
    convert = commands.add_parser("convert", help="Convert ordinary ZIP/TAR archives")
    convert.add_argument("source", type=Path)
    convert.add_argument("-o", "--output", type=Path, required=True)
    convert.add_argument(
        "-f", "--format", choices=sorted(ARCHIVE_FORMATS), required=True
    )
    convert.add_argument("-l", "--level", type=int, choices=range(10), default=6)
    convert.add_argument("--max-output-gib", type=int, default=20)
    scan = commands.add_parser("inventory", help="Count files, folders and bytes")
    scan.add_argument("inputs", nargs="+", type=Path)
    plan = commands.add_parser("plan", help="Preview batch names and input totals")
    plan.add_argument("inputs", nargs="+", type=Path)
    plan.add_argument("--output-dir", type=Path, required=True)
    plan.add_argument("-d", "--decompress", action="store_true")
    plan.add_argument("-f", "--format", choices=("auto", *EXTENSIONS), default="auto")
    plan.add_argument("-l", "--level", choices=range(10), type=int, default=6)
    args = parser.parse_args(arguments)
    try:
        limit = getattr(args, "max_output_gib", 20)
        if limit < 0:
            raise ValueError("Output limit must be nonnegative.")
        limit *= 1024**3
        if args.command == "split":
            result = split_file(args.source, args.output, args.part_mib * 1024**2)
        elif args.command == "join":
            result = asdict(join_parts(args.manifest, args.output, max_output=limit))
        elif args.command == "compare":
            result = benchmark(args.source, args.work_dir, args.level)
            if args.report:
                write_json(args.report, result)
        elif args.command == "convert":
            result = asdict(
                convert_archive(
                    args.source, args.output, args.format, args.level, max_output=limit
                )
            )
        elif args.command == "inventory":
            result = inventory(args.inputs)
        else:
            result = plan_batch(
                args.inputs, args.output_dir, args.decompress, args.format, args.level
            )
        print(json.dumps(result, indent=2))
        return 0
    except KeyboardInterrupt:
        print("Interrupted. Completed outputs are kept.", file=sys.stderr)
        return 130
    except Exception as error:
        print(f"Error: {error}", file=sys.stderr)
        return 1
