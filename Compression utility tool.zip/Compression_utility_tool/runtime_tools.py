"""Cooperative worker controls and optional integrations; no Tk dependencies."""

from __future__ import annotations

import threading
import time


class OperationControl:
    """Event-compatible cancellation with a cancellable condition-based pause."""

    def __init__(self):
        self._condition = threading.Condition()
        self.cancelled = False
        self.paused = False
        self.bytes = 0
        self.pause_seconds = 0.0
        self._pause_started = None

    def clear(self):
        with self._condition:
            self.cancelled = self.paused = False
            self.bytes = 0
            self.pause_seconds = 0.0
            self._pause_started = None
            self._condition.notify_all()

    def set(self):
        with self._condition:
            self.cancelled = True
            self._condition.notify_all()

    def is_set(self):
        with self._condition:
            while self.paused and not self.cancelled:
                self._condition.wait()
            return self.cancelled

    def toggle_pause(self):
        with self._condition:
            if self.cancelled:
                return
            if self.paused:
                self.pause_seconds += time.monotonic() - self._pause_started
                self._pause_started = None
            else:
                self._pause_started = time.monotonic()
            self.paused = not self.paused
            self._condition.notify_all()

    def record_bytes(self, amount):
        with self._condition:
            self.bytes += amount

    def snapshot(self):
        with self._condition:
            paused_time = self.pause_seconds
            if self._pause_started is not None:
                paused_time += time.monotonic() - self._pause_started
            return self.bytes, paused_time, self.paused


class TransferMeter:
    def __init__(self, control):
        self.control = control
        self.reset()

    def reset(self):
        self.started = time.monotonic()

    def describe(self, percent):
        amount, paused_time, paused = self.control.snapshot()
        elapsed = max(time.monotonic() - self.started - paused_time, 0.001)
        speed = amount / elapsed / 1024**2
        eta = elapsed * (100 - percent) / percent if 0 < percent < 100 else None
        estimate = (
            f"estimated {eta:.0f}s remaining" if eta is not None else "ETA pending"
        )
        return f"{'Paused · ' if paused else ''}{amount / 1024**2:.1f} MiB streamed · {speed:.1f} MiB/s average · {estimate}"


def aes_zip_class():
    try:
        from pyzipper import AESZipFile
    except ImportError as error:
        raise RuntimeError(
            "Password ZIP support needs pyzipper. Run: python -m pip install -r requirements-optional.txt"
        ) from error
    return AESZipFile
