#!/usr/bin/env python3
"""Desktop GUI and CLI. Keep all package files together; see README.md."""

from __future__ import annotations

import argparse
from contextlib import suppress
import os
from pathlib import Path
import queue
import sys
import threading
from runtime_tools import OperationControl, TransferMeter

# A stale module from an earlier release also shadows Python 3.14's package.
if __name__ == "__main__" and Path(__file__).with_name("compression.py").exists():
    print(
        "Old compression.py found. Extract this update into a NEW folder, "
        "then run Start.bat. Keep archive_engine.py beside compression_utility_tool.py.",
        file=sys.stderr,
    )
    raise SystemExit(1)

from archive_engine import (
    EXTENSIONS,
    PROCESS_ERRORS,
    process_file,
    build_jobs,
    run_jobs,
    inspect_archive,
)
from advanced_tools import (
    create_zip,
    list_members,
    extract_selected,
    sha256_file,
    cli as advanced_cli,
)
from preferences import load_settings, save_settings, compatibility_report
from file_tools import (
    split_file,
    join_parts,
    benchmark,
    convert_archive,
    inventory,
    plan_batch,
    save_queue,
    load_queue,
    cli as file_tools_cli,
)


class CompressorApp:
    """Batch desktop UI. Workers communicate only through thread-safe queues."""

    def __init__(self, root):
        import tkinter as tk
        from tkinter import ttk
        from tkinter import font as tkfont

        self.font_family = tkfont.nametofont("TkDefaultFont", root=root).actual(
            "family"
        )
        self.tk, self.ttk, self.root = tk, ttk, root
        self.busy = False
        self.inputs, self.completed = [], {}
        self.results = queue.Queue()
        self.progress_updates = queue.Queue(maxsize=1)
        self.cancel_event = OperationControl()
        self.meter = TransferMeter(self.cancel_event)
        self.retry_indices = []
        self.controls = []
        self.tools_window = None
        self.tool_controls = []
        self.last_tool_output = None
        self.preferences = load_settings()
        self.dark = self.preferences.get("dark", False)
        self.mode = tk.StringVar(value=self.preferences.get("mode", "compress"))
        self.format = tk.StringVar(value=self.preferences.get("format", "gzip"))
        self.level = tk.IntVar(value=self.preferences.get("level", 6))
        self.preset = tk.StringVar(value=self.preferences.get("preset", "Balanced"))
        self.limit = tk.DoubleVar(value=self.preferences.get("limit", 20))
        downloads = Path.home() / "Downloads"
        self.output_directory = tk.StringVar(
            value=self.preferences.get(
                "output_directory",
                str(downloads if downloads.is_dir() else Path.home()),
            )
        )
        self.status = tk.StringVar(value="Add files or a folder to begin.")
        self.count = tk.StringVar(value="0 items")
        root.title("Compression utility tool")
        root.geometry("1180x820")
        root.minsize(1020, 760)
        root.protocol("WM_DELETE_WINDOW", self.close)
        root.columnconfigure(0, weight=1)
        root.rowconfigure(1, weight=1)
        self.style = ttk.Style(root)
        if "clam" in self.style.theme_names():
            self.style.theme_use("clam")
        header = ttk.Frame(root, padding=(28, 24, 28, 20))
        header.grid(row=0, column=0, sticky="ew")
        header.columnconfigure(0, weight=1)
        ttk.Label(header, text="Compression utility tool", style="Title.TLabel").grid(
            row=0, column=0, sticky="w"
        )
        ttk.Label(
            header,
            text="Compress, organize and restore your files.",
            style="Muted.TLabel",
        ).grid(row=1, column=0, sticky="w", pady=(4, 0))
        self.theme_button = ttk.Button(
            header, text="Dark theme", command=self.toggle_theme
        )
        self.theme_button.grid(row=0, column=3, rowspan=2)
        self.button(header, "Compatibility", self.show_compatibility).grid(
            row=0, column=2, rowspan=2, padx=(0, 8)
        )
        self.button(header, "More tools...", self.more_tools).grid(
            row=0, column=1, rowspan=2, padx=(0, 8)
        )
        body = ttk.Frame(root, padding=(28, 0, 28, 18))
        body.grid(row=1, column=0, sticky="nsew")
        body.columnconfigure(0, weight=1)
        body.rowconfigure(0, weight=1)
        workspace = ttk.Frame(body, padding=20, style="Card.TFrame")
        workspace.grid(row=0, column=0, sticky="nsew", padx=(0, 18))
        workspace.columnconfigure(0, weight=1)
        workspace.rowconfigure(1, weight=3)
        workspace.rowconfigure(3, weight=2)
        toolbar = ttk.Frame(workspace, style="Card.TFrame")
        toolbar.grid(row=0, column=0, sticky="ew", pady=(0, 16))
        queue_heading = ttk.Frame(toolbar, style="Card.TFrame")
        queue_heading.pack(fill="x", pady=(0, 14))
        ttk.Label(queue_heading, text="Your files", style="Section.TLabel").pack(
            side="left"
        )
        ttk.Label(queue_heading, textvariable=self.count, style="Badge.TLabel").pack(
            side="right"
        )
        self.button(
            toolbar, "+ Add files", self.add_files, style="Accent.TButton"
        ).pack(side="left", padx=(0, 6))
        self.button(toolbar, "Add folder", self.add_folder).pack(
            side="left", padx=(0, 6)
        )
        self.button(toolbar, "Remove", self.remove_selected).pack(
            side="left", padx=(0, 6)
        )
        self.button(toolbar, "Clear", self.clear_queue).pack(side="left")
        table = ttk.Frame(workspace, style="Card.TFrame")
        table.grid(row=1, column=0, sticky="nsew")
        table.columnconfigure(0, weight=1)
        table.rowconfigure(0, weight=1)
        self.tree = ttk.Treeview(
            table,
            columns=("name", "size", "status", "output"),
            show="headings",
            selectmode="extended",
        )
        for name, label, width in [
            ("name", "File or folder", 240),
            ("size", "Size", 85),
            ("status", "Status", 100),
            ("output", "Output", 200),
        ]:
            self.tree.heading(name, text=label)
            self.tree.column(
                name, width=width, minwidth=70, stretch=name in ("name", "output")
            )
        self.tree.grid(row=0, column=0, sticky="nsew")
        vertical = ttk.Scrollbar(table, command=self.tree.yview)
        vertical.grid(row=0, column=1, sticky="ns")
        horizontal = ttk.Scrollbar(table, orient="horizontal", command=self.tree.xview)
        horizontal.grid(row=1, column=0, sticky="ew")
        self.tree.configure(yscrollcommand=vertical.set, xscrollcommand=horizontal.set)
        self.tree.bind("<Double-1>", lambda _event: self.preview())
        self.empty_state = ttk.Frame(table, style="Card.TFrame", padding=16)
        ttk.Label(
            self.empty_state,
            text="Your queue is ready",
            style="EmptyTitle.TLabel",
        ).pack()
        ttk.Label(
            self.empty_state,
            text="Add files or a folder to start your queue.",
            style="CardMuted.TLabel",
        ).pack(pady=(8, 14))
        self.button(
            self.empty_state, "Browse files", self.add_files, style="Accent.TButton"
        ).pack()
        self.empty_state.place(relx=0.5, rely=0.52, anchor="center")
        actions = ttk.Frame(workspace, style="Card.TFrame")
        actions.grid(row=2, column=0, sticky="ew", pady=10)
        self.button(actions, "Preview archive", self.preview).pack(
            side="left", padx=(0, 6)
        )
        self.button(actions, "Verify integrity", lambda: self.preview(True)).pack(
            side="left", padx=(0, 6)
        )
        self.button(actions, "Open output", self.open_output).pack(
            side="left", padx=(0, 6)
        )
        self.button(actions, "Export results...", self.export_results).pack(side="left")
        self.tabs = ttk.Notebook(workspace)
        self.tabs.grid(row=3, column=0, sticky="nsew")
        self.log = self.text_tab("Results")
        self.preview_text = self.text_tab("Archive preview")
        self.append_log("Ready. Add files, choose an output folder, then start.\n")
        settings = ttk.Frame(body, padding=18, style="Card.TFrame", width=260)
        settings.grid(row=0, column=1, sticky="ns")
        ttk.Label(settings, text="Operation", style="Section.TLabel").pack(
            anchor="w", pady=(0, 14)
        )
        modes = ttk.Frame(settings, style="Card.TFrame")
        modes.pack(fill="x", pady=(0, 18))
        for label, value in [("Compress", "compress"), ("Decompress", "decompress")]:
            control = ttk.Radiobutton(
                modes,
                text=label,
                value=value,
                variable=self.mode,
                command=self.mode_changed,
                style="Segment.TRadiobutton",
            )
            control.pack(side="left", fill="x", expand=True)
            self.controls.append(control)
        self.label(settings, "Format")
        self.format_box = ttk.Combobox(
            settings,
            textvariable=self.format,
            values=tuple(EXTENSIONS),
            state="readonly",
            width=23,
        )
        self.format_box.pack(fill="x", pady=(4, 14))
        self.controls.append(self.format_box)
        self.label(settings, "Compression preset")
        self.preset_box = ttk.Combobox(
            settings,
            textvariable=self.preset,
            values=("Fast", "Balanced", "Smallest", "Custom"),
            state="readonly",
            width=23,
        )
        self.preset_box.pack(fill="x", pady=(4, 8))
        self.preset_box.bind("<<ComboboxSelected>>", self.preset_changed)
        self.controls.append(self.preset_box)
        self.level_box = ttk.Spinbox(
            settings,
            from_=0,
            to=9,
            textvariable=self.level,
            width=5,
            command=lambda: self.preset.set("Custom"),
        )
        self.level_box.pack(anchor="w", pady=(0, 14))
        self.level_box.bind("<KeyRelease>", lambda _event: self.preset.set("Custom"))
        self.controls.append(self.level_box)
        self.label(settings, "Extraction limit (GiB)")
        self.limit_box = ttk.Spinbox(
            settings, from_=0, to=10000, textvariable=self.limit, width=23
        )
        self.limit_box.pack(fill="x", pady=(4, 4))
        self.controls.append(self.limit_box)
        ttk.Label(settings, text="0 = unlimited", style="CardMuted.TLabel").pack(
            anchor="w", pady=(0, 16)
        )
        self.label(settings, "Output folder")
        self.output_entry = ttk.Entry(
            settings, textvariable=self.output_directory, width=25
        )
        self.output_entry.pack(fill="x", pady=(4, 8))
        self.controls.append(self.output_entry)
        self.output_button = self.button(
            settings, "Choose output folder...", self.choose_output
        )
        self.output_button.pack(fill="x", pady=(0, 14))
        ttk.Label(
            settings,
            text="Outputs are saved as new files.\nConflicting names get a numbered suffix.",
            style="CardMuted.TLabel",
            wraplength=220,
        ).pack(anchor="w", pady=(0, 20))
        footer = ttk.Frame(root, padding=(28, 0, 28, 20))
        footer.grid(row=2, column=0, sticky="ew")
        footer.columnconfigure(0, weight=1)
        self.progress = ttk.Progressbar(footer, mode="determinate", maximum=100)
        self.progress.grid(row=0, column=0, columnspan=5, sticky="ew", pady=(0, 18))
        self.start_button = self.button(
            footer, "Start compression", self.start, style="Primary.TButton"
        )
        self.start_button.grid(row=1, column=1, padx=(0, 8), pady=(0, 8))
        self.cancel_button = ttk.Button(
            footer, text="Cancel", command=self.cancel, state="disabled"
        )
        self.cancel_button.grid(row=1, column=2, pady=(0, 8))
        self.pause_button = ttk.Button(
            footer, text="Pause", command=self.toggle_pause, state="disabled"
        )
        self.pause_button.grid(row=1, column=3, padx=(8, 0), pady=(0, 8))
        self.retry_button = ttk.Button(
            footer, text="Retry unfinished", command=self.retry_failed, state="disabled"
        )
        self.retry_button.grid(row=1, column=4, padx=(8, 0), pady=(0, 8))
        self.transfer_status = tk.StringVar(value="")
        ttk.Label(footer, textvariable=self.transfer_status).grid(
            row=2, column=0, columnspan=5, sticky="w", pady=(4, 0)
        )
        ttk.Label(
            footer, textvariable=self.status, style="Muted.TLabel", wraplength=400
        ).grid(row=1, column=0, sticky="w", padx=(0, 16))
        root.bind("<Control-o>", lambda _event: self.add_files())
        root.bind("<Delete>", lambda _event: self.remove_selected())
        root.bind("<Escape>", lambda _event: self.cancel())
        self.apply_theme()
        if self.mode.get() == "decompress":
            self.format_box.configure(values=("auto", *EXTENSIONS))
            self.start_button.configure(text="Start decompression")
        elif self.format.get() == "auto":
            self.format.set("gzip")
        self.update_controls()
        root.after(100, self.poll)

    def button(self, parent, text, command, **options):
        control = self.ttk.Button(parent, text=text, command=command, **options)
        self.controls.append(control)
        return control

    def label(self, parent, text):
        self.ttk.Label(parent, text=text, style="CardHeading.TLabel").pack(anchor="w")

    def text_tab(self, title):
        frame = self.ttk.Frame(self.tabs)
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)
        text = self.tk.Text(
            frame,
            wrap="word",
            borderwidth=0,
            highlightthickness=0,
            padx=14,
            pady=12,
            font="TkFixedFont",
            state="disabled",
            height=10,
        )
        text.grid(row=0, column=0, sticky="nsew")
        scroll = self.ttk.Scrollbar(frame, command=text.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        text.configure(yscrollcommand=scroll.set)
        self.tabs.add(frame, text=title)
        return text

    def apply_theme(self):
        background, card, foreground, muted, selected = (
            ("#101722", "#192330", "#edf2f8", "#a1b0c1", "#263e61")
            if self.dark
            else ("#edf1f7", "#ffffff", "#18263b", "#64748b", "#e3edff")
        )
        self.root.configure(bg=background)
        if self.tools_window is not None and self.tools_window.winfo_exists():
            self.tools_window.configure(bg=background)
        self.style.configure(
            ".",
            font=(self.font_family, 10),
            background=background,
            foreground=foreground,
        )
        self.style.configure("TFrame", background=background)
        self.style.configure("TLabel", background=background, foreground=foreground)
        self.style.configure("Title.TLabel", font=(self.font_family, 24, "bold"))
        self.style.configure("Muted.TLabel", foreground=muted)
        self.style.configure(
            "Section.TLabel", background=card, font=(self.font_family, 14, "bold")
        )
        self.style.configure(
            "EmptyTitle.TLabel",
            background=card,
            foreground=foreground,
            font=(self.font_family, 13, "bold"),
        )
        self.style.configure(
            "Badge.TLabel",
            background=selected,
            foreground=foreground,
            padding=(10, 4),
            font=(self.font_family, 9),
        )
        self.style.configure("Card.TFrame", background=card)
        self.style.configure(
            "CardHeading.TLabel",
            background=card,
            foreground=foreground,
            font=(self.font_family, 10, "bold"),
        )
        self.style.configure(
            "CardMuted.TLabel",
            background=card,
            foreground=muted,
            font=(self.font_family, 9),
        )
        self.style.configure("TRadiobutton", background=card, foreground=foreground)
        self.style.map("TRadiobutton", background=[("active", card)])
        self.style.layout(
            "Segment.TRadiobutton",
            [
                (
                    "Radiobutton.padding",
                    {
                        "sticky": "nswe",
                        "children": [("Radiobutton.label", {"sticky": "nswe"})],
                    },
                )
            ],
        )
        self.style.configure(
            "Segment.TRadiobutton",
            background=background,
            foreground=muted,
            padding=(10, 10),
            anchor="center",
            font=(self.font_family, 10, "bold"),
        )
        self.style.map(
            "Segment.TRadiobutton",
            background=[("selected", selected), ("active", selected)],
            foreground=[("disabled", muted), ("selected", foreground)],
        )
        self.style.configure(
            "TButton",
            padding=(12, 9),
            background=card,
            foreground=foreground,
            borderwidth=0,
            relief="flat",
            focusthickness=1,
            focuscolor=selected,
        )
        self.style.map(
            "TButton",
            background=[("active", selected), ("disabled", background)],
            foreground=[("disabled", muted)],
        )
        self.style.configure(
            "Accent.TButton",
            background=selected,
            foreground=foreground,
            font=(self.font_family, 10, "bold"),
        )
        self.style.map(
            "Accent.TButton",
            background=[
                ("disabled", background),
                ("active", "#314d73" if self.dark else "#d4e3fc"),
            ],
            foreground=[("disabled", muted)],
        )
        self.style.configure(
            "Primary.TButton",
            background="#3976ed",
            foreground="white",
            font=(self.font_family, 10, "bold"),
        )
        self.style.map(
            "Primary.TButton",
            background=[("disabled", card), ("active", "#2b62d4")],
            foreground=[("disabled", muted)],
        )
        self.style.configure(
            "Treeview",
            background=card,
            fieldbackground=card,
            foreground=foreground,
            rowheight=40,
            borderwidth=0,
            lightcolor=card,
            darkcolor=card,
            bordercolor=card,
        )
        self.style.configure(
            "Treeview.Heading",
            background=card,
            foreground=muted,
            padding=(12, 12),
            relief="flat",
            borderwidth=0,
            font=(self.font_family, 9, "bold"),
        )
        self.style.map(
            "Treeview",
            background=[("selected", selected)],
            foreground=[("selected", foreground)],
        )
        self.style.configure(
            "TEntry",
            fieldbackground=background,
            foreground=foreground,
            padding=7,
            borderwidth=0,
            lightcolor=background,
            darkcolor=background,
        )
        self.style.configure(
            "TCheckbutton", background=background, foreground=foreground
        )
        self.style.map("TCheckbutton", background=[("active", background)])
        self.style.configure(
            "TCombobox",
            fieldbackground=background,
            foreground=foreground,
            padding=7,
            borderwidth=0,
            lightcolor=background,
            darkcolor=background,
            bordercolor=background,
            arrowsize=12,
            arrowcolor=muted,
        )
        self.style.configure(
            "TSpinbox",
            fieldbackground=background,
            foreground=foreground,
            padding=6,
            borderwidth=0,
            lightcolor=background,
            darkcolor=background,
            bordercolor=background,
            arrowsize=10,
            arrowcolor=muted,
        )
        self.style.configure(
            "TNotebook",
            background=card,
            borderwidth=0,
            lightcolor=card,
            darkcolor=card,
            bordercolor=card,
        )
        self.style.configure(
            "TNotebook.Tab",
            background=card,
            foreground=muted,
            padding=(16, 10),
            borderwidth=0,
            lightcolor=card,
            darkcolor=card,
            bordercolor=card,
        )
        self.style.map(
            "TNotebook.Tab",
            background=[("selected", selected)],
            foreground=[("selected", foreground)],
            lightcolor=[("selected", selected), ("!selected", card)],
            darkcolor=[("selected", selected), ("!selected", card)],
            bordercolor=[("selected", selected), ("!selected", card)],
        )
        self.style.configure(
            "TScrollbar",
            background=selected,
            troughcolor=card,
            arrowcolor=muted,
            bordercolor=card,
            lightcolor=card,
            darkcolor=card,
            borderwidth=0,
            arrowsize=8,
        )
        for orientation, sticky in (("Vertical", "ns"), ("Horizontal", "ew")):
            self.style.layout(
                f"{orientation}.TScrollbar",
                [
                    (
                        f"{orientation}.Scrollbar.trough",
                        {
                            "sticky": "nswe",
                            "children": [
                                (
                                    f"{orientation}.Scrollbar.thumb",
                                    {"sticky": sticky, "expand": True},
                                )
                            ],
                        },
                    )
                ],
            )
        self.style.map(
            "TScrollbar", background=[("active", muted), ("!active", selected)]
        )
        self.style.configure(
            "Horizontal.TProgressbar",
            background="#3976ed",
            troughcolor=card,
            borderwidth=0,
            thickness=5,
            lightcolor=background,
            darkcolor=background,
            bordercolor=background,
        )
        self.style.map(
            "TCombobox",
            fieldbackground=[("readonly", background), ("disabled", background)],
            foreground=[("disabled", muted), ("readonly", foreground)],
        )
        for text in (self.log, self.preview_text):
            text.configure(
                bg=card,
                fg=foreground,
                insertbackground=foreground,
                selectbackground=selected,
            )
        for tag, color in (
            ("Completed", "#68d8b1" if self.dark else "#167453"),
            ("Failed", "#ff9caa" if self.dark else "#bc354b"),
            ("Running", "#91b7ff" if self.dark else "#285cb5"),
        ):
            self.tree.tag_configure(tag, foreground=color)
        self.theme_button.configure(text="Light theme" if self.dark else "Dark theme")

    def toggle_theme(self):
        self.dark = not self.dark
        self.apply_theme()

    def update_controls(self):
        for control in self.controls + self.tool_controls:
            control.state(["disabled"] if self.busy else ["!disabled"])
        self.cancel_button.state(["!disabled"] if self.busy else ["disabled"])
        self.pause_button.state(["!disabled"] if self.busy else ["disabled"])
        self.pause_button.configure(
            text="Resume" if self.cancel_event.paused else "Pause"
        )
        self.retry_button.state(
            ["!disabled"] if self.retry_indices and not self.busy else ["disabled"]
        )
        if self.tools_window is not None and self.tools_window.winfo_exists():
            self.tools_cancel.state(["!disabled"] if self.busy else ["disabled"])
            if not self.busy:
                self.tool_scope.configure(state="readonly")
        if not self.busy:
            for box in (self.format_box, self.preset_box):
                box.configure(state="readonly")
            decompress = self.mode.get() == "decompress"
            for control in (self.level_box, self.preset_box):
                control.state(["disabled"] if decompress else ["!disabled"])
            self.limit_box.state(["!disabled"] if decompress else ["disabled"])
            if not self.inputs:
                self.start_button.state(["disabled"])

    def mode_changed(self):
        self.format.set("auto" if self.mode.get() == "decompress" else "gzip")
        self.format_box.configure(
            values=("auto", *EXTENSIONS)
            if self.mode.get() == "decompress"
            else tuple(EXTENSIONS)
        )
        self.start_button.configure(
            text="Start decompression"
            if self.mode.get() == "decompress"
            else "Start compression"
        )
        self.update_controls()

    def preset_changed(self, _event=None):
        value = {"Fast": 1, "Balanced": 6, "Smallest": 9}.get(self.preset.get())
        if value is not None:
            self.level.set(value)

    def add_paths(self, paths):
        if self.busy:
            return
        existing = {os.path.normcase(str(path.resolve())) for path in self.inputs}
        for value in paths:
            path = Path(value)
            key = os.path.normcase(str(path.resolve()))
            if key not in existing:
                self.inputs.append(path)
                existing.add(key)
        self.refresh_queue()

    def add_files(self):
        from tkinter import filedialog

        if not self.busy:
            self.add_paths(
                filedialog.askopenfilenames(
                    parent=self.root, title="Add files to the queue"
                )
            )

    def add_folder(self):
        from tkinter import filedialog

        if self.busy or self.mode.get() != "compress":
            return
        path = filedialog.askdirectory(parent=self.root, title="Add a folder to ZIP")
        if path:
            self.format.set("zip")
            self.add_paths([path])

    def refresh_queue(self):
        self.tree.delete(*self.tree.get_children())
        self.completed.clear()
        self.retry_indices = []
        for index, path in enumerate(self.inputs):
            try:
                size = (
                    "Folder"
                    if path.is_dir()
                    else f"{path.stat().st_size / 1024:,.1f} KiB"
                )
            except OSError:
                size = "Unavailable"
            self.tree.insert(
                "", "end", iid=str(index), values=(path.name, size, "Queued", "")
            )
        if self.inputs:
            self.empty_state.place_forget()
        else:
            self.empty_state.place(relx=0.5, rely=0.52, anchor="center")
        self.count.set(f"{len(self.inputs)} item{'s' if len(self.inputs) != 1 else ''}")
        self.update_controls()

    def remove_selected(self):
        if not self.busy:
            for index in sorted(
                (int(value) for value in self.tree.selection()), reverse=True
            ):
                del self.inputs[index]
            self.refresh_queue()

    def clear_queue(self):
        if not self.busy:
            self.inputs.clear()
            self.refresh_queue()

    def choose_output(self):
        from tkinter import filedialog

        if not self.busy:
            path = filedialog.askdirectory(
                parent=self.root,
                title="Choose output folder",
                initialdir=self.output_directory.get(),
            )
            if path:
                self.output_directory.set(path)

    def publish_progress(self, value):
        with suppress(queue.Empty):
            self.progress_updates.get_nowait()
        with suppress(queue.Full):
            self.progress_updates.put_nowait(value)

    def begin(self, target, args=(), result_kind=None):
        self.busy = True
        self.cancel_event.clear()
        self.meter.reset()
        self.transfer_status.set("")
        self.progress["value"] = 0
        while not self.progress_updates.empty():
            self.progress_updates.get_nowait()
        self.update_controls()

        def worker():
            try:
                result = target(*args)
                if result_kind is not None:
                    self.results.put((result_kind, result))
            except Exception as error:
                self.results.put(("error", str(error)))

        try:
            threading.Thread(
                target=worker, name="file-compressor", daemon=False
            ).start()
        except RuntimeError as error:
            self.results.put(("error", str(error)))

    def start(self):
        if self.busy or not self.inputs:
            return
        try:
            decompress = self.mode.get() == "decompress"
            level = self.level.get() if not decompress else 6
            limit = self.tool_limit() if decompress else 20 * 1024**3
            if not 0 <= level <= 9:
                raise ValueError("Use a compression level from 0–9.")
            jobs = build_jobs(
                self.inputs,
                self.output_directory.get(),
                decompress,
                self.format.get(),
                level,
            )
        except Exception as error:
            self.status.set(f"Error: {error}")
            return
        self.retry_indices = []
        self.completed.clear()
        for index, job in enumerate(jobs):
            self.tree.set(str(index), "status", "Queued")
            self.tree.item(str(index), tags=())
            self.tree.set(str(index), "output", job.output.name)
        self.status.set(f"Starting {len(jobs)} jobs...")
        self.begin(self.batch_worker, (jobs, limit))

    def batch_worker(self, jobs, limit, indices=None):
        indices = list(range(len(jobs))) if indices is None else indices
        results = run_jobs(
            jobs,
            self.cancel_event,
            self.publish_progress,
            on_result=lambda index, result: self.results.put(
                ("job", (indices[index], result))
            ),
            on_started=lambda index: self.results.put(("started", indices[index])),
            max_output=limit,
        )
        self.results.put(("complete", results))

    def preview(self, verify=False):
        if self.busy:
            return
        selected = self.tree.selection()
        if len(selected) != 1:
            self.status.set("Select one archive in the queue to preview or verify.")
            return
        path = self.inputs[int(selected[0])]
        if path.is_dir():
            self.status.set("Select an archive file, not a folder.")
            return
        try:
            limit = self.tool_limit()
        except Exception as error:
            self.status.set(f"Error: {error}")
            return
        self.status.set(
            "Verifying archive..." if verify else "Reading archive preview..."
        )
        self.begin(inspect_archive, (path, verify, self.cancel_event, limit), "preview")

    def write_text(self, widget, text, append=False):
        widget.configure(state="normal")
        if not append:
            widget.delete("1.0", "end")
        widget.insert("end", text)
        widget.see("end")
        widget.configure(state="disabled")

    def append_log(self, text):
        self.write_text(self.log, text, True)

    def poll(self):
        if self.busy:
            self.transfer_status.set(self.meter.describe(float(self.progress["value"])))
        try:
            value = self.progress_updates.get_nowait()
            self.progress["value"] = value
            if (
                self.busy
                and not self.cancel_event.cancelled
                and not self.cancel_event.paused
            ):
                self.status.set(f"Processing... {value:.0f}%")
        except queue.Empty:
            pass
        for _ in range(100):
            try:
                kind, payload = self.results.get_nowait()
            except queue.Empty:
                break
            if kind not in ("started", "job"):
                self.busy = False
            if kind == "started":
                self.tree.set(str(payload), "status", "Running")
                self.tree.item(str(payload), tags=("Running",))
            elif kind == "job":
                index, result = payload
                self.tree.set(str(index), "status", result.status)
                self.tree.item(str(index), tags=(result.status,))
                if result.stats:
                    self.completed[index] = result.job.output
                details = result.stats.report() if result.stats else result.error
                self.append_log(
                    f"\n{result.job.source.name} — {result.status}\n{details}\n"
                )
            elif kind == "complete":
                self.retry_indices = [
                    int(item)
                    for item in self.tree.get_children()
                    if self.tree.set(item, "status")
                    in ("Failed", "Cancelled", "Queued", "Not run")
                ]
                done = sum(result.status == "Completed" for result in payload)
                failed = sum(result.status == "Failed" for result in payload)
                stopped = self.cancel_event.cancelled
                for item in self.tree.get_children():
                    if self.tree.set(item, "status") == "Queued":
                        self.tree.set(item, "status", "Not run")
                if not stopped:
                    self.progress["value"] = 100
                self.status.set(
                    f"{'Stopped' if stopped else 'Finished'} · {done} completed · {failed} failed"
                )
                self.tabs.select(0)
            elif kind == "preview":
                self.write_text(self.preview_text, payload)
                self.tabs.select(1)
                self.status.set("Archive inspection completed.")
                self.progress["value"] = 100
            elif kind == "members":
                self.member_source, self.member_records = payload
                self.member_label.set(f"Archive: {self.member_source.name}")
                self.render_members()
                self.status.set(f"Loaded {len(self.member_records):,} archive entries.")
            elif kind == "tool":
                message, output = payload
                if output is not None:
                    self.last_tool_output = Path(output)
                self.append_log("\n" + message + "\n")
                self.tabs.select(0)
                self.progress["value"] = 100
                self.status.set("Tool completed. See Results.")
            elif kind == "error":
                self.status.set(f"Error: {payload}")
                self.append_log(f"\nError: {payload}\n")
            if kind not in ("started", "job"):
                self.update_controls()
        self.root.after(100, self.poll)

    def toggle_pause(self):
        if self.busy:
            self.cancel_event.toggle_pause()
            self.status.set(
                "Paused. Choose Resume to continue."
                if self.cancel_event.paused
                else "Resuming..."
            )
            self.update_controls()

    def retry_failed(self):
        if self.busy or not self.retry_indices:
            return
        try:
            indices = list(self.retry_indices)
            jobs = build_jobs(
                [self.inputs[i] for i in indices],
                self.output_directory.get(),
                self.mode.get() == "decompress",
                self.format.get(),
                self.level.get(),
            )
            limit = self.tool_limit()
            for index, job in zip(indices, jobs, strict=True):
                self.tree.set(str(index), "status", "Queued")
                self.tree.item(str(index), tags=())
                self.tree.set(str(index), "output", job.output.name)
            self.retry_indices = []
            self.begin(self.batch_worker, (jobs, limit, indices))
        except Exception as error:
            self.status.set(f"Error: {error}")

    def cancel(self):
        if self.busy:
            self.cancel_event.set()
            self.status.set(
                "Cancelling the current job... completed outputs will be kept."
            )
            self.cancel_button.state(["disabled"])

    def open_output(self):
        import subprocess

        if self.busy:
            return
        selected = self.tree.selection()
        output = self.completed.get(int(selected[0])) if len(selected) == 1 else None
        output = output or self.last_tool_output
        path = (
            (output if output.is_dir() else output.parent)
            if output
            else Path(self.output_directory.get())
        )
        try:
            if not path.is_dir():
                raise OSError("Output folder does not exist.")
            if os.name == "nt":
                os.startfile(str(path))
            else:
                subprocess.Popen(
                    ["open" if sys.platform == "darwin" else "xdg-open", str(path)]
                )
        except OSError as error:
            self.status.set(f"Could not open folder: {error}")

    def export_results(self):
        from tkinter import filedialog

        if self.busy:
            return
        path = filedialog.asksaveasfilename(
            parent=self.root,
            title="Export results",
            initialfile="compression-results.txt",
            defaultextension=".txt",
        )
        if path:
            try:
                Path(path).write_text(self.log.get("1.0", "end-1c"), encoding="utf-8")
                self.status.set("Results exported.")
            except OSError as error:
                self.status.set(f"Export failed: {error}")

    def more_tools(self):
        if self.busy:
            return
        if self.tools_window is not None and self.tools_window.winfo_exists():
            self.tools_window.lift()
            return
        window = self.tk.Toplevel(self.root)
        self.tools_window = window
        self.tool_controls = []
        self.member_records = []
        self.member_source = None
        window.title("Compression utility tool — More Tools")
        window.configure(bg=self.root.cget("bg"))
        window.geometry("940x660")
        window.minsize(860, 620)
        window.protocol("WM_DELETE_WINDOW", self.close_tools)
        window.columnconfigure(0, weight=1)
        window.rowconfigure(0, weight=1)
        tabs = self.ttk.Notebook(window)
        tabs.grid(row=0, column=0, sticky="nsew", padx=18, pady=18)
        builder = self.ttk.Frame(tabs, padding=20)
        extraction = self.ttk.Frame(tabs, padding=20)
        hashes = self.ttk.Frame(tabs, padding=20)
        tabs.add(builder, text="ZIP builder")
        tabs.add(extraction, text="Extract")
        tabs.add(hashes, text="SHA-256")

        def label(parent, text):
            self.ttk.Label(parent, text=text, wraplength=660).pack(
                anchor="w", pady=(0, 10)
            )

        def button(parent, text, command):
            control = self.ttk.Button(parent, text=text, command=command)
            control.pack(anchor="w", pady=8)
            self.tool_controls.append(control)
            return control

        label(
            builder,
            "Combine queue items into a single ZIP, including unrelated files and folders.",
        )
        self.tool_scope_value = self.tk.StringVar(value="All queued items")
        self.tool_scope = self.ttk.Combobox(
            builder,
            textvariable=self.tool_scope_value,
            values=("All queued items", "Selected queue items"),
            state="readonly",
            width=28,
        )
        self.tool_scope.pack(anchor="w", pady=(0, 20))
        self.tool_controls.append(self.tool_scope)
        label(
            builder,
            "Exclude patterns, separated by commas. Examples: *.tmp, .git, __pycache__",
        )
        self.tool_excludes = self.tk.StringVar()
        entry = self.ttk.Entry(builder, textvariable=self.tool_excludes)
        entry.pack(fill="x", pady=(0, 18))
        self.tool_controls.append(entry)
        self.tool_stored = self.tk.BooleanVar(value=False)
        stored = self.ttk.Checkbutton(
            builder, text="Store only (no compression)", variable=self.tool_stored
        )
        stored.pack(anchor="w", pady=(0, 16))
        self.tool_controls.append(stored)
        label(
            builder,
            "Uses the main window's compression level. Conflicting root names receive a suffix.",
        )
        self.tool_encrypt = self.tk.BooleanVar(value=False)
        encrypted = self.ttk.Checkbutton(
            builder,
            text="AES-256 password protection (optional pyzipper)",
            variable=self.tool_encrypt,
        )
        encrypted.pack(anchor="w")
        self.tool_controls.append(encrypted)
        button(builder, "Choose new ZIP filename and build...", self.build_combined)
        button(builder, "Unlock selected encrypted ZIP...", self.unlock_zip)

        self.member_label = self.tk.StringVar(
            value="Select one archive in the main queue, then load its entries."
        )
        self.ttk.Label(extraction, textvariable=self.member_label, wraplength=660).pack(
            anchor="w"
        )
        button(extraction, "Load selected archive", self.load_members)
        self.member_search = self.tk.StringVar()
        search = self.ttk.Entry(extraction, textvariable=self.member_search)
        search.pack(fill="x", pady=(0, 8))
        self.tool_controls.append(search)
        table = self.ttk.Frame(extraction)
        table.pack(fill="both", expand=True)
        table.columnconfigure(0, weight=1)
        table.rowconfigure(0, weight=1)
        self.members_tree = self.ttk.Treeview(
            table,
            columns=("name", "size"),
            show="headings",
            selectmode="extended",
            height=7,
        )
        self.members_tree.heading("name", text="Member name (type above to search)")
        self.members_tree.heading("size", text="Bytes")
        self.members_tree.column("name", width=520, minwidth=240)
        self.members_tree.column("size", width=100, minwidth=60)
        self.members_tree.grid(row=0, column=0, sticky="nsew")
        scroll = self.ttk.Scrollbar(table, command=self.members_tree.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        self.members_tree.configure(yscrollcommand=scroll.set)
        self.member_search.trace_add("write", lambda *_args: self.render_members())
        label(
            extraction,
            "Ctrl/Shift selects multiple entries. Selecting a directory includes its contents.\nUp to 1,000 search matches are displayed; search narrows larger archives.",
        )
        button(extraction, "Extract selection to a NEW folder...", self.extract_members)

        label(
            hashes,
            "Select one regular file in the main queue. Calculate SHA-256 or compare it with an expected value.",
        )
        self.expected_hash = self.tk.StringVar()
        label(hashes, "Expected SHA-256 (optional, 64 hexadecimal characters)")
        expected = self.ttk.Entry(hashes, textvariable=self.expected_hash)
        expected.pack(fill="x", pady=(0, 16))
        self.tool_controls.append(expected)
        button(hashes, "Calculate / compare SHA-256", self.hash_selected)
        label(
            hashes,
            "The digest is added to Results. Export Results to keep it. A checksum detects changes; it does not identify the sender of a file.",
        )
        transfers = self.ttk.Frame(tabs, padding=20)
        comparisons = self.ttk.Frame(tabs, padding=20)
        conversion = self.ttk.Frame(tabs, padding=20)
        sessions = self.ttk.Frame(tabs, padding=20)
        for frame, title in (
            (transfers, "Split / join"),
            (comparisons, "Compare"),
            (conversion, "Convert"),
            (sessions, "Queue"),
        ):
            tabs.add(frame, text=title)
        label(
            transfers,
            "Split any selected file into numbered parts for transfer. Rejoin using manifest.json; checksums detect missing or changed parts.",
        )
        label(transfers, "Part size (MiB)")
        self.part_size = self.tk.IntVar(value=100)
        part_size = self.ttk.Spinbox(
            transfers, from_=1, to=4096, textvariable=self.part_size, width=15
        )
        part_size.pack(anchor="w", pady=(0, 12))
        self.tool_controls.append(part_size)
        button(
            transfers, "Split selected file into a NEW folder...", self.split_selected
        )
        button(
            transfers, "Choose manifest and rejoin to a NEW file...", self.join_selected
        )
        label(
            transfers,
            "Parts are ordinary binary chunks, not independently extractable archives. Keep manifest.json and every part together. The main extraction limit also limits rejoining.",
        )
        label(
            comparisons,
            "Compare Gzip, Bzip2, XZ and ZIP on the selected regular file. Uses the current compression level and real full-file data; temporary outputs are deleted.",
        )
        button(comparisons, "Compare compression formats", self.compare_selected)
        label(
            comparisons,
            "Results show final bytes, time, savings and the smallest/fastest format. A large input can take time. Results can be exported from the main window.",
        )
        label(
            conversion,
            "Convert one unencrypted ZIP/TAR archive to another archive format while retaining member paths. Temporary extraction uses disk space and the configured size limit.",
        )
        self.convert_format = self.tk.StringVar(value="zip")
        conversion_box = self.ttk.Combobox(
            conversion,
            textvariable=self.convert_format,
            values=("zip", "tar", "tar-gzip", "tar-bzip2", "tar-xz"),
            state="readonly",
            width=24,
        )
        conversion_box.pack(anchor="w", pady=(0, 12))
        self.tool_controls.append(conversion_box)
        button(
            conversion,
            "Convert selected archive to a NEW file...",
            self.convert_selected,
        )
        label(
            conversion,
            "Conversion uses the current compression level. File contents and empty directories are preserved; original metadata/permissions are not preserved.",
        )
        label(
            sessions,
            "Save the current queue and settings, reload a saved queue, or inspect files and planned output names before starting. Queue files contain paths, not copies of your data.",
        )
        button(sessions, "Save queue session...", self.save_session)
        button(sessions, "Load queue session...", self.load_session)
        button(sessions, "Plan batch without writing output", self.plan_queue)
        button(
            sessions, "Analyze queue files, folders and total size", self.analyze_queue
        )
        button(sessions, "Sort queue by name", self.sort_queue)
        # Give the member list the flexible space; keep action buttons visible.
        children = extraction.winfo_children()
        for widget in children:
            widget.pack_forget()
        extraction.columnconfigure(0, weight=1)
        extraction.rowconfigure(3, weight=1)
        for row, widget in enumerate(children):
            widget.grid(
                row=row,
                column=0,
                sticky="nsew" if row == 3 else ("w" if row in (1, 5) else "ew"),
                pady=5,
            )
        footer = self.ttk.Frame(window, padding=(18, 0, 18, 18))
        footer.grid(row=1, column=0, sticky="ew")
        self.tools_cancel = self.ttk.Button(
            footer,
            text="Cancel current operation",
            command=self.cancel,
            state="disabled",
        )
        self.tools_cancel.pack(anchor="w", pady=(0, 8))
        self.ttk.Label(footer, textvariable=self.status, wraplength=700).pack(
            anchor="w"
        )
        self.update_controls()

    def close_tools(self):
        if self.busy:
            self.status.set("Cancel and wait for cleanup before closing More Tools.")
            return
        self.tool_controls.clear()
        if self.tools_window is not None:
            self.tools_window.destroy()
        self.tools_window = None

    def selected_input(self):
        selected = self.tree.selection()
        if len(selected) != 1:
            raise ValueError("Select exactly one file in the main queue.")
        return self.inputs[int(selected[0])]

    def tool_limit(self):
        value = self.limit.get()
        if not 0 <= value < float("inf"):
            raise ValueError("Use a finite, nonnegative extraction limit.")
        return int(value * 1024**3)

    def run_tool(self, function):
        if self.busy:
            return

        self.status.set("Processing tool operation...")
        self.begin(function, result_kind="tool")

    def build_combined(self):
        from tkinter import filedialog

        if self.busy:
            return
        try:
            selected = self.tree.selection()
            inputs = (
                [self.inputs[int(index)] for index in selected]
                if self.tool_scope_value.get() == "Selected queue items"
                else list(self.inputs)
            )
            if not inputs:
                raise ValueError("Add/select items in the main queue first.")
            level = self.level.get()
            if not 0 <= level <= 9:
                raise ValueError("Use a compression level from 0–9.")
            patterns = tuple(
                value.strip()
                for value in self.tool_excludes.get().split(",")
                if value.strip()
            )
            stored = self.tool_stored.get()
            password = None
            if self.tool_encrypt.get():
                from runtime_tools import aes_zip_class
                from tkinter import simpledialog

                aes_zip_class()
                password = simpledialog.askstring(
                    "ZIP password",
                    "Password (not saved):",
                    show="*",
                    parent=self.tools_window,
                )
                if not password:
                    return
                confirmation = simpledialog.askstring(
                    "Confirm password",
                    "Repeat password:",
                    show="*",
                    parent=self.tools_window,
                )
                if password != confirmation:
                    raise ValueError("Passwords do not match.")
            output = filedialog.asksaveasfilename(
                parent=self.tools_window,
                title="Choose a NEW ZIP filename",
                initialdir=self.output_directory.get(),
                initialfile="combined.zip",
                defaultextension=".zip",
                confirmoverwrite=False,
            )
            if not output:
                return
        except Exception as error:
            self.status.set(f"Error: {error}")
            return

        def build():
            stats = create_zip(
                inputs,
                Path(output),
                level,
                patterns,
                stored,
                self.cancel_event,
                self.publish_progress,
                password=password,
            )
            return (f"Combined ZIP: {output}\n" + stats.report(), Path(output))

        self.run_tool(build)

    def unlock_zip(self):
        from tkinter import filedialog, simpledialog
        from runtime_tools import aes_zip_class

        if self.busy:
            return
        try:
            aes_zip_class()
            source = self.selected_input()
            password = simpledialog.askstring(
                "Unlock ZIP",
                "Archive password (not saved):",
                show="*",
                parent=self.tools_window,
            )
            if not password:
                return
            output = filedialog.asksaveasfilename(
                parent=self.tools_window,
                title="Choose a NEW extraction folder",
                confirmoverwrite=False,
            )
            if not output:
                return
            limit = self.tool_limit()
        except Exception as error:
            self.status.set(f"Error: {error}")
            return

        def unlock():
            stats = process_file(
                source,
                output,
                True,
                format="zip",
                password=password,
                cancel=self.cancel_event,
                progress=self.publish_progress,
                max_output=limit,
            )
            return ("Unlocked ZIP: " + stats.report(), Path(output))

        self.run_tool(unlock)

    def load_members(self):
        if self.busy:
            return
        try:
            source, limit = self.selected_input(), self.tool_limit()
        except Exception as error:
            self.status.set(f"Error: {error}")
            return

        self.status.set("Reading member list...")
        self.begin(
            lambda: (source, list_members(source, self.cancel_event, limit)),
            result_kind="members",
        )

    def render_members(self):
        if self.tools_window is None:
            return
        self.members_tree.delete(*self.members_tree.get_children())
        query, shown = self.member_search.get().casefold(), 0
        for index, member in enumerate(self.member_records):
            if query in member.name.casefold():
                self.members_tree.insert(
                    "", "end", iid=str(index), values=(member.name, f"{member.size:,}")
                )
                shown += 1
                if shown >= 1000:
                    break

    def extract_members(self):
        from tkinter import filedialog

        if self.busy:
            return
        try:
            names = [
                self.member_records[int(index)].name
                for index in self.members_tree.selection()
            ]
            if not names or self.member_source is None:
                raise ValueError("Load an archive and select entries first.")
            source, limit = self.member_source, self.tool_limit()
            output = filedialog.asksaveasfilename(
                parent=self.tools_window,
                title="Name a NEW extraction folder",
                initialdir=self.output_directory.get(),
                initialfile="selected files",
                confirmoverwrite=False,
            )
            if not output:
                return
        except Exception as error:
            self.status.set(f"Error: {error}")
            return

        def extract():
            stats = extract_selected(
                source,
                Path(output),
                names,
                self.cancel_event,
                self.publish_progress,
                limit,
            )
            return (f"Selected extraction: {output}\n" + stats.report(), Path(output))

        self.run_tool(extract)

    def hash_selected(self):
        if self.busy:
            return
        try:
            source = self.selected_input()
            expected = self.expected_hash.get().strip() or None
        except Exception as error:
            self.status.set(f"Error: {error}")
            return

        def calculate():
            digest, match = sha256_file(
                source, expected, self.cancel_event, self.publish_progress
            )
            message = f"SHA-256: {source.name}\n{digest}"
            if match is not None:
                message += (
                    "\nMATCH"
                    if match
                    else "\nMISMATCH — the file differs from the expected digest."
                )
            return (message, None)

        self.run_tool(calculate)

    def split_selected(self):
        from tkinter import filedialog

        if self.busy:
            return
        try:
            source, size = self.selected_input(), self.part_size.get() * 1024**2
            if not 1 <= size <= 1024**4:
                raise ValueError("Use a part size from 1 MiB to 1 TiB.")
            output = filedialog.asksaveasfilename(
                parent=self.tools_window,
                title="Choose a NEW parts folder",
                initialfile=source.name + ".parts",
                confirmoverwrite=False,
            )
            if not output:
                return
        except Exception as error:
            self.status.set(f"Error: {error}")
            return

        def split():
            result = split_file(
                source, output, size, self.cancel_event, self.publish_progress
            )
            return (
                f"Split {source.name}: {len(result['parts'])} parts · {result['size']:,} bytes\nSHA-256: {result['sha256']}\nManifest: {output}/manifest.json",
                Path(output),
            )

        self.run_tool(split)

    def join_selected(self):
        from tkinter import filedialog

        if self.busy:
            return
        try:
            manifest = filedialog.askopenfilename(
                parent=self.tools_window,
                title="Choose split-file manifest.json",
                filetypes=[("JSON manifest", "*.json"), ("All files", "*")],
            )
            if not manifest:
                return
            output = filedialog.asksaveasfilename(
                parent=self.tools_window,
                title="Choose a NEW joined filename",
                initialfile="joined.bin",
                confirmoverwrite=False,
            )
            if not output:
                return
            limit = self.tool_limit()
        except Exception as error:
            self.status.set(f"Error: {error}")
            return

        def join():
            stats = join_parts(
                manifest, output, self.cancel_event, self.publish_progress, limit
            )
            return (
                f"Rejoined and SHA-256 verified: {output}\n" + stats.report(),
                Path(output),
            )

        self.run_tool(join)

    def compare_selected(self):
        if self.busy:
            return
        try:
            source, directory, level = (
                self.selected_input(),
                Path(self.output_directory.get()),
                self.level.get(),
            )
        except Exception as error:
            self.status.set(f"Error: {error}")
            return

        def compare():
            rows = benchmark(
                source, directory, level, self.cancel_event, self.publish_progress
            )
            lines = [
                f"Compression comparison: {source.name}",
                "Format      Output bytes       Seconds      Saved",
            ]
            for row in rows:
                saved = (
                    f"{(1 - row['output_size'] / row['input_size']) * 100:.1f}%"
                    if row["input_size"]
                    else "N/A"
                )
                lines.append(
                    f"{row['format']:10} {row['output_size']:12,} {row['elapsed']:13.3f} {saved:>10}"
                )
            lines.append(
                "Smallest: " + min(rows, key=lambda r: r["output_size"])["format"]
            )
            lines.append("Fastest: " + min(rows, key=lambda r: r["elapsed"])["format"])
            return ("\n".join(lines), None)

        self.run_tool(compare)

    def convert_selected(self):
        from tkinter import filedialog

        if self.busy:
            return
        try:
            source, format, level, limit = (
                self.selected_input(),
                self.convert_format.get(),
                self.level.get(),
                self.tool_limit(),
            )
            output = filedialog.asksaveasfilename(
                parent=self.tools_window,
                title="Choose a NEW converted archive",
                initialfile="converted" + EXTENSIONS[format],
                confirmoverwrite=False,
            )
            if not output:
                return
        except Exception as error:
            self.status.set(f"Error: {error}")
            return

        def convert():
            stats = convert_archive(
                source,
                output,
                format,
                level,
                self.cancel_event,
                self.publish_progress,
                limit,
            )
            return (f"Converted archive: {output}\n" + stats.report(), Path(output))

        self.run_tool(convert)

    def current_settings(self):
        return {
            "dark": self.dark,
            "mode": self.mode.get(),
            "format": self.format.get(),
            "level": self.level.get(),
            "preset": self.preset.get(),
            "limit": self.limit.get(),
            "output_directory": self.output_directory.get(),
        }

    def save_session(self):
        from tkinter import filedialog

        if self.busy:
            return
        try:
            path = filedialog.asksaveasfilename(
                parent=self.tools_window,
                title="Save a NEW queue session",
                initialfile="queue.json",
                defaultextension=".json",
                confirmoverwrite=False,
            )
            if path:
                save_queue(path, self.inputs, self.current_settings())
                self.status.set("Queue session saved.")
        except Exception as error:
            self.status.set(f"Error: {error}")

    def load_session(self):
        from tkinter import filedialog

        if self.busy:
            return
        try:
            path = filedialog.askopenfilename(
                parent=self.tools_window,
                title="Load queue session",
                filetypes=[("JSON session", "*.json")],
            )
            if not path:
                return
            inputs, settings = load_queue(path)
            self.mode.set(settings.get("mode", self.mode.get()))
            self.mode_changed()
            for name in ("format", "level", "preset", "limit", "output_directory"):
                if name in settings:
                    getattr(self, name).set(settings[name])
            if self.mode.get() == "compress" and self.format.get() == "auto":
                self.format.set("gzip")
            self.dark = settings.get("dark", self.dark)
            self.inputs = inputs
            self.refresh_queue()
            self.apply_theme()
            self.status.set(
                f"Loaded {len(inputs)} queue items. Check paths and settings before starting."
            )
        except Exception as error:
            self.status.set(f"Error: {error}")

    def plan_queue(self):
        if self.busy or not self.inputs:
            return
        try:
            inputs, settings = list(self.inputs), self.current_settings()
        except Exception as error:
            self.status.set(f"Error: {error}")
            return

        def plan():
            result = plan_batch(
                inputs,
                settings["output_directory"],
                settings["mode"] == "decompress",
                settings["format"],
                settings["level"],
                self.cancel_event,
            )
            total = result["inventory"]
            lines = [
                f"Batch plan · {total['files']:,} files · {total['folders']:,} folders · {total['bytes']:,} input bytes",
                f"Output volume free: {result['output_free_bytes']:,} bytes",
            ]
            lines.extend(
                f"{row['source']} -> {row['output']} [{row['format']}]"
                for row in result["jobs"]
            )
            lines.append(
                "Planning writes no outputs and does not reserve names or predict final sizes."
            )
            return ("\n".join(lines), None)

        self.run_tool(plan)

    def analyze_queue(self):
        if self.busy or not self.inputs:
            return
        inputs = list(self.inputs)

        def analyze():
            result = inventory(inputs, self.cancel_event)
            return (
                f"Queue inventory: {result['files']:,} files · {result['folders']:,} folders · {result['bytes']:,} bytes",
                None,
            )

        self.run_tool(analyze)

    def sort_queue(self):
        if not self.busy:
            self.inputs.sort(key=lambda p: (p.name.casefold(), str(p).casefold()))
            self.refresh_queue()
            self.status.set("Queue sorted by name.")

    def show_compatibility(self):
        if not self.busy:
            self.append_log(
                "\n" + compatibility_report(Path(self.output_directory.get())) + "\n"
            )
            self.tabs.select(0)
            self.status.set(
                "Compatibility report added to Results; use Export to save it."
            )

    def close(self):
        if self.busy:
            self.status.set(
                "Cancel the current operation and wait for cleanup before closing."
            )
        else:
            try:
                save_settings(self.current_settings())
            except Exception as error:
                from tkinter import messagebox

                messagebox.showwarning(
                    "Settings",
                    f"Preferences could not be saved: {error}",
                    parent=self.root,
                )
            self.root.destroy()


def show_startup_error(message: str) -> None:
    """Make failures visible even when pythonw has no stderr console."""
    if os.name == "nt":
        import ctypes

        with suppress(OSError, AttributeError):
            ctypes.windll.user32.MessageBoxW(
                None, message, "Compression utility tool", 0x10
            )
            return
    if sys.stderr is not None:
        print(message, file=sys.stderr)


def launch_gui() -> int:
    root = None
    try:
        import tkinter as tk

        root = tk.Tk()
        drag_enabled = False
        try:
            from tkinterdnd2 import TkinterDnD

            TkinterDnD.require(root)
            drag_enabled = True
        except (ImportError, tk.TclError, RuntimeError):
            pass
        # Unexpected UI callback errors must also be visible without a console.
        root.report_callback_exception = lambda kind, error, _trace: show_startup_error(
            f"{kind.__name__}: {error}"
        )
        app = CompressorApp(root)
        if drag_enabled:
            from tkinterdnd2 import DND_FILES

            for target in (
                app.tree,
                app.empty_state,
                *app.empty_state.winfo_children(),
            ):
                target.drop_target_register(DND_FILES)
                target.dnd_bind(
                    "<<Drop>>",
                    lambda event: app.add_paths(root.tk.splitlist(event.data)),
                )
        root.mainloop()
        return 0
    except ImportError:
        show_startup_error(
            "GUI unavailable. Install Python with Tkinter/Tcl-Tk support."
        )
        return 1
    except Exception as error:
        show_startup_error(
            f"Could not open Compression utility tool:\n{type(error).__name__}: {error}"
        )
        return 1
    finally:
        if root is not None:
            with suppress(Exception):
                root.destroy()


def main(argv=None) -> int:
    arguments = list(sys.argv[1:] if argv is None else argv)
    if not arguments or arguments == ["--gui"]:
        return launch_gui()
    if arguments == ["--compatibility"]:
        print(compatibility_report())
        return 0
    if arguments and arguments[0] in {
        "split",
        "join",
        "compare",
        "convert",
        "inventory",
        "plan",
    }:
        return file_tools_cli(arguments)
    if arguments and arguments[0] in {"combine", "extract", "hash", "batch"}:
        return advanced_cli(arguments)
    parser = argparse.ArgumentParser(
        description="Compress or restore ZIP, TAR, Gzip, Bzip2 and XZ archives.",
        epilog="Run without arguments (or --gui) for the GUI; --compatibility prints system checks. Commands: combine, extract, hash, batch, split, join, compare, convert, inventory, plan (use COMMAND --help).",
    )
    parser.add_argument("-i", "--input", type=Path, required=True)
    parser.add_argument("-o", "--output", type=Path, required=True)
    parser.add_argument("-d", "--decompress", action="store_true")
    parser.add_argument("-f", "--format", choices=("auto", *EXTENSIONS), default="auto")
    parser.add_argument("-l", "--level", type=int, choices=range(10), default=6)
    parser.add_argument(
        "--max-output-gib",
        type=float,
        default=20,
        help="Decompression size limit in GiB; 0 disables it (default 20)",
    )
    args = parser.parse_args(arguments)
    try:
        if not 0 <= args.max_output_gib < float("inf"):
            parser.error("--max-output-gib must be finite and nonnegative")
        print(
            process_file(
                args.input,
                args.output,
                args.decompress,
                format=args.format,
                level=args.level,
                max_output=int(args.max_output_gib * 1024**3),
            ).report()
        )
        return 0
    except PROCESS_ERRORS as error:
        print(f"Error: {error}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main())
