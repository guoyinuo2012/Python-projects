"""Streaming archive engine: no GUI dependencies or side effects at import."""

from __future__ import annotations

from contextlib import suppress, nullcontext
from dataclasses import dataclass
import bz2
import errno
import gzip
import lzma
import os
from pathlib import Path
import shutil
import stat
import tarfile
import tempfile
import time
import zipfile
import zlib

BUFFER_SIZE = 128 * 1024
PROCESS_ERRORS = (
    OSError,
    EOFError,
    zlib.error,
    lzma.LZMAError,
    zipfile.BadZipFile,
    tarfile.TarError,
    ValueError,
    RuntimeError,
    NotImplementedError,
)
EXTENSIONS = {
    "gzip": ".gz",
    "bzip2": ".bz2",
    "xz": ".xz",
    "zip": ".zip",
    "tar": ".tar",
    "tar-gzip": ".tar.gz",
    "tar-bzip2": ".tar.bz2",
    "tar-xz": ".tar.xz",
}
TAR_FORMATS = {"tar", "tar-gzip", "tar-bzip2", "tar-xz"}
ARCHIVE_FORMATS = {"zip", *TAR_FORMATS}
DEFAULT_LIMIT = 20 * 1024**3


@dataclass(frozen=True)
class Stats:
    input_size: int
    output_size: int
    elapsed: float
    decompress: bool
    format: str = "gzip"
    files: int = 1
    partial: bool = False

    def report(self) -> str:
        original, compressed = (
            (self.output_size, self.input_size)
            if self.decompress
            else (self.input_size, self.output_size)
        )
        lines = [
            f"Format: {self.format.upper()} · Files: {self.files}",
            f"Elapsed: {self.elapsed * 1000:.3f} ms",
            f"Input file size: {self.input_size:,} bytes",
            f"Final file size: {self.output_size:,} bytes",
            f"Original (uncompressed): {original:,} bytes",
        ]
        if self.partial:
            lines.append("Selective extraction: ratio is not applicable.")
        elif original:
            ratio = compressed / original * 100
            lines.extend(
                [
                    f"Compression ratio (compressed/original): {ratio:.2f}%",
                    f"Space saved: {100 - ratio:.2f}%",
                ]
            )
        else:
            lines.append("Compression ratio: N/A (empty original)")
        return "\n".join(lines)


class CancelledError(OSError):
    pass


def check_cancel(cancel):
    if cancel is not None and cancel.is_set():
        raise CancelledError("Cancelled. No completed output was published.")


def copy_stream(source, destination, cancel=None, progress=None, limit=0):
    copied = 0
    while True:
        check_cancel(cancel)
        chunk = source.read(BUFFER_SIZE)
        if not chunk:
            break
        copied += len(chunk)
        if limit and copied > limit:
            raise OSError("Decompressed output exceeds the configured size limit.")
        destination.write(chunk)
        if cancel is not None and hasattr(cancel, "record_bytes"):
            cancel.record_bytes(len(chunk))
        if progress:
            progress(copied)
    check_cancel(cancel)
    return copied


def publish_file(temporary, output, cancel=None):
    """Prefer no-overwrite hard links; support FAT/exFAT through exclusive copy."""
    try:
        os.link(temporary, output)
        return
    except OSError as error:
        unsupported = {
            errno.EPERM,
            errno.EACCES,
            errno.EXDEV,
            errno.ENOSYS,
            errno.ENOTSUP,
            errno.EOPNOTSUPP,
        }
        if error.errno not in unsupported and getattr(error, "winerror", None) not in (
            1,
            50,
        ):
            raise
    # The exclusive create prevents overwrite even if a competing output appears.
    # This fallback exposes incomplete output while copying; remove it on failure.
    created = False
    try:
        with Path(output).open("xb", buffering=BUFFER_SIZE) as destination:
            created = True
            with Path(temporary).open("rb", buffering=BUFFER_SIZE) as source:
                copy_stream(source, destination, cancel)
            destination.flush()
            os.fsync(destination.fileno())
    except BaseException:
        if created:
            with suppress(OSError):
                Path(output).unlink()
        raise


def codec_stream(fileobj, format, decompress=False, level=6):
    if format == "tar":
        return nullcontext(fileobj)
    selected = format.removeprefix("tar-")
    if selected == "gzip":
        return gzip.GzipFile(
            filename="",
            fileobj=fileobj,
            mode="rb" if decompress else "wb",
            compresslevel=level,
            mtime=0,
        )
    if selected == "bzip2":
        return bz2.BZ2File(
            fileobj, "rb" if decompress else "wb", compresslevel=max(1, level)
        )
    if selected == "xz":
        return lzma.LZMAFile(
            fileobj, "rb" if decompress else "wb", preset=None if decompress else level
        )
    raise ValueError("Unsupported stream codec.")


def detect_format(path):
    with Path(path).open("rb") as source:
        magic = source.read(6)
    if magic.startswith((b"PK\x03\x04", b"PK\x05\x06")):
        return "zip"
    selected = next(
        (
            format
            for signature, format in [
                (b"\x1f\x8b", "gzip"),
                (b"BZh", "bzip2"),
                (b"\xfd7zXZ\x00", "xz"),
            ]
            if magic.startswith(signature)
        ),
        None,
    )
    # is_tarfile reads the first header, not the entire archive.
    if tarfile.is_tarfile(path):
        return "tar-" + selected if selected else "tar"
    if selected:
        return selected
    raise OSError("Unrecognized archive. Supported: ZIP, TAR, Gzip, Bzip2 and XZ.")


def safe_member_path(filename):
    """Portable relative paths shared by ZIP and TAR extraction."""
    name = filename.rstrip("/")
    parts = name.split("/")
    devices = {"CON", "PRN", "AUX", "NUL"} | {
        f"{prefix}{n}" for prefix in ("COM", "LPT") for n in range(1, 10)
    }
    if any(
        not part
        or part in (".", "..")
        or part != part.rstrip(" .")
        or any(c in part for c in '\\<>:"|?*')
        or any(ord(c) < 32 for c in part)
        or part.split(".")[0].upper() in devices
        for part in parts
    ):
        raise OSError(f"Unsafe or unsupported archive path: {filename!r}")
    return Path(*parts)


def zip_member_path(info, allow_encrypted=False):
    mode = (info.external_attr >> 16) & 0xFFFF
    if mode and stat.S_IFMT(mode) not in (0, stat.S_IFREG, stat.S_IFDIR):
        raise OSError("Archive links and special files are not supported.")
    if info.flag_bits & 1 and not allow_encrypted:
        raise OSError("Encrypted ZIP files are not supported.")
    return safe_member_path(info.filename)


class CheckedReader:
    def __init__(self, reader, cancel, progress):
        self.reader, self.cancel, self.progress, self.copied = (
            reader,
            cancel,
            progress,
            0,
        )

    def read(self, size):
        check_cancel(self.cancel)
        data = self.reader.read(size)
        self.copied += len(data)
        if self.progress:
            self.progress(self.copied)
        return data


def write_tar(source, entries, destination, format, level, cancel, progress, total):
    completed, files = 0, 0
    with codec_stream(destination, format, level=level) as encoded:
        with tarfile.open(
            fileobj=encoded, mode="w|", format=tarfile.PAX_FORMAT
        ) as archive:
            for path in entries:
                check_cancel(cancel)
                info = tarfile.TarInfo(path.relative_to(source.parent).as_posix())
                info.mtime = int(path.stat().st_mtime)
                if path.is_dir():
                    info.type, info.mode = tarfile.DIRTYPE, 0o755
                    archive.addfile(info)
                else:
                    info.size, info.mode = path.stat().st_size, 0o644
                    base = completed

                    def update(amount, base=base):
                        if progress:
                            progress(min(99.0, (base + amount) / max(total, 1) * 100))

                    with path.open("rb", buffering=BUFFER_SIZE) as reader:
                        archive.addfile(info, CheckedReader(reader, cancel, update))
                    completed += info.size
                    files += 1
    return files


def walk_tar(path, format, cancel=None, limit=DEFAULT_LIMIT, on_member=None):
    """Read TAR sequentially and drain the outer codec to validate its trailer."""
    entries, total = 0, 0
    with Path(path).open("rb", buffering=BUFFER_SIZE) as raw:
        with codec_stream(raw, format, True) as decoded:
            with tarfile.open(
                fileobj=CheckedReader(decoded, cancel, None), mode="r|"
            ) as archive:
                for info in archive:
                    check_cancel(cancel)
                    entries += 1
                    if entries > 100_000:
                        raise OSError("TAR exceeds the 100,000-entry limit.")
                    if info.size < 0 or (limit and total + info.size > limit):
                        raise OSError("TAR contents exceed the configured size limit.")
                    reader = archive.extractfile(info) if info.isfile() else None
                    try:
                        if on_member:
                            on_member(info, reader, raw.tell())
                        elif reader:
                            copy_stream(
                                reader,
                                DiscardWriter(),
                                cancel,
                                limit=limit - total if limit else 0,
                            )
                    finally:
                        if reader:
                            reader.close()
                    if info.isfile():
                        total += info.size
            # TAR ends before its padding/trailer; consume the codec through EOF.
            copy_stream(decoded, DiscardWriter(), cancel, limit=16 * 1024 * 1024)
    check_cancel(cancel)
    return entries, total


def selected_matches(name, choices):
    if choices is None:
        return set()
    return {
        choice
        for choice in choices
        if name == choice or (choice.endswith("/") and name.startswith(choice))
    }


def extract_tar(
    source, output, started, format, cancel, progress, max_output, members=None
):
    output.mkdir()
    seen, files, extracted, found = set(), 0, 0, set()
    try:

        def extract(info, reader, position):
            nonlocal files, extracted
            name = info.name
            while name.startswith("./"):
                name = name[2:]
            if info.isdir() and name in ("", "."):
                return
            if not (info.isfile() or info.isdir()) or info.sparse is not None:
                raise OSError("TAR links, sparse and special files are not supported.")
            relative = safe_member_path(name)
            key = relative.as_posix().casefold()
            if key in seen:
                raise OSError("TAR contains duplicate or case-colliding paths.")
            seen.add(key)
            canonical = relative.as_posix() + ("/" if info.isdir() else "")
            matches = selected_matches(canonical, members)
            if members is not None and not matches:
                return
            found.update(matches)
            target = output / relative
            if info.isdir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with target.open("xb", buffering=BUFFER_SIZE) as writer:
                    copied = copy_stream(reader, writer, cancel, limit=info.size + 1)
                    if copied != info.size:
                        raise OSError("Truncated TAR member.")
                    writer.flush()
                    os.fsync(writer.fileno())
                files += 1
                extracted += copied
            if progress:
                progress(min(99.0, position / max(source.stat().st_size, 1) * 100))

        walk_tar(source, format, cancel, max_output, extract)
        if members is not None and found != members:
            raise ValueError("One or more selected archive members were not found.")
    except BaseException:
        shutil.rmtree(output)
        raise
    if progress:
        progress(100.0)
    return Stats(
        source.stat().st_size,
        extracted,
        time.perf_counter() - started,
        True,
        format,
        files,
        members is not None,
    )


def extract_zip(
    source, output, started, cancel, progress, max_output, members=None, password=None
):
    archive_class = zipfile.ZipFile
    if password is not None:
        from runtime_tools import aes_zip_class

        archive_class = aes_zip_class()
    with archive_class(source) as archive:
        if password is not None:
            archive.setpassword(password.encode("utf-8"))
        entries = archive.infolist()
        if len(entries) > 100_000:
            raise OSError("ZIP archive exceeds the 100,000-entry limit.")
        planned, seen = [], set()
        for info in entries:
            check_cancel(cancel)
            relative = zip_member_path(info, allow_encrypted=password is not None)
            key = relative.as_posix().casefold()
            if key in seen:
                raise OSError("ZIP contains duplicate or case-colliding paths.")
            seen.add(key)
            planned.append((info, relative))
        if members is not None:
            filtered, found = [], set()
            for info, relative in planned:
                matches = selected_matches(info.filename, members)
                if matches:
                    filtered.append((info, relative))
                    found.update(matches)
            if found != members:
                raise ValueError("One or more selected archive members were not found.")
            planned = filtered
        total = sum(info.file_size for info, _ in planned)
        if max_output and total > max_output:
            raise OSError("ZIP contents exceed the configured size limit.")
        # Exclusive directory creation protects existing output, including races.
        output.mkdir()
        copied, files = 0, 0
        try:
            for info, relative in planned:
                check_cancel(cancel)
                target = output / relative
                if info.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                base = copied

                def update(amount, base=base):
                    if progress:
                        progress(min(99.0, (base + amount) / max(total, 1) * 100))

                remaining = max_output - copied if max_output else 0
                if max_output and remaining <= 0 and info.file_size:
                    raise OSError(
                        "Decompressed output exceeds the configured size limit."
                    )
                with (
                    archive.open(info) as reader,
                    target.open("xb", buffering=BUFFER_SIZE) as writer,
                ):
                    copied += copy_stream(reader, writer, cancel, update, remaining)
                    writer.flush()
                    os.fsync(writer.fileno())
                files += 1
            check_cancel(cancel)
        except BaseException:
            shutil.rmtree(output)
            raise
    if progress:
        progress(100.0)
    return Stats(
        source.stat().st_size,
        copied,
        time.perf_counter() - started,
        True,
        "zip",
        files,
        members is not None,
    )


def archive_inputs(source, output, cancel):
    if source.is_dir():
        if output.resolve().is_relative_to(source.resolve()):
            raise OSError("Save the archive outside the folder being compressed.")
        entries = [source]

        def walk_error(error):
            raise error

        for directory, folders, files in os.walk(
            source, followlinks=False, onerror=walk_error
        ):
            check_cancel(cancel)
            entries.extend(Path(directory) / name for name in sorted(folders + files))
    else:
        entries = [source]
    for path in entries:
        check_cancel(cancel)
        safe_member_path(path.relative_to(source.parent).as_posix())
        if path.is_symlink() or not (path.is_dir() or path.is_file()):
            raise OSError("Archive input cannot contain symlinks or special files.")
    return entries


def validate_options(level, max_output):
    if type(level) is not int or not 0 <= level <= 9:
        raise ValueError("Level must be an integer from 0–9.")
    if type(max_output) is not int or max_output < 0:
        raise ValueError("Output limit must be a nonnegative integer byte count.")


def process_file(
    input_path: Path,
    output_path: Path,
    decompress: bool = False,
    *,
    format="auto",
    level=6,
    cancel=None,
    progress=None,
    max_output=DEFAULT_LIMIT,
    members=None,
    password=None,
) -> Stats:
    """Stream an archive, support cancellation, and refuse output overwrites."""
    started = time.perf_counter()
    source, output = Path(os.path.abspath(input_path)), Path(output_path)
    check_cancel(cancel)
    if os.path.lexists(output):
        raise FileExistsError("Output already exists; choose a new filename or folder.")
    if members is not None:
        if not decompress or not members or isinstance(members, str):
            raise ValueError("Select at least one member for archive extraction.")
        members = set(members)
        for name in members:
            if not isinstance(name, str):
                raise ValueError("Member names must be strings.")
            safe_member_path(name)
    validate_options(level, max_output)
    format = (
        detect_format(source)
        if decompress and format == "auto"
        else ("gzip" if format == "auto" else format)
    )
    if format not in EXTENSIONS:
        raise ValueError("Unsupported format.")
    if decompress and format == "zip":
        return extract_zip(
            source, output, started, cancel, progress, max_output, members, password
        )
    if decompress and format in TAR_FORMATS:
        return extract_tar(
            source, output, started, format, cancel, progress, max_output, members
        )
    if members is not None:
        raise ValueError("Selective extraction requires ZIP or TAR.")
    if source.is_dir() and (decompress or format not in ARCHIVE_FORMATS):
        raise OSError("Choose ZIP or TAR to compress a folder.")
    if source.is_symlink():
        raise OSError("Symlink inputs are not supported.")
    entries = (
        archive_inputs(source, output, cancel)
        if format in ARCHIVE_FORMATS
        else [source]
    )
    if format not in ARCHIVE_FORMATS and not stat.S_ISREG(source.stat().st_mode):
        raise OSError("Input must be a regular file.")
    original_size = sum(path.stat().st_size for path in entries if path.is_file())
    temporary_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w+b",
            buffering=BUFFER_SIZE,
            delete=False,
            dir=output.parent,
            prefix=".file-compressor-",
            suffix=".tmp",
        ) as destination:
            temporary_path = Path(destination.name)
            files = 1
            if format in TAR_FORMATS:
                files = write_tar(
                    source,
                    entries,
                    destination,
                    format,
                    level,
                    cancel,
                    progress,
                    original_size,
                )
            elif format == "zip":
                completed, files = 0, 0
                with zipfile.ZipFile(
                    destination,
                    "w",
                    zipfile.ZIP_DEFLATED,
                    compresslevel=level,
                    allowZip64=True,
                ) as archive:
                    for path in entries:
                        check_cancel(cancel)
                        name = path.relative_to(source.parent).as_posix()
                        if path.is_dir():
                            archive.writestr(name + "/", b"")
                            continue
                        base = completed

                        def update(amount, base=base):
                            if progress:
                                progress(
                                    min(
                                        99.0,
                                        (base + amount) / max(original_size, 1) * 100,
                                    )
                                )

                        with (
                            path.open("rb", buffering=BUFFER_SIZE) as reader,
                            archive.open(
                                name,
                                "w",
                                force_zip64=path.stat().st_size * 1.05
                                >= zipfile.ZIP64_LIMIT,
                            ) as writer,
                        ):
                            completed += copy_stream(reader, writer, cancel, update)
                        files += 1
            else:
                with source.open("rb", buffering=BUFFER_SIZE) as reader:
                    if (
                        decompress
                        and detect_format(source).removeprefix("tar-") != format
                    ):
                        raise OSError("Selected format does not match the input file.")

                    def update(amount):
                        consumed = reader.tell() if decompress else amount
                        if progress:
                            progress(min(99.0, consumed / max(original_size, 1) * 100))

                    codec = codec_stream(
                        reader if decompress else destination, format, decompress, level
                    )
                    with codec:
                        copy_stream(
                            codec if decompress else reader,
                            destination if decompress else codec,
                            cancel,
                            update,
                            max_output if decompress else 0,
                        )
            check_cancel(cancel)
            destination.flush()
            os.fsync(destination.fileno())
            final_size = os.fstat(destination.fileno()).st_size
        check_cancel(cancel)
        publish_file(temporary_path, output, cancel)
        if progress:
            progress(100.0)
        return Stats(
            original_size,
            final_size,
            time.perf_counter() - started,
            decompress,
            format,
            files,
        )
    finally:
        if temporary_path is not None:
            with suppress(OSError):
                temporary_path.unlink()


def compress_file(input_path: Path, output_path: Path) -> Stats:
    return process_file(input_path, output_path)


def decompress_file(input_path: Path, output_path: Path) -> Stats:
    return process_file(input_path, output_path, decompress=True)


@dataclass(frozen=True)
class Job:
    source: Path
    output: Path
    decompress: bool = False
    format: str = "gzip"
    level: int = 6


@dataclass(frozen=True)
class JobResult:
    job: Job
    status: str
    stats: Stats | None = None
    error: str = ""


def build_jobs(inputs, output_directory, decompress=False, format="gzip", level=6):
    """Choose unique destinations, including collisions across source folders."""
    directory = Path(output_directory)
    if not directory.is_dir():
        raise OSError("Choose an existing output folder.")
    jobs, reserved = [], set()
    for input_path in inputs:
        source = Path(input_path)
        selected = detect_format(source) if decompress and format == "auto" else format
        if selected not in EXTENSIONS:
            raise ValueError("Choose a supported format.")
        if source.is_dir() and (decompress or selected not in ARCHIVE_FORMATS):
            raise OSError("Folders require ZIP or TAR.")
        if not source.exists():
            raise FileNotFoundError(source)
        if decompress:
            suffix = EXTENSIONS[selected]
            base = (
                source.name[: -len(suffix)]
                if source.name.lower().endswith(suffix)
                else source.stem
            )
            name = (base or "restored") + (
                " extracted" if selected in ARCHIVE_FORMATS else ""
            )
        else:
            name = source.name + EXTENSIONS[selected]
        candidate, counter = directory / name, 2
        while candidate.name.casefold() in reserved or os.path.lexists(candidate):
            original = Path(name)
            candidate = directory / f"{original.stem} ({counter}){original.suffix}"
            counter += 1
        reserved.add(candidate.name.casefold())
        jobs.append(Job(source, candidate, decompress, selected, level))
    return jobs


def run_jobs(
    jobs,
    cancel=None,
    progress=None,
    on_result=None,
    on_started=None,
    max_output=DEFAULT_LIMIT,
):
    """Run sequentially, continue after failures, and retain completed outputs."""
    results = []
    for index, job in enumerate(jobs):
        if cancel is not None and cancel.is_set():
            break
        if on_started:
            on_started(index)

        def update(value, index=index):
            if progress:
                progress((index + value / 100) / max(len(jobs), 1) * 100)

        try:
            stats = process_file(
                job.source,
                job.output,
                job.decompress,
                format=job.format,
                level=job.level,
                cancel=cancel,
                progress=update,
                max_output=max_output,
            )
            result = JobResult(job, "Completed", stats)
        except CancelledError as error:
            result = JobResult(job, "Cancelled", error=str(error))
        except Exception as error:
            result = JobResult(job, "Failed", error=str(error) or type(error).__name__)
        results.append(result)
        if on_result:
            on_result(index, result)
        if result.status == "Cancelled":
            break
    return results


class DiscardWriter:
    def write(self, data):
        return len(data)


def inspect_archive(path, verify=False, cancel=None, max_output=DEFAULT_LIMIT):
    """Preview ZIP metadata; optionally stream-check integrity without extracting."""
    path = Path(path)
    selected = detect_format(path)
    lines = [
        f"Archive: {path.name}",
        f"Format: {selected.upper()}",
        f"Compressed size: {path.stat().st_size:,} bytes",
    ]
    if selected in TAR_FORMATS:
        names = []
        if verify:

            def collect(info, reader, _position):
                if len(names) < 500:
                    names.append(f"{info.size:>12,} bytes  {info.name!r}")
                if reader:
                    copy_stream(reader, DiscardWriter(), cancel, limit=max_output)

            entries, size = walk_tar(path, selected, cancel, max_output, collect)
            lines.extend(
                [
                    f"Entries: {entries:,}",
                    f"Uncompressed size: {size:,} bytes",
                    "",
                    *names,
                ]
            )
            lines.append(
                "TAR has no content checksums; structure and any outer codec were checked."
            )
        else:
            with Path(path).open("rb", buffering=BUFFER_SIZE) as raw:
                with codec_stream(raw, selected, True) as decoded:
                    with tarfile.open(
                        fileobj=CheckedReader(decoded, cancel, None), mode="r|"
                    ) as archive:
                        for index, info in enumerate(archive):
                            check_cancel(cancel)
                            if index >= 500:
                                names.append(
                                    "... preview limited to the first 500 entries"
                                )
                                break
                            names.append(f"{info.size:>12,} bytes  {info.name!r}")
            lines.extend(["TAR entries (preview only):", "", *names])
    elif selected == "zip":
        with zipfile.ZipFile(path) as archive:
            entries = archive.infolist()
            if len(entries) > 100_000:
                raise OSError("ZIP exceeds the 100,000-entry limit.")
            lines.extend(
                [
                    f"Entries: {len(entries):,}",
                    f"Uncompressed size: {sum(info.file_size for info in entries):,} bytes",
                    "",
                ]
            )
            for info in entries[:500]:
                check_cancel(cancel)
                lines.append(f"{info.file_size:>12,} bytes  {info.filename!r}")
            if len(entries) > 500:
                lines.append("... preview limited to the first 500 entries")
            if verify:
                copied = 0
                for info in entries:
                    check_cancel(cancel)
                    if info.is_dir():
                        continue
                    if max_output and copied + info.file_size > max_output:
                        raise OSError("Archive exceeds the verification size limit.")
                    with archive.open(info) as reader:
                        copied += copy_stream(
                            reader,
                            DiscardWriter(),
                            cancel,
                            limit=max_output - copied if max_output else 0,
                        )
    elif verify:
        opener = {"gzip": gzip.open, "bzip2": bz2.open, "xz": lzma.open}[selected]
        with opener(path, "rb") as reader:
            size = copy_stream(reader, DiscardWriter(), cancel, limit=max_output)
        lines.append(f"Uncompressed size: {size:,} bytes")
    else:
        lines.append(
            "Single-file archive. Verify to check integrity and original size."
        )
    check_cancel(cancel)
    if verify:
        lines.append("\nIntegrity check passed. No files were extracted.")
    return "\n".join(lines)
